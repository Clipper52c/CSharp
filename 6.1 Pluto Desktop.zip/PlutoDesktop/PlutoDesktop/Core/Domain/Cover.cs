﻿namespace PlutoDesktop.Core.Domain
{
    public class Cover
    {
        public int Id { get; set; }
        public Course Course { get; set; }
    }
}

using PlutoDesktop.Core.Repositories;
using System;

namespace PlutoDesktop.Core
{
    public interface IUnitOfWork : IDisposable
    {
        ICourseRepository Courses { get; }
        IAuthorRepository Authors { get; }
        int Complete();
    }
}
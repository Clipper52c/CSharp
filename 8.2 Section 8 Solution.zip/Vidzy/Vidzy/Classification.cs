﻿namespace Vidzy
{
    public enum Classification : byte
    {
        Silver = 1, 
        Gold = 2,
        Platinum = 3
    }
}
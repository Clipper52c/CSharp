import { UserComponent } from './user/user.component';

export default [
  { path: '', component: UserComponent }
];

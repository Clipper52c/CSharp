export interface Cart {
  id: number;
  products: { productId :number }[];
}

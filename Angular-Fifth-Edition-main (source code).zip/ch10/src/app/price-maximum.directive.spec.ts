import { PriceMaximumDirective } from './price-maximum.directive';

describe('PriceMaximumDirective', () => {
  it('should create an instance', () => {
    const directive = new PriceMaximumDirective();
    expect(directive).toBeTruthy();
  });
});

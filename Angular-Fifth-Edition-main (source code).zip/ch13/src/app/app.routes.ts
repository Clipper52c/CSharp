import { Routes } from '@angular/router';
import { RoutedComponent } from './routed/routed.component';

export const routes: Routes = [
  { path: 'routed', component: RoutedComponent }
];

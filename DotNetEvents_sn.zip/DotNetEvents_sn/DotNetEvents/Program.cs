﻿using System;

namespace DotNetEvents
{
    // Define a class to hold custom event info
    public class CustomEventArgs : EventArgs
    {
        public CustomEventArgs(string message)
        {
            Message = message;
        }

        public string Message { get; set; }
    }

    // Class that publishes an event
    class Publisher
    {

        /// <summary>
        /// 
        /// Pulisher publish an event and raise the event.
        /// However, publish needs a subscriber to catch that raise event.
        /// 
        /// Hence, a connection must exist between a publisher and a subscriber or no one is catching that "throw" event that was raised by the publisher
        /// The publisher checks for this relationship by using the if statement: if (raiseEvent != null)
        /// 
        /// A subscriber can subscribe to an event but decide to not handle it, like many of the pre-defined windows interface events: click button, etc.
        /// 
        /// The publisher also has something to do that necessitate the raising of an event.
        /// 
        /// Think of a delegate as a special function or method that delegates or separates the function-declaration
        /// and function-implementation.
        /// 
        /// The implementation is the job of a subscriber. Like when you drop a button into the form, there is the code behind
        /// that subscribe to the event for you behind the scene.
        /// 
        /// When an event is raised, the act of raising an even launches the command and hence fires the call-back, letting whoever subscribes
        /// to the event know that and event was raised, and notifying (callback) the subscriber to do something.
        /// 
        /// 
        /// this.button1.Click += new System.EventHandler(this.button1_Click);
        /// 
        /// because System.EventHandler is a delegate type: public delegate void EventHandler(object sender, EventArgs e); and the idea
        /// of a delegate is to let other subscribes to it's service.
        /// 
        /// When delegate is in the context of an event, then the notion of Publisher, Subscriber comes into play.
        /// 
        /// we are subscribing to this delegate with the this.button1.click method. 
        /// As an excercise, go to this line:  this.button1.Click += new System.EventHandler(this.button1_Click); try to delete
        /// the end all the way to 1 character prior to the open bracket, then type the open bracket, and you will see
        /// that the EventHandler shows up as a delegate signature behind the scene.
        /// 
        /// this.button1.Click (is an event behind the scene) subscribes to the "EventHandler" which is a delegate and also an Event at the same time.
        /// The handling method is also this.button1_Click
        /// 
        /// In general, to make this event mechanism work, you need the following:
        /// 
        /// 1)  A class that publish the event.
        /// 2). A connection needs to be established between the publisher and the subscriber.
        /// 3). Once the connection is established, the subscriber can handle the event.
        /// 
        /// Note that in general the button click event method has the same function signature as the System.EventHandler delegate,
        /// this is why the "private void button1_Click(object sender, EventArgs e)" method can handle the System.EventHandler, System.EventArgs()
        /// 
        /// 
        /// Note: EventHandler is a generic delegate that can handle any types of TEventArgs
        /// 
        /// Note that when we are talking about delegate in the context of event, we are not talking about any types of
        /// delegate.  We are talking about a specific delegate signature: void EventHandler (object obj, EventArgs e);
        /// 
        /// </summary>


        // Declare the event using EventHandler<T>
        // This is a delegate type.

        // We declare the delegate.  Delegate #1
        public event EventHandler<CustomEventArgs> RaiseCustomEvent;

        public void DoSomething()
        {
            // Write some code that does something useful here
            // then raise the event. You can also raise an event
            // before you execute a block of code.

            // Do something until you fucked it up, then raise the event here.

            OnRaiseCustomEvent(new CustomEventArgs("Event triggered"));
        }

        // Wrap event invocations inside a protected virtual method
        // to allow derived classes to override the event invocation behavior
        protected virtual void OnRaiseCustomEvent(CustomEventArgs e)
        {
            // Make a temporary copy of the event to avoid possibility of
            // a race condition if the last subscriber unsubscribes
            // immediately after the null check and before the event is raised.

            // this is a delegate.  Delegate #2

            EventHandler<CustomEventArgs> raiseEvent = RaiseCustomEvent;

            // Event will be null if there are no subscribers
            if (raiseEvent != null)
            {
                // Format the string to send inside the CustomEventArgs parameter
                e.Message += $" at {DateTime.Now}";

                // Call to raise the event.
                raiseEvent(this, e);
            }
        }
    }

    //Class that subscribes to an event
    class Subscriber
    {
        private readonly string _id;

        public Subscriber(string id, Publisher pub)
        {
            _id = id;

            // Subscribe to the event
            pub.RaiseCustomEvent += HandleCustomEvent;
        }

        // Define what actions to take when the event is raised.
        void HandleCustomEvent(object sender, CustomEventArgs e)
        {
            Console.WriteLine($"{_id} received this message: {e.Message}");
        }
    }

    class Program
    {
        static void Main()
        {
            var pub = new Publisher();
            var sub1 = new Subscriber("sub1", pub);
            var sub2 = new Subscriber("sub2", pub);

            // Call the method that raises the event.
            pub.DoSomething();

            // Keep the console window open
            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
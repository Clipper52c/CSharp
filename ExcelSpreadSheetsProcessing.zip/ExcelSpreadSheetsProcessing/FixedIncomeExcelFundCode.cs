﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PowerPointAutomation.Core.Domain.PerformanceDeck;
using PowerPointAutomation.Core.Repositories;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using PowerPointAutomation.BusinessLogicAlgorithm.Utils;
using System.Data.Entity.Validation;
using PowerPointAutomation.Persistence.UnitOfWork;
using PowerPointAutomation.Core.IUnitOfWork;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    class FixedIncomeExcelFundCode
    {
        private int LastRow;
        private int FirstColumn = 1;
        private int LastColumn = 2;
        private int FirstRow = 1;
        private int iFundCode = 0;
        private string sFundDescription = string.Empty;
        private static FixedIncomeExcelFundCode instance = null;
        private IUnitOfWork _unitOfWork;

        public static FixedIncomeExcelFundCode Init()
        {
            instance = new FixedIncomeExcelFundCode();
            return instance;
        }

        void resetvariables()
        {
            iFundCode = 0;
            sFundDescription = string.Empty;
        }

        public Excel.Workbook Open(Excel.Application excelInstance,
               string fileName, bool readOnly = false,
               bool editable = true, bool updateLinks = true)
        {
            return excelInstance.Workbooks.Open(fileName, updateLinks, readOnly, Editable: editable);
        }

        public void ProcessWorkbook(Excel.Application excel, string file)
        {
            var wkbPerformance = Open(excel, file);

            // load regular performance files
            foreach (Excel.Worksheet sht in wkbPerformance.Sheets)
            {
                if (sht.Name == "One to One Mapping")
                {
                    ProcessWorkSheet(sht);
                }
            }
            excel.EnableAnimations = true;
            wkbPerformance.Close(true);
        }

        public Excel.Worksheet ProcessWorkSheet(Excel.Worksheet sht)
        {
            Logger.Debug("Enter FixedIncomeFundCodeRepository ProcessWorkSheet(): " + sht.Name + " ...");
            resetvariables();
            LastRow = (int)LastRowPerColumn(1, sht);
            Excel.Range rngDataRangeCOM = sht.Range[sht.Cells[FirstRow, FirstColumn], sht.Cells[LastRow, LastColumn]];
            object[,] rngDataRange = (object[,])rngDataRangeCOM.Value;

            for (int i = FirstRow + 1; i < LastRow + 1; i++)
            {
                Logger.Debug("Processing worksheet: " + sht.Name + " - row: " + i);
                FixedIncomeFundCode fixedIncomeFundCodeRecord = new FixedIncomeFundCode();

                #region grab all detail lines in FixedIncome fund code spreadsheet and insert these information into FixedIncomeFund entity
                try
                {
                    _unitOfWork = new UnitOfWork(new PerformanceContext());
                    var fixedIncomeRepository = _unitOfWork.fixedIncomeFundCode;

                    int.TryParse((string)rngDataRange[i, 1]?.ToString(),out iFundCode);
                    sFundDescription = rngDataRange[i, 2]?.ToString();
                    fixedIncomeFundCodeRecord.FundCode = iFundCode;
                    fixedIncomeFundCodeRecord.FundDescription = sFundDescription;
                    fixedIncomeRepository.Add(fixedIncomeFundCodeRecord);
                    _unitOfWork.Complete();
                }
                catch (DbEntityValidationException ex)
                {
                    Logger.Error("Error coming from ProcessWorkSheet routine: " + ex.Message);
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                }
                #endregion
            }
            return sht;
        }

        private int LastRowTotal(Excel.Worksheet wks)
        {
            Excel.Range lastCell = wks.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
            return lastCell.Row;
        }

        private int LastRowPerColumn(int column, Excel.Worksheet wks)
        {
            int lastRow = LastRowTotal(wks);
            while (((wks.Cells[lastRow, column]).Text == "") && (lastRow != 1))
            {
                lastRow--;
            }
            return lastRow;
        }

        public void CloseExcelExe(Excel.Application excel)
        {
            Marshal.ReleaseComObject(excel);
        }
    }
}
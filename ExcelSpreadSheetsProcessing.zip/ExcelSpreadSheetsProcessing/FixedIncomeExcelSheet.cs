﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PowerPointAutomation.Core.Domain.PerformanceDeck;
using PowerPointAutomation.Core.Repositories;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using PowerPointAutomation.BusinessLogicAlgorithm.Utils;
using System.Data.Entity.Validation;
using PowerPointAutomation.Persistence.UnitOfWork;
using PowerPointAutomation.Core.IUnitOfWork;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    class FixedIncomeExcelSheet
    {
        private int LastRow;
        private int FirstColumn = Convert.ToInt16(ConfigurationManager.AppSettings["FirstColumn_FixedIncomeFund"]);
        private int LastColumn = Convert.ToInt16(ConfigurationManager.AppSettings["LastColumn_FixedIncomeFund"]);
        private int FirstRow = Convert.ToInt16(ConfigurationManager.AppSettings["FirstRow_FixedIncomeFund"]);

        // temp variables used to store header data
        private DateTime? _AsOfDate = null;
        private int iFundId = 0;
        private int iFundCode = 0;
        private double dFundAUM = 0;
        private double dStrategyAUM = 0;
        private int iFundNumberOfSecurities = 0;
        private double dFundYieldToMaturity = 0;
        private double dFundTermToMaturity = 0;
        private double dFundCouponYield = 0;
        private double dFundAverageCoupon = 0;
        private double dFundEffectiveDuration = 0;
        private double dFundModifiedDuration = 0;
        private string sFundAverageCreditQuality = string.Empty;
        private int iBenchmarkNumberOfSecurities = 0;
        private double dBenchmarkYieldToMaturity = 0;
        private double dBenchmarkTermToMaturity = 0;
        private double dBenchmarkCouponYield = 0;
        private double dBenchmarkAverageCoupon = 0;
        private double dBenchmarkEffectiveDuration = 0;
        private double dBenchmarkModifiedDuration = 0;
        private string sBenchmarkAverageCreditQuality = string.Empty;
        private double dBeta = 0;
        private double dTrackingError = 0;
        private double dSharpeRatio = 0;
        private double dFundStandardDeviation = 0;
        private double dBenchmarkStandardDeviation = 0;
        private double dBenchmarkSharpeRatio = 0;
        private double dInvestmentGrade = 0;
        private double dCurrent_Yield = 0;

        private static FixedIncomeExcelSheet instance = null;
        private IUnitOfWork _unitOfWork;

        public static FixedIncomeExcelSheet Init()
        {
            instance = new FixedIncomeExcelSheet();
            return instance;
        }

        void resetvariables()
        {
            _AsOfDate = null;
            iFundId = 0;
            iFundCode = 0;
            dFundAUM = 0;
            dStrategyAUM = 0;
            iFundNumberOfSecurities = 0;
            dFundYieldToMaturity = 0;
            dFundTermToMaturity = 0;
            dFundCouponYield = 0;
            dFundAverageCoupon = 0;
            dFundEffectiveDuration = 0;
            dFundModifiedDuration = 0;
            sFundAverageCreditQuality = string.Empty;
            iBenchmarkNumberOfSecurities = 0;
            dBenchmarkYieldToMaturity = 0;
            dBenchmarkTermToMaturity = 0;
            dBenchmarkCouponYield = 0;
            dBenchmarkAverageCoupon = 0;
            dBenchmarkEffectiveDuration = 0;
            dBenchmarkModifiedDuration = 0;
            sBenchmarkAverageCreditQuality = string.Empty;
            dBeta = 0;
            dTrackingError = 0;
            dSharpeRatio = 0;
            dFundStandardDeviation = 0;
            dBenchmarkStandardDeviation = 0;
            dBenchmarkSharpeRatio = 0;
            dInvestmentGrade = 0;
            dCurrent_Yield = 0;
        }

        public void ProcessWorkbook(Excel.Application excel, string file)
        {
            var wkbFixedIncome = SpreadSheetUtils.Open(excel, file);

            // load regular performance files
            foreach (Excel.Worksheet sht in wkbFixedIncome.Sheets)
            {
                if (sht.Name == "FixedIncomeFundReport")
                {
                    ProcessWorkSheet(sht);
                }
            }
            excel.EnableAnimations = true;
            wkbFixedIncome.Close(true);
        }

        public Excel.Worksheet ProcessWorkSheet(Excel.Worksheet sht)
        {
            Logger.Debug("Enter FixedIncomeFundRepository ProcessWorkSheet(): " + sht.Name + " ...");
            resetvariables();
            LastRow = (int)SpreadSheetUtils.LastRowPerColumn(FirstColumn, sht);
            Excel.Range rngDataRangeCOM = sht.Range[sht.Cells[FirstRow, FirstColumn], sht.Cells[LastRow, LastColumn]];
            object[,] rngDataRange = (object[,])rngDataRangeCOM.Value;

            _unitOfWork = new UnitOfWork(new PerformanceContext());

            for (int i = 2; i < LastRow + 1; i++)
            {
                Logger.Debug("Processing worksheet: " + sht.Name + " - row: " + i);
                FixedIncomeFund FixedIncomeRecord = new FixedIncomeFund();

                #region grab all detail lines in FixedIncomefund spreadsheet and insert these information into FixedIncomeFund entity
                try
                {
                    _AsOfDate = string.IsNullOrEmpty(rngDataRange[i, 1].ToString()) ? (DateTime?)null : DateTime.Parse(rngDataRange[i, 1].ToString());
                    int.TryParse((string)rngDataRange[i, 2]?.ToString(),out iFundId);
                    int.TryParse((string)rngDataRange[i, 3]?.ToString(), out iFundCode);
                    double.TryParse((string)rngDataRange[i, 4]?.ToString(), out dFundAUM);
                    double.TryParse((string)rngDataRange[i, 5]?.ToString(), out dStrategyAUM);
                    int.TryParse((string)rngDataRange[i, 6]?.ToString(), out iFundNumberOfSecurities);
                    double.TryParse((string)rngDataRange[i, 7]?.ToString(), out dFundYieldToMaturity);
                    double.TryParse((string)rngDataRange[i, 8]?.ToString(), out dFundTermToMaturity);
                    double.TryParse((string)rngDataRange[i, 9]?.ToString(), out dFundCouponYield);
                    double.TryParse((string)rngDataRange[i, 10]?.ToString(), out dFundAverageCoupon);
                    double.TryParse((string)rngDataRange[i, 11]?.ToString(), out dFundEffectiveDuration);
                    double.TryParse((string)rngDataRange[i, 12]?.ToString(), out dFundModifiedDuration);
                    sFundAverageCreditQuality = rngDataRange[i, 13]?.ToString();
                    int.TryParse((string)rngDataRange[i, 14]?.ToString(), out iBenchmarkNumberOfSecurities);
                    double.TryParse((string)rngDataRange[i, 15]?.ToString(), out dBenchmarkYieldToMaturity);
                    double.TryParse((string)rngDataRange[i, 16]?.ToString(), out dBenchmarkTermToMaturity);
                    double.TryParse((string)rngDataRange[i, 17]?.ToString(), out dBenchmarkCouponYield);
                    double.TryParse((string)rngDataRange[i, 18]?.ToString(),out dBenchmarkAverageCoupon);
                    double.TryParse((string)rngDataRange[i, 19]?.ToString(), out dBenchmarkEffectiveDuration);
                    double.TryParse((string)rngDataRange[i, 20]?.ToString(), out dBenchmarkModifiedDuration);
                    sBenchmarkAverageCreditQuality = rngDataRange[i, 21]?.ToString();
                    double.TryParse(rngDataRange[i, 22]?.ToString(), out dBeta);
                    double.TryParse((string)rngDataRange[i, 23]?.ToString(), out dTrackingError);
                    double.TryParse((string)rngDataRange[i, 24]?.ToString(), out dSharpeRatio);
                    double.TryParse((string)rngDataRange[i, 25]?.ToString(), out dFundStandardDeviation);
                    double.TryParse((string)rngDataRange[i, 26]?.ToString(), out dBenchmarkStandardDeviation);
                    double.TryParse((string)rngDataRange[i, 27]?.ToString(), out dBenchmarkSharpeRatio);
                    double.TryParse((string)rngDataRange[i, 28]?.ToString(), out dInvestmentGrade);
                    double.TryParse((string)rngDataRange[i, 29]?.ToString(), out dCurrent_Yield);
                }
                catch (DbEntityValidationException ex)
                {
                    Logger.Error("Error coming from ProcessWorkSheet routine: " + ex.Message);
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                }
                #endregion

                FixedIncomeFund fixedIncomeRecord = new FixedIncomeFund();
                var fixedIncomeRepository = _unitOfWork.fixedIncomeFund;

                fixedIncomeRecord.WorkbookName = sht.Parent.Name;
                fixedIncomeRecord.WorksheetName = sht.Name;
                fixedIncomeRecord.AsOfDate = _AsOfDate;
                fixedIncomeRecord.FundCode = iFundCode;
                fixedIncomeRecord.AssetUnderManagement = dFundAUM;
                fixedIncomeRecord.StrategyAssetUnderManagement = dStrategyAUM;
                fixedIncomeRecord.FundNumberOfSecurities = iFundNumberOfSecurities;
                fixedIncomeRecord.FundYieldToMaturity = dFundYieldToMaturity;
                fixedIncomeRecord.FundTermToMaturity = dFundTermToMaturity;
                fixedIncomeRecord.FundCouponYield = dFundCouponYield;
                fixedIncomeRecord.FundAverageCoupon = dFundAverageCoupon;
                fixedIncomeRecord.FundEffectiveDuration = dFundEffectiveDuration;
                fixedIncomeRecord.FundModifiedDuration = dFundModifiedDuration;
                fixedIncomeRecord.FundAverageCreditQuality = sFundAverageCreditQuality;
                fixedIncomeRecord.BenchmarkNumberOfSecurities = iBenchmarkNumberOfSecurities;
                fixedIncomeRecord.BenchmarkYieldToMaturity = dBenchmarkYieldToMaturity;
                fixedIncomeRecord.BenchmarkTermToMaturity = dBenchmarkTermToMaturity;
                fixedIncomeRecord.BenchmarkCouponYield = dBenchmarkCouponYield;
                fixedIncomeRecord.BenchmarkAverageCoupon = dBenchmarkAverageCoupon;
                fixedIncomeRecord.BenchmarkEffectiveDuration = dBenchmarkEffectiveDuration;
                fixedIncomeRecord.BenchmarkModificationDuration = dBenchmarkModifiedDuration;
                fixedIncomeRecord.BenchmarkAverageCreditQuality = sBenchmarkAverageCreditQuality;
                fixedIncomeRecord.Beta = dBeta;
                fixedIncomeRecord.TrackingError = dTrackingError;
                fixedIncomeRecord.SharpeRatio = dSharpeRatio;
                fixedIncomeRecord.FundStandardDeviation = dFundStandardDeviation;
                fixedIncomeRecord.BenchmarkStandardDeviation = dBenchmarkStandardDeviation;
                fixedIncomeRecord.BenchmarkSharpeRatio = dBenchmarkSharpeRatio;
                fixedIncomeRecord.InvestmentGrade = dInvestmentGrade;
                fixedIncomeRecord.Current_Yield = dCurrent_Yield;
                fixedIncomeRepository.Add(fixedIncomeRecord);
                _unitOfWork.Complete();
            }
            return sht;
        }
    }
}

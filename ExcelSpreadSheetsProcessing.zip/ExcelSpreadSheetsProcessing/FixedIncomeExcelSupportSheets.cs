﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PowerPointAutomation.Core.Domain.PerformanceDeck;
using PowerPointAutomation.Core.Repositories;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using PowerPointAutomation.BusinessLogicAlgorithm.Utils;
using System.Data.Entity.Validation;
using PowerPointAutomation.Persistence.UnitOfWork;
using PowerPointAutomation.Core.IUnitOfWork;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    class FixedIncomeExcelSupportSheets
    {
        private int LastRow;
        private int FirstColumn = Convert.ToInt16(ConfigurationManager.AppSettings["FirstColumn_FixedIncomeSupportTabs"]);
        private int LastColumn = Convert.ToInt16(ConfigurationManager.AppSettings["LastColumn_FixedIncomeSupportTabs"]);
        private int FirstRow = Convert.ToInt16(ConfigurationManager.AppSettings["FirstRow_FixedIncomeSupportTabs"]);
        private int FundColumn = Convert.ToInt16(ConfigurationManager.AppSettings["FundColumn"]);
        private int BenchMarkColumn = Convert.ToInt16(ConfigurationManager.AppSettings["BenchMarkColumn"]);

        // temp variables used to store header data
        private DateTime? _AsOfDate = null;
        private string sSector = string.Empty;
        private double dFund = 0;
        private double dBenchMark = 0;
        private static FixedIncomeExcelSupportSheets instance = null;
        private IUnitOfWork _unitOfWork;

        public static FixedIncomeExcelSupportSheets Init()
        {
            instance = new FixedIncomeExcelSupportSheets();
            return instance;
        }

        void resetvariables()
        {
            LastRow = 0;

            // temp variables used to store header data
            sSector = string.Empty;
            dFund = 0;
            dBenchMark = 0;
        }

        public void ProcessWorkbook(Excel.Application excel, string file)
        {
            var wkbFixedIncome = SpreadSheetUtils.Open(excel, file);

            // Process relevant fixed income worksheets
            foreach (Excel.Worksheet sht in wkbFixedIncome.Sheets)
            {
                switch (sht.Name)
                {
                    case "SectorMix":
                        ProcessWorkSheet(sht, "SectorMix");
                        break;
                    case "CreditQualityMix":
                        ProcessWorkSheet(sht, "CreditQualityMix");
                        break;
                    case "TermBreakdown":
                        ProcessWorkSheet(sht, "TermBreakdown");
                        break;
                    default:
                        break;
                }
            }
            excel.EnableAnimations = true;
            wkbFixedIncome.Close(true);
        }

        public Excel.Worksheet ProcessWorkSheet(Excel.Worksheet sht, string shtName)
        {
            Logger.Debug("Enter FixedIncomeSectorMixRepository ProcessWorkSheet(): " + sht.Name + " ...");
            resetvariables();

            LastRow = (int) SpreadSheetUtils.LastRowPerColumn(FirstColumn, sht);
            Excel.Range rngDataRangeCOM = sht.Range[sht.Cells[FirstRow, FirstColumn], sht.Cells[LastRow, LastColumn]];
            object[,] rngDataRange = (object[,])rngDataRangeCOM.Value;

            _unitOfWork = new UnitOfWork(new PerformanceContext());

            for (int i = FirstRow + 1; i < LastRow + 1; i++)
            {
                Logger.Debug("Processing worksheet: " + sht.Name + " - row: " + i);
                try
                {
                    _AsOfDate = string.IsNullOrEmpty(rngDataRange[i, 1].ToString()) ? (DateTime?)null : DateTime.Parse(rngDataRange[i, 1].ToString());
                    double.TryParse((string)rngDataRange[i, FundColumn]?.ToString(), out dFund);
                    double.TryParse((string)rngDataRange[i, BenchMarkColumn]?.ToString(), out dBenchMark);
                }
                catch (DbEntityValidationException ex)
                {
                    Logger.Error("Error coming from ProcessWorkSheet routine: " + ex.Message);
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                }

                switch (shtName)
                {
                    case "SectorMix":
                        FixedIncomeSectorMix SectorMixRecord = new FixedIncomeSectorMix();
                        var fixedIncomeRepository = _unitOfWork.fixedIncomeSectorMix;
                        SectorMixRecord.WorkbookName = sht.Parent.Name;
                        SectorMixRecord.WorksheetName = sht.Name;
                        SectorMixRecord.AsOfDate = _AsOfDate;
                        SectorMixRecord.FundCode = Int32.Parse(rngDataRange[i, FirstColumn + 2].ToString());
                        SectorMixRecord.Sector = (string)rngDataRange[i, FirstColumn + 3].ToString();
                        SectorMixRecord.FundWeightBySector = dFund;
                        SectorMixRecord.BenchmarkWeightBySector = dBenchMark;
                        fixedIncomeRepository.Add(SectorMixRecord);
                        break;
                    case "CreditQualityMix":
                        var CreditQualityRecord = new FixedIncomeCreditQualityMix();
                        var CreditQualityRepository = _unitOfWork.fixedIncomeCreditQualityMix;
                        CreditQualityRecord.WorkbookName = sht.Parent.Name;
                        CreditQualityRecord.WorksheetName = sht.Name;
                        CreditQualityRecord.AsOfDate = _AsOfDate;
                        CreditQualityRecord.FundCode = Int32.Parse(rngDataRange[i, FirstColumn + 2].ToString());
                        CreditQualityRecord.Rating = (string)rngDataRange[i, FirstColumn + 3].ToString();
                        CreditQualityRecord.FundWeightByRating = dFund;
                        CreditQualityRecord.BenchmarkWeightByRating = dBenchMark;
                        CreditQualityRepository.Add(CreditQualityRecord);
                        break;
                    case "TermBreakdown":
                        var TermBreakDownRecord = new FixedIncomeTermBreakDown();
                        var TermBreakDownRepository = _unitOfWork.fixedIncomeTermBreakDown;
                        TermBreakDownRecord.WorkbookName = sht.Parent.Name;
                        TermBreakDownRecord.WorksheetName = sht.Name;
                        TermBreakDownRecord.AsOfDate = _AsOfDate;
                        TermBreakDownRecord.FundCode = Int32.Parse(rngDataRange[i, FirstColumn + 2].ToString());
                        TermBreakDownRecord.FundTerm = (string)rngDataRange[i, FirstColumn + 3].ToString();
                        TermBreakDownRecord.FundWeightByTerm = dFund;
                        TermBreakDownRecord.BenchmarkWeightByTerm = dBenchMark;
                        TermBreakDownRepository.Add(TermBreakDownRecord);
                        break;
                    default:
                        break;
                }
                _unitOfWork.Complete();
            }
            return sht;
        }
    }
}

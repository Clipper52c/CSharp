﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PowerPointAutomation.Core.Domain.PerformanceDeck;
using PowerPointAutomation.Core.Repositories;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using PowerPointAutomation.BusinessLogicAlgorithm.Utils;
using System.Data.Entity.Validation;
using PowerPointAutomation.Persistence.UnitOfWork;
using PowerPointAutomation.Core.IUnitOfWork;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    class PerformanceExcelData
    {
        private int LastRow;
        private int FirstColumn = Convert.ToInt16(ConfigurationManager.AppSettings["FirstColumn"]);
        private int LastColumn = Convert.ToInt16(ConfigurationManager.AppSettings["LastColumn"]);
        private int FirstRow = Convert.ToInt16(ConfigurationManager.AppSettings["FirstRow"]);
        private double numValue = 0; double MonthEndMarketValue = 0;
        private DateTime? _inceptiondate = null;
        private DateTime? _benchmarksince = null;

        // temp variables used to store header data
        private string tmpFundNumber = string.Empty;
        private string tmpFundName = string.Empty;
        private string tmpFundName1 = string.Empty;
        private string tmpFundName2 = string.Empty;
        private double stDev1yr = 0;
        private double stDev5yr = 0;
        private double MER = 0;
        private double fundVolatility1yr = 0;
        private double fundVolatility5yr = 0;
        private double benchMarkVolatility1yr = 0;
        private double benchMarkVolatility5yr = 0;
        private double trackingError1yr = 0;
        private double trackingError5yr = 0;
        private string managerName = String.Empty;
        private double informationRatio1Yr = 0;
        private double informationRatio5Yr = 0;
        private double alpha1Yr = 0;
        private double alpha5Yr = 0;
        private double beta1Yr = 0;
        private double beta5Yr = 0;
        private double rSquared1Yr = 0;
        private double rSquared5Yr = 0;
        private double sharpeRatio1Yr = 0;
        private double sharpeRatio5Yr = 0;

        private static PerformanceExcelData instance = null;
        private IUnitOfWork _unitOfWork;

        void resetvariables()
        {
            LastRow = 0;
            numValue = 0;
            MonthEndMarketValue = 0;
            _inceptiondate = null;
            _benchmarksince = null;

            // temp variables used to store header data
            tmpFundNumber = string.Empty;
            tmpFundName = string.Empty;
            tmpFundName1 = string.Empty;
            tmpFundName2 = string.Empty;
            stDev1yr = 0;
            stDev5yr = 0;
            MER = 0;
            fundVolatility1yr = 0;
            fundVolatility5yr = 0;
            benchMarkVolatility1yr = 0;
            benchMarkVolatility5yr = 0;
            trackingError1yr = 0;
            trackingError5yr = 0;
            managerName = String.Empty;
            informationRatio1Yr = 0;
            informationRatio5Yr = 0;
            alpha1Yr = 0;
            alpha5Yr = 0;
            beta1Yr = 0;
            beta5Yr = 0;
            rSquared1Yr = 0;
            rSquared5Yr = 0;
            sharpeRatio1Yr = 0;
            sharpeRatio5Yr = 0;
        }

        public static PerformanceExcelData Init()
        {
            instance = new PerformanceExcelData();
            return instance;
        }

        public Excel.Workbook Open(Excel.Application excelInstance,
               string fileName, bool readOnly = false,
               bool editable = true, bool updateLinks = true)
        {
            return excelInstance.Workbooks.Open(fileName, updateLinks, readOnly, Editable: editable);
        }

        public void ProcessWorkbook(Excel.Application excel, string file)
        {
            var wkbPerformance = Open(excel, file);

            // load regular performance files
            foreach (Excel.Worksheet sht in wkbPerformance.Sheets)
            {
                if (sht.Name != "Risk Statistics Methodology" || sht.Name != "Benchmark History")
                {
                    ProcessWorkSheet(sht);
                }
            }
            excel.EnableAnimations = true;
            wkbPerformance.Close(true);
        }

        public Excel.Worksheet ProcessWorkSheet(Excel.Worksheet sht)
        {
            Logger.Debug("Enter ProcessWorkSheet(): " + sht.Name + " ...");
            resetvariables();
            LastRow = (int)LastRowPerColumn(FirstColumn + 3, sht);
            Excel.Range rngDataRangeCOM = sht.Range[sht.Cells[FirstRow, FirstColumn], sht.Cells[LastRow, LastColumn]];
            object[,] rngDataRange = (object[,])rngDataRangeCOM.Value;

            for (int i = 1; i < (LastRow - FirstRow) + 1; i++)
            {
                Logger.Debug("Processing worksheet: " + sht.Name + " - row: " + i);
                PerformanceRecord PerfRecord = new PerformanceRecord();

                #region Fund Number Group - heading and auxiliary information: 

                //identify heading row: where the Fund number account row showed up
                if (rngDataRange[i, 3] != null && RegexHelper.RegexFound(@"([0-9]+.$|.[0-9]+)", rngDataRange[i, 3]))
                {
                    #region grab header line in a performance Excel sheet
                    tmpFundNumber = rngDataRange[i, 3].ToString();
                    tmpFundName = rngDataRange[i, 4].ToString();
                    tmpFundName = Regex.Replace(tmpFundName, @"\s +", " ");  // get rid of extra space between words, if any.

                    tmpFundName1 = rngDataRange[i, 4].ToString();
                    tmpFundName1 = Regex.Replace(tmpFundName1, @"-", " ");
                    tmpFundName1 = Regex.Replace(tmpFundName1, @"\s +", " ");
                    tmpFundName2 = tmpFundName1 + "FundNameTitleLine";
          
                    if (rngDataRange[i, 5] != null) // inception date
                    {
                        _inceptiondate = string.IsNullOrEmpty(rngDataRange[i, 5].ToString()) ? (DateTime?)null : DateTime.Parse(rngDataRange[i, 5].ToString());
                        PerfRecord.InceptionDate = _inceptiondate;
                    }
                    if (rngDataRange[i, 6] != null) // monthend value
                    {
                        double.TryParse((string)rngDataRange[i, 6].ToString(), out MonthEndMarketValue);
                        PerfRecord.MonthEndMarketValue = MonthEndMarketValue;
                    }
                    #endregion
                    #region grab other auxiliary information in the group (not in O-series) and store these information in temp variables
                    int tmpRow = i + 1;
                    while (rngDataRange[tmpRow, 3] == null && tmpRow < (LastRow - FirstRow))
                    {
                        if (rngDataRange[tmpRow, 6] != null && rngDataRange[tmpRow, 6].ToString().Contains("Std Dev of Rolling"))
                        {
                            if (rngDataRange[tmpRow, 7] != null)
                            {
                                double.TryParse(RegexHelper.value(@"\+/-\s*(\d*.\d*)", rngDataRange[tmpRow, 7], 1), out stDev1yr);
                                double.TryParse(RegexHelper.value(@"\+/-\s*(\d*.\d*)", rngDataRange[tmpRow, 8], 1), out stDev5yr);
                            }
                        }
                        string tmp;
                        if (rngDataRange[tmpRow, 4] != null && rngDataRange[tmpRow, 4].ToString().Contains("Benchmark"))
                        {
                            tmp = RegexHelper.value(@"(\d{2}\/\d{2}\/\d{4}$)", rngDataRange[tmpRow, 4], 1);
                            _benchmarksince = string.IsNullOrEmpty(tmp) ? (DateTime?)null : DateTime.Parse(tmp);
                        }
                        if (rngDataRange[tmpRow, 8] != null && rngDataRange[tmpRow, 8].ToString().Contains("Fund"))
                        {
                            double.TryParse(RegexHelper.value(@"(\d *.\d+$)", rngDataRange[tmpRow, 4], 1), out MER);
                            double.TryParse(RegexHelper.value(@"(Fund\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 8], 2), out fundVolatility1yr);
                            double.TryParse(RegexHelper.value(@"(Fund\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 8], 3),out fundVolatility5yr);
                            double.TryParse(RegexHelper.value(@"(Benchmark\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 12], 2), out benchMarkVolatility1yr);
                            double.TryParse(RegexHelper.value(@"(Benchmark\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 12], 3), out benchMarkVolatility5yr);
                            double.TryParse(RegexHelper.value(@"(Tracking\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 15], 2), out trackingError1yr);
                            double.TryParse(RegexHelper.value(@"(Tracking\s*\w+:)\s+(\-*\d*.\d+)%\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 15], 3), out trackingError5yr);
                        }
                        if (rngDataRange[tmpRow, 4] != null && rngDataRange[tmpRow, 4].ToString().Contains("Manager"))
                        {
                            managerName = RegexHelper.value(@"([\'*\s*]Manager:)\s*(\w+\s\w+)", rngDataRange[tmpRow, 4], 2);
                            if (rngDataRange[tmpRow, 5] != null && rngDataRange[tmpRow, 5].ToString().Contains("Information Ratio"))
                            {
                                double.TryParse(RegexHelper.value(@"(^Information Ratio:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 5], 2), out informationRatio1Yr);
                                double.TryParse(RegexHelper.value(@"(^Information Ratio:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 5], 3), out informationRatio5Yr);
                                double.TryParse(RegexHelper.value(@"(Alpha:)\s+(\-*\d*.\d+)%*\s*\/\s*(\-*\d*.\d+)%*", rngDataRange[tmpRow, 8], 2), out alpha1Yr);
                                double.TryParse(RegexHelper.value(@"(Alpha:)\s+(\-*\d*.\d+)%*\s*\/\s*(\-*\d*.\d+)%*", rngDataRange[tmpRow, 8], 3), out alpha5Yr);
                                double.TryParse(RegexHelper.value(@"(^Beta:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 12], 2), out beta1Yr);
                                double.TryParse(RegexHelper.value(@"(^Beta:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 12], 3), out beta5Yr);
                                double.TryParse(RegexHelper.value(@"(^R squared:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 15], 2), out rSquared1Yr);
                                double.TryParse(RegexHelper.value(@"(^R squared:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 15], 3), out rSquared5Yr);
                                double.TryParse(RegexHelper.value(@"(^Sharpe Ratio:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 19], 2), out sharpeRatio1Yr);
                                double.TryParse(RegexHelper.value(@"(^Sharpe Ratio:)\s+(\-*\d*.\d+)\s*\/\s*(\-*\d*.\d+)", rngDataRange[tmpRow, 19], 3), out sharpeRatio5Yr);
                            }
                        }
                        tmpRow++;
                    }
                    #endregion
                }
                else
                {
                    tmpFundName2 = tmpFundName1;
                }
                #endregion

                #region grab all detail lines in performance record spreadsheet and insert these information into performance entity
                try
                {
                    _unitOfWork = new UnitOfWork(new PerformanceContext());
                    if (rngDataRange[i, 4] != null && rngDataRange[i, 7] != null)
                    {
                        var PerformanceRepository = _unitOfWork.performance;
                        var cellvalue = rngDataRange[i, 4] ?? DateTime.Now.ToString();
                        PerfRecord.WorkbookName = sht.Parent.Name;
                        PerfRecord.WorksheetName = sht.Name;
                        PerfRecord.FundNumber = tmpFundNumber;
                        PerfRecord.FundName = tmpFundName;
                        PerfRecord.FundName1 = tmpFundName2;
                        PerfRecord.BenchMark = rngDataRange[i, 4].ToString().Trim();
                        PerfRecord.MonthEndMarketValue = MonthEndMarketValue;
                        PerfRecord.FundVolatility1Yr = fundVolatility1yr / 100;
                        PerfRecord.FundVolatility5YrSI = fundVolatility5yr / 100;
                        PerfRecord.StdDev1Yr = stDev1yr / 100;
                        PerfRecord.StdDev5YrSI = stDev5yr / 100;
                        PerfRecord.BenchmarkVolatility1Yr = benchMarkVolatility1yr / 100;
                        PerfRecord.BenchmarkVolatility5YrSI = benchMarkVolatility5yr / 100;
                        PerfRecord.TrackingError1Yr = trackingError1yr / 100;
                        PerfRecord.TrackingError5YrSI = trackingError5yr / 100;
                        PerfRecord.InformationRatio1Yr = informationRatio1Yr / 100;
                        PerfRecord.InformationRatio5YrSI = informationRatio5Yr / 100;
                        PerfRecord.Alpha1Yr = alpha1Yr / 100;
                        PerfRecord.Alpha5YrSI = alpha5Yr / 100;
                        PerfRecord.Beta1Yr = beta1Yr / 100;
                        PerfRecord.Beta5YrSI = beta5Yr / 100;
                        PerfRecord.RSquared1Yr = rSquared1Yr / 100;
                        PerfRecord.RSquared5YrSI = rSquared5Yr / 100;
                        PerfRecord.SharpeRatio1Yr = sharpeRatio1Yr / 100;
                        PerfRecord.SharpeRatio5YrSI = sharpeRatio5Yr / 100;
                        PerfRecord.ManagerName = managerName;
                        PerfRecord.MER = MER;

                        double.TryParse((string)rngDataRange[i, 1]?.ToString(), out numValue); PerfRecord.BenchMarkCode = rngDataRange[i, 1].ToString().Trim();
                        double.TryParse((string)rngDataRange[i, 7]?.ToString(), out numValue); PerfRecord._1Month = numValue;
                        double.TryParse((string)rngDataRange[i, 8]?.ToString(), out numValue); PerfRecord._3Month = numValue;
                        double.TryParse((string)rngDataRange[i, 9]?.ToString(), out numValue); PerfRecord._6Month = numValue;
                        double.TryParse((string)rngDataRange[i, 10]?.ToString(), out numValue); PerfRecord.YTDMonth = numValue;
                        double.TryParse((string)rngDataRange[i, 11]?.ToString(), out numValue); PerfRecord._1Year = numValue;
                        double.TryParse((string)rngDataRange[i, 12]?.ToString(), out numValue); PerfRecord._2Year = numValue;
                        double.TryParse((string)rngDataRange[i, 13]?.ToString(), out numValue); PerfRecord._3Year = numValue;
                        double.TryParse((string)rngDataRange[i, 14]?.ToString(), out numValue); PerfRecord._4Year = numValue;
                        double.TryParse((string)rngDataRange[i, 15]?.ToString(), out numValue); PerfRecord._5Year = numValue;
                        double.TryParse((string)rngDataRange[i, 16]?.ToString(), out numValue); PerfRecord._10Year = numValue;
                        double.TryParse((string)rngDataRange[i, 17]?.ToString(), out numValue); PerfRecord.SI = numValue;
                        double.TryParse((string)rngDataRange[i, 18]?.ToString(), out numValue); PerfRecord._2020 = numValue;
                        double.TryParse((string)rngDataRange[i, 19]?.ToString(), out numValue); PerfRecord._2019 = numValue;
                        double.TryParse((string)rngDataRange[i, 20]?.ToString(), out numValue); PerfRecord._2018 = numValue;
                        double.TryParse((string)rngDataRange[i, 21]?.ToString(), out numValue); PerfRecord._2017 = numValue;
                        PerfRecord.InceptionDate = _inceptiondate;
                        PerfRecord.BenchMarkSince = _benchmarksince;
                        PerformanceRepository.Add(PerfRecord);
                        _unitOfWork.Complete();
                    }
                }
                catch (DbEntityValidationException ex)
                {
                    Logger.Error("Error coming from ProcessWorkSheet routine: " + ex.Message);
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                }
                #endregion
            }
            return sht;
        }

        private int LastRowTotal(Excel.Worksheet wks)
        {
            Excel.Range lastCell = wks.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
            return lastCell.Row;
        }

        private int LastRowPerColumn(int column, Excel.Worksheet wks)
        {
            int lastRow = LastRowTotal(wks);
            while (((wks.Cells[lastRow, column]).Text == "") && (lastRow != 1))
            {
                lastRow--;
            }
            return lastRow;
        }

        public void CloseExcelExe(Excel.Application excel)
        {
            Marshal.ReleaseComObject(excel);
        }
    }
}

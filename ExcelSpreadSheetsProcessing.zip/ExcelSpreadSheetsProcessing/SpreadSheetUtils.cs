﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    internal static class SpreadSheetUtils
    {
        public static Excel.Workbook Open(Excel.Application excelInstance,
                                          string fileName, bool readOnly = false,
                                          bool editable = true, bool updateLinks = true)
        {
            return excelInstance.Workbooks.Open(fileName, updateLinks, readOnly, Editable: editable);
        }

        public static int LastRowTotal(Excel.Worksheet wks)
        {
            Excel.Range lastCell = wks.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
            return lastCell.Row;
        }

        public static int LastRowPerColumn(int column, Excel.Worksheet wks)
        {
            int lastRow = LastRowTotal(wks);
            while (((wks.Cells[lastRow, column]).Text == "") && (lastRow != 1))
            {
                lastRow--;
            }
            return lastRow;
        }

        public static void CloseExcelExe(Excel.Application excel)
        {
            Marshal.ReleaseComObject(excel);
        }
    }
}

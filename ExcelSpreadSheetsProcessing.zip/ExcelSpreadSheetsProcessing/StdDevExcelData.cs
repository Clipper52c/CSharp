﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PowerPointAutomation.Core.Domain.PerformanceDeck;
using PowerPointAutomation.Core.Repositories;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using PowerPointAutomation.BusinessLogicAlgorithm.Utils;
using System.Data.Entity.Validation;
using System.Linq.Expressions;
using PowerPointAutomation.Persistence.UnitOfWork;
using PowerPointAutomation.Core.IUnitOfWork;

namespace PowerPointAutomation.BusinessLogicAlgorithm.ExcelSpreadSheetsProcessing
{
    class StdDevExcelData
    {
        private int LastRow;
        private int FirstColumn = Convert.ToInt16(ConfigurationManager.AppSettings["FirstColumn_Stdev"]);
        private int LastColumn = Convert.ToInt16(ConfigurationManager.AppSettings["LastColumn_Stdev"]);
        private int FirstRow = Convert.ToInt16(ConfigurationManager.AppSettings["FirstRow_Stdev"]);
        private int StdevColumn = Convert.ToInt16(ConfigurationManager.AppSettings["_10YearStandardDeviationColumn"]);
        private int BenchMarkColumn = Convert.ToInt16(ConfigurationManager.AppSettings["_10YearStandardDeviationBenchMarkColumn"]);

        // temp variables used to store header data
        private double tmpStdev = 0;
        private double tmpBenchMark = 0;

        private static StdDevExcelData instance = null;
        private IUnitOfWork _unitOfWork;

        void resetvariables()
        {
            LastRow = 0;

            // temp variables used to store header data
            tmpStdev = 0;
            tmpBenchMark = 0;
        }

        public static StdDevExcelData Init()
        {
            instance = new StdDevExcelData();
            return instance;
        }

        public Excel.Workbook Open(Excel.Application excelInstance,
               string fileName, bool readOnly = false,
               bool editable = true, bool updateLinks = true)
        {
            return excelInstance.Workbooks.Open(fileName, updateLinks, readOnly, Editable: editable);
        }

        public void ProcessWorkbook(Excel.Application excel, string file)
        {
            var wkbPerformance = Open(excel, file);

            // load regular performance files
            foreach (Excel.Worksheet sht in wkbPerformance.Sheets)
            {
                if (sht.Name != "Risk Statistics Methodology" || sht.Name != "Benchmark History")
                {
                    ProcessWorkSheet(sht);
                }
            }
            excel.EnableAnimations = true;
            wkbPerformance.Close(true);
        }


        public Excel.Worksheet ProcessWorkSheet(Excel.Worksheet sht)
        {
            Logger.Debug("Enter PerformanceStdevRepository ProcessWorkSheet(): " + sht.Name + " ...");
            resetvariables();
            LastRow = (int)LastRowPerColumn(FirstColumn, sht);
            Excel.Range rngDataRangeCOM = sht.Range[sht.Cells[FirstRow, FirstColumn], sht.Cells[LastRow, LastColumn]];
            object[,] rngDataRange = (object[,])rngDataRangeCOM.Value;

            for (int i = FirstRow - 4; i < LastRow + 1 - 4; i++)
            {
                Logger.Debug("Processing worksheet: " + sht.Name + " - row: " + i);
                PerformanceStdev StdevRecord = new PerformanceStdev();

                #region grab all detail lines in 10 year standard deviation spreadsheet and insert these information into standard deviation entity
                try
                {
                    _unitOfWork = new UnitOfWork(new PerformanceContext());
                    var StdevRepository = _unitOfWork.performanceStdev;

                    double.TryParse((string)rngDataRange[i, StdevColumn - 1]?.ToString(), out tmpStdev);
                    double.TryParse((string)rngDataRange[i, BenchMarkColumn - 1]?.ToString(), out tmpBenchMark);

                    StdevRecord.WorkbookName = sht.Parent.Name;
                    StdevRecord.WorksheetName = sht.Name;
                    StdevRecord.FundName = (string)rngDataRange[i, FirstColumn - 1];
                    StdevRecord.Stdev = tmpStdev;
                    StdevRecord.BenchMark = tmpBenchMark;
                    StdevRepository.Add(StdevRecord);
                    _unitOfWork.Complete();
                }
                catch (DbEntityValidationException ex)
                {
                    Logger.Error("Error coming from ProcessWorkSheet routine: " + ex.Message);
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                }
                #endregion
            }
            return sht;
        }

        private int LastRowTotal(Excel.Worksheet wks)
        {
            Excel.Range lastCell = wks.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);
            return lastCell.Row;
        }

        private int LastRowPerColumn(int column, Excel.Worksheet wks)
        {
            int lastRow = LastRowTotal(wks);
            while (((wks.Cells[lastRow, column]).Text == "") && (lastRow != 1))
            {
                lastRow--;
            }
            return lastRow;
        }

        public void CloseExcelExe(Excel.Application excel)
        {
            Marshal.ReleaseComObject(excel);
        }


        public IEnumerable<PerformanceRecord> GetPerformanceRecords(int count)
        {
            throw new NotImplementedException();
        }
    }
}

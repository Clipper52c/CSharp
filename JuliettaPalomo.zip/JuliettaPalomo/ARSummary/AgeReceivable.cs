﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CustomInterface;

namespace ARSummary
{
    public partial class AgeReceivable : Form, IProgressStatus
    {

        private double _statusProgressValue = 0;
        private double _statusProgressMaxValue = 0;


        #region Implementing IProgressStatus ...

        public void SetProgressBarValues(double value, double MaxValue)
        {
            _statusProgressValue = value;
            _statusProgressMaxValue = MaxValue;
        }


        public void RefreshProgressBar()
        {
            statusProgress.Value = int.Parse(Math.Round(((_statusProgressValue * 100) / (_statusProgressMaxValue * 100) * 100), 0).ToString());
            this.Refresh();

        }

        public void ToggleStatus()
        {
            this.statusLabel.Visible =
                this.statusLabel.Visible == false ? true : false;

            this.statusProgress.Visible =
                this.statusProgress.Visible == false ? true : false;

        }

        #endregion
        
        public AgeReceivable()
        {
            InitializeComponent();
        }

        private void cmdOpenCurrentPeriodDataFile_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
            {
                this.txFileCurrent.Text = Foldr.SelectedPath;
            }   

        }

        private void cmdProcess_Click(object sender, EventArgs e)
        {
            ExcelDataFile ExcelFileProcessing = new ExcelDataFile(
                                                        this.txFileCurrent.Text,
                                                        this.txtXML.Text);
            ExcelFileProcessing.ProcessExcelFiles(this);
            this.ToggleStatus();

        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // this is used for testing purpose only, remove when done.
            this.txFileCurrent.Text = "D:\\015";

            this.statusLabel.Visible = false;
            this.statusProgress.Visible = false;

        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                this.txtXML.Text = saveFile.FileName;
            }

        }
    }
}

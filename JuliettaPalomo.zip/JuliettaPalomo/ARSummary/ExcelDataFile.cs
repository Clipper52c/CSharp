﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Reflection;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ARSummary
{
    public class ExcelDataFile
    {
        private string _TextFileFolder;
        private string _XMLFileName;

        // Excel Worksheets declaration
        private Excel.Application _objApp;
        private Excel.Workbooks _objBooks;
        private List<WorkSheetData> Lines;

        // Constructor ...
        public ExcelDataFile(string txFileCurrent, string txXMLFileName){
            _TextFileFolder = txFileCurrent;

            if (txXMLFileName.Substring(txXMLFileName.Length - 4, 4) == ".XML" 
                || txXMLFileName.Substring(txXMLFileName.Length - 4, 4) == ".xml")
            {
                _XMLFileName = txXMLFileName;
            }
            else
            {
                _XMLFileName = txXMLFileName += ".xml";
            }
        
        }

        /// <summary>
        /// Main procedure for processing optional equity Excel files.
        /// </summary>
        public void ProcessExcelFiles(ARSummary.AgeReceivable MainForm)
        {
            Excel.Workbook CurrentWorkBook;
            Lines = new List<WorkSheetData>();

            if (_TextFileFolder == "")
            {
                MessageBox.Show("Text File Directory cannot be blank...");
            }

            else
            {
                Cursor.Current = Cursors.WaitCursor;

                string[] items = Directory.GetFiles(_TextFileFolder);

                // initialize the Excel Application class
                _objApp = new Excel.Application();
                _objBooks = _objApp.Workbooks;

                WorkSheetData DataCollection = new WorkSheetData();

                double itemNumber = 0;

                MainForm.ToggleStatus();

                foreach (string item in items)
                {
                    MainForm.SetProgressBarValues(++itemNumber, items.Count());
                    MainForm.RefreshProgressBar();

                    CurrentWorkBook = _objBooks.Open(
                                item,
                                false, true, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing);

                    ExtractWorkSheetInfo ProcessWorkSheetInfo =
                                new ExtractWorkSheetInfo(
                                        DataCollection,
                                        CurrentWorkBook
                                        );

                    ProcessWorkSheetInfo.Process(Lines, item.Substring(item.LastIndexOf("\\") + 1, 4));
                }

                if (File.Exists(@_XMLFileName))
                {
                    File.Delete(@_XMLFileName);
                }

                System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(Lines.GetType());
                x.Serialize(File.Create(@_XMLFileName), Lines);
                MessageBox.Show("done");

                Cursor.Current = Cursors.Default;
            }
        }

        class ExtractWorkSheetInfo
        {

            private WorkSheetData _data;
            private Excel.Workbook _objBook;
            private Excel.Worksheet CurrentWorkSheet;
            int LastRow = 0;
            Excel.Range objRange;

            public ExtractWorkSheetInfo(WorkSheetData pdata,
                                        Excel.Workbook objBook)
            {
                _objBook = objBook;
                _data = pdata;
            }
            public void Process(List<WorkSheetData> lines, string storenumber)
            {
                CurrentWorkSheet = (Excel.Worksheet)_objBook.Sheets[1];
                datagroupAttribute dataItem;

                // search for the last cell
                objRange =
                    CurrentWorkSheet.get_Range("A1", "Z60000").SpecialCells(Excel.XlCellType.xlCellTypeLastCell, Type.Missing);

                LastRow = objRange.Row;
                datagroups groups = new datagroups();

                // look for how many groups there are in the worksheet:
                for (int i = 1; i < LastRow; i++)
                {
                    if (CurrentWorkSheet.get_Range("A" + i, "A" + i).Value2 != null &
                        CurrentWorkSheet.get_Range("A" + i, "A" + i).get_Offset(0, 1).Value2 == null)
                    {
                        if ((int)CurrentWorkSheet.get_Range("A" + i, "A" + i).Value2.ToString().Length < 30)
                        {
                            dataItem = new datagroupAttribute();
                            dataItem.StartingRow = i;
                            dataItem.groupname = CurrentWorkSheet.get_Range("A" + i, "A" + i).Value2.ToString();
                            groups.Add(dataItem);

                        }
                    }
                }

                // LOOP through the number of categories
                for (int i = 0; i < groups.Count; i++)
                {
                    int BegRow = 0;
                    int EndRow = 0;

                    // setup the Excel column ID
                    string[] letters = new string[26]{"A", "B", "C", "D", "E", "F", "G", "H",
                        "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
                        "W", "X", "Y", "Z"};

                    //determine the beginning row and end row
                    BegRow = groups[i].StartingRow + 1;

                    if (i == groups.Count - 1) EndRow = groups[i].StartingRow;
                    else EndRow = groups[i + 1].StartingRow;

                    // LOOP within the block
                    for (int j = BegRow; j < EndRow; j++)
                    {
                        string ColumnID = letters.GetValue(0) + (j).ToString();
                        WorkSheetData item = new WorkSheetData();

                        // if this is a header column, then get the column label.
                        if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "Code")
                            item.GetColumnLabel(j, CurrentWorkSheet);

                        // if not a header column, start the process and collect the values
                        else
                        {
                            if (CurrentWorkSheet.get_Range(letters.GetValue(0) + (j).ToString(), letters.GetValue(0) + (j).ToString()).Value2 != null &
                                CurrentWorkSheet.get_Range(letters.GetValue(1) + (j).ToString(), letters.GetValue(1) + (j).ToString()).Value2 != null)
                            {
                                item.Category = groups[i].groupname;
                                item.Code = CurrentWorkSheet.get_Range(WorkSheetData.CodeColumn + (j).ToString(), WorkSheetData.CodeColumn + (j).ToString()).Value2.ToString().Trim();
                                item.Customer = CurrentWorkSheet.get_Range(WorkSheetData.CustomerColumn + (j).ToString(), WorkSheetData.CustomerColumn + (j).ToString()).Value2.ToString().Trim();
                                item.Amount = double.Parse(CurrentWorkSheet.get_Range(WorkSheetData.AmountColumn + (j).ToString(), WorkSheetData.AmountColumn + (j).ToString()).Value2.ToString().Trim());
                                item.Days90 = double.Parse(CurrentWorkSheet.get_Range(WorkSheetData.Days90Column + (j).ToString(), WorkSheetData.Days90Column + (j).ToString()).Value2.ToString().Trim());
                                item.Days180 = double.Parse(CurrentWorkSheet.get_Range(WorkSheetData.Days180Column + (j).ToString(), WorkSheetData.Days180Column + (j).ToString()).Value2.ToString().Trim());
                                item.Days270 = double.Parse(CurrentWorkSheet.get_Range(WorkSheetData.Days270Column + (j).ToString(), WorkSheetData.Days270Column + (j).ToString()).Value2.ToString().Trim());
                                item.Over364 = double.Parse(CurrentWorkSheet.get_Range(WorkSheetData.DaysOver364Column + (j).ToString(), WorkSheetData.DaysOver364Column + (j).ToString()).Value2.ToString().Trim());
                                item.store = storenumber.Substring(0, 4);

                                lines.Add(item);

                            }
                        }

                    }

                }

            }

        }

        class datagroupAttribute
        {

            public int StartingRow = 0;
            public string groupname = "";

        }

        class datagroups : CollectionBase
        {
            public virtual void Add(datagroupAttribute NewdatagroupAttribute)
            {
                //forward our Add method on to 
                //CollectionBase.IList.Add   
                this.List.Add(NewdatagroupAttribute);

            }

            //this is the indexer (readonly)
            public virtual datagroupAttribute this[int Index]
            {

                get
                {
                    //return the Widget at IList[Index]
                    return (datagroupAttribute)this.List[Index];

                }

            }
        }

        /// <summary>
        /// Store line items in the worksheet
        /// </summary>
        public class WorkSheetData
        {

            // setup the Excel column ID
            private string[] letters = new string[26]{"A", "B", "C", "D", "E", "F", "G", "H",
                        "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
                        "W", "X", "Y", "Z"};


            public static string CodeColumn = "";
            public static string CustomerColumn = "";
            public static string AmountColumn = "";
            public static string Days90Column = "";
            public static string Days180Column = "";
            public static string Days270Column = "";
            public static string DaysOver364Column = "";

            private string _Code = "";
            private string _Category = "";
            private string _store = "";
            private string _Customer = "";
            private double _Amount = 0;
            private double _Days90 = 0;
            private double _Days180 = 0;
            private double _Days270 = 0;
            private double _Over364 = 0;


            public string Code {
                get {return _Code;}
                set {_Code = value;}
            }

            public string Category
            {
                get { return _Category; }
                set { _Category = value; }
            }

            public string store
            {
                get { return _store; }
                set { _store = value; }
            }

            public string Customer
            {
                get { return _Customer; }
                set { _Customer = value; }
            }

            public double Amount
            {
                get { return _Amount; }
                set { _Amount = value; }
            }

            public double Days90
            {
                get { return _Days90; }
                set { _Days90 = value; }
            }

            public double Days180
            {
                get { return _Days180; }
                set { _Days180 = value; }
            }

            public double Days270
            {
                get { return _Days270; }
                set { _Days270 = value; }
            }

            public double Over364
            {
                get { return _Over364; }
                set { _Over364 = value; }
            }

           
            public void GetColumnLabel(int RowNumber, Excel.Worksheet CurrentWorkSheet)
            {
                string ColumnID = letters.GetValue(0) + (RowNumber).ToString();

                // get the columnIDs
                for (int a = 0; a < 26; a++)
                {
                    ColumnID = letters.GetValue(a) + (RowNumber).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "Code")
                        WorkSheetData.CodeColumn = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "Customer")
                        WorkSheetData.CustomerColumn = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "Amount")
                        WorkSheetData.AmountColumn = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "90 Days")
                        WorkSheetData.Days90Column = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "180 Days")
                        WorkSheetData.Days180Column = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "270 Days")
                        WorkSheetData.Days270Column = letters.GetValue(a).ToString();

                    if ((string)CurrentWorkSheet.get_Range(ColumnID, ColumnID).Value2 == "Over 364")
                        WorkSheetData.DaysOver364Column = letters.GetValue(a).ToString();


                }
            }



        }
    }
}



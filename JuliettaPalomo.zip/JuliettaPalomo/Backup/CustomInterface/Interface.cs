﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomInterface
{
    public interface IProgressStatus
    {
        void RefreshProgressBar();
        void ToggleStatus(); // toggle status on off. (status label and progress bar)
        void SetProgressBarValues(double value, double MaxValue);

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace OptionalEquity
{
    class Data
    {
        // String variables - Form
        protected string _FinalizedTemplateLocation = "";
        protected string _NonFinalizedTemplateLocation = "";
        protected string _AccessDataBaseLocation = "";
        protected string _OutputDirectoryFinalized = "";
        protected string _OutputDirectoryNonFinalized = "";
        protected int _Period = 0;
        protected int _Year = 0;

        // String variables - Access SQL string
        protected string _ConnectionString = "";
        protected string _AllowableDrawQueryString = SQL.stFunctionAllowableDraw();
        protected string _PeriodEndQueryString = SQL.stFunctionPeriodEndDates();
        protected string _OpeningBalanceString = SQL.stOpeningBalance();
        protected string _OpeningEquityBalanceString = SQL.stOpeningEquity();
        protected string _AdvancesString = SQL.stAdvances();
        protected string _DividendString = SQL.stDividend();

        // ADO.NET variables
        protected System.Data.OleDb.OleDbConnection AccessConnectionDotNet;
        protected System.Data.DataSet ds;

        // data adaptor objects ...
        protected System.Data.OleDb.OleDbDataAdapter adpAllowableDraw;
        protected System.Data.OleDb.OleDbDataAdapter adpPeriodEndDates;
        protected System.Data.OleDb.OleDbDataAdapter adpOpeningBalance;
        protected System.Data.OleDb.OleDbDataAdapter adpOpeningEquity;
        protected System.Data.OleDb.OleDbDataAdapter adpAdvances;
        protected System.Data.OleDb.OleDbDataAdapter adpDividend;

        //ADO classic variables, Command, Connection and Recordset.
        protected ADODB.Command cmd;
        protected ADODB.Connection cnn;
        protected ADODB.Recordset rst;
        protected ADODB.Recordset CompanyNumberRst;

        // Constructor ...
        public Data(  
                    string FinalizedTemplateLocation,
                    string NonFinalizedTemplateLocation,
                    string AccessDataBaseLocation,
                    string OutputDirectoryFinalized,
                    string OutputDirectoryNonFinalized,
                    int Period,
                    int Year
                    ) {

            // Assign variables ...    
            _FinalizedTemplateLocation = FinalizedTemplateLocation;
            _NonFinalizedTemplateLocation = NonFinalizedTemplateLocation;
            _AccessDataBaseLocation = AccessDataBaseLocation;
            _FinalizedTemplateLocation = FinalizedTemplateLocation;
            _OutputDirectoryFinalized = OutputDirectoryFinalized;
            _OutputDirectoryNonFinalized = OutputDirectoryNonFinalized;
            _Period = Period;
            _Year = Year;
            }

        protected void InitiateDotNETDataSets()
        {
            //create .Net database connection and objects
            AccessConnectionDotNet = new System.Data.OleDb.OleDbConnection();
            AccessConnectionDotNet = new System.Data.OleDb.OleDbConnection(_ConnectionString);
            AccessConnectionDotNet.Open();

            // create dataset
            ds = new System.Data.DataSet();

            // initiate data adaptors
            adpAllowableDraw =
                new System.Data.OleDb.OleDbDataAdapter(_AllowableDrawQueryString, AccessConnectionDotNet);
            adpPeriodEndDates =
                new System.Data.OleDb.OleDbDataAdapter(_PeriodEndQueryString, AccessConnectionDotNet);
            adpOpeningBalance =
                new System.Data.OleDb.OleDbDataAdapter(_OpeningBalanceString, AccessConnectionDotNet);
            adpOpeningEquity =
                new System.Data.OleDb.OleDbDataAdapter(_OpeningEquityBalanceString, AccessConnectionDotNet);
            adpAdvances =
                new System.Data.OleDb.OleDbDataAdapter(_AdvancesString, AccessConnectionDotNet);
            adpDividend =
                new System.Data.OleDb.OleDbDataAdapter(_DividendString, AccessConnectionDotNet);


            // Filling the Data Set ...
            adpAllowableDraw.Fill(ds, "AllowableDraw");
            adpPeriodEndDates.Fill(ds, "PeriodEndDates");
            adpOpeningBalance.Fill(ds, "OpeningBalance");
            adpOpeningEquity.Fill(ds, "OpeningEquity");
            adpAdvances.Fill(ds, "Advances");
            adpDividend.Fill(ds, "Dividend");


            // Set the primary keys : single primary key
            DataColumn[] colPkAllowableDraw = new DataColumn[1];
            colPkAllowableDraw[0] = ds.Tables["AllowableDraw"].Columns["Co#"];
            ds.Tables["AllowableDraw"].PrimaryKey = colPkAllowableDraw;

            DataColumn[] colPkPeriodEndDate = new DataColumn[1];
            colPkPeriodEndDate[0] = ds.Tables["PeriodEndDates"].Columns["PD"];
            ds.Tables["PeriodEndDates"].PrimaryKey = colPkPeriodEndDate;

            DataColumn[] colPkOpeningBalance = new DataColumn[1];
            colPkOpeningBalance[0] = ds.Tables["OpeningBalance"].Columns["Company#"];
            ds.Tables["OpeningBalance"].PrimaryKey = colPkOpeningBalance;

            DataColumn[] colPkOpeningEquity = new DataColumn[1];
            colPkOpeningEquity[0] = ds.Tables["OpeningEquity"].Columns["Company#"];
            ds.Tables["OpeningEquity"].PrimaryKey = colPkOpeningEquity;

            DataColumn[] colPkAdvances = new DataColumn[1];
            colPkAdvances[0] = ds.Tables["Advances"].Columns["Company#"];
            ds.Tables["Advances"].PrimaryKey = colPkAdvances;

            DataColumn[] colPkDividend = new DataColumn[1];
            colPkDividend[0] = ds.Tables["Dividend"].Columns["Company#"];
            ds.Tables["Dividend"].PrimaryKey = colPkDividend;

        }


        protected void InitiateCOMDatasets()
        {
            // Create Classic ADO connection and objects
            cnn = new ADODB.Connection();
            cmd = new ADODB.Command();
            rst = new ADODB.Recordset();
            CompanyNumberRst = new ADODB.Recordset();
            cnn.CursorLocation = ADODB.CursorLocationEnum.adUseClient;

            // Access Connection string
            _ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;";
            _ConnectionString += "Data Source=";
            _ConnectionString += _AccessDataBaseLocation;

            cnn.Open(_ConnectionString, "admin", "", 0);   // open the Classic ADO connection

            // Classic ADO company number query string
            CompanyNumberRst.Open(SQL.stFunctionCompanyNumber(),
                                cnn, ADODB.CursorTypeEnum.adOpenForwardOnly,
                                ADODB.LockTypeEnum.adLockReadOnly, 0);

        }
    }
}

﻿namespace OptionalEquity
{
    partial class OptionalEquity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionalEquity));
            this.txtFinalized = new System.Windows.Forms.TextBox();
            this.txtNonFinalized = new System.Windows.Forms.TextBox();
            this.lbFinalized = new System.Windows.Forms.Label();
            this.lbNonFinalized = new System.Windows.Forms.Label();
            this.cmdOpenFinalizedTemplate = new System.Windows.Forms.Button();
            this.cmdOpenNonFinalizedTemplate = new System.Windows.Forms.Button();
            this.txtOutputDirectoryFinalized = new System.Windows.Forms.TextBox();
            this.cmdOpenOutPutDirectoryFinalized = new System.Windows.Forms.Button();
            this.lbOutputDirectoryFinalized = new System.Windows.Forms.Label();
            this.cmdOpenAccessDataBaseLocation = new System.Windows.Forms.Button();
            this.lbAccessDataBaseLocation = new System.Windows.Forms.Label();
            this.txtAccessDataBase = new System.Windows.Forms.TextBox();
            this.lbOutputDirectoryNonFinalized = new System.Windows.Forms.Label();
            this.cmdOpenOutPutDirectoryNonFinalized = new System.Windows.Forms.Button();
            this.txtOutputDirectoryNonFinalized = new System.Windows.Forms.TextBox();
            this.cbPeriod = new System.Windows.Forms.ComboBox();
            this.cbYear = new System.Windows.Forms.ComboBox();
            this.lbPeriod = new System.Windows.Forms.Label();
            this.lbYear = new System.Windows.Forms.Label();
            this.cbPrintOut = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.cmdProcess = new System.Windows.Forms.Button();
            this.cmdCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtFinalized
            // 
            this.txtFinalized.BackColor = System.Drawing.Color.White;
            this.txtFinalized.Enabled = false;
            this.txtFinalized.Location = new System.Drawing.Point(47, 124);
            this.txtFinalized.Name = "txtFinalized";
            this.txtFinalized.Size = new System.Drawing.Size(417, 20);
            this.txtFinalized.TabIndex = 2;
            // 
            // txtNonFinalized
            // 
            this.txtNonFinalized.BackColor = System.Drawing.Color.White;
            this.txtNonFinalized.Enabled = false;
            this.txtNonFinalized.Location = new System.Drawing.Point(47, 182);
            this.txtNonFinalized.Name = "txtNonFinalized";
            this.txtNonFinalized.Size = new System.Drawing.Size(417, 20);
            this.txtNonFinalized.TabIndex = 3;
            // 
            // lbFinalized
            // 
            this.lbFinalized.AutoSize = true;
            this.lbFinalized.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFinalized.ForeColor = System.Drawing.Color.Yellow;
            this.lbFinalized.Location = new System.Drawing.Point(49, 108);
            this.lbFinalized.Name = "lbFinalized";
            this.lbFinalized.Size = new System.Drawing.Size(170, 13);
            this.lbFinalized.TabIndex = 4;
            this.lbFinalized.Text = "Finalized Template Location:";
            // 
            // lbNonFinalized
            // 
            this.lbNonFinalized.AutoSize = true;
            this.lbNonFinalized.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNonFinalized.ForeColor = System.Drawing.Color.Yellow;
            this.lbNonFinalized.Location = new System.Drawing.Point(49, 166);
            this.lbNonFinalized.Name = "lbNonFinalized";
            this.lbNonFinalized.Size = new System.Drawing.Size(197, 13);
            this.lbNonFinalized.TabIndex = 5;
            this.lbNonFinalized.Text = "Non-Finalized Template Location:";
            // 
            // cmdOpenFinalizedTemplate
            // 
            this.cmdOpenFinalizedTemplate.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenFinalizedTemplate.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenFinalizedTemplate.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenFinalizedTemplate.Image")));
            this.cmdOpenFinalizedTemplate.Location = new System.Drawing.Point(470, 124);
            this.cmdOpenFinalizedTemplate.Name = "cmdOpenFinalizedTemplate";
            this.cmdOpenFinalizedTemplate.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenFinalizedTemplate.TabIndex = 17;
            this.cmdOpenFinalizedTemplate.UseVisualStyleBackColor = false;
            this.cmdOpenFinalizedTemplate.Click += new System.EventHandler(this.cmdOpenFinalizedTemplate_Click);
            // 
            // cmdOpenNonFinalizedTemplate
            // 
            this.cmdOpenNonFinalizedTemplate.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenNonFinalizedTemplate.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenNonFinalizedTemplate.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenNonFinalizedTemplate.Image")));
            this.cmdOpenNonFinalizedTemplate.Location = new System.Drawing.Point(470, 181);
            this.cmdOpenNonFinalizedTemplate.Name = "cmdOpenNonFinalizedTemplate";
            this.cmdOpenNonFinalizedTemplate.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenNonFinalizedTemplate.TabIndex = 18;
            this.cmdOpenNonFinalizedTemplate.UseVisualStyleBackColor = false;
            this.cmdOpenNonFinalizedTemplate.Click += new System.EventHandler(this.cmdOpenNonFinalizedTemplate_Click);
            // 
            // txtOutputDirectoryFinalized
            // 
            this.txtOutputDirectoryFinalized.BackColor = System.Drawing.Color.White;
            this.txtOutputDirectoryFinalized.Enabled = false;
            this.txtOutputDirectoryFinalized.Location = new System.Drawing.Point(47, 303);
            this.txtOutputDirectoryFinalized.Name = "txtOutputDirectoryFinalized";
            this.txtOutputDirectoryFinalized.Size = new System.Drawing.Size(412, 20);
            this.txtOutputDirectoryFinalized.TabIndex = 19;
            // 
            // cmdOpenOutPutDirectoryFinalized
            // 
            this.cmdOpenOutPutDirectoryFinalized.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenOutPutDirectoryFinalized.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenOutPutDirectoryFinalized.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenOutPutDirectoryFinalized.Image")));
            this.cmdOpenOutPutDirectoryFinalized.Location = new System.Drawing.Point(470, 303);
            this.cmdOpenOutPutDirectoryFinalized.Name = "cmdOpenOutPutDirectoryFinalized";
            this.cmdOpenOutPutDirectoryFinalized.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenOutPutDirectoryFinalized.TabIndex = 20;
            this.cmdOpenOutPutDirectoryFinalized.UseVisualStyleBackColor = false;
            this.cmdOpenOutPutDirectoryFinalized.Click += new System.EventHandler(this.cmdOpenOutPutDirectoryFinalized_Click);
            // 
            // lbOutputDirectoryFinalized
            // 
            this.lbOutputDirectoryFinalized.AutoSize = true;
            this.lbOutputDirectoryFinalized.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOutputDirectoryFinalized.ForeColor = System.Drawing.Color.Yellow;
            this.lbOutputDirectoryFinalized.Location = new System.Drawing.Point(49, 287);
            this.lbOutputDirectoryFinalized.Name = "lbOutputDirectoryFinalized";
            this.lbOutputDirectoryFinalized.Size = new System.Drawing.Size(158, 13);
            this.lbOutputDirectoryFinalized.TabIndex = 21;
            this.lbOutputDirectoryFinalized.Text = "Output Directory Finalized:";
            // 
            // cmdOpenAccessDataBaseLocation
            // 
            this.cmdOpenAccessDataBaseLocation.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenAccessDataBaseLocation.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenAccessDataBaseLocation.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenAccessDataBaseLocation.Image")));
            this.cmdOpenAccessDataBaseLocation.Location = new System.Drawing.Point(470, 237);
            this.cmdOpenAccessDataBaseLocation.Name = "cmdOpenAccessDataBaseLocation";
            this.cmdOpenAccessDataBaseLocation.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenAccessDataBaseLocation.TabIndex = 24;
            this.cmdOpenAccessDataBaseLocation.UseVisualStyleBackColor = false;
            this.cmdOpenAccessDataBaseLocation.Click += new System.EventHandler(this.cmdOpenAccessDataBaseLocation_Click);
            // 
            // lbAccessDataBaseLocation
            // 
            this.lbAccessDataBaseLocation.AutoSize = true;
            this.lbAccessDataBaseLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAccessDataBaseLocation.ForeColor = System.Drawing.Color.Yellow;
            this.lbAccessDataBaseLocation.Location = new System.Drawing.Point(49, 222);
            this.lbAccessDataBaseLocation.Name = "lbAccessDataBaseLocation";
            this.lbAccessDataBaseLocation.Size = new System.Drawing.Size(164, 13);
            this.lbAccessDataBaseLocation.TabIndex = 23;
            this.lbAccessDataBaseLocation.Text = "Access DataBase Location:";
            // 
            // txtAccessDataBase
            // 
            this.txtAccessDataBase.BackColor = System.Drawing.Color.White;
            this.txtAccessDataBase.Enabled = false;
            this.txtAccessDataBase.Location = new System.Drawing.Point(47, 238);
            this.txtAccessDataBase.Name = "txtAccessDataBase";
            this.txtAccessDataBase.Size = new System.Drawing.Size(417, 20);
            this.txtAccessDataBase.TabIndex = 22;
            // 
            // lbOutputDirectoryNonFinalized
            // 
            this.lbOutputDirectoryNonFinalized.AutoSize = true;
            this.lbOutputDirectoryNonFinalized.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOutputDirectoryNonFinalized.ForeColor = System.Drawing.Color.Yellow;
            this.lbOutputDirectoryNonFinalized.Location = new System.Drawing.Point(49, 351);
            this.lbOutputDirectoryNonFinalized.Name = "lbOutputDirectoryNonFinalized";
            this.lbOutputDirectoryNonFinalized.Size = new System.Drawing.Size(185, 13);
            this.lbOutputDirectoryNonFinalized.TabIndex = 27;
            this.lbOutputDirectoryNonFinalized.Text = "Output Directory Non Finalized:";
            // 
            // cmdOpenOutPutDirectoryNonFinalized
            // 
            this.cmdOpenOutPutDirectoryNonFinalized.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenOutPutDirectoryNonFinalized.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenOutPutDirectoryNonFinalized.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenOutPutDirectoryNonFinalized.Image")));
            this.cmdOpenOutPutDirectoryNonFinalized.Location = new System.Drawing.Point(470, 367);
            this.cmdOpenOutPutDirectoryNonFinalized.Name = "cmdOpenOutPutDirectoryNonFinalized";
            this.cmdOpenOutPutDirectoryNonFinalized.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenOutPutDirectoryNonFinalized.TabIndex = 26;
            this.cmdOpenOutPutDirectoryNonFinalized.UseVisualStyleBackColor = false;
            this.cmdOpenOutPutDirectoryNonFinalized.Click += new System.EventHandler(this.cmdOpenOutPutDirectoryNonFinalized_Click);
            // 
            // txtOutputDirectoryNonFinalized
            // 
            this.txtOutputDirectoryNonFinalized.BackColor = System.Drawing.Color.White;
            this.txtOutputDirectoryNonFinalized.Enabled = false;
            this.txtOutputDirectoryNonFinalized.Location = new System.Drawing.Point(47, 367);
            this.txtOutputDirectoryNonFinalized.Name = "txtOutputDirectoryNonFinalized";
            this.txtOutputDirectoryNonFinalized.Size = new System.Drawing.Size(412, 20);
            this.txtOutputDirectoryNonFinalized.TabIndex = 25;
            // 
            // cbPeriod
            // 
            this.cbPeriod.FormattingEnabled = true;
            this.cbPeriod.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13"});
            this.cbPeriod.Location = new System.Drawing.Point(48, 429);
            this.cbPeriod.Name = "cbPeriod";
            this.cbPeriod.Size = new System.Drawing.Size(82, 21);
            this.cbPeriod.TabIndex = 28;
            // 
            // cbYear
            // 
            this.cbYear.FormattingEnabled = true;
            this.cbYear.Items.AddRange(new object[] {
            "2007",
            "2008",
            "2009",
            "2010"});
            this.cbYear.Location = new System.Drawing.Point(157, 429);
            this.cbYear.Name = "cbYear";
            this.cbYear.Size = new System.Drawing.Size(89, 21);
            this.cbYear.TabIndex = 29;
            // 
            // lbPeriod
            // 
            this.lbPeriod.AutoSize = true;
            this.lbPeriod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPeriod.ForeColor = System.Drawing.Color.Yellow;
            this.lbPeriod.Location = new System.Drawing.Point(45, 413);
            this.lbPeriod.Name = "lbPeriod";
            this.lbPeriod.Size = new System.Drawing.Size(47, 13);
            this.lbPeriod.TabIndex = 30;
            this.lbPeriod.Text = "Period:";
            // 
            // lbYear
            // 
            this.lbYear.AutoSize = true;
            this.lbYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbYear.ForeColor = System.Drawing.Color.Yellow;
            this.lbYear.Location = new System.Drawing.Point(156, 413);
            this.lbYear.Name = "lbYear";
            this.lbYear.Size = new System.Drawing.Size(37, 13);
            this.lbYear.TabIndex = 31;
            this.lbYear.Text = "Year:";
            // 
            // cbPrintOut
            // 
            this.cbPrintOut.AutoSize = true;
            this.cbPrintOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPrintOut.ForeColor = System.Drawing.Color.Yellow;
            this.cbPrintOut.Location = new System.Drawing.Point(305, 433);
            this.cbPrintOut.Name = "cbPrintOut";
            this.cbPrintOut.Size = new System.Drawing.Size(154, 17);
            this.cbPrintOut.TabIndex = 32;
            this.cbPrintOut.Text = "Create Excel PrintOuts";
            this.cbPrintOut.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::OptionalEquity.Properties.Resources.shoppers;
            this.pictureBox1.Location = new System.Drawing.Point(47, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(207, 38);
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel,
            this.statusProgress});
            this.statusStrip1.Location = new System.Drawing.Point(0, 567);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(559, 22);
            this.statusStrip1.TabIndex = 35;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            this.statusLabel.BackColor = System.Drawing.SystemColors.Control;
            this.statusLabel.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(64, 17);
            this.statusLabel.Text = "Progress ...";
            this.statusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // statusProgress
            // 
            this.statusProgress.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.statusProgress.AutoSize = false;
            this.statusProgress.BackColor = System.Drawing.SystemColors.Control;
            this.statusProgress.ForeColor = System.Drawing.Color.Lime;
            this.statusProgress.Name = "statusProgress";
            this.statusProgress.Size = new System.Drawing.Size(150, 16);
            // 
            // cmdProcess
            // 
            this.cmdProcess.BackColor = System.Drawing.SystemColors.Control;
            this.cmdProcess.Location = new System.Drawing.Point(44, 500);
            this.cmdProcess.Name = "cmdProcess";
            this.cmdProcess.Size = new System.Drawing.Size(85, 26);
            this.cmdProcess.TabIndex = 36;
            this.cmdProcess.Text = "Process";
            this.cmdProcess.UseVisualStyleBackColor = false;
            this.cmdProcess.Click += new System.EventHandler(this.cmdProcess_Click);
            // 
            // cmdCancel
            // 
            this.cmdCancel.BackColor = System.Drawing.SystemColors.Control;
            this.cmdCancel.Location = new System.Drawing.Point(155, 500);
            this.cmdCancel.Name = "cmdCancel";
            this.cmdCancel.Size = new System.Drawing.Size(90, 25);
            this.cmdCancel.TabIndex = 37;
            this.cmdCancel.Text = "Cancel";
            this.cmdCancel.UseVisualStyleBackColor = false;
            this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
            // 
            // OptionalEquity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(559, 589);
            this.Controls.Add(this.cmdCancel);
            this.Controls.Add(this.cmdProcess);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cbPrintOut);
            this.Controls.Add(this.lbYear);
            this.Controls.Add(this.lbPeriod);
            this.Controls.Add(this.cbYear);
            this.Controls.Add(this.cbPeriod);
            this.Controls.Add(this.lbOutputDirectoryNonFinalized);
            this.Controls.Add(this.cmdOpenOutPutDirectoryNonFinalized);
            this.Controls.Add(this.txtOutputDirectoryNonFinalized);
            this.Controls.Add(this.cmdOpenAccessDataBaseLocation);
            this.Controls.Add(this.lbAccessDataBaseLocation);
            this.Controls.Add(this.txtAccessDataBase);
            this.Controls.Add(this.lbOutputDirectoryFinalized);
            this.Controls.Add(this.cmdOpenOutPutDirectoryFinalized);
            this.Controls.Add(this.txtOutputDirectoryFinalized);
            this.Controls.Add(this.cmdOpenNonFinalizedTemplate);
            this.Controls.Add(this.cmdOpenFinalizedTemplate);
            this.Controls.Add(this.lbNonFinalized);
            this.Controls.Add(this.lbFinalized);
            this.Controls.Add(this.txtNonFinalized);
            this.Controls.Add(this.txtFinalized);
            this.Name = "OptionalEquity";
            this.Text = "Optional Equity";
            this.Load += new System.EventHandler(this.OptionalEquity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFinalized;
        private System.Windows.Forms.TextBox txtNonFinalized;
        private System.Windows.Forms.Label lbFinalized;
        private System.Windows.Forms.Label lbNonFinalized;
        private System.Windows.Forms.Button cmdOpenFinalizedTemplate;
        private System.Windows.Forms.Button cmdOpenNonFinalizedTemplate;
        private System.Windows.Forms.TextBox txtOutputDirectoryFinalized;
        private System.Windows.Forms.Button cmdOpenOutPutDirectoryFinalized;
        private System.Windows.Forms.Label lbOutputDirectoryFinalized;
        private System.Windows.Forms.Button cmdOpenAccessDataBaseLocation;
        private System.Windows.Forms.Label lbAccessDataBaseLocation;
        private System.Windows.Forms.TextBox txtAccessDataBase;
        private System.Windows.Forms.Label lbOutputDirectoryNonFinalized;
        private System.Windows.Forms.Button cmdOpenOutPutDirectoryNonFinalized;
        private System.Windows.Forms.TextBox txtOutputDirectoryNonFinalized;
        private System.Windows.Forms.ComboBox cbPeriod;
        private System.Windows.Forms.ComboBox cbYear;
        private System.Windows.Forms.Label lbPeriod;
        private System.Windows.Forms.Label lbYear;
        private System.Windows.Forms.CheckBox cbPrintOut;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.ToolStripProgressBar statusProgress;
        private System.Windows.Forms.Button cmdProcess;
        private System.Windows.Forms.Button cmdCancel;
    }
}


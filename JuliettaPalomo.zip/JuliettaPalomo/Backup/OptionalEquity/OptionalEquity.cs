﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Text.RegularExpressions;
using CustomInterface;


namespace OptionalEquity
{
    
    public partial class OptionalEquity : Form, IProgressStatus
    {
        private double _statusProgressValue = 0;
        private double _statusProgressMaxValue = 0;

        enum PrintExcelFile : short
        {
            Print = 1,
            DoNotPrint = 0,
        }


        #region Implementing IProgressStatus ...

        public void SetProgressBarValues(double value, double MaxValue)
        {
            _statusProgressValue = value;
            _statusProgressMaxValue = MaxValue;
        }


        public void RefreshProgressBar()
        {
            statusProgress.Value = int.Parse(Math.Round(((_statusProgressValue * 100) / (_statusProgressMaxValue * 100) * 100), 0).ToString());
            this.Refresh();

        }

        public void ToggleStatus()
        {
            this.statusLabel.Visible = 
                this.statusLabel.Visible == false ? true : false;

            this.statusProgress.Visible = 
                this.statusProgress.Visible == false ? true : false;

        }

        #endregion
 
        public OptionalEquity()
        {
            InitializeComponent();
        }


        private void cmdOpenNonFinalizedTemplate_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                this.txtNonFinalized.Text = openFile.FileName;
            }
                
        }

        private void cmdOpenFinalizedTemplate_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                this.txtFinalized.Text = openFile.FileName;
            }

        }

        private void cmdOpenOutPutDirectoryFinalized_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
            {
                this.txtOutputDirectoryFinalized.Text = Foldr.SelectedPath;

            }
        }

        private void cmdOpenAccessDataBaseLocation_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                this.txtAccessDataBase.Text = openFile.FileName;
            }
        }

        private void cmdOpenOutPutDirectoryNonFinalized_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
            {
                this.txtOutputDirectoryNonFinalized.Text = Foldr.SelectedPath;

            }

        }

        private void OptionalEquity_Load(object sender, EventArgs e)
        {
            this.cbPrintOut.CheckState = CheckState.Checked;
            this.ToggleStatus();

        }

        private void cmdProcess_Click(object sender, EventArgs e)
        {
            if (this.txtFinalized.Text == "")
            {
                MessageBox.Show("Please supply the name of the Excel Finalized template file");
                goto ExitHere;
            }

            if (this.txtNonFinalized.Text == "")
            {
                MessageBox.Show("Please supply the name of the Excel Non Finalized template file");
                goto ExitHere;
            }

            if (this.txtAccessDataBase.Text == "")
            {
                MessageBox.Show("Please supply the name MS Access DataBase");
                goto ExitHere;
            }

            if (this.txtOutputDirectoryFinalized.Text == "")
            {
                MessageBox.Show("Please supply the name of the Finalized output directory");
                goto ExitHere;
            }

            if (this.txtOutputDirectoryNonFinalized.Text == "")
            {
                MessageBox.Show("Please supply the name of the Non Finalized output directory");
                goto ExitHere;
            }

            if (this.cbPeriod.Text == "")
            {
                MessageBox.Show("Please supply the period");
                goto ExitHere;
            }

            if (this.cbYear.Text == "")
            {
                MessageBox.Show("Please supply the year");
                goto ExitHere;
            }

            Cursor.Current = Cursors.WaitCursor;

            Workbook xlOptionalEquity = new Workbook(
                this.txtFinalized.Text,
                this.txtNonFinalized.Text,
                this.txtAccessDataBase.Text,
                this.txtOutputDirectoryFinalized.Text,
                this.txtOutputDirectoryNonFinalized.Text,
                int.Parse(this.cbPeriod.Text),
                int.Parse(this.cbYear.Text)
                );

            if (this.cbPrintOut.Checked == true)
                xlOptionalEquity.ProcessExcelFiles((short)PrintExcelFile.Print, _statusProgressValue, this);
            else
                xlOptionalEquity.ProcessExcelFiles((short)PrintExcelFile.DoNotPrint, _statusProgressValue, this);

            this.ToggleStatus();


            Cursor.Current = Cursors.Default;

        ExitHere:
            return;


        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }




        #region IProgressStatus Members

        void IProgressStatus.RefreshProgressBar()
        {
            throw new NotImplementedException();
        }

        void IProgressStatus.ToggleStatus()
        {
            throw new NotImplementedException();
        }

        void IProgressStatus.SetProgressBarValues(double value, double MaxValue)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace OptionalEquity
{
    //*****************************************************
    //SummaryLines collection class MUST derive from 
    //System.Collections.CollectionBase

    public class Lines : CollectionBase
    {
        public virtual void Add(ReconciledLine NewLine)
        {
            //forward our Add method on to 
            //CollectionBase.IList.Add   
            this.List.Add(NewLine);
        }

        //this is the indexer (readonly)
        public virtual ReconciledLine this[int Index]
        {
            get
            {
                //return the Line at IList[Index]
                return (ReconciledLine)this.List[Index];
            }
        }
    }


    public class DeficientLines : CollectionBase
    {
        public virtual void Add(DeficientLine NewLine)
        {
            //forward our Add method on to 
            //CollectionBase.IList.Add   
            this.List.Add(NewLine);
        }

        //this is the indexer (readonly)
        public virtual DeficientLine this[int Index]
        {
            get
            {
                //return the Line at IList[Index]
                return (DeficientLine)this.List[Index];
            }
        }
    }


    //the individual Line class
    public class ReconciledLine
    {
        // Auto-implemented properties ...
        public int CompanyNumber { get; set; }
        public double TotalAllowableDraw { get; set; }
        public double TotalSummaryBox { get; set; }
        public double ReconciliationAmount { get; set; }
    }

    //the individual Line class
    public class DeficientLine
    {
        // Auto-implemented properties ...
        public string MultiStore { get; set; }
        public string Region { get; set; }
        public string DM { get; set; }
        public string VP { get; set; }
        public string AssociateName { get; set; }
        public int SDM_Number { get; set; }
        public double AllowableDrawAmount { get; set; }
        public double RequiredEquityAmount { get; set; }
        public double Exposure { get; set; }
        public string Comments { get; set; }
        public string EquityPosition { get; set; }
        public double Total_Overdrawn { get; set; }
        public int Number_Of_Times_Deficient { get; set; }
        public double Opening_Equity { get; set; }
        public double Advances { get; set; }
        public double AdminExpense { get; set; }
        public double Dividend { get; set; }
    }


}


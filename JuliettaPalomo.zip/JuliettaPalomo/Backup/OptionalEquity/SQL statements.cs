﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OptionalEquity
{
    class SQL
    {

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stOpeningEquity()
        {
            string SQLOpeningEquity;

            // Classic ADO recordset to fill the opening equity recordset
            SQLOpeningEquity = "SELECT ";
            SQLOpeningEquity += "[Data With Opening Balance].[Company#], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].BeginBal) AS BeginBal, ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  1]) AS [Period 1], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  2]) AS [Period 2], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  3]) AS [Period 3], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  4]) AS [Period 4], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  5]) AS [Period 5], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  6]) AS [Period 6], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  7]) AS [Period 7], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  8]) AS [Period 8], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period  9]) AS [Period 9], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period 10]) AS [Period 10], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period 11]) AS [Period 11], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period 12]) AS [Period 12], ";
            SQLOpeningEquity += "Sum([Data With Opening Balance].[Period 13]) AS [Period 13] ";

            SQLOpeningEquity += "FROM ";
            SQLOpeningEquity += "[Data With Opening Balance] ";
            SQLOpeningEquity += "WHERE ";
            SQLOpeningEquity += "([Data With Opening Balance].[Account1#]='2511' ";
            SQLOpeningEquity += "OR [Data With Opening Balance].[Account1#]='2512' ";
            SQLOpeningEquity += "OR [Data With Opening Balance].[Account1#]='2513' ";
            SQLOpeningEquity += "OR [Data With Opening Balance].[Account1#]='2801' ";
            SQLOpeningEquity += "OR [Data With Opening Balance].[Account1#]='2802' ";
            SQLOpeningEquity += "OR [Data With Opening Balance].[Account1#]='2811'";
            SQLOpeningEquity += ") ";

            SQLOpeningEquity += "GROUP BY ";
            SQLOpeningEquity += "[Data With Opening Balance].[Company#] ";

            return SQLOpeningEquity;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stAdvances()
        {
            string SQLAdvances;

            // Classic ADO recordset to fill the opening equity recordset
            SQLAdvances = "SELECT ";
            SQLAdvances += "[Data With Opening Balance].[Company#], ";
            SQLAdvances += "Sum([Data With Opening Balance].BeginBal) AS BeginBal, ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  1]) AS [Period 1], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  2]) AS [Period 2], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  3]) AS [Period 3], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  4]) AS [Period 4], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  5]) AS [Period 5], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  6]) AS [Period 6], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  7]) AS [Period 7], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  8]) AS [Period 8], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period  9]) AS [Period 9], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period 10]) AS [Period 10], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period 11]) AS [Period 11], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period 12]) AS [Period 12], ";
            SQLAdvances += "Sum([Data With Opening Balance].[Period 13]) AS [Period 13] ";

            SQLAdvances += "FROM ";
            SQLAdvances += "[Data With Opening Balance] ";
            SQLAdvances += "WHERE ";
            SQLAdvances += "([Data With Opening Balance].[Account1#]='2511' ";
            SQLAdvances += "OR [Data With Opening Balance].[Account1#]='2512' ";
            SQLAdvances += ") ";

            SQLAdvances += "GROUP BY ";
            SQLAdvances += "[Data With Opening Balance].[Company#] ";

            return SQLAdvances;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stDividend()
        {
            string SQLDividend;


            // Classic ADO recordset to fill the opening equity recordset
            SQLDividend = "SELECT ";
            SQLDividend += "[Data With Opening Balance].[Company#], ";
            SQLDividend += "[Data With Opening Balance].[Account1#], ";
            SQLDividend += "Sum([Data With Opening Balance].BeginBal) AS BeginBal, ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  1]) AS [Period 1], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  2]) AS [Period 2], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  3]) AS [Period 3], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  4]) AS [Period 4], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  5]) AS [Period 5], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  6]) AS [Period 6], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  7]) AS [Period 7], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  8]) AS [Period 8], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period  9]) AS [Period 9], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period 10]) AS [Period 10], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period 11]) AS [Period 11], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period 12]) AS [Period 12], ";
            SQLDividend += "Sum([Data With Opening Balance].[Period 13]) AS [Period 13] ";

            SQLDividend += "FROM ";
            SQLDividend += "[Data With Opening Balance] ";
            SQLDividend += "WHERE ";
            SQLDividend += "([Data With Opening Balance].[Account1#]='2513'";
            SQLDividend += ") ";

            SQLDividend += "GROUP BY ";
            SQLDividend += "[Data With Opening Balance].[Company#], ";
            SQLDividend += "[Data With Opening Balance].[Account1#] ";

            return SQLDividend;

        }        

        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stTransaction(ADODB.Recordset CompanyNumber)
        {
            string SQLTransactions;
            // SQLTransactions += "Last([Data With Opening Balance].[Store#]) AS [Store#], ";

            // Classic ADO recordset to fill the transactions sheet
            SQLTransactions = "SELECT ";
            SQLTransactions += "[Data With Opening Balance].[Account#], ";
            SQLTransactions += "[Data With Opening Balance].[Company#], ";
            SQLTransactions += "'' AS [Store#], ";
            SQLTransactions += "[Data With Opening Balance].[Account1#], ";
            SQLTransactions += "First([Data With Opening Balance].SubAccount) AS SubAccount, ";
            SQLTransactions += "First([Data With Opening Balance].Description) AS Description, ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  1]) AS [Period  1], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  2]) AS [Period  2], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  3]) AS [Period  3], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  4]) AS [Period  4], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  5]) AS [Period  5], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  6]) AS [Period  6], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  7]) AS [Period  7], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  8]) AS [Period  8], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period  9]) AS [Period  9], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period 10]) AS [Period 10], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period 11]) AS [Period 11], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period 12]) AS [Period 12], ";
            SQLTransactions += "Sum([Data With Opening Balance].[Period 13]) AS [Period 13], ";
            SQLTransactions += "Sum([Data With Opening Balance].BeginBal) AS BeginBal ";

            SQLTransactions += "FROM ";
            SQLTransactions += "[Data With Opening Balance] ";
            SQLTransactions += "WHERE ";
            SQLTransactions += "([Data With Opening Balance].[Company#]='";
            SQLTransactions += CompanyNumber.Fields[0].Value.ToString();
            SQLTransactions += "')";

            SQLTransactions += "GROUP BY ";
            SQLTransactions += "[Data With Opening Balance].[Account#],";
            SQLTransactions += "[Data With Opening Balance].[Company#],";
            SQLTransactions += "[Data With Opening Balance].[Account1#] ";

            return SQLTransactions;

        }   

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stRequiredEquity(ADODB.Recordset CompanyNumber)
        {
            string SQLRequiredEquity;

            // Required Equity Sheet
            SQLRequiredEquity = "SELECT ";
            SQLRequiredEquity += "[Required Equity].[1] AS [RequiredEquity P1], ";
            SQLRequiredEquity += "[Required Equity].[2] AS [RequiredEquity P2], ";
            SQLRequiredEquity += "[Required Equity].[3] AS [RequiredEquity P3], ";
            SQLRequiredEquity += "[Required Equity].[4] AS [RequiredEquity P4], ";
            SQLRequiredEquity += "[Required Equity].[5] AS [RequiredEquity P5], ";
            SQLRequiredEquity += "[Required Equity].[6] AS [RequiredEquity P6], ";
            SQLRequiredEquity += "[Required Equity].[7] AS [RequiredEquity P7], ";
            SQLRequiredEquity += "[Required Equity].[8] AS [RequiredEquity P8], ";
            SQLRequiredEquity += "[Required Equity].[9] AS [RequiredEquity P9], ";
            SQLRequiredEquity += "[Required Equity].[10] AS [RequiredEquity P10], ";
            SQLRequiredEquity += "[Required Equity].[11] AS [RequiredEquity P11], ";
            SQLRequiredEquity += "[Required Equity].[12] AS [RequiredEquity P12], ";
            SQLRequiredEquity += "[Required Equity].[13] AS [RequiredEquity P13] ";
            SQLRequiredEquity += "FROM ";
            SQLRequiredEquity += "(([Qry - Company Numbers To Process] ";
            SQLRequiredEquity += "Left JOIN ";
            SQLRequiredEquity += "[Required Equity] ";
            SQLRequiredEquity += "ON ";
            SQLRequiredEquity += "[Qry - Company Numbers To Process].[Co#] = [Required Equity].[Co#]) ";
            SQLRequiredEquity += "Left JOIN ";
            SQLRequiredEquity += "[Allowable Draw] ";
            SQLRequiredEquity += "On ";
            SQLRequiredEquity += "[Qry - Company Numbers To Process].[Co#] = [Allowable Draw].[Co#]) ";
            SQLRequiredEquity += "Left JOIN ";
            SQLRequiredEquity += "[Main Stores] ";
            SQLRequiredEquity += "On ";
            SQLRequiredEquity += "[Qry - Company Numbers To Process].[Co#] = [Main Stores].[Co#] ";
            SQLRequiredEquity += "WHERE ([Qry - Company Numbers To Process].[Co#]=";
            SQLRequiredEquity += CompanyNumber.Fields[0].Value.ToString();
            SQLRequiredEquity += " AND [Main Stores].[Co#] Is Not Null";
            SQLRequiredEquity += ");";

            return SQLRequiredEquity;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stLabels(ADODB.Recordset CompanyNumber)
        {
            string SQLLabels;

            // recordset to fill various labels such as names, company#, legal names, etc.
            SQLLabels = "SELECT ";
            SQLLabels += "[Qry - Company Numbers To Process].[Co#], ";
            SQLLabels += "[Main Stores].MAIN, ";
            SQLLabels += "[Main Stores].[Other stores], ";
            SQLLabels += "[Allowable Draw].[Associate Name], ";
            SQLLabels += "[Allowable Draw].[Legal Entity] ";
            SQLLabels += "FROM ";
            SQLLabels += "(([Qry - Company Numbers To Process] ";
            SQLLabels += "Left JOIN ";
            SQLLabels += "[Required Equity] ";
            SQLLabels += "ON ";
            SQLLabels += "[Qry - Company Numbers To Process].[Co#] = [Required Equity].[Co#]) ";
            SQLLabels += "Left JOIN ";
            SQLLabels += "[Allowable Draw] ";
            SQLLabels += "On ";
            SQLLabels += "[Qry - Company Numbers To Process].[Co#] = [Allowable Draw].[Co#]) ";
            SQLLabels += "Left JOIN ";
            SQLLabels += "[Main Stores] ";
            SQLLabels += "On ";
            SQLLabels += "[Qry - Company Numbers To Process].[Co#] = [Main Stores].[Co#] ";
            SQLLabels += "WHERE ([Qry - Company Numbers To Process].[Co#]=";
            SQLLabels += CompanyNumber.Fields[0].Value.ToString();
            SQLLabels += " AND [Main Stores].[Co#] Is Not Null";
            SQLLabels += ");";

            return SQLLabels;
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stFunctionCompanyNumber()
        {
            string stCompanyNumber;

            // Classic ADO company number query string
            stCompanyNumber = "SELECT ";
            stCompanyNumber += "[Qry - Company Numbers To Process].[Co#], ";
            stCompanyNumber += "[Main Stores].[Store No], ";
            stCompanyNumber += "[Main Stores].MAIN, ";
            stCompanyNumber += "[Main Stores].[Other stores], ";
            stCompanyNumber += "[Main Stores].[Final], ";
            stCompanyNumber += "[Allowable Draw].[Store No], ";
            stCompanyNumber += "[Allowable Draw].[Associate Name], ";
            stCompanyNumber += "[Allowable Draw].[Legal Entity], ";
            stCompanyNumber += "[Allowable Draw].[Region], ";
            stCompanyNumber += "[Allowable Draw].[VP], ";
            stCompanyNumber += "[Allowable Draw].[DM] ";
            stCompanyNumber += "FROM ";
            stCompanyNumber += "(([Qry - Company Numbers To Process] ";
            stCompanyNumber += "Left JOIN ";
            stCompanyNumber += "[Required Equity] ";
            stCompanyNumber += "ON ";
            stCompanyNumber += "[Qry - Company Numbers To Process].[Co#] = [Required Equity].[Co#]) ";
            stCompanyNumber += "Left JOIN ";
            stCompanyNumber += "[Allowable Draw] ";
            stCompanyNumber += "On ";
            stCompanyNumber += "[Qry - Company Numbers To Process].[Co#] = [Allowable Draw].[Co#]) ";
            stCompanyNumber += "Left JOIN ";
            stCompanyNumber += "[Main Stores] ";
            stCompanyNumber += "On ";
            stCompanyNumber += "[Qry - Company Numbers To Process].[Co#] = [Main Stores].[Co#] ";
            stCompanyNumber += "WHERE ([Main Stores].[Co#] Is Not Null)";

            return stCompanyNumber;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stFunctionPeriodEndDates()
        {
            string stPeriodEnd;

            stPeriodEnd = "SELECT ";
            stPeriodEnd += "[Period End Dates].PD, ";
            stPeriodEnd += "[Period End Dates].[Beg date], ";
            stPeriodEnd += "[Period End Dates].[End date] ";
            stPeriodEnd += "FROM ";
            stPeriodEnd += "[Period End Dates];";

            return stPeriodEnd;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stOpeningBalance()
        {
            string stOpeningBalance;

            stOpeningBalance = "SELECT ";
            stOpeningBalance += "BegBalData.[Company#], ";
            stOpeningBalance += "Sum(BegBalData.[Open Bal]) AS [Open Bal] ";
            stOpeningBalance += "FROM ";
            stOpeningBalance += "BegBalData ";
            stOpeningBalance += "GROUP BY ";
            stOpeningBalance += "BegBalData.[Company#] ";
            stOpeningBalance += "HAVING ";
            stOpeningBalance += "(sum(BegBalData.[Open Bal]) Is Not Null) ";




            return stOpeningBalance;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string stFunctionAllowableDraw()
        {
            string stAllowableDraw;

            //stAllowableDraw = "SELECT ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Store No], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Co#], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Associate Name], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Legal Entity], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Start Date of New Co], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[1], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[2], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[3], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[4], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[5], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[6], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[7], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[8], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[9], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[10], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[11], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[12], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[13], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 1 - Current], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 2 - Next increase], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 3 - Next increase], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 4 - Next increase], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 5 - Next increase], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Term 6 - Next increase], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 1], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 2], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 3], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 4], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 5], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 6], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Comments (To show on Optional Equity)], ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Other Comments (RAD purpose only)] ";
            //stAllowableDraw += "FROM ";
            //stAllowableDraw += "[Allow Draw - Annual Amount] ";
            //stAllowableDraw += "WHERE ";
            //stAllowableDraw += "[Allow Draw - Annual Amount].[Co#] IS NOT NULL ";



            stAllowableDraw = "SELECT ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Store No], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Co#], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Associate Name], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Legal Entity], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Start Date of New Co], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 1 - Current], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 2 - Next increase], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 3 - Next increase], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 4 - Next increase], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 5 - Next increase], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Term 6 - Next increase], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 1], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 2], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 3], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 4], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 5], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Yrly rate -Term 6], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Comments (To show on Optional Equity)], ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Other Comments (RAD purpose only)] ";
            stAllowableDraw += "FROM ";
            stAllowableDraw += "[Allow Draw - Annual Amount] ";
            stAllowableDraw += "WHERE ";
            stAllowableDraw += "[Allow Draw - Annual Amount].[Co#] IS NOT NULL ";



            return stAllowableDraw;

        }

    }

}

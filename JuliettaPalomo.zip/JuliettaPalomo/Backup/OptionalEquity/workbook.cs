﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using System.Reflection;
using System.Windows.Forms;

namespace OptionalEquity
{
    class Workbook : Data
    {
        // Excel variables
        private Excel.Application objApp;
        private Excel._Workbook objBookFinalized;
        private Excel._Workbook objBookNonFinalized;
        private Excel.Workbooks objBooks; 

        //this variable collects the reconciliation lines
        private Lines ReconciliationSummary; 
        
        // Constructor ...
        public Workbook(string FinalizedTemplateLocation,
                        string NonFinalizedTemplateLocation,
                        string AccessDataBaseLocation,
                        string OutputDirectoryFinalized,
                        string OutputDirectoryNonFinalized,
                        int Period,
                        int Year): base(FinalizedTemplateLocation,
                                        NonFinalizedTemplateLocation,
                                        AccessDataBaseLocation,
                                        OutputDirectoryFinalized,
                                        OutputDirectoryNonFinalized,
                                        Period,
                                        Year){}

        
        /// <summary>
        /// Main procedure for processing optional equity Excel files.
        /// </summary>
        public void ProcessExcelFiles(short CheckedState, 
                                       double statusProgressValue,
                                       OptionalEquity MainForm)  
                          // Note: the "OptionalEquity" is the our main Form class
      
        {
            // open all connections ...
            base.InitiateCOMDatasets();
            base.InitiateDotNETDataSets();

            
            if (!(base._FinalizedTemplateLocation == "" || 
                    base._NonFinalizedTemplateLocation == "" || 
                    base._AccessDataBaseLocation == "" || 
                    base._OutputDirectoryFinalized == "")) {


                // initialize the Excel Application class
                objApp = new Excel.Application();
                objBooks = objApp.Workbooks;

                objBookFinalized = objBooks.Open(
                            base._FinalizedTemplateLocation,
                            false, true, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing);

                objBookNonFinalized = objBooks.Open(
                            base._NonFinalizedTemplateLocation,
                            false, true, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                            Type.Missing, Type.Missing);

                ReconciliationSummary = new Lines();
              // DeficientLines deficentlines = new DeficientLines();

                Worksheets worksheets;

                MainForm.ToggleStatus();
                MainForm.Refresh();

                // start operation
                for (int i = 0; i < CompanyNumberRst.RecordCount; i++)
                {

                    MainForm.SetProgressBarValues(i, CompanyNumberRst.RecordCount - 1);

                    string FileNameToSave;

                    if (!(CompanyNumberRst.Fields["Final"].Value.ToString() == ""))
                    {
                        objBookFinalized.Activate();

                        worksheets = new Worksheets(objBookFinalized, 
                                                    cnn, CompanyNumberRst, 
                                                    ds, ReconciliationSummary,
                                                    CheckedState);

                        FileNameToSave =
                            base._OutputDirectoryFinalized + "\\SDM" +
                            CompanyNumberRst.Fields["Main"].Value +
                            " " + CompanyNumberRst.Fields["Associate Name"].Value + " Co"
                            + CompanyNumberRst.Fields["Co#"].Value +
                            " - OpEq " + "P" + base._Period + " - " + base._Year + ".xls";

                        // Note: the attribute xlExcel9795 is the most recent one , the xlExcel7 attribute
                        //       will cause the date format to be lost.
                        objBookFinalized.SaveAs(FileNameToSave,
                              Excel.XlFileFormat.xlExcel9795, Missing.Value, Missing.Value,
                              false, false, Excel.XlSaveAsAccessMode.xlNoChange,
                              Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

                    }
                    else
                    {
                        objBookNonFinalized.Activate();

                        worksheets = new Worksheets(objBookNonFinalized, 
                                                    cnn, CompanyNumberRst, 
                                                    ds, ReconciliationSummary,
                                                    CheckedState);

                        FileNameToSave =
                            base._OutputDirectoryNonFinalized + "\\SDM" +
                            CompanyNumberRst.Fields["Main"].Value +
                            " " + CompanyNumberRst.Fields["Associate Name"].Value + " Co"
                            + CompanyNumberRst.Fields["Co#"].Value +
                            " - OpEq " + "P" + base._Period + " - " + base._Year + ".xls";

                        // Note: the attribute xlExcel9795 is the most recent one , the xlExcel7 attribute
                        //       will cause the date format to be lost.
                        objBookNonFinalized.SaveAs(FileNameToSave,
                              Excel.XlFileFormat.xlExcel9795, Missing.Value, Missing.Value,
                              false, false, Excel.XlSaveAsAccessMode.xlNoChange,
                              Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

                    }
                    
                    MainForm.RefreshProgressBar();
                    System.GC.Collect();
                    CompanyNumberRst.MoveNext();
                }

                    objBookFinalized.Close(false, Missing.Value, Missing.Value);
                    objBookNonFinalized.Close(false, Missing.Value, Missing.Value);
                    objApp.Quit();

                    System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(ReconciliationSummary.GetType());
                    x.Serialize(File.Create(System.Environment.CurrentDirectory + "\\AllowableDrawReconc.xml"), ReconciliationSummary);

                    //MainForm.KillProgressBar();
                    //MainForm.KillStatusLabel();
                    MessageBox.Show("All Done !");
            }

            else
            {
                if (base._FinalizedTemplateLocation == "")
                    MessageBox.Show("Finalized Template File cannot be blank...");
                if (base._NonFinalizedTemplateLocation == "")
                    MessageBox.Show("Non-Finalized Template File cannot be blank...");
                if (base._AccessDataBaseLocation == "")
                    MessageBox.Show("Access DataBase File cannot be blank...");
                if (base._OutputDirectoryFinalized == "")
                    MessageBox.Show("File output location cannot be blank...");
             }
        }
    }
 }


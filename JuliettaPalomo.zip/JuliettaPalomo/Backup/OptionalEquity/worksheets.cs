﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data;
using System.Reflection;
using System.Windows.Forms;


namespace OptionalEquity
{
    class Worksheets
    {
        #region Variables ...
        // ADO data connection declaration
        private ADODB.Connection _cnn;
        private ADODB.Recordset _CompanyNumber;
        private int iCompanyNumber;
        private DataRow ADO_Cursor;  // this is used as a main unit of operation, i.e., this worksheet operation is on a per record basis.

        // Excel Worksheets declaration
        private Excel.Application _objApp;
        private Excel.Sheets _objSheets;
        private Excel._Worksheet _objSheetTransactions;
        private Excel._Worksheet _objSheetOptinalEquity;
        private Excel._Worksheet _objSheetAssociateDraw;
        private Excel._Worksheet _objSheetMain;
        private DataSet _ds;
        private Lines _ReconciliationSummary;
        private short _PrintExcelWorkBookCheckedState = 0;

        private object Term1Date;
        private object Term2Date;
        private object Term3Date;
        private object Term4Date;
        private object Term5Date;
        private object Term6Date;

        private object Term1Amount;
        private object Term2Amount;
        private object Term3Amount;
        private object Term4Amount;
        private object Term5Amount;
        private object Term6Amount;
        #endregion

        // Constructor ...
      public Worksheets(Excel._Workbook workbook, 
                    ADODB.Connection cnn,
                    ADODB.Recordset CompanyNumber, 
                    DataSet ds, 
                    Lines ReconciliationSummary,
                    short CheckedState) {
        
            // initialized variables
            _objApp = (Excel.Application) workbook.Parent;
            _cnn = cnn;
            _CompanyNumber = CompanyNumber;
            _ds = ds;
            _ReconciliationSummary = ReconciliationSummary;
            _PrintExcelWorkBookCheckedState = CheckedState;
            iCompanyNumber = int.Parse(_CompanyNumber.Fields[0].Value.ToString());

            // locate the record
            ADO_Cursor = _ds.Tables["AllowableDraw"].Rows.Find(iCompanyNumber);

            // rename the fields in the cursor to make them more readible.
            // this is also done to standardize field names away from user field names. 

            // date fields
            Term1Date = ADO_Cursor["Term 1 - Current"];
            Term2Date = ADO_Cursor["Term 2 - Next increase"];
            Term3Date = ADO_Cursor["Term 3 - Next increase"];
            Term4Date = ADO_Cursor["Term 4 - Next increase"];
            Term5Date = ADO_Cursor["Term 5 - Next increase"];
            Term6Date = ADO_Cursor["Term 6 - Next increase"];


            // amount fields
            Term1Amount = ADO_Cursor["Yrly rate -Term 1"];
            Term2Amount = ADO_Cursor["Yrly rate -Term 2"];
            Term3Amount = ADO_Cursor["Yrly rate -Term 3"];
            Term4Amount = ADO_Cursor["Yrly rate -Term 4"];
            Term5Amount = ADO_Cursor["Yrly rate -Term 5"];
            Term6Amount = ADO_Cursor["Yrly rate -Term 6"];


            // Initialize the sheets
            _objSheets = _objApp.Worksheets;
            _objSheetTransactions = (Excel._Worksheet)_objSheets.get_Item("Transactions");
            _objSheetOptinalEquity = (Excel._Worksheet)_objSheets.get_Item("Optional Equity");
            _objSheetAssociateDraw = (Excel._Worksheet)_objSheets.get_Item("Associate Draw");
            _objSheetMain = (Excel._Worksheet)_objSheets.get_Item("main");

            // execute methods.
            this.Populate_Worksheet_ADO();
            this.Populate_Allowable_Draw(ReconciliationSummary);

            // print out the sheets as per Jinky's request.
            if (_PrintExcelWorkBookCheckedState == 1)
            {
                _objSheetOptinalEquity.Activate();
                _objSheetOptinalEquity.PrintOut(1, 1, 1, false, Type.Missing, false, false, Type.Missing);
                _objSheetAssociateDraw.Activate();
                _objSheetAssociateDraw.PrintOut(1, 1, 1, false, Type.Missing, false, false, Type.Missing);
            }

        }


        /// <summary>
        /// setup a class ADO COM object to dump a set of data into Excel
        /// Classic ADO is more efficient in a situation
        /// where we need to dump a whole block of data into an Excel Sheet
        /// </summary>
        void Populate_Worksheet_ADO()
      {
            #region Variables ...
            // Excel Range Variables.
            Excel.Range rgRequiredEquity;
            Excel.Range rgTransactions;
            Excel.Range rgAssociateName;
            Excel.Range rgLegalEntity;
            Excel.Range rgMainStoreNumber;
            Excel.Range rgSecondaryStoreNumber;
            Excel.Range rgCompanyNumber;
            #endregion

            //Transaction data range
            rgTransactions = _objSheetTransactions.get_Range("A4", "A4");

            // Optional Equity data range
            rgRequiredEquity = _objSheetOptinalEquity.get_Range("F25", "F25");
            rgSecondaryStoreNumber = _objSheetOptinalEquity.get_Range("D7", "D7");

            // Main data range
            rgAssociateName = _objSheetMain.get_Range("D2", "D2");
            rgLegalEntity = _objSheetMain.get_Range("D3", "D3");
            rgMainStoreNumber = _objSheetMain.get_Range("B2", "B2");
            rgCompanyNumber = _objSheetMain.get_Range("B3", "B3");

            ADODB.Recordset rst = new ADODB.Recordset();

            // Transaction sheet data fill
            rst.Open(SQL.stTransaction(_CompanyNumber), _cnn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 0);
            rgTransactions.CopyFromRecordset(rst, rst.RecordCount, rst.Fields.Count);
            rst.Close();


            // Optional Equity sheet data fill
            rst.Open(SQL.stRequiredEquity(_CompanyNumber), _cnn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 0);
            rgRequiredEquity.CopyFromRecordset(rst, rst.RecordCount, rst.Fields.Count);
            rst.Close();

            // Main sheet data fill
            rst.Open(SQL.stLabels(_CompanyNumber), _cnn, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 0);
            rgAssociateName.Value2 = rst.Fields["Associate Name"].Value;
            rgLegalEntity.Value2 = rst.Fields["Legal Entity"].Value;
            rgMainStoreNumber.Value2 = rst.Fields["Main"].Value;
            rgSecondaryStoreNumber.Value2 = rst.Fields["Other Stores"].Value;
            rgCompanyNumber.Value2 = rst.Fields["Co#"].Value;
            rst.Close();
        }


        /// <summary>
        /// This method populates the Allowance Draw line and the Summary Box
        /// </summary>
        void Populate_Allowable_Draw(Lines ReconciliationSummary)
        {

            #region Variables ...
            DateTime PeriodBeginDate;
            DateTime PeriodEndDate;
            int NumberOfDays = 0;
            int NumberOfDaysinYear = 364;
            DateTime TermDate;

            double TermAmountToAllocate = 0;
            double PreviousTermAmountToAllocate = 0;
            double ApportionFactor = 0;

            // for summary box
            int BeginningPeriod = 0;
            int EndingPeriod = 0;
            int BoxRowWritten = 1;
            int DaysToAllocate = 0;
            int DaysToAllocateCummulative = 0;
            int SummaryBoxExcelStartingRow = 57;
            int SummaryBoxExcelRow = SummaryBoxExcelStartingRow;  // this is the start row of the range
            DateTime BeginningTermDate;
            DateTime EndingTermDate;

            // to work with the array ranges for purpose of temporary data storage.
            Object[,] rgAllowableDrawLine;
            Object[,] rgSummaryBox;
            #endregion

            rgAllowableDrawLine = (Object[,])((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("C49", "O49").get_Value(Missing.Value);
            rgSummaryBox = (Object[,])((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("A57", "D62").Formula;   // Summary box range

            // Period variables and initiation
            double[] PeriodAmounts = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            try
            {
                // process the first term
                if ((Term1Amount.ToString() != "") &&
                    Term1Date.ToString() != "")
                {
                    TermDate = DateTime.Parse(Term1Date.ToString());
                    TermAmountToAllocate = (double)Term1Amount;

                    // LOOP through the period end table
                    for (int i = 0; i < 13; i++)
                    {
                        PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                        PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];
                        NumberOfDays = (PeriodEndDate - PeriodBeginDate).Days + 1;

                        if (PeriodBeginDate <= TermDate && TermDate <= PeriodEndDate)
                        {
                            ApportionFactor = (PeriodEndDate - TermDate).Days + 1;
                            PeriodAmounts[i] = TermAmountToAllocate * ApportionFactor / NumberOfDaysinYear;

                            // fill the rest
                            for (int a = i + 1; a < 13; a++)
                                PeriodAmounts[a] = TermAmountToAllocate * NumberOfDays / NumberOfDaysinYear + PeriodAmounts[a - 1];
                        }
                    }

                }

                // process the second term
                if ((Term2Amount.ToString() != "")
                     && Term2Date.ToString() != "")
                {
                    TermDate = DateTime.Parse(Term2Date.ToString());

                    if (Term2Amount.ToString() == "")
                        TermAmountToAllocate = 0;
                    else
                        TermAmountToAllocate = double.Parse(Term2Amount.ToString());

                    if (Term1Amount.ToString() == "")
                        PreviousTermAmountToAllocate = 0;
                    else
                        PreviousTermAmountToAllocate = double.Parse(Term1Amount.ToString());


                    // LOOP through the period end table
                    for (int i = 0; i < 13; i++)
                    {
                        PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                        PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];
                        NumberOfDays = (PeriodEndDate - PeriodBeginDate).Days + 1;

                        if (PeriodBeginDate <= TermDate && TermDate <= PeriodEndDate)
                        {
                            ApportionFactor = (PeriodEndDate - TermDate).Days + 1;

                            // second term date falls in the 2nd period and beyond
                            if (i > 0)
                                PeriodAmounts[i] =
                                    TermAmountToAllocate / 13 * (ApportionFactor / NumberOfDays)
                                    + PreviousTermAmountToAllocate / 13 * (1 - ApportionFactor / NumberOfDays)
                                    + PeriodAmounts[i - 1];

                            else

                            /*   
                              the second term date could start during the 1st period
                              in which case, you need to go back and adjust the first period. 
                              The first period have a term date at the beginning of the year
                              and was calculated term 1 above using the full 28 days
                                  
                              i = 0 meaning the second term starts at the first period.
                              we are now adjusting the first period amount
                           */
                            {
                                ApportionFactor = (PeriodEndDate - TermDate).Days + 1; // second term date starts at 1st period

                                PeriodAmounts[i] =
                                    TermAmountToAllocate / 13 * (ApportionFactor / NumberOfDays)  /* Second term portion  */
                                    + PreviousTermAmountToAllocate / 13 * (1 - ApportionFactor / NumberOfDays);  /* First term portion*/
                            }

                            // once done the initial period, fill the rest to end of year
                            for (int a = i + 1; a < 13; a++)
                                PeriodAmounts[a] = TermAmountToAllocate * NumberOfDays / NumberOfDaysinYear + PeriodAmounts[a - 1];
                        }
                    }
                }


                // process the third term
                if ((Term3Amount.ToString() != "") &&
                     Term3Date.ToString() != "")
                {

                    TermDate = DateTime.Parse(Term3Date.ToString());

                    if (Term3Amount.ToString() == "")
                    {
                        TermAmountToAllocate = 0;
                    }
                    else
                    {
                        TermAmountToAllocate = double.Parse(Term3Amount.ToString());
                    }

                    if (Term2Amount.ToString() == "")
                    {
                        PreviousTermAmountToAllocate = 0;
                    }
                    else
                    {
                        PreviousTermAmountToAllocate = double.Parse(Term2Amount.ToString());
                    }

                    // LOOP through the period end table
                    for (int i = 0; i < 13; i++)
                    {
                        PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                        PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];
                        NumberOfDays = (PeriodEndDate - PeriodBeginDate).Days + 1;

                        // found the term date between the period
                        // note: the contends of this For LOOP only execute once
                        // when the TermDate fall within the period range.
                        if (PeriodBeginDate <= TermDate && TermDate <= PeriodEndDate)
                        {
                            ApportionFactor = (PeriodEndDate - TermDate).Days + 1;

                            // third term date starts at least in the 2nd period
                            if (i > 0)
                                PeriodAmounts[i] =
                                    TermAmountToAllocate / 13 * (ApportionFactor / NumberOfDays)
                                    + PreviousTermAmountToAllocate / 13 * (1 - ApportionFactor / NumberOfDays)
                                    + PeriodAmounts[i - 1];
                            /*
                             the third term date could start during the 1st period
                             in which case, there is nothing to accumulate
                            */
                            else
                                PeriodAmounts[i] =
                                    TermAmountToAllocate * ApportionFactor / NumberOfDaysinYear;

                            // once done the initial period, fill the rest to end of year
                            for (int a = i + 1; a < 13; a++)
                                PeriodAmounts[a] = TermAmountToAllocate * NumberOfDays / NumberOfDaysinYear + PeriodAmounts[a - 1];
                        }

                    }

                }


                // process the fourth term
                if ((ADO_Cursor["Yrly rate -Term 4"].ToString() != "") &&
                    Term4Date.ToString() != "")
                {

                    TermDate = DateTime.Parse(Term4Date.ToString());

                    if (Term4Amount.ToString() == "")
                    {
                        TermAmountToAllocate = 0;
                    }
                    else
                    {
                        TermAmountToAllocate = double.Parse(Term4Amount.ToString());
                    }

                    if (Term3Amount.ToString() == "")
                    {
                        PreviousTermAmountToAllocate = 0;
                    }
                    else
                    {
                        PreviousTermAmountToAllocate = double.Parse(Term3Amount.ToString());
                    }



                    // LOOP through the period end table
                    for (int i = 0; i < 13; i++)
                    {
                        PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                        PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];
                        NumberOfDays = (PeriodEndDate - PeriodBeginDate).Days + 1;

                        if (PeriodBeginDate <= TermDate && TermDate <= PeriodEndDate)
                        {
                            ApportionFactor = (PeriodEndDate - TermDate).Days + 1;

                            // fourth term date starts at least in the 2nd period
                            if (i > 0)
                                PeriodAmounts[i] =
                                    TermAmountToAllocate / 13 * (ApportionFactor / NumberOfDays)
                                    + PreviousTermAmountToAllocate / 13 * (1 - ApportionFactor / NumberOfDays)
                                    + PeriodAmounts[i - 1];
                            /*
                             the fourth term date could start during the 1st period
                             in which case, there is nothing to accumulate
                            */
                            else
                                PeriodAmounts[i] =
                                    TermAmountToAllocate * ApportionFactor / NumberOfDaysinYear;

                            // once done the initial period, fill the rest to end of year
                            for (int a = i + 1; a < 13; a++)
                                PeriodAmounts[a] = TermAmountToAllocate * NumberOfDays / NumberOfDaysinYear + PeriodAmounts[a - 1];
                        }
                    }

                }


                // process the fifth term
                if ((Term5Amount.ToString() != "") &&
                    Term5Date.ToString() != "")
                {
                
                    TermDate = DateTime.Parse(Term5Date.ToString());

                    if (Term5Amount.ToString() == "")
                        TermAmountToAllocate = 0;
                    else
                        TermAmountToAllocate = double.Parse(Term5Amount.ToString());

                    if (Term4Amount.ToString() == "")
                        PreviousTermAmountToAllocate = 0;
                    else
                        PreviousTermAmountToAllocate = double.Parse(Term4Amount.ToString());


                    // LOOP through the period end table
                    for (int i = 0; i < 13; i++)
                    {
                        PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                        PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];
                        NumberOfDays = (PeriodEndDate - PeriodBeginDate).Days + 1;

                        // found the term date between the period
                        // note: the contends of this For LOOP only execute once
                        // when the TermDate fall within the period range.
                        if (PeriodBeginDate <= TermDate && TermDate <= PeriodEndDate)
                        {
                            ApportionFactor = (PeriodEndDate - TermDate).Days + 1;

                            // fifth term date starts at least in the 2nd period
                            if (i > 0)
                                PeriodAmounts[i] =
                                    TermAmountToAllocate / 13 * (ApportionFactor / NumberOfDays)
                                    + PreviousTermAmountToAllocate / 13 * (1 - ApportionFactor / NumberOfDays)
                                    + PeriodAmounts[i - 1];
                            /*
                             the fifth term date could start during the 1st period
                             in which case, there is nothing to accumulate
                            */
                            else
                                PeriodAmounts[i] =
                                    TermAmountToAllocate * ApportionFactor / NumberOfDaysinYear;

                            // once done the initial period, fill the rest to end of year
                            for (int a = i + 1; a < 13; a++)
                                PeriodAmounts[a] = TermAmountToAllocate * NumberOfDays / NumberOfDaysinYear + PeriodAmounts[a - 1];
                        }
                    }

                }

                // after the adjustments, now fill the array
                for (int i = 0; i < 13; i++)
                    rgAllowableDrawLine[1, i + 1] = PeriodAmounts[i];

                // Finally, copy to the Excel range
                ((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("C49", "O49").Formula = rgAllowableDrawLine;

                #region "Process Summary Box Down in the Excel Sheet"

                // Fill the Summary Box ...

                // create a 6 x 4 box range
                // clear the ArrayRangeSummaryBox array.
                for (int j = 1; j < 6; j++)
                    for (int k = 1; k < 4; k++)
                        rgSummaryBox[j, k] = "";


                // the box algorithm won't be executed if there is no term 1 date
                if ((Term1Date.ToString() != ""))
                {
                    // fist entry in the box
                    if ((Term2Date.ToString() != ""))  // if there are more terms than the current term, accummulate the dates
                    {
                        TermAmountToAllocate = double.Parse(Term1Amount.ToString());

                        // if the term amount is zero, do not use a line in summary box
                        if (TermAmountToAllocate != 0)
                        {
                            BeginningTermDate = (DateTime)Term1Date;
                            EndingTermDate = ((DateTime)Term2Date).AddDays(-1);

                            for (int i = 0; i < 13; i++)
                            {
                                PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                                PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];

                                if (BeginningTermDate >= PeriodBeginDate && BeginningTermDate <= PeriodEndDate)
                                    BeginningPeriod = i + 1;

                                if (EndingTermDate >= PeriodBeginDate && EndingTermDate <= PeriodEndDate)
                                    EndingPeriod = i + 1;

                            }


                            DaysToAllocate = (EndingTermDate - BeginningTermDate).Days + 1;

                            rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P" + EndingPeriod;
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocate + "/" + NumberOfDaysinYear;

                            BoxRowWritten++;

                            DaysToAllocateCummulative += DaysToAllocate;
                        }
                    }
                    else
                    {
                        TermAmountToAllocate = double.Parse(Term1Amount.ToString());

                        if (TermAmountToAllocate != 0)
                        {
                            // this is the only term, no other terms exist.
                            rgSummaryBox[BoxRowWritten, 1] = "P1 - P13";
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + "13/13";
                            BoxRowWritten++;
                        }
                    }


                    // second entry in the box
                    if ((Term3Date.ToString() != ""))
                    {
                        TermAmountToAllocate = double.Parse(Term2Amount.ToString());

                        if (TermAmountToAllocate != 0)
                        {
                            BeginningTermDate = (DateTime)Term2Date;
                            EndingTermDate = ((DateTime)Term3Date).AddDays(-1);

                            for (int i = 0; i < 13; i++)
                            {
                                PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                                PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];


                                if (BeginningTermDate >= PeriodBeginDate && BeginningTermDate <= PeriodEndDate)
                                    BeginningPeriod = i + 1;

                                if (EndingTermDate >= PeriodBeginDate && EndingTermDate <= PeriodEndDate)
                                    EndingPeriod = i + 1;

                            }

                            DaysToAllocate = ((DateTime)Term3Date - (DateTime)Term2Date).Days;

                            rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P" + EndingPeriod;
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocate + "/" + NumberOfDaysinYear;
                            BoxRowWritten++;

                            DaysToAllocateCummulative += DaysToAllocate;
                        }
                    }
                    else
                    {
                        if ((Term2Date.ToString() != ""))
                        {
                            TermAmountToAllocate = double.Parse(Term2Amount.ToString());

                            if (TermAmountToAllocate != 0)
                            {
                                BeginningTermDate = (DateTime)Term2Date;
                                DaysToAllocateCummulative = NumberOfDaysinYear - BeginningTermDate.DayOfYear - 1;

                                for (int i = 0; i < 13; i++)
                                {
                                    PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];

                                    if (PeriodBeginDate <= BeginningTermDate)
                                        BeginningPeriod = i + 1;

                                }

                                rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P13";
                                rgSummaryBox[BoxRowWritten, 2] = Term2Amount;
                                rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocateCummulative + "/" + NumberOfDaysinYear;
                                BoxRowWritten++;
                            }
                        }
                    }


                    // third entry in the box
                    if ((Term4Date.ToString() != ""))
                    {
                        TermAmountToAllocate = double.Parse(Term3Amount.ToString());

                        if (TermAmountToAllocate != 0)
                        {
                            BeginningTermDate = (DateTime)Term3Date;
                            EndingTermDate = ((DateTime)Term4Date).AddDays(-1);

                            for (int i = 0; i < 13; i++)
                            {
                                PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                                PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];

                                if (BeginningTermDate >= PeriodBeginDate && BeginningTermDate <= PeriodEndDate)
                                    BeginningPeriod = i + 1;

                                if (EndingTermDate >= PeriodBeginDate && EndingTermDate <= PeriodEndDate)
                                    EndingPeriod = i + 1;

                            }

                            DaysToAllocate = ((DateTime)Term4Date - (DateTime)Term3Date).Days;

                            rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P" + EndingPeriod;
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocate + "/" + NumberOfDaysinYear;
                            BoxRowWritten++;

                            DaysToAllocateCummulative += DaysToAllocate;
                        }
                    }
                    else
                    {
                        if ((Term3Date.ToString() != ""))
                        {
                            TermAmountToAllocate = double.Parse(Term3Amount.ToString());

                            if (TermAmountToAllocate != 0)
                            {
                                EndingTermDate = (DateTime)Term3Date;
                                DaysToAllocateCummulative = NumberOfDaysinYear - EndingTermDate.DayOfYear - 1;

                                for (int i = 0; i < 13; i++)
                                {
                                    PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];

                                    if (PeriodBeginDate <= EndingTermDate)
                                        BeginningPeriod = i + 1;

                                }

                                rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P13";
                                rgSummaryBox[BoxRowWritten, 2] = Term3Amount;
                                rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocateCummulative + "/" + NumberOfDaysinYear;
                                BoxRowWritten++;

                            }
                        }
                    }


                    // fourth entry in the box
                    if ((Term5Date.ToString() != ""))
                    {
                        TermAmountToAllocate = double.Parse(Term4Amount.ToString());

                        if (TermAmountToAllocate != 0)
                        {
                            BeginningTermDate = (DateTime)Term4Date;
                            EndingTermDate = ((DateTime)Term5Date).AddDays(-1);

                            for (int i = 0; i < 13; i++)
                            {
                                PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                                PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];

                                if (BeginningTermDate >= PeriodBeginDate && BeginningTermDate <= PeriodEndDate)
                                    BeginningPeriod = i + 1;

                                if (EndingTermDate >= PeriodBeginDate && EndingTermDate <= PeriodEndDate)
                                    EndingPeriod = i + 1;
                            }

                            DaysToAllocate = ((DateTime)Term5Date - (DateTime)Term4Date).Days;

                            rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P" + EndingPeriod;
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocate + "/" + NumberOfDaysinYear;
                            BoxRowWritten++;

                            DaysToAllocateCummulative += DaysToAllocate;


                        }
                    }
                    else
                    {
                        if ((Term4Date.ToString() != ""))
                        {
                            TermAmountToAllocate = double.Parse(Term4Amount.ToString());

                            if (TermAmountToAllocate != 0)
                            {
                                BeginningTermDate = (DateTime)Term4Date;
                                DaysToAllocateCummulative = NumberOfDaysinYear - BeginningTermDate.DayOfYear - 1;

                                for (int i = 0; i < 13; i++)
                                {
                                    PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];

                                    if (PeriodBeginDate <= BeginningTermDate)
                                        BeginningPeriod = i + 1;

                                }

                                rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P13";
                                rgSummaryBox[BoxRowWritten, 2] = Term4Amount;
                                rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocateCummulative + "/" + NumberOfDaysinYear;
                                BoxRowWritten++;

                            }
                        }
                    }


                    // fifth entry in the box
                    if ((Term6Date.ToString() != ""))
                    {
                        TermAmountToAllocate = double.Parse(Term5Amount.ToString());

                        if (TermAmountToAllocate != 0)
                        {
                            BeginningTermDate = (DateTime)Term5Date;
                            EndingTermDate = ((DateTime)Term6Date).AddDays(-1);

                            for (int i = 0; i < 13; i++)
                            {
                                PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];
                                PeriodEndDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][2];

                                if (BeginningTermDate >= PeriodBeginDate && BeginningTermDate <= PeriodEndDate)
                                    BeginningPeriod = i + 1;

                                if (EndingTermDate >= PeriodBeginDate && EndingTermDate <= PeriodEndDate)
                                    EndingPeriod = i + 1;
                            }

                            DaysToAllocate = ((DateTime)Term6Date - (DateTime)Term5Date).Days;

                            rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P" + EndingPeriod;
                            rgSummaryBox[BoxRowWritten, 2] = TermAmountToAllocate;
                            rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocate + "/" + NumberOfDaysinYear;
                            BoxRowWritten++;


                            DaysToAllocateCummulative += DaysToAllocate;
                        }
                    }
                    else
                    {
                        if ((Term5Date.ToString() != ""))
                        {
                            TermAmountToAllocate = double.Parse(Term5Amount.ToString());

                            if (TermAmountToAllocate != 0)
                            {
                                BeginningTermDate = (DateTime)Term5Date;
                                DaysToAllocateCummulative = NumberOfDaysinYear - BeginningTermDate.DayOfYear - 1;

                                for (int i = 0; i < 13; i++)
                                {
                                    PeriodBeginDate = (DateTime)_ds.Tables["PeriodEndDates"].Rows[i][1];

                                    if (PeriodBeginDate <= BeginningTermDate)
                                        BeginningPeriod = i + 1;

                                }

                                rgSummaryBox[BoxRowWritten, 1] = "P" + BeginningPeriod + " - P13";
                                rgSummaryBox[BoxRowWritten, 2] = Term5Amount;
                                rgSummaryBox[BoxRowWritten, 3] = "=B" + SummaryBoxExcelRow++.ToString() + "*" + DaysToAllocateCummulative + "/" + NumberOfDaysinYear;
                                BoxRowWritten++;

                            }
                        }
                    }

                    rgSummaryBox[1, 4] = ADO_Cursor["Comments (To show on Optional Equity)"].ToString();
                    ((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("A57", "D62").Formula = rgSummaryBox;

                    _objApp.Calculate();  // force re-calculation to update all totals
                    
                    ReconciledLine newline = new ReconciledLine();

                    newline.CompanyNumber = int.Parse(ADO_Cursor["Co#"].ToString());
                    newline.TotalAllowableDraw = double.Parse(((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("O49", "O49").Text.ToString());
                    newline.TotalSummaryBox = double.Parse(((Excel._Worksheet)_objSheets.get_Item("Associate Draw")).get_Range("C63", "C63").Text.ToString());
                    newline.ReconciliationAmount = 0;

                    _ReconciliationSummary.Add(newline);
                    ReconciliationSummary = _ReconciliationSummary;  // re-assign back to sender parameter

                }
                #endregion

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

    }
}

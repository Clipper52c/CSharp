﻿namespace SettlementLetters
{
    partial class JuliettaSettlementLetters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(JuliettaSettlementLetters));
            this.txFile = new System.Windows.Forms.TextBox();
            this.cmdOpen = new System.Windows.Forms.Button();
            this.cmdProcessSettlementLetters = new System.Windows.Forms.Button();
            this.cmdExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmdOpenFolder = new System.Windows.Forms.Button();
            this.txtLawsonFiles = new System.Windows.Forms.TextBox();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmdOpenCompletedLocation = new System.Windows.Forms.Button();
            this.txtCompletedFiles = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmdOpenTemplateFile = new System.Windows.Forms.Button();
            this.txTemplateFile = new System.Windows.Forms.TextBox();
            this.cmdLawsonXMLSummary = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.cbLawsonReport = new System.Windows.Forms.ComboBox();
            this.ckBoxPeer = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txFile
            // 
            this.txFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txFile.Location = new System.Drawing.Point(52, 184);
            this.txFile.Name = "txFile";
            this.txFile.ReadOnly = true;
            this.txFile.Size = new System.Drawing.Size(581, 20);
            this.txFile.TabIndex = 0;
            this.txFile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txFile_KeyPress);
            // 
            // cmdOpen
            // 
            this.cmdOpen.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpen.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpen.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpen.Image")));
            this.cmdOpen.Location = new System.Drawing.Point(651, 184);
            this.cmdOpen.Name = "cmdOpen";
            this.cmdOpen.Size = new System.Drawing.Size(24, 20);
            this.cmdOpen.TabIndex = 1;
            this.cmdOpen.UseVisualStyleBackColor = false;
            this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
            // 
            // cmdProcessSettlementLetters
            // 
            this.cmdProcessSettlementLetters.BackColor = System.Drawing.SystemColors.Control;
            this.cmdProcessSettlementLetters.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdProcessSettlementLetters.ForeColor = System.Drawing.Color.Blue;
            this.cmdProcessSettlementLetters.Location = new System.Drawing.Point(52, 355);
            this.cmdProcessSettlementLetters.Name = "cmdProcessSettlementLetters";
            this.cmdProcessSettlementLetters.Size = new System.Drawing.Size(223, 25);
            this.cmdProcessSettlementLetters.TabIndex = 2;
            this.cmdProcessSettlementLetters.Text = "Create Excel Settlement Letters";
            this.cmdProcessSettlementLetters.UseVisualStyleBackColor = false;
            this.cmdProcessSettlementLetters.Click += new System.EventHandler(this.cmdProcessSettlementLetters_Click);
            // 
            // cmdExit
            // 
            this.cmdExit.BackColor = System.Drawing.SystemColors.Control;
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.ForeColor = System.Drawing.Color.Blue;
            this.cmdExit.Location = new System.Drawing.Point(316, 396);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(223, 25);
            this.cmdExit.TabIndex = 3;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = false;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(52, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Master(C) Data Files for Stores ...";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(52, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Directory for Lawson Data Files";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenFolder
            // 
            this.cmdOpenFolder.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenFolder.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenFolder.Image")));
            this.cmdOpenFolder.Location = new System.Drawing.Point(651, 242);
            this.cmdOpenFolder.Name = "cmdOpenFolder";
            this.cmdOpenFolder.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenFolder.TabIndex = 6;
            this.cmdOpenFolder.UseVisualStyleBackColor = false;
            this.cmdOpenFolder.Click += new System.EventHandler(this.cmdOpenFolder_Click);
            // 
            // txtLawsonFiles
            // 
            this.txtLawsonFiles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtLawsonFiles.Location = new System.Drawing.Point(52, 243);
            this.txtLawsonFiles.Name = "txtLawsonFiles";
            this.txtLawsonFiles.ReadOnly = true;
            this.txtLawsonFiles.Size = new System.Drawing.Size(581, 20);
            this.txtLawsonFiles.TabIndex = 5;
            this.txtLawsonFiles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLawsonFiles_KeyPress);
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(470, 44);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(205, 41);
            this.PictureBox1.TabIndex = 10;
            this.PictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Lime;
            this.label3.Location = new System.Drawing.Point(52, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(395, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "Settlement Letters Processing Utility";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(52, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(293, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Directory for Completed Settlement Letters Files ...";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenCompletedLocation
            // 
            this.cmdOpenCompletedLocation.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenCompletedLocation.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenCompletedLocation.Image")));
            this.cmdOpenCompletedLocation.Location = new System.Drawing.Point(651, 304);
            this.cmdOpenCompletedLocation.Name = "cmdOpenCompletedLocation";
            this.cmdOpenCompletedLocation.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenCompletedLocation.TabIndex = 13;
            this.cmdOpenCompletedLocation.UseVisualStyleBackColor = false;
            this.cmdOpenCompletedLocation.Click += new System.EventHandler(this.cmdOpenCompletedLocation_Click);
            // 
            // txtCompletedFiles
            // 
            this.txtCompletedFiles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCompletedFiles.Location = new System.Drawing.Point(52, 305);
            this.txtCompletedFiles.Name = "txtCompletedFiles";
            this.txtCompletedFiles.ReadOnly = true;
            this.txtCompletedFiles.Size = new System.Drawing.Size(581, 20);
            this.txtCompletedFiles.TabIndex = 12;
            this.txtCompletedFiles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCompletedFiles_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(52, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Template File Location";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenTemplateFile
            // 
            this.cmdOpenTemplateFile.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenTemplateFile.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenTemplateFile.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenTemplateFile.Image")));
            this.cmdOpenTemplateFile.Location = new System.Drawing.Point(651, 134);
            this.cmdOpenTemplateFile.Name = "cmdOpenTemplateFile";
            this.cmdOpenTemplateFile.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenTemplateFile.TabIndex = 16;
            this.cmdOpenTemplateFile.UseVisualStyleBackColor = false;
            this.cmdOpenTemplateFile.Click += new System.EventHandler(this.cmdOpenTemplateFile_Click);
            // 
            // txTemplateFile
            // 
            this.txTemplateFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txTemplateFile.Location = new System.Drawing.Point(52, 134);
            this.txTemplateFile.Name = "txTemplateFile";
            this.txTemplateFile.ReadOnly = true;
            this.txTemplateFile.Size = new System.Drawing.Size(581, 20);
            this.txTemplateFile.TabIndex = 15;
            this.txTemplateFile.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txTemplateFile_KeyPress);
            // 
            // cmdLawsonXMLSummary
            // 
            this.cmdLawsonXMLSummary.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.cmdLawsonXMLSummary.BackColor = System.Drawing.SystemColors.Control;
            this.cmdLawsonXMLSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdLawsonXMLSummary.ForeColor = System.Drawing.Color.Blue;
            this.cmdLawsonXMLSummary.Location = new System.Drawing.Point(316, 355);
            this.cmdLawsonXMLSummary.Name = "cmdLawsonXMLSummary";
            this.cmdLawsonXMLSummary.Size = new System.Drawing.Size(223, 25);
            this.cmdLawsonXMLSummary.TabIndex = 18;
            this.cmdLawsonXMLSummary.Text = "Create Lawson XML Summary";
            this.cmdLawsonXMLSummary.UseVisualStyleBackColor = false;
            this.cmdLawsonXMLSummary.Click += new System.EventHandler(this.cmdLawsonXMLSummary_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel,
            this.statusProgress});
            this.statusStrip1.Location = new System.Drawing.Point(0, 467);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(722, 22);
            this.statusStrip1.TabIndex = 19;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            this.statusLabel.BackColor = System.Drawing.SystemColors.Control;
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(64, 17);
            this.statusLabel.Text = "Progress ...";
            // 
            // statusProgress
            // 
            this.statusProgress.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.statusProgress.BackColor = System.Drawing.SystemColors.Control;
            this.statusProgress.ForeColor = System.Drawing.Color.Lime;
            this.statusProgress.Name = "statusProgress";
            this.statusProgress.Size = new System.Drawing.Size(150, 16);
            // 
            // cbLawsonReport
            // 
            this.cbLawsonReport.FormattingEnabled = true;
            this.cbLawsonReport.Location = new System.Drawing.Point(52, 400);
            this.cbLawsonReport.Name = "cbLawsonReport";
            this.cbLawsonReport.Size = new System.Drawing.Size(218, 21);
            this.cbLawsonReport.TabIndex = 20;
            // 
            // ckBoxPeer
            // 
            this.ckBoxPeer.AutoSize = true;
            this.ckBoxPeer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckBoxPeer.ForeColor = System.Drawing.Color.Cyan;
            this.ckBoxPeer.Location = new System.Drawing.Point(570, 360);
            this.ckBoxPeer.Name = "ckBoxPeer";
            this.ckBoxPeer.Size = new System.Drawing.Size(63, 17);
            this.ckBoxPeer.TabIndex = 21;
            this.ckBoxPeer.Text = "Peer ?";
            this.ckBoxPeer.UseVisualStyleBackColor = true;
            // 
            // JuliettaSettlementLetters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(722, 489);
            this.Controls.Add(this.ckBoxPeer);
            this.Controls.Add(this.cbLawsonReport);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.cmdLawsonXMLSummary);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmdOpenTemplateFile);
            this.Controls.Add(this.txTemplateFile);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmdOpenCompletedLocation);
            this.Controls.Add(this.txtCompletedFiles);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmdOpenFolder);
            this.Controls.Add(this.txtLawsonFiles);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdExit);
            this.Controls.Add(this.cmdProcessSettlementLetters);
            this.Controls.Add(this.cmdOpen);
            this.Controls.Add(this.txFile);
            this.Name = "JuliettaSettlementLetters";
            this.Text = "Julietta Settlement Letters";
            this.Load += new System.EventHandler(this.JuliettaSettlementLetters_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txFile;
        private System.Windows.Forms.Button cmdOpen;
        private System.Windows.Forms.Button cmdProcessSettlementLetters;
        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button cmdOpenFolder;
        private System.Windows.Forms.TextBox txtLawsonFiles;
        internal System.Windows.Forms.PictureBox PictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button cmdOpenCompletedLocation;
        private System.Windows.Forms.TextBox txtCompletedFiles;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cmdOpenTemplateFile;
        private System.Windows.Forms.TextBox txTemplateFile;
        private System.Windows.Forms.Button cmdLawsonXMLSummary;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.ToolStripProgressBar statusProgress;
        private System.Windows.Forms.ComboBox cbLawsonReport;
        private System.Windows.Forms.CheckBox ckBoxPeer;
    }
}


﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CustomInterface;


namespace SettlementLetters
{
    
    public struct SettlementLetterFormParameters{
        public static string TemplateFile;
        public static string Masterfile;
        public static string LawsonTextFileDirectory;
        public static string CompletedFilesDirectory;
        public static bool Peer;


    }

    
    /// <summary>
    /// This class produces Settlement Letter in Excel format
    /// based on 1 settlement letter template and a Master(c) file.
    /// IProgressStatus
    /// </summary>
    public partial class JuliettaSettlementLetters : Form, IProgressStatus
    {
        private double _statusProgressValue = 0;
        private double _statusProgressMaxValue = 0;

        #region open file buttons, key press validations ...

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
                this.txFile.Text = openFile.FileName;

        }

        private void cmdOpenFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
                this.txtLawsonFiles.Text = Foldr.SelectedPath;

        }

        private void cmdOpenCompletedLocation_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
                this.txtCompletedFiles.Text = Foldr.SelectedPath;

        }

        private void cmdOpenTemplateFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
                this.txTemplateFile.Text = openFile.FileName;


        }

        private void txTemplateFile_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Please use the open button on the right", "Invalid Entry ...");
        }

        private void txFile_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Please use the open button on the right", "Invalid Entry ...");
        }

        private void txtLawsonFiles_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Please use the open button on the right", "Invalid Entry ...");
        }

        private void txtCompletedFiles_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("Please use the open button on the right", "Invalid Entry ...");
        }

        #endregion
        
        #region Implementing IProgressStatus ...

        public void SetProgressBarValues(double value, double MaxValue)
        {
            _statusProgressValue = value;
            _statusProgressMaxValue = MaxValue;
        }
        
        
        public void RefreshProgressBar(){
            statusProgress.Value = int.Parse(Math.Round(((_statusProgressValue * 100) / (_statusProgressMaxValue * 100) * 100), 0).ToString());
            this.Refresh();

        }

        public void ToggleStatus()
        {
            this.statusLabel.Visible =
                this.statusLabel.Visible == false ? true : false;

            this.statusProgress.Visible =
                this.statusProgress.Visible == false ? true : false;

        }

        #endregion

        public int WhichReport
        {
            get {return cbLawsonReport.SelectedIndex;}
        }

        public string AssociateName { get; set; }


        public JuliettaSettlementLetters(){
            InitializeComponent();
        }

        private void cmdProcessSettlementLetters_Click(object sender, EventArgs e)
        {
            #region Data validation ...

            if (this.txTemplateFile.Text == null || this.txTemplateFile.Text.Length < 1) {
                MessageBox.Show("Please specified a value for the model template file ...");
                goto ExitHere;
            }

            if (this.txFile.Text == null || this.txFile.Text.Length < 1) {
                MessageBox.Show("Please specified a value for the master template file ...");
                goto ExitHere;
            }


            if (this.txtCompletedFiles.Text == null || this.txtCompletedFiles.Text.Length < 1) {
                MessageBox.Show("Please specified a valid completed file directory ...");
                goto ExitHere;
            }

            #endregion

            Cursor StoredCursor = this.Cursor; 
            this.Cursor = Cursors.WaitCursor; 

            this.statusLabel.Visible = true;
            this.statusProgress.Visible = true;
            this.Refresh();

            SettlementLetterFormParameters.TemplateFile = this.txTemplateFile.Text;
            SettlementLetterFormParameters.Masterfile = this.txFile.Text;
            SettlementLetterFormParameters.LawsonTextFileDirectory = this.txtLawsonFiles.Text;
            SettlementLetterFormParameters.CompletedFilesDirectory = this.txtCompletedFiles.Text;

            if (this.ckBoxPeer.Checked)
                SettlementLetterFormParameters.Peer = true;
            else
                SettlementLetterFormParameters.Peer = false;

            
            SettlementLetters CreateSettlementLetters = new SettlementLetters();

            CreateSettlementLetters.ProcessMasterFile(this);

            this.ToggleStatus();
            this.Cursor = StoredCursor;

            MessageBox.Show("Done!");

        ExitHere:
            return;

        }


        private void JuliettaSettlementLetters_Load(object sender, EventArgs e)
        {
            this.statusLabel.Visible = false;
            this.statusProgress.Visible = false;
            this.cbLawsonReport.Items.Insert(0, "IS290");
            this.cbLawsonReport.Items.Insert(1, "IS292");
            this.cbLawsonReport.SelectedIndex = 0;
            this.ckBoxPeer.Checked = false;

        }

        /// <summary>
        /// This method is used to parse the lines in the Lawson output files
        /// and then add a key figure line per company to the class KeyFigures
        /// afterward, the KeyFigure lines are gather in a Generic List of type KeyFigures.
        /// The Generic List of KeyFigures is then converted to an XML File
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdLawsonXMLSummary_Click(object sender, EventArgs e)
        {
            if (this.txtLawsonFiles.Text == null ||
                    this.txtLawsonFiles.Text.Length < 1)
            {
                MessageBox.Show("Please specified a valid Lawson file directory ...");
                return;

            }
            else
            {
                Cursor StoredCursor = this.Cursor; 
                this.Cursor = Cursors.WaitCursor; 

                SettlementLetterFormParameters.TemplateFile = this.txTemplateFile.Text;
                SettlementLetterFormParameters.Masterfile = this.txTemplateFile.Text;
                SettlementLetterFormParameters.LawsonTextFileDirectory = this.txtLawsonFiles.Text;
                SettlementLetterFormParameters.CompletedFilesDirectory = this.txtCompletedFiles.Text;

                LawsonKeyFiguresXML LawsonXMLFile =
                    new LawsonKeyFiguresXML(this);

                LawsonXMLFile.CreateXML(this);

                this.Cursor = StoredCursor;

            }



        }

 



                
    }
}

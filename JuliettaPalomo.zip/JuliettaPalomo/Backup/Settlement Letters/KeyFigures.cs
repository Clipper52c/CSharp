﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


namespace SettlementLetters
{
    /// <summary>
    /// This class is used to collection Key information on Excel Files
    /// and Lawson Files
    /// </summary>
    public class KeyFigures
    {
        // Auto-implemented properties ...
        public int CompanyNumber { get; set; }
        public string AdminExpense { get; set; }
        public string ProfitOrLoss { get; set; }
        public string TotalAssocEarningsActual { get; set; }
        public string TotalAssocEarningsPlan { get; set; }
        public string SubTotalAssociateAssets { get; set; }
        public string CummulativeEquityRequirement { get; set; }
        public string TotalServiceFees { get; set; }
        public string ShareCapital { get; set; }
        public string REOpening { get; set; }
        public string AdvancesToFromShareHolder { get; set; }
        public string Dividends { get; set; }

        public void FillLine(List<LineItem> items, JuliettaSettlementLetters MainForm)
        {
            foreach (LineItem item in items)
            {
                switch (item.Tag)
                {
                    case "CompanyNumber":
                       if (MainForm.WhichReport == 1)
                            CompanyNumber = int.Parse(item.Value.Substring(11, 6).Trim());
                       break;
                   
                    case "Admin":
                        string Admin = item.Value;
                        Admin = Regex.Replace(Admin, ",", "");
                        Admin = Admin.Substring(60, 10).Trim();
                        AdminExpense = Admin;
                        break;

                    case "ProfitOrLoss":
                        string _ProfitOrLoss = item.Value;
                        _ProfitOrLoss = Regex.Replace(_ProfitOrLoss, ",", "");
                        _ProfitOrLoss = _ProfitOrLoss.Substring(60, 10).Trim();
                        ProfitOrLoss = _ProfitOrLoss;
                        break;

                    case "TotalAssocEarnings":
                        string _TotalAssocEarningsActual = item.Value;
                        _TotalAssocEarningsActual = Regex.Replace(_TotalAssocEarningsActual, ",", "");
                        _TotalAssocEarningsActual = _TotalAssocEarningsActual.Substring(60, 10).Trim();
                        TotalAssocEarningsActual = _TotalAssocEarningsActual;

                        string _TotalAssocEarningsPlan = item.Value;
                        _TotalAssocEarningsPlan = Regex.Replace(_TotalAssocEarningsPlan, ",", "");
                        _TotalAssocEarningsPlan = _TotalAssocEarningsPlan.Substring(31, 15).Trim();
                        TotalAssocEarningsPlan = _TotalAssocEarningsPlan;

                        break;

                    case "SubTotalAssociateAssets":
                        string _SubTotalAssociateAssets = item.Value;
                        _SubTotalAssociateAssets = Regex.Replace(_SubTotalAssociateAssets, ",", "");
                        _SubTotalAssociateAssets = _SubTotalAssociateAssets.Substring(_SubTotalAssociateAssets.Length - 10, 10).Trim();
                        SubTotalAssociateAssets = _SubTotalAssociateAssets;
                        break;

                    case "CummulativeEquityRequirement":
                        string _CummulativeEquityRequirement = item.Value;
                        _CummulativeEquityRequirement = Regex.Replace(_CummulativeEquityRequirement, ",", "");
                        _CummulativeEquityRequirement = _CummulativeEquityRequirement.Substring(_CummulativeEquityRequirement.Length - 10, 10).Trim();
                        CummulativeEquityRequirement = _CummulativeEquityRequirement;
                        break;

                    case "TotalServiceFees":
                        string _TotalServiceFees = item.Value;
                        _TotalServiceFees = Regex.Replace(_TotalServiceFees, ",", "");
                        _TotalServiceFees = _TotalServiceFees.Substring(58, 12).Trim();
                        TotalServiceFees = _TotalServiceFees;
                        break;

                    case "ShareCapital":
                        string _ShareCapital = item.Value;
                        _ShareCapital = Regex.Replace(_ShareCapital, ",", "");
                        _ShareCapital = _ShareCapital.Substring(_ShareCapital.Length - 10, 10).Trim();
                        ShareCapital = _ShareCapital;
                        break;

                    case "REOpening":
                        string _REOpening = item.Value;
                        _REOpening = Regex.Replace(_REOpening, ",", "");
                        _REOpening = _REOpening.Substring(_REOpening.Length - 10, 10).Trim();
                        REOpening = _REOpening;
                        break;

                    case "Dividends":
                        string _Dividends = item.Value;
                        _Dividends = Regex.Replace(_Dividends, ",", "");
                        _Dividends = _Dividends.Substring(_Dividends.Length - 10, 10).Trim();
                        Dividends = _Dividends;
                        break;

                    case "AdvancesToFromShareHolder":
                        string _AdvancesToFromShareHolder = item.Value;
                        _AdvancesToFromShareHolder = Regex.Replace(_AdvancesToFromShareHolder, ",", "");
                        _AdvancesToFromShareHolder = _AdvancesToFromShareHolder.Substring(_AdvancesToFromShareHolder.Length - 10, 10).Trim();
                        AdvancesToFromShareHolder = _AdvancesToFromShareHolder;
                        break;

                }
            }
        }
    }
}

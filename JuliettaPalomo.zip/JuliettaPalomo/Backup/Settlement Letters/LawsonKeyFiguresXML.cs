﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace SettlementLetters
{
    public struct LineItem
    {
        public string Tag;
        public string Value;
    };


    class LawsonKeyFiguresXML
    {
        private string _SettlementLetterTemplateFile;
        private string _MasterCorporateTemplateFile;
        private string _LawsonTextFileDirectory;
        private string _CompletedExcelFileDirectory;
        
        public LawsonKeyFiguresXML(JuliettaSettlementLetters MainForm)
        {
            _SettlementLetterTemplateFile = SettlementLetterFormParameters.TemplateFile;
            _MasterCorporateTemplateFile = SettlementLetterFormParameters.Masterfile;
            _LawsonTextFileDirectory = SettlementLetterFormParameters.LawsonTextFileDirectory;
            _CompletedExcelFileDirectory = SettlementLetterFormParameters.CompletedFilesDirectory;
        
        }


        
        public void CreateXML(JuliettaSettlementLetters MainForm)
        {
            string TemplateFileLocation = _SettlementLetterTemplateFile;
            string MasterFileLocation = _MasterCorporateTemplateFile;
            string LawsonFileLocation = _LawsonTextFileDirectory;
            string CompletedFileLocation = _CompletedExcelFileDirectory;

            List<KeyFigures> LawsonKeyFigureLines = new List<KeyFigures>();
            KeyFigures LawsonKeyFiguresLineItem;

            foreach (string FileName in Directory.GetFiles(@LawsonFileLocation, "*.txt"))
            {
                string[] lines;
                lines = File.ReadAllLines(FileName);

                List<LineItem> lineitems = new List<LineItem>
                {
                    // create anonymous types (anonymous LineItem, and anonymous delegates):
                    new LineItem {Tag = "CompanyNumber", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 11) == "Associate :";
                                                }
                                        )
                                    },
                    
                    // using Lambda expression:
                     new LineItem {Tag = "Admin", Value = 
                            Array.Find(lines, (str) => {
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 23) == "ADMINISTRATION EXPENSES";
                                                }
                                        )
                                    },
                  
                    // using anonymous delegate:
                     new LineItem {Tag = "ProfitOrLoss", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 17) == "PROFIT OR (-LOSS)";
                                                }
                                        )
                                    },
                    
                     // using Lambda expression (one input parameter, ommit bracket):
                     new LineItem {Tag = "TotalAssocEarnings", Value = 
                            Array.Find(lines, str => {
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 21) == "TOTAL ASSOC. EARNINGS";
                                                }
                                        )
                                    },
                    
                    
                      new LineItem {Tag = "SubTotalAssociateAssets", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 28) == "SUB-TOTAL (ASSOCIATE ASSETS)";
                                                }
                                        )
                                    },
                   
                      new LineItem {Tag = "CummulativeEquityRequirement", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 22) == "ADD: CUMULATIVE EQUITY";
                                                }
                                        )
                                    },

                      new LineItem {Tag = "TotalServiceFees", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 18) == "TOTAL SERVICE FEES";
                                                }
                                        )
                                    },

                      new LineItem {Tag = "ShareCapital", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 13) == "SHARE CAPITAL";
                                                }
                                        )
                                    },

                      new LineItem {Tag = "REOpening", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 22) == "RETAINED EARNINGS (OPE";
                                                }
                                        )
                                    },

                      new LineItem {Tag = "Dividends", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 9) == "DIVIDENDS";
                                                }
                                        )
                                    },

                      new LineItem {Tag = "AdvancesToFromShareHolder", Value = 
                            Array.Find(lines, delegate(string str){
                                                if (str.Length < 23) return false;
                                                else return str.Substring(0, 22) == "ADVANCES TO/FROM SHARE";
                                                }
                                        )
                                    },

                };


                // Add the results to a Item collection
                LawsonKeyFiguresLineItem = new KeyFigures();
                LawsonKeyFiguresLineItem.FillLine(lineitems, MainForm);

                // Add the Item Collection to the Items Collection
                LawsonKeyFigureLines.Add(LawsonKeyFiguresLineItem);

            }

            if (File.Exists(@CompletedFileLocation + "\\LawsonKeyFigures.xml"))
                File.Delete(@CompletedFileLocation + "\\LawsonKeyFigures.xml");

            System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(LawsonKeyFigureLines.GetType());
            x.Serialize(File.Create(@CompletedFileLocation + "\\LawsonKeyFigures.xml"), LawsonKeyFigureLines);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SettlementLetters
{
    /// <summary>
    /// This class represents the columns in the Master(C) template spreadsheet
    /// </summary>
    class MasterTemplateItem
    {
        private int mStoreNumber;

        public int getStoreNumber(){
            return mStoreNumber;
        }

        public void setStoreNumber(int pStoreNumber){
            mStoreNumber = pStoreNumber;
        }

        
        // Auto-implemented properties ...
        public int ItemNumber { get; set; }
        public string MainStoreNumber { get; set; }
        public string AssociateName { get; set; }
        public int NumberOfDays { get; set; }
        public int CompanyNumber { get; set; }
        public int StoreNumber { get; set; }
        public double AdminExpense { get; set; }
        public double NetPL { get; set; }
        public double Rebate { get; set; }
        public double AssetContribution { get; set; }
        public double PeersHonorarium { get; set; }
        public double CummEq { get; set; }
        public double PersonalAssets { get; set; }
        public double BaseGuarantee { get; set; }
        public double REBeginning { get; set; }
        public double OptionalEquityInterest { get; set; }
        public double ProfitSharing { get; set; }
        public double Dividends { get; set; }
        public double ShareHoldersAdvance { get; set; }
        public double Capital { get; set; }

    }
}

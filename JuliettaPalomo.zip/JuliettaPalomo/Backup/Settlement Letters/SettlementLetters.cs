﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Text.RegularExpressions;
using System.IO;

namespace SettlementLetters
{
    class SettlementLetters
    {
        private string _SettlementLetterTemplateFile;
        private string _MasterCorporateTemplateFile;
        private string _LawsonTextFileDirectory;
        private string _CompletedExcelFileDirectory;
        private string Peer;

        Excel.Application objApp;
        Excel._Workbook objBook;

        Excel.Workbooks objBooks;
        Excel.Sheets objSheets;
        Excel._Worksheet objSheet;

        public SettlementLetters()
        {
            _SettlementLetterTemplateFile = SettlementLetterFormParameters.TemplateFile;
            _MasterCorporateTemplateFile = SettlementLetterFormParameters.Masterfile;
            _LawsonTextFileDirectory = SettlementLetterFormParameters.LawsonTextFileDirectory;
            _CompletedExcelFileDirectory = SettlementLetterFormParameters.CompletedFilesDirectory;

            if (SettlementLetterFormParameters.Peer == true)
                Peer = "Peers";
            else
                Peer = "Non-Peer";


        }

        
        /// <summary>
        /// This method opens the Master template file, collect the information into
        /// arrays, collection classes, Generic List, etc, and then pass the arrays
        /// to the method "CreateExcelFile ()" to create the Excel files
        /// 
        /// Note:   the line -  int MasterTemplateLastRow = 1992; is used to record
        ///         the last line in the Master(C) template, do a search to find this line
        ///         and then change the last line as neccessary
        /// 
        /// Other Notes:
        ///     The Master(C) template file must be open to prevent the Excel errors
        ///     caused by to using too many levels of nested VLookup links.
        ///     
        ///     Once this Master(C) template file is opened, the nested VLookup links
        ///     will be part of the memory, hence this problem of too many levels of 
        ///     nested link error will go away.
        /// 
        /// </summary>
        public void ProcessMasterFile(JuliettaSettlementLetters MainForm)
        {

            // The List ExcelKeyFigureLines will be used to store Excel Key Figures.
            List<KeyFigures> ExcelKeyFigureLines = new List<KeyFigures>();

            // initialize the Excel Application class
            objApp = new Excel.Application();
            objBooks = objApp.Workbooks;

            objBook = objApp.Workbooks.Open
                                    (@_MasterCorporateTemplateFile,
                                    false, true, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing);

            objSheets = objBook.Worksheets;
            objSheet = (Excel._Worksheet)objSheets.get_Item(1);

            //Get a range of data.
            Excel.Range MasterTemplateRange = objSheet.get_Range("A10", "CW1212"); // used to be AW2000

            //Transfer the range to a temporary array saRet.
            Object[,] oFormulaRange; Object[,] oValueRange;

            oFormulaRange = (System.Object[,])MasterTemplateRange.Formula;
            oValueRange = (System.Object[,])MasterTemplateRange.get_Value(Missing.Value);
            int MasterTemplateLastRow = 1204; // we have less than 2000 company 1992

            //      LEAVE THIS MASTER TEMPLATE OPEN SO THE VLOOKUP LINK CAN UPDATE EASILY.
            //      objBook.Close(false, Missing.Value, Missing.Value);

            /*
                    This for LOOP do 2 things
                    1). Due to muliple stores with same company number, we can pickup the same line twice
                        as we go down the page; thus, we used column 49 to flag whether the row has been picked up
                    2). The Associate name in column 9 have some formatting characters such as Derek "E" James,
                        and if we picked up the " and include the name with the FileName, the " will cause the
                        program to crash.  We used Regex to get rid of these characters.
            */

            // cleaning up the array before processing starts ...
            for (int i = 1; i < MasterTemplateLastRow; i++)  //we are picking up 2000 - 10 rows
            {

                // Getting rid of the format symbols within the text string
                if (oValueRange[i, 2] != null 
                        && Regex.Match(oValueRange[i, 2].ToString(), "^\\d{4}").Value.Length == 4 
                        && oValueRange[i, 9] != null)
                {
                    oValueRange[i, 9] = Regex.Replace(oValueRange[i, 9].ToString(), "\"", "");
                    oValueRange[i, 9] = Regex.Replace(oValueRange[i, 9].ToString(), "/", "");
                }

                if (Regex.Match(oFormulaRange[i, 2].ToString(), "^\\d{4}").Value.Length == 4)
                {
                    if (oFormulaRange[i, 100].ToString() == "#N/A") oFormulaRange[i, 100] = "#NA";
                    if (oValueRange[i, 100].ToString() == "#N/A") oValueRange[i, 100] = "#NA";
                }

                // set the flag column
                oFormulaRange[i, 98] = 0; oValueRange[i, 98] = 0;

            }


            for (int i = 1; i < MasterTemplateLastRow; i++)  //we are picking up 2000 - 10 rows
            {
                MainForm.SetProgressBarValues(i, MasterTemplateLastRow);

                // create a collection items to hold the master template line items
                List<MasterTemplateItem> MasterTemplateItems = new List<MasterTemplateItem>();
                MasterTemplateItem MasterTemplateItem;

                int ItemCount = 0;  // reset the item count for every items group

                /*
                        We are matching the second column of the array for a 4
                        digit company number
                */


                if (Regex.Match(oFormulaRange[i, 2].ToString(), "^\\d{4}").Value.Length == 4
                                && oValueRange[i, 98].ToString() == "0"
                                && oFormulaRange[i, 98].ToString() == "0"
                                && oValueRange[i, 101].ToString() == Peer
                                && oFormulaRange[i, 101].ToString() == Peer)  
                {

                    /*
                     *      Collect the contend of a line item to an item class MasterTemplateItem
                     *      store this class in a generic List of type class MasterTemplateItem
                     *      look to see if there is anymore similar company number down the line
                    */


                    MasterTemplateItem = new MasterTemplateItem();


                    MasterTemplateItem.ItemNumber = ItemCount++;
                    MasterTemplateItem.CompanyNumber = int.Parse(oFormulaRange[i, 2].ToString());

                    MasterTemplateItem.MainStoreNumber = oFormulaRange[i, 100].ToString();
                    MasterTemplateItem.setStoreNumber(int.Parse(oFormulaRange[i, 1].ToString()));
                    MasterTemplateItem.NumberOfDays = int.Parse(oValueRange[i, 11].ToString());

                    // Associate name can be a blank in the data sheet
                    if (oValueRange[i, 9] != null)
                        MasterTemplateItem.AssociateName = oValueRange[i, 9].ToString();


                    // flag this item as used
                    oFormulaRange[i, 98] = 1; oValueRange[i, 98] = 1;

                    MasterTemplateItems.Add(MasterTemplateItem);

                    // Look for other stores within the same company ...
                    for (int DupeItems = i + 1;
                            DupeItems < MasterTemplateLastRow;
                            DupeItems++)
                    {

                        // Note: the && is a short curcuit AND operator.
                        // thus, if oValueRange[DupeItems, 49] is evaluated to null,
                        // the oValueRange[DupeItems, 49].ToString() won't be executed,
                        // which could caused problems.

                            if (oFormulaRange[DupeItems, 2].ToString() == oFormulaRange[i, 2].ToString()
                                        && oValueRange[DupeItems, 98].ToString() == "0"
                                        && oFormulaRange[DupeItems, 98].ToString() == "0"
                                        && oValueRange[DupeItems, 101].ToString() == Peer
                                        && oFormulaRange[DupeItems, 101].ToString() == Peer)  
                                     
                            {

                                //we have another match
                                MasterTemplateItem = new MasterTemplateItem();

                                MasterTemplateItem.ItemNumber = ItemCount++;
                                MasterTemplateItem.CompanyNumber = int.Parse(oFormulaRange[DupeItems, 2].ToString());
                                MasterTemplateItem.setStoreNumber(int.Parse(oFormulaRange[DupeItems, 1].ToString()));
                                MasterTemplateItem.NumberOfDays = int.Parse(oValueRange[DupeItems, 11].ToString());

                                if (oValueRange[DupeItems, 9] != null)
                                    MasterTemplateItem.AssociateName = oValueRange[DupeItems, 9].ToString();

                                // flag this item as used
                                oFormulaRange[DupeItems, 98] = 1;
                                oValueRange[DupeItems, 98] = 1;

                                MasterTemplateItems.Add(MasterTemplateItem);



                            }
                        }       // for (int DupeItems = i+1; DupeItems < 1992; DupeItems++)


                        CreateExcelFile(MasterTemplateItems, ExcelKeyFigureLines);
                        MainForm.RefreshProgressBar();

                    }       // if (Regex.Match(oFormulaRange[i, 2].ToString(), "^\\d{4}").Value.Length == 4 && oValueRange[i, 49].ToString() == "0" && oFormulaRange[i, 49].ToString() == "0")


                }  // for (int i = 1; i < MasterTemplateLastRow; i++)


                if (File.Exists(@_CompletedExcelFileDirectory + "\\ExcelKeyFigures.xml"))
                    File.Delete(@_CompletedExcelFileDirectory + "\\ExcelKeyFigures.xml");

                System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(ExcelKeyFigureLines.GetType());
                x.Serialize(File.Create(_CompletedExcelFileDirectory + "\\ExcelKeyFigures.xml"), ExcelKeyFigureLines);

                objApp.Quit();

            }
       


        /// <summary>
        /// This function is used to create one Excel file
        /// based on the items listed in a Generic List of type MasterTemplateItem
        /// and also add one line of Key Figure Item to the Generic List of type KeyFigures
        /// </summary>
        /// <param name="MasterTemplateItems">Supply the Generic List MasterTemplateItems</param>
        /// <param name="ExcelKeyFigureLines">Please supply a generic List 
        /// for this function to fill in the Excel key figures line items
        /// </param>
        /// 

        private void CreateExcelFile(List<MasterTemplateItem> MasterTemplateItems,
                                List<KeyFigures> ExcelKeyFigureLines)
        {
            Object[,] HeaderValueArray = new Object[3, 7];
            Excel.Range HeaderRange;

            objBook = objApp.Workbooks.Open
            (@_SettlementLetterTemplateFile, false, Missing.Value, Missing.Value,
                                Missing.Value, Missing.Value, Missing.Value,
                                Missing.Value, Missing.Value, Missing.Value,
                                Missing.Value, Missing.Value, Missing.Value,
                                Missing.Value, Missing.Value);


            objSheets = objBook.Worksheets;
            objSheet = (Excel._Worksheet)objSheets.get_Item(1);

            //Get a range of data.
            HeaderRange = objSheet.get_Range("B3", "H5");

            HeaderValueArray[0, 0] = MasterTemplateItems[0].AssociateName;  // fixed cell
            HeaderValueArray[0, 6] = MasterTemplateItems[0].CompanyNumber;  // fixed cell


            foreach (MasterTemplateItem MasterTemplateItem in MasterTemplateItems)
            {
                HeaderValueArray[1, MasterTemplateItem.ItemNumber] = MasterTemplateItem.getStoreNumber(); // fixed row, variable column
                HeaderValueArray[2, MasterTemplateItem.ItemNumber] = MasterTemplateItem.NumberOfDays;     // fixed row, variable column
            }

            // assign the virtual range back into Excel
            HeaderRange.Formula = HeaderValueArray;

            // Check to see how many store numbers within this company

            string StoreNumberList = "";

            for (int i = 0; i < MasterTemplateItems.Count; i++)
            {
                if (i == MasterTemplateItems.Count - 1)
                {
                    if (MasterTemplateItems[i].getStoreNumber().ToString() != MasterTemplateItems[0].MainStoreNumber)
                        StoreNumberList += MasterTemplateItems[i].getStoreNumber().ToString();
                }
                else
                {
                    if (MasterTemplateItems[i].getStoreNumber().ToString() != MasterTemplateItems[0].MainStoreNumber)
                        StoreNumberList += MasterTemplateItems[i].getStoreNumber().ToString() + " ";
                }

            }

            objApp.Calculate();

            string FileNameToSave =
                _CompletedExcelFileDirectory + "\\SDM" + MasterTemplateItems[0].MainStoreNumber + " " +
                StoreNumberList + " " +
                " - " + HeaderValueArray[0, 0] + " - Co" + HeaderValueArray[0, 6] + " - 2008 Settlement" + ".xls";


            objBook.BreakLink(@_MasterCorporateTemplateFile, Excel.XlLinkType.xlLinkTypeExcelLinks);

            // Collect key figures.
            Excel.Range ExcelKeyFigureRange;
            object[,] KeyFiguresRangeValued;
            ExcelKeyFigureRange = objSheet.get_Range("E12", "N129");
            KeyFiguresRangeValued = (System.Object[,])ExcelKeyFigureRange.get_Value(Missing.Value);

            KeyFigures ExcelKeyFiguresLineItem = new KeyFigures();

            ExcelKeyFiguresLineItem.CompanyNumber = MasterTemplateItems[0].CompanyNumber;
            ExcelKeyFiguresLineItem.AdminExpense = KeyFiguresRangeValued[1, 10].ToString();
            ExcelKeyFiguresLineItem.ProfitOrLoss = KeyFiguresRangeValued[6, 2].ToString();
            ExcelKeyFiguresLineItem.TotalAssocEarningsActual = KeyFiguresRangeValued[8, 2].ToString();
            ExcelKeyFiguresLineItem.SubTotalAssociateAssets = KeyFiguresRangeValued[35, 10].ToString();

            if (KeyFiguresRangeValued[32, 2] != null)
                ExcelKeyFiguresLineItem.CummulativeEquityRequirement = KeyFiguresRangeValued[32, 2].ToString();
            else
                ExcelKeyFiguresLineItem.CummulativeEquityRequirement = "0";

            if (KeyFiguresRangeValued[118, 3] != null)
                ExcelKeyFiguresLineItem.TotalServiceFees = KeyFiguresRangeValued[118, 3].ToString();
            else
                ExcelKeyFiguresLineItem.TotalServiceFees = "0";

            if (KeyFiguresRangeValued[69, 2] != null)
                ExcelKeyFiguresLineItem.ShareCapital = KeyFiguresRangeValued[69, 2].ToString();
            else
                ExcelKeyFiguresLineItem.ShareCapital = "0";

            if (KeyFiguresRangeValued[55, 2] != null)
                ExcelKeyFiguresLineItem.REOpening = KeyFiguresRangeValued[55, 2].ToString();
            else
                ExcelKeyFiguresLineItem.REOpening = "0";

            if (KeyFiguresRangeValued[65, 2] != null)
                ExcelKeyFiguresLineItem.Dividends = KeyFiguresRangeValued[65, 2].ToString();
            else
                ExcelKeyFiguresLineItem.Dividends = "0";

            if (KeyFiguresRangeValued[67, 2] != null)
                ExcelKeyFiguresLineItem.AdvancesToFromShareHolder = KeyFiguresRangeValued[67, 2].ToString();
            else
                ExcelKeyFiguresLineItem.AdvancesToFromShareHolder = "0";
            

            ExcelKeyFigureLines.Add(ExcelKeyFiguresLineItem);


            // Note: the attribute xlExcel9795 is the most recent one , the xlExcel7 attribute
            //       will cause the date format to be lost.

            objBook.SaveAs(FileNameToSave,
                      Excel.XlFileFormat.xlExcel9795, Missing.Value, Missing.Value,
                      false, false, Excel.XlSaveAsAccessMode.xlNoChange,
                      Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            objBook.Close(false, Missing.Value, Missing.Value);
            System.GC.Collect();  // force garbage collection

        }



    }
}

﻿namespace TaxPrep
{
    partial class frmTaxPrepMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTaxPrepMain));
            this.label5 = new System.Windows.Forms.Label();
            this.cmdOpenTemplateFile = new System.Windows.Forms.Button();
            this.txTemplateFile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdOpenResourceFile = new System.Windows.Forms.Button();
            this.txResourceFile = new System.Windows.Forms.TextBox();
            this.cmdParseLawsonKeyFigures = new System.Windows.Forms.Button();
            this.cmdExit = new System.Windows.Forms.Button();
            this.cmdProcessTaxPrep = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmdOpenCompletedLocation = new System.Windows.Forms.Button();
            this.txtCompletedFiles = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Green;
            this.label5.Location = new System.Drawing.Point(16, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Tax Checklist Template";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenTemplateFile
            // 
            this.cmdOpenTemplateFile.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenTemplateFile.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenTemplateFile.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenTemplateFile.Image")));
            this.cmdOpenTemplateFile.Location = new System.Drawing.Point(598, 222);
            this.cmdOpenTemplateFile.Name = "cmdOpenTemplateFile";
            this.cmdOpenTemplateFile.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenTemplateFile.TabIndex = 24;
            this.cmdOpenTemplateFile.UseVisualStyleBackColor = false;
            this.cmdOpenTemplateFile.Click += new System.EventHandler(this.cmdOpenTemplateFile_Click);
            // 
            // txTemplateFile
            // 
            this.txTemplateFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txTemplateFile.Location = new System.Drawing.Point(16, 221);
            this.txTemplateFile.Name = "txTemplateFile";
            this.txTemplateFile.ReadOnly = true;
            this.txTemplateFile.Size = new System.Drawing.Size(571, 20);
            this.txTemplateFile.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(16, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(291, 25);
            this.label3.TabIndex = 22;
            this.label3.Text = "TaxPrep Processing Utility";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("PictureBox1.Image")));
            this.PictureBox1.Location = new System.Drawing.Point(21, 29);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(206, 41);
            this.PictureBox1.TabIndex = 21;
            this.PictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Green;
            this.label1.Location = new System.Drawing.Point(16, 156);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Resource File";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenResourceFile
            // 
            this.cmdOpenResourceFile.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenResourceFile.ForeColor = System.Drawing.SystemColors.Control;
            this.cmdOpenResourceFile.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenResourceFile.Image")));
            this.cmdOpenResourceFile.Location = new System.Drawing.Point(598, 173);
            this.cmdOpenResourceFile.Name = "cmdOpenResourceFile";
            this.cmdOpenResourceFile.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenResourceFile.TabIndex = 19;
            this.cmdOpenResourceFile.UseVisualStyleBackColor = false;
            this.cmdOpenResourceFile.Click += new System.EventHandler(this.cmdOpenResourceFile_Click);
            // 
            // txResourceFile
            // 
            this.txResourceFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txResourceFile.Location = new System.Drawing.Point(16, 172);
            this.txResourceFile.Name = "txResourceFile";
            this.txResourceFile.ReadOnly = true;
            this.txResourceFile.Size = new System.Drawing.Size(571, 20);
            this.txResourceFile.TabIndex = 18;
            // 
            // cmdParseLawsonKeyFigures
            // 
            this.cmdParseLawsonKeyFigures.BackColor = System.Drawing.SystemColors.Control;
            this.cmdParseLawsonKeyFigures.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdParseLawsonKeyFigures.ForeColor = System.Drawing.Color.Blue;
            this.cmdParseLawsonKeyFigures.Location = new System.Drawing.Point(270, 373);
            this.cmdParseLawsonKeyFigures.Name = "cmdParseLawsonKeyFigures";
            this.cmdParseLawsonKeyFigures.Size = new System.Drawing.Size(196, 25);
            this.cmdParseLawsonKeyFigures.TabIndex = 28;
            this.cmdParseLawsonKeyFigures.Text = "Parse Lawson File Key Figures";
            this.cmdParseLawsonKeyFigures.UseVisualStyleBackColor = false;
            // 
            // cmdExit
            // 
            this.cmdExit.BackColor = System.Drawing.SystemColors.Control;
            this.cmdExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdExit.ForeColor = System.Drawing.Color.Blue;
            this.cmdExit.Location = new System.Drawing.Point(524, 373);
            this.cmdExit.Name = "cmdExit";
            this.cmdExit.Size = new System.Drawing.Size(67, 25);
            this.cmdExit.TabIndex = 27;
            this.cmdExit.Text = "Exit";
            this.cmdExit.UseVisualStyleBackColor = false;
            this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
            // 
            // cmdProcessTaxPrep
            // 
            this.cmdProcessTaxPrep.BackColor = System.Drawing.SystemColors.Control;
            this.cmdProcessTaxPrep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdProcessTaxPrep.ForeColor = System.Drawing.Color.Blue;
            this.cmdProcessTaxPrep.Location = new System.Drawing.Point(20, 373);
            this.cmdProcessTaxPrep.Name = "cmdProcessTaxPrep";
            this.cmdProcessTaxPrep.Size = new System.Drawing.Size(197, 25);
            this.cmdProcessTaxPrep.TabIndex = 26;
            this.cmdProcessTaxPrep.Text = "Process TaxPrep";
            this.cmdProcessTaxPrep.UseVisualStyleBackColor = false;
            this.cmdProcessTaxPrep.Click += new System.EventHandler(this.cmdProcessTaxPrep_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(18, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(301, 13);
            this.label4.TabIndex = 31;
            this.label4.Text = "Directory for Completed Settlement TaxPrep Files ...";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmdOpenCompletedLocation
            // 
            this.cmdOpenCompletedLocation.BackColor = System.Drawing.SystemColors.Control;
            this.cmdOpenCompletedLocation.Image = ((System.Drawing.Image)(resources.GetObject("cmdOpenCompletedLocation.Image")));
            this.cmdOpenCompletedLocation.Location = new System.Drawing.Point(600, 284);
            this.cmdOpenCompletedLocation.Name = "cmdOpenCompletedLocation";
            this.cmdOpenCompletedLocation.Size = new System.Drawing.Size(24, 20);
            this.cmdOpenCompletedLocation.TabIndex = 30;
            this.cmdOpenCompletedLocation.UseVisualStyleBackColor = false;
            this.cmdOpenCompletedLocation.Click += new System.EventHandler(this.cmdOpenCompletedLocation_Click);
            // 
            // txtCompletedFiles
            // 
            this.txtCompletedFiles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtCompletedFiles.Location = new System.Drawing.Point(18, 284);
            this.txtCompletedFiles.Name = "txtCompletedFiles";
            this.txtCompletedFiles.ReadOnly = true;
            this.txtCompletedFiles.Size = new System.Drawing.Size(571, 20);
            this.txtCompletedFiles.TabIndex = 29;
            // 
            // frmTaxPrepMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(663, 440);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmdOpenCompletedLocation);
            this.Controls.Add(this.txtCompletedFiles);
            this.Controls.Add(this.cmdParseLawsonKeyFigures);
            this.Controls.Add(this.cmdExit);
            this.Controls.Add(this.cmdProcessTaxPrep);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmdOpenTemplateFile);
            this.Controls.Add(this.txTemplateFile);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdOpenResourceFile);
            this.Controls.Add(this.txResourceFile);
            this.Name = "frmTaxPrepMain";
            this.Text = "TaxPrep";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cmdOpenTemplateFile;
        private System.Windows.Forms.TextBox txTemplateFile;
        private System.Windows.Forms.Label label3;
        internal System.Windows.Forms.PictureBox PictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdOpenResourceFile;
        private System.Windows.Forms.TextBox txResourceFile;
        private System.Windows.Forms.Button cmdParseLawsonKeyFigures;
        private System.Windows.Forms.Button cmdExit;
        private System.Windows.Forms.Button cmdProcessTaxPrep;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button cmdOpenCompletedLocation;
        private System.Windows.Forms.TextBox txtCompletedFiles;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace TaxPrep
{
    public partial class frmTaxPrepMain : Form
    {

        private string TemplateFileLocation;
        private string ResourceFileLocation;
        private string CompletedFileLocation;


        Excel.Application objApp;
        Excel._Workbook objBook;

        Excel.Workbooks objBooks;
        Excel.Sheets objSheets;
        Excel._Worksheet objSheet;
        Excel.Range RngTaxPrepareName;
        Excel.Range RngLawsonNumber;
        Excel.Range RngStoreNumber;
        Excel.Range RngRAExtension;
        Excel.Range RngYearEndDate;
        Excel.Range RngCurrentDateLabel;
        Excel.Range RngCurrentDate;


        public frmTaxPrepMain()
        {
            InitializeComponent();
        }

        private void cmdExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmdOpenTemplateFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                this.txTemplateFile.Text = openFile.FileName;
            }

        }

        private void cmdOpenResourceFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                this.txResourceFile.Text = openFile.FileName;
            }

        }




        private void cmdProcessTaxPrep_Click(object sender, EventArgs e)
        {
            Cursor StoredCursor = this.Cursor; //store your current Cursor
            this.Cursor = Cursors.WaitCursor; //HourGlass is ON and default Cursor is OFF

            TemplateFileLocation = this.txTemplateFile.Text;
            ResourceFileLocation = this.txResourceFile.Text;
            CompletedFileLocation = this.txtCompletedFiles.Text;


            // initialize the Excel Application class
            objApp = new Excel.Application();
            objBooks = objApp.Workbooks;

            objBook = objApp.Workbooks.Open
                        (@ResourceFileLocation,
                        false, true, Type.Missing, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                        Type.Missing, Type.Missing);


            Excel.Range Rng;

            objSheets = objBook.Worksheets;

            objSheet = (Excel._Worksheet)objSheets.get_Item(10);

            Rng = objSheet.get_Range("A1", "A1");

            int ResourceFileLastRow = Rng.CurrentRegion.Rows.Count;  // get the last row
          

            //Get a range of data.
            Excel.Range ResourceFileTargetRange = objSheet.get_Range("A2", "BJ" + ResourceFileLastRow);

            //Transfer the range to a temporary array saRet.
            Object[,] oFormulaRange; Object[,] oValueRange;

            oFormulaRange = (System.Object[,])ResourceFileTargetRange.Formula;
            oValueRange = (System.Object[,])ResourceFileTargetRange.get_Value(Missing.Value);

            // Close the resource workbook, we are done collecting the data.
            objBook.Close(false, Missing.Value, Missing.Value);
            
            //now open the taxprep template
            objBook = objApp.Workbooks.Open
            (TemplateFileLocation, false, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value, Missing.Value,
                    Missing.Value, Missing.Value);


            objSheets = objBook.Worksheets;
            objSheet = (Excel._Worksheet)objSheets.get_Item(1);
           

            Excel.Range HeaderRange;
            HeaderRange = objSheet.get_Range("B3", "E44");

            Object[,] HeaderValueArray = new Object[44, 5];

            string AssociateName;

            for (int i = 2; i < ResourceFileLastRow; i++)  
            {
                  if (oValueRange[i, 3] != null )
                {
                    //Get a range of data.
                    AssociateName = oValueRange[i, 5].ToString();
                    HeaderValueArray[0, 0] = oValueRange[i, 6];  //Corporate Name
                    HeaderValueArray[1, 0] = oValueRange[i, 5];  //Corporate Name
                    HeaderValueArray[2, 0] = oValueRange[i, 3];  // Lawson company number
                    HeaderValueArray[3, 0] = oValueRange[i, 1];  // store numbers
                    HeaderValueArray[4, 0] = "01/03/2009";  // store numbers
                    HeaderValueArray[7, 0] = oValueRange[i, 8]; // tax preparer name
                    HeaderValueArray[8, 0] = oValueRange[i, 9];     // address 1
                    HeaderValueArray[9, 0] = oValueRange[i, 10];     // address 2
                    HeaderValueArray[13, 0] = oValueRange[i, 11];    // phone
                    HeaderValueArray[14, 0] = oValueRange[i, 12];    // fax
                    HeaderValueArray[16, 0] = oValueRange[i, 13];    // email
                    HeaderValueArray[41, 0] = oValueRange[i, 4];    // accountant name, prepare by

                    // assign the virtual range back into Excel
                    HeaderRange.Formula = HeaderValueArray;

                    this.RngTaxPrepareName = objSheet.get_Range("D9", "D9");
                    this.RngTaxPrepareName.Font.Bold = true;

                    this.RngLawsonNumber = objSheet.get_Range("D4", "D4");
                    this.RngStoreNumber = objSheet.get_Range("D5", "D5");
                    this.RngRAExtension = objSheet.get_Range("D40", "D40");

                    this.RngLawsonNumber.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
                    this.RngStoreNumber.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
                    this.RngRAExtension.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;


                    string FileNameToSave =
                    CompletedFileLocation + "\\Company Number " +
                    oValueRange[i, 3] + " Store number " + oValueRange[i, 1].ToString().Trim() 
                    + " " + AssociateName + " - 2008 tax checklist"
                    + ".xls";


                    objBook.SaveAs(FileNameToSave,
                                Excel.XlFileFormat.xlExcel9795, Missing.Value, Missing.Value,
                                false, false, Excel.XlSaveAsAccessMode.xlNoChange,
                                Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                    
                }


            }

            // Close the template workbook, we are done collecting the data.
            objBook.Close(false, Missing.Value, Missing.Value);
            objApp.Quit();


            this.Cursor = StoredCursor;//default Cursor is ON and HourGlass is OFF

            MessageBox.Show("Done !");
        }

        private Excel.Application ResourceListDataCollection(Excel.Application objApp)
        {
            objBook = objApp.Workbooks.Open
                                    (@ResourceFileLocation,
                                    false, true, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing);



            objSheets = objBook.Worksheets;
            objSheet = (Excel._Worksheet)objSheets.get_Item(1);

            int ResourceFileLastRow = 930; // we have less than 2000 company

            //Get a range of data.
            Excel.Range ResourceFileTargetRange = objSheet.get_Range("A2", "BJ" + ResourceFileLastRow);

            //Transfer the range to a temporary array saRet.
            Object[,] oFormulaRange; Object[,] oValueRange;

            oFormulaRange = (System.Object[,])ResourceFileTargetRange.Formula;
            oValueRange = (System.Object[,])ResourceFileTargetRange.get_Value(Missing.Value);

            // Close the resource workbook, we are done collecting the data.
            objBook.Close(false, Missing.Value, Missing.Value);

            return objApp;

        }

        private void cmdOpenCompletedLocation_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Foldr = new FolderBrowserDialog();
            if (Foldr.ShowDialog() == DialogResult.OK)
            {
                this.txtCompletedFiles.Text = Foldr.SelectedPath;

            }

        }

    }
}

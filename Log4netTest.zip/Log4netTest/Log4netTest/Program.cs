﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Log4netTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Logger.Info("Initializing database information.");
            Logger.Debug("Initializing schema information.");
            // Console.WriteLine("test");

            try
            {
                throw new Exception("division by zero");
            }
            catch (Exception ex)
            {
                Logger.Debug(ex.Message);
            }
        }
    }
}

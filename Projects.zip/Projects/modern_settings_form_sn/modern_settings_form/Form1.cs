﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modern_settings_form
{
    public partial class Form1 : MaterialSkin.Controls.MaterialForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        MaterialSkin.Primary primary_color = MaterialSkin.Primary.Blue400;
        MaterialSkin.Primary dark_primary = MaterialSkin.Primary.Blue700;
        MaterialSkin.TextShade text_color = MaterialSkin.TextShade.WHITE;
        modern_settings_form.my_classes.skin_loader_cls my_class = new my_classes.skin_loader_cls();

        private void Form1_Load(object sender, EventArgs e)
        {
            MaterialSkin.MaterialSkinManager sm;
            sm = MaterialSkin.MaterialSkinManager.Instance;
            sm.AddFormToManage(this);
            //------------------------------
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            //--------------------------------
            sm.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Blue400,
                                                          MaterialSkin.Primary.Blue700,
                                                          MaterialSkin.Primary.Blue100,
                                                          MaterialSkin.Accent.Orange400,
                                                          MaterialSkin.TextShade.WHITE);
            //=============================Skin setting loader============================
            //----------------------Load settings---------------------
            MaterialSkin.Controls.MaterialRadioButton rb = new MaterialSkin.Controls.MaterialRadioButton();

            //-------------------- Load Theme -------------------------
            my_class.theme_loader(rb, rb, sm);
            //--------------------------------------------------------
            //---------------------restore skin color-----------------
            my_class.skin_color_loader(ref primary_color, ref dark_primary, rb, rb,   rb, rb);                                     
            //--------------------------------------------------------
            //-------------------- restore text color-----------------
            my_class.text_color_loader(rb, rb, ref text_color);
            //--------------------------------------------------------
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            //============================================================================
        }

        private void MaterialFlatButton1_Click(object sender, EventArgs e)
        {
             skin_settings f = new skin_settings();
            f.ShowDialog();
            f.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modern_settings_form.my_classes
{
    class skin_loader_cls
    {
  
       public  void color_changer(MaterialSkin.Primary primary_color,
                                  MaterialSkin.Primary dark_primary,
                                  MaterialSkin.TextShade text_color,
                                  MaterialSkin.MaterialSkinManager sm)
        {
            sm.ColorScheme = new MaterialSkin.ColorScheme(primary_color,
                                                           dark_primary,
                                                           MaterialSkin.Primary.Blue100,
                                                           MaterialSkin.Accent.Orange400,
                                                           text_color);
        }


        public void theme_loader(MaterialSkin.Controls.MaterialRadioButton light_rb,
                                MaterialSkin.Controls.MaterialRadioButton dark_rb,
                                MaterialSkin.MaterialSkinManager sm)
        {
            Boolean b;
            b = modern_settings_form.Properties.Settings.Default.theme_light_rb;
            if (b == true)
            {
                 light_rb.Checked = true;
                 dark_rb.Checked = false;
                sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            }
            else
            {
                 light_rb.Checked = false;
                 dark_rb.Checked = true;
                sm.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            }
        }



        public void skin_color_loader(ref MaterialSkin.Primary primary_color,
                                      ref  MaterialSkin.Primary dark_primary,
                                      MaterialSkin.Controls.MaterialRadioButton Blue_rb,
                                      MaterialSkin.Controls.MaterialRadioButton Green_rb,
                                      MaterialSkin.Controls.MaterialRadioButton Orange_rb,
                                      MaterialSkin.Controls.MaterialRadioButton Pink_rb )
        {
            Boolean b;
            b = modern_settings_form.Properties.Settings.Default.skin_color_blue;
             Blue_rb.Checked = b;
            //---------------
            if (b == true)
            {
                primary_color = MaterialSkin.Primary.Blue400;
                dark_primary = MaterialSkin.Primary.Blue700;
            }
            //---------------
            //------------------------
            b = modern_settings_form.Properties.Settings.Default.skin_color_green;
             Green_rb.Checked = b;
            //---------------
            if (b == true)
            {
                primary_color = MaterialSkin.Primary.Green400;
                dark_primary = MaterialSkin.Primary.Green700;
            }
            //---------------
            //---------------------------
            b = modern_settings_form.Properties.Settings.Default.skin_color_orange;
             Orange_rb.Checked = b;
            //---------------
            if (b == true)
            {
                primary_color = MaterialSkin.Primary.Orange400;
                dark_primary = MaterialSkin.Primary.Orange700;
            }
            //---------------
            //----------------------------
            b = modern_settings_form.Properties.Settings.Default.skin_color_pink;
             Pink_rb.Checked = b;
            //---------------
            if (b == true)
            {
                primary_color = MaterialSkin.Primary.Pink400;
                dark_primary = MaterialSkin.Primary.Pink700;
            }
            //---------------
        }


        public void text_color_loader(MaterialSkin.Controls.MaterialRadioButton text_color_white_rb,
                                      MaterialSkin.Controls.MaterialRadioButton text_color_black_rb,
                                      ref MaterialSkin.TextShade text_color)
        {
            Boolean b;
            b = modern_settings_form.Properties.Settings.Default.text_color_white;
             text_color_white_rb.Checked = b;
            if (b == true)
            {
                text_color = MaterialSkin.TextShade.WHITE;
            }
            //---------------
            b = modern_settings_form.Properties.Settings.Default.text_color_black;
            text_color_black_rb.Checked = b;
            if (b == true)
            {
                text_color = MaterialSkin.TextShade.BLACK;
            }
        }
    }
}

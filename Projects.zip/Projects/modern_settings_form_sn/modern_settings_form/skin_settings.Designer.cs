﻿namespace modern_settings_form
{
    partial class skin_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.dark_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.light_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.Green_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.Blue_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.Pink_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.Orange_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.text_color_white_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.text_color_black_rb = new MaterialSkin.Controls.MaterialRadioButton();
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(88, 73);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(59, 19);
            this.materialLabel1.TabIndex = 15;
            this.materialLabel1.Text = "Theme:";
            // 
            // dark_rb
            // 
            this.dark_rb.AutoSize = true;
            this.dark_rb.Depth = 0;
            this.dark_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.dark_rb.Location = new System.Drawing.Point(274, 68);
            this.dark_rb.Margin = new System.Windows.Forms.Padding(0);
            this.dark_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.dark_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.dark_rb.Name = "dark_rb";
            this.dark_rb.Ripple = true;
            this.dark_rb.Size = new System.Drawing.Size(57, 30);
            this.dark_rb.TabIndex = 14;
            this.dark_rb.Text = "Dark";
            this.dark_rb.UseVisualStyleBackColor = true;
            this.dark_rb.CheckedChanged += new System.EventHandler(this.Dark_rb_CheckedChanged);
            this.dark_rb.Click += new System.EventHandler(this.Dark_rb_Click);
            // 
            // light_rb
            // 
            this.light_rb.AutoSize = true;
            this.light_rb.Checked = true;
            this.light_rb.Depth = 0;
            this.light_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.light_rb.Location = new System.Drawing.Point(162, 68);
            this.light_rb.Margin = new System.Windows.Forms.Padding(0);
            this.light_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.light_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.light_rb.Name = "light_rb";
            this.light_rb.Ripple = true;
            this.light_rb.Size = new System.Drawing.Size(60, 30);
            this.light_rb.TabIndex = 13;
            this.light_rb.Text = "Light";
            this.light_rb.UseVisualStyleBackColor = true;
            this.light_rb.CheckedChanged += new System.EventHandler(this.Light_rb_CheckedChanged);
            this.light_rb.Click += new System.EventHandler(this.Light_rb_Click);
            // 
            // materialLabel2
            // 
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(69, 60);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(83, 19);
            this.materialLabel2.TabIndex = 19;
            this.materialLabel2.Text = "Skin Color:";
            // 
            // Green_rb
            // 
            this.Green_rb.AutoSize = true;
            this.Green_rb.Depth = 0;
            this.Green_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.Green_rb.Location = new System.Drawing.Point(271, 55);
            this.Green_rb.Margin = new System.Windows.Forms.Padding(0);
            this.Green_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.Green_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.Green_rb.Name = "Green_rb";
            this.Green_rb.Ripple = true;
            this.Green_rb.Size = new System.Drawing.Size(66, 30);
            this.Green_rb.TabIndex = 18;
            this.Green_rb.Text = "Green";
            this.Green_rb.UseVisualStyleBackColor = true;
            this.Green_rb.Click += new System.EventHandler(this.Green_rb_Click);
            // 
            // Blue_rb
            // 
            this.Blue_rb.AutoSize = true;
            this.Blue_rb.Checked = true;
            this.Blue_rb.Depth = 0;
            this.Blue_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.Blue_rb.Location = new System.Drawing.Point(159, 55);
            this.Blue_rb.Margin = new System.Windows.Forms.Padding(0);
            this.Blue_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.Blue_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.Blue_rb.Name = "Blue_rb";
            this.Blue_rb.Ripple = true;
            this.Blue_rb.Size = new System.Drawing.Size(56, 30);
            this.Blue_rb.TabIndex = 17;
            this.Blue_rb.Text = "Blue";
            this.Blue_rb.UseVisualStyleBackColor = true;
            this.Blue_rb.Click += new System.EventHandler(this.Blue_rb_Click);
            // 
            // Pink_rb
            // 
            this.Pink_rb.AutoSize = true;
            this.Pink_rb.Depth = 0;
            this.Pink_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.Pink_rb.Location = new System.Drawing.Point(271, 98);
            this.Pink_rb.Margin = new System.Windows.Forms.Padding(0);
            this.Pink_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.Pink_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.Pink_rb.Name = "Pink_rb";
            this.Pink_rb.Ripple = true;
            this.Pink_rb.Size = new System.Drawing.Size(56, 30);
            this.Pink_rb.TabIndex = 21;
            this.Pink_rb.Text = "Pink";
            this.Pink_rb.UseVisualStyleBackColor = true;
            this.Pink_rb.CheckedChanged += new System.EventHandler(this.Pink_rb_CheckedChanged);
            this.Pink_rb.Click += new System.EventHandler(this.Pink_rb_Click);
            // 
            // Orange_rb
            // 
            this.Orange_rb.AutoSize = true;
            this.Orange_rb.Depth = 0;
            this.Orange_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.Orange_rb.Location = new System.Drawing.Point(159, 98);
            this.Orange_rb.Margin = new System.Windows.Forms.Padding(0);
            this.Orange_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.Orange_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.Orange_rb.Name = "Orange_rb";
            this.Orange_rb.Ripple = true;
            this.Orange_rb.Size = new System.Drawing.Size(73, 30);
            this.Orange_rb.TabIndex = 20;
            this.Orange_rb.Text = "Orange";
            this.Orange_rb.UseVisualStyleBackColor = true;
            this.Orange_rb.Click += new System.EventHandler(this.Orange_rb_Click);
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(0, 71);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(461, 42);
            this.materialTabSelector1.TabIndex = 22;
            this.materialTabSelector1.Text = "materialTabSelector1";
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(0, 107);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(461, 236);
            this.materialTabControl1.TabIndex = 23;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.materialLabel1);
            this.tabPage1.Controls.Add(this.light_rb);
            this.tabPage1.Controls.Add(this.dark_rb);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(453, 208);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Theme";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Blue_rb);
            this.tabPage2.Controls.Add(this.Pink_rb);
            this.tabPage2.Controls.Add(this.Green_rb);
            this.tabPage2.Controls.Add(this.Orange_rb);
            this.tabPage2.Controls.Add(this.materialLabel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(453, 208);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Skin Color";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.materialLabel3);
            this.tabPage3.Controls.Add(this.text_color_white_rb);
            this.tabPage3.Controls.Add(this.text_color_black_rb);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(453, 208);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Text Color";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(62, 82);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(83, 19);
            this.materialLabel3.TabIndex = 18;
            this.materialLabel3.Text = "Text Color:";
            // 
            // text_color_white_rb
            // 
            this.text_color_white_rb.AutoSize = true;
            this.text_color_white_rb.Checked = true;
            this.text_color_white_rb.Depth = 0;
            this.text_color_white_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.text_color_white_rb.Location = new System.Drawing.Point(159, 77);
            this.text_color_white_rb.Margin = new System.Windows.Forms.Padding(0);
            this.text_color_white_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.text_color_white_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.text_color_white_rb.Name = "text_color_white_rb";
            this.text_color_white_rb.Ripple = true;
            this.text_color_white_rb.Size = new System.Drawing.Size(64, 30);
            this.text_color_white_rb.TabIndex = 16;
            this.text_color_white_rb.Text = "White";
            this.text_color_white_rb.UseVisualStyleBackColor = true;
            this.text_color_white_rb.Click += new System.EventHandler(this.Text_color_white_rb_Click);
            // 
            // text_color_black_rb
            // 
            this.text_color_black_rb.AutoSize = true;
            this.text_color_black_rb.Depth = 0;
            this.text_color_black_rb.Font = new System.Drawing.Font("Roboto", 10F);
            this.text_color_black_rb.Location = new System.Drawing.Point(271, 77);
            this.text_color_black_rb.Margin = new System.Windows.Forms.Padding(0);
            this.text_color_black_rb.MouseLocation = new System.Drawing.Point(-1, -1);
            this.text_color_black_rb.MouseState = MaterialSkin.MouseState.HOVER;
            this.text_color_black_rb.Name = "text_color_black_rb";
            this.text_color_black_rb.Ripple = true;
            this.text_color_black_rb.Size = new System.Drawing.Size(63, 30);
            this.text_color_black_rb.TabIndex = 17;
            this.text_color_black_rb.Text = "Black";
            this.text_color_black_rb.UseVisualStyleBackColor = true;
            this.text_color_black_rb.Click += new System.EventHandler(this.Text_color_black_rb_Click);
            // 
            // skin_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(463, 355);
            this.Controls.Add(this.materialTabSelector1);
            this.Controls.Add(this.materialTabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "skin_settings";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Skin Chosser";
            this.Load += new System.EventHandler(this.Skin_settings_Load);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRadioButton dark_rb;
        private MaterialSkin.Controls.MaterialRadioButton light_rb;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialRadioButton Green_rb;
        private MaterialSkin.Controls.MaterialRadioButton Blue_rb;
        private MaterialSkin.Controls.MaterialRadioButton Pink_rb;
        private MaterialSkin.Controls.MaterialRadioButton Orange_rb;
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialRadioButton text_color_white_rb;
        private MaterialSkin.Controls.MaterialRadioButton text_color_black_rb;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modern_settings_form
{
    public partial class skin_settings : MaterialSkin.Controls.MaterialForm 
    {
        public skin_settings()
        {
            InitializeComponent();
        }

        MaterialSkin.MaterialSkinManager sm;
        MaterialSkin.Primary primary_color= MaterialSkin.Primary.Blue400;
        MaterialSkin.Primary dark_primary= MaterialSkin.Primary.Blue700;
        MaterialSkin.TextShade text_color = MaterialSkin.TextShade.WHITE;
        modern_settings_form.my_classes.skin_loader_cls my_class = new my_classes.skin_loader_cls();


        private void Skin_settings_Load(object sender, EventArgs e)
        {
           
            sm = MaterialSkin.MaterialSkinManager.Instance;
            sm.AddFormToManage(this);
            //------------------------------
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT  ;
            //--------------------------------
            sm.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Blue400,
                                                          MaterialSkin.Primary.Blue700,
                                                          MaterialSkin.Primary.Blue100,
                                                          MaterialSkin.Accent.Orange400,
                                                          MaterialSkin.TextShade.WHITE);
            //----------------------Load settings---------------------
            //-------------------- Load Theme -------------------------
            my_class.theme_loader(this.light_rb, this.dark_rb, sm);
            //--------------------------------------------------------
            //---------------------restore skin color-----------------
            my_class.skin_color_loader(ref primary_color, ref dark_primary,
                                       this.Blue_rb, this.Green_rb,
                                       this.Orange_rb, this.Pink_rb);
            //--------------------------------------------------------
            //-------------------- restore text color-----------------
            my_class.text_color_loader(this.text_color_white_rb, this.text_color_black_rb,ref text_color);
            //--------------------------------------------------------
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color,sm);
            //------------------
          
          }

        private void Light_rb_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Dark_rb_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Light_rb_Click(object sender, EventArgs e)
        {
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            modern_settings_form.Properties.Settings.Default.theme_light_rb = this.light_rb.Checked;
            modern_settings_form.Properties.Settings.Default.theme_dark_rb = this.dark_rb.Checked;
            modern_settings_form.Properties.Settings.Default.Save();
        }

        private void Dark_rb_Click(object sender, EventArgs e)
        {
           sm.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
            modern_settings_form.Properties.Settings.Default.theme_light_rb = this.light_rb.Checked;
            modern_settings_form.Properties.Settings.Default.theme_dark_rb = this.dark_rb.Checked;
            modern_settings_form.Properties.Settings.Default.Save();
        }

        private void Blue_rb_Click(object sender, EventArgs e)
        {
            //------------------
            primary_color = MaterialSkin.Primary.Blue400;
            dark_primary = MaterialSkin.Primary.Blue700;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            color_loader();
            //------------------
        }

        private void Green_rb_Click(object sender, EventArgs e)
        {
            //------------------
            primary_color = MaterialSkin.Primary.Green400;
            dark_primary = MaterialSkin.Primary.Green700;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            color_loader();
            //------------------
        }

        private void Orange_rb_Click(object sender, EventArgs e)
        {
            //------------------
            primary_color = MaterialSkin.Primary.Orange400;
            dark_primary = MaterialSkin.Primary.Orange700;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            color_loader();
            //------------------
        }

        private void Pink_rb_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Pink_rb_Click(object sender, EventArgs e)
        {
            //------------------
            primary_color = MaterialSkin.Primary.Pink400;
            dark_primary = MaterialSkin.Primary.Pink700;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            color_loader();
            //------------------
        }

        void color_loader()
        {
            //---------------------------
            modern_settings_form.Properties.Settings.Default.skin_color_blue = this.Blue_rb.Checked;
            modern_settings_form.Properties.Settings.Default.skin_color_green = this.Green_rb.Checked;
            modern_settings_form.Properties.Settings.Default.skin_color_orange = this.Orange_rb.Checked;
            modern_settings_form.Properties.Settings.Default.skin_color_pink = this.Pink_rb.Checked;
            modern_settings_form.Properties.Settings.Default.Save();
            //---------------------------
        }

     

        private void Text_color_white_rb_Click(object sender, EventArgs e)
        {
            //------------------
            text_color = MaterialSkin.TextShade.WHITE;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            modern_settings_form.Properties.Settings.Default.text_color_white = this.text_color_white_rb.Checked;
            modern_settings_form.Properties.Settings.Default.text_color_black = this.text_color_black_rb.Checked;
            modern_settings_form.Properties.Settings.Default.Save();
            //-----------------
        }

        private void Text_color_black_rb_Click(object sender, EventArgs e)
        {
            //------------------
            text_color = MaterialSkin.TextShade.BLACK;
            //------------------
            my_class.color_changer(primary_color, dark_primary, text_color, sm);
            //------------------
            modern_settings_form.Properties.Settings.Default.text_color_white = this.text_color_white_rb.Checked;
            modern_settings_form.Properties.Settings.Default.text_color_black = this.text_color_black_rb.Checked;
            modern_settings_form.Properties.Settings.Default.Save();
            //-----------------
        }
    }
}

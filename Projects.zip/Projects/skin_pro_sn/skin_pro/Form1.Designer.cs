﻿namespace skin_pro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.materialContextMenuStrip1 = new MaterialSkin.Controls.MaterialContextMenuStrip();
            this.sdsdsdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.materialContextMenuStrip2 = new MaterialSkin.Controls.MaterialContextMenuStrip();
            this.dark_butt = new MaterialSkin.Controls.MaterialFlatButton();
            this.light_butt = new MaterialSkin.Controls.MaterialFlatButton();
            this.ml = new MaterialSkin.Controls.MaterialLabel();
            this.MaterialCheckBox3 = new MaterialSkin.Controls.MaterialCheckBox();
            this.MaterialFlatButton1 = new MaterialSkin.Controls.MaterialFlatButton();
            this.MaterialRaisedButton2 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.MaterialRadioButton4 = new MaterialSkin.Controls.MaterialRadioButton();
            this.MaterialCheckBox2 = new MaterialSkin.Controls.MaterialCheckBox();
            this.MaterialRadioButton3 = new MaterialSkin.Controls.MaterialRadioButton();
            this.MaterialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.MaterialSingleLineTextField2 = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.MaterialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.MaterialRadioButton2 = new MaterialSkin.Controls.MaterialRadioButton();
            this.MaterialCheckBox1 = new MaterialSkin.Controls.MaterialCheckBox();
            this.MaterialRadioButton1 = new MaterialSkin.Controls.MaterialRadioButton();
            this.TabPage2 = new System.Windows.Forms.TabPage();
            this.MaterialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.MaterialDivider1 = new MaterialSkin.Controls.MaterialDivider();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialContextMenuStrip1.SuspendLayout();
            this.MaterialTabControl1.SuspendLayout();
            this.TabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialContextMenuStrip1
            // 
            this.materialContextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialContextMenuStrip1.Depth = 0;
            this.materialContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sdsdsdToolStripMenuItem});
            this.materialContextMenuStrip1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialContextMenuStrip1.Name = "materialContextMenuStrip1";
            this.materialContextMenuStrip1.Size = new System.Drawing.Size(111, 26);
            // 
            // sdsdsdToolStripMenuItem
            // 
            this.sdsdsdToolStripMenuItem.Name = "sdsdsdToolStripMenuItem";
            this.sdsdsdToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.sdsdsdToolStripMenuItem.Text = "sdsdsd";
            // 
            // materialContextMenuStrip2
            // 
            this.materialContextMenuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.materialContextMenuStrip2.Depth = 0;
            this.materialContextMenuStrip2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialContextMenuStrip2.Name = "materialContextMenuStrip2";
            this.materialContextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // dark_butt
            // 
            this.dark_butt.AutoSize = true;
            this.dark_butt.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.dark_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dark_butt.Depth = 0;
            this.dark_butt.Location = new System.Drawing.Point(396, 26);
            this.dark_butt.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dark_butt.MouseState = MaterialSkin.MouseState.HOVER;
            this.dark_butt.Name = "dark_butt";
            this.dark_butt.Primary = true;
            this.dark_butt.Size = new System.Drawing.Size(47, 36);
            this.dark_butt.TabIndex = 11;
            this.dark_butt.Text = "Dark";
            this.dark_butt.UseVisualStyleBackColor = true;
            this.dark_butt.Click += new System.EventHandler(this.Dark_butt_Click);
            // 
            // light_butt
            // 
            this.light_butt.AutoSize = true;
            this.light_butt.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.light_butt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.light_butt.Depth = 0;
            this.light_butt.Location = new System.Drawing.Point(340, 26);
            this.light_butt.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.light_butt.MouseState = MaterialSkin.MouseState.HOVER;
            this.light_butt.Name = "light_butt";
            this.light_butt.Primary = true;
            this.light_butt.Size = new System.Drawing.Size(51, 36);
            this.light_butt.TabIndex = 12;
            this.light_butt.Text = "Light";
            this.light_butt.UseVisualStyleBackColor = true;
            this.light_butt.Click += new System.EventHandler(this.Light_butt_Click);
            // 
            // ml
            // 
            this.ml.AutoSize = true;
            this.ml.Depth = 0;
            this.ml.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ml.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ml.Location = new System.Drawing.Point(28, 369);
            this.ml.MouseState = MaterialSkin.MouseState.HOVER;
            this.ml.Name = "ml";
            this.ml.Size = new System.Drawing.Size(103, 18);
            this.ml.TabIndex = 36;
            this.ml.Text = "MaterialLabel1";
            // 
            // MaterialCheckBox3
            // 
            this.MaterialCheckBox3.AutoSize = true;
            this.MaterialCheckBox3.Checked = true;
            this.MaterialCheckBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MaterialCheckBox3.Depth = 0;
            this.MaterialCheckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialCheckBox3.Location = new System.Drawing.Point(238, 298);
            this.MaterialCheckBox3.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialCheckBox3.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialCheckBox3.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialCheckBox3.Name = "MaterialCheckBox3";
            this.MaterialCheckBox3.Ripple = true;
            this.MaterialCheckBox3.Size = new System.Drawing.Size(150, 30);
            this.MaterialCheckBox3.TabIndex = 34;
            this.MaterialCheckBox3.Text = "MaterialCheckBox3";
            this.MaterialCheckBox3.UseVisualStyleBackColor = true;
            // 
            // MaterialFlatButton1
            // 
            this.MaterialFlatButton1.AutoSize = true;
            this.MaterialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.MaterialFlatButton1.Depth = 0;
            this.MaterialFlatButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialFlatButton1.Location = new System.Drawing.Point(349, 422);
            this.MaterialFlatButton1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.MaterialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialFlatButton1.Name = "MaterialFlatButton1";
            this.MaterialFlatButton1.Primary = true;
            this.MaterialFlatButton1.Size = new System.Drawing.Size(46, 36);
            this.MaterialFlatButton1.TabIndex = 26;
            this.MaterialFlatButton1.Text = "Save";
            this.MaterialFlatButton1.UseVisualStyleBackColor = true;
            // 
            // MaterialRaisedButton2
            // 
            this.MaterialRaisedButton2.Depth = 0;
            this.MaterialRaisedButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialRaisedButton2.ForeColor = System.Drawing.Color.Red;
            this.MaterialRaisedButton2.Location = new System.Drawing.Point(220, 424);
            this.MaterialRaisedButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialRaisedButton2.Name = "MaterialRaisedButton2";
            this.MaterialRaisedButton2.Primary = true;
            this.MaterialRaisedButton2.Size = new System.Drawing.Size(105, 34);
            this.MaterialRaisedButton2.TabIndex = 25;
            this.MaterialRaisedButton2.Text = "Save";
            this.MaterialRaisedButton2.UseVisualStyleBackColor = true;
            // 
            // MaterialRadioButton4
            // 
            this.MaterialRadioButton4.AutoSize = true;
            this.MaterialRadioButton4.Depth = 0;
            this.MaterialRadioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialRadioButton4.Location = new System.Drawing.Point(40, 297);
            this.MaterialRadioButton4.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialRadioButton4.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialRadioButton4.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialRadioButton4.Name = "MaterialRadioButton4";
            this.MaterialRadioButton4.Ripple = true;
            this.MaterialRadioButton4.Size = new System.Drawing.Size(163, 30);
            this.MaterialRadioButton4.TabIndex = 33;
            this.MaterialRadioButton4.Text = "MaterialRadioButton4";
            this.MaterialRadioButton4.UseVisualStyleBackColor = true;
            // 
            // MaterialCheckBox2
            // 
            this.MaterialCheckBox2.AutoSize = true;
            this.MaterialCheckBox2.Checked = true;
            this.MaterialCheckBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MaterialCheckBox2.Depth = 0;
            this.MaterialCheckBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialCheckBox2.Location = new System.Drawing.Point(238, 265);
            this.MaterialCheckBox2.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialCheckBox2.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialCheckBox2.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialCheckBox2.Name = "MaterialCheckBox2";
            this.MaterialCheckBox2.Ripple = true;
            this.MaterialCheckBox2.Size = new System.Drawing.Size(150, 30);
            this.MaterialCheckBox2.TabIndex = 32;
            this.MaterialCheckBox2.Text = "MaterialCheckBox2";
            this.MaterialCheckBox2.UseVisualStyleBackColor = true;
            // 
            // MaterialRadioButton3
            // 
            this.MaterialRadioButton3.AutoSize = true;
            this.MaterialRadioButton3.Checked = true;
            this.MaterialRadioButton3.Depth = 0;
            this.MaterialRadioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialRadioButton3.Location = new System.Drawing.Point(45, 277);
            this.MaterialRadioButton3.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialRadioButton3.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialRadioButton3.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialRadioButton3.Name = "MaterialRadioButton3";
            this.MaterialRadioButton3.Ripple = false;
            this.MaterialRadioButton3.Size = new System.Drawing.Size(158, 20);
            this.MaterialRadioButton3.TabIndex = 31;
            this.MaterialRadioButton3.TabStop = true;
            this.MaterialRadioButton3.Text = "MaterialRadioButton3";
            this.MaterialRadioButton3.UseVisualStyleBackColor = true;
            // 
            // MaterialLabel2
            // 
            this.MaterialLabel2.AutoSize = true;
            this.MaterialLabel2.Depth = 0;
            this.MaterialLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.MaterialLabel2.Location = new System.Drawing.Point(15, 244);
            this.MaterialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialLabel2.Name = "MaterialLabel2";
            this.MaterialLabel2.Size = new System.Drawing.Size(209, 42);
            this.MaterialLabel2.TabIndex = 30;
            this.MaterialLabel2.Text = "First Name:";
            // 
            // MaterialSingleLineTextField2
            // 
            this.MaterialSingleLineTextField2.Depth = 0;
            this.MaterialSingleLineTextField2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialSingleLineTextField2.Hint = "First Name";
            this.MaterialSingleLineTextField2.Location = new System.Drawing.Point(106, 239);
            this.MaterialSingleLineTextField2.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialSingleLineTextField2.Name = "MaterialSingleLineTextField2";
            this.MaterialSingleLineTextField2.PasswordChar = '\0';
            this.MaterialSingleLineTextField2.SelectedText = "";
            this.MaterialSingleLineTextField2.SelectionLength = 0;
            this.MaterialSingleLineTextField2.SelectionStart = 0;
            this.MaterialSingleLineTextField2.Size = new System.Drawing.Size(309, 23);
            this.MaterialSingleLineTextField2.TabIndex = 29;
            this.MaterialSingleLineTextField2.UseSystemPasswordChar = false;
            // 
            // MaterialTabControl1
            // 
            this.MaterialTabControl1.Controls.Add(this.TabPage1);
            this.MaterialTabControl1.Controls.Add(this.TabPage2);
            this.MaterialTabControl1.Depth = 0;
            this.MaterialTabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaterialTabControl1.Location = new System.Drawing.Point(8, 105);
            this.MaterialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialTabControl1.Name = "MaterialTabControl1";
            this.MaterialTabControl1.SelectedIndex = 0;
            this.MaterialTabControl1.Size = new System.Drawing.Size(438, 118);
            this.MaterialTabControl1.TabIndex = 28;
            // 
            // TabPage1
            // 
            this.TabPage1.BackColor = System.Drawing.Color.White;
            this.TabPage1.Controls.Add(this.MaterialRadioButton2);
            this.TabPage1.Controls.Add(this.MaterialCheckBox1);
            this.TabPage1.Controls.Add(this.MaterialRadioButton1);
            this.TabPage1.Location = new System.Drawing.Point(4, 42);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(430, 72);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "Settings";
            // 
            // MaterialRadioButton2
            // 
            this.MaterialRadioButton2.AutoSize = true;
            this.MaterialRadioButton2.Depth = 0;
            this.MaterialRadioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.MaterialRadioButton2.Location = new System.Drawing.Point(28, 45);
            this.MaterialRadioButton2.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialRadioButton2.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialRadioButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialRadioButton2.Name = "MaterialRadioButton2";
            this.MaterialRadioButton2.Ripple = true;
            this.MaterialRadioButton2.Size = new System.Drawing.Size(163, 30);
            this.MaterialRadioButton2.TabIndex = 15;
            this.MaterialRadioButton2.TabStop = true;
            this.MaterialRadioButton2.Text = "MaterialRadioButton2";
            this.MaterialRadioButton2.UseVisualStyleBackColor = true;
            // 
            // MaterialCheckBox1
            // 
            this.MaterialCheckBox1.AutoSize = true;
            this.MaterialCheckBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.MaterialCheckBox1.Depth = 0;
            this.MaterialCheckBox1.Font = new System.Drawing.Font("Roboto", 10F);
            this.MaterialCheckBox1.ForeColor = System.Drawing.Color.Black;
            this.MaterialCheckBox1.Location = new System.Drawing.Point(253, 9);
            this.MaterialCheckBox1.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialCheckBox1.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialCheckBox1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialCheckBox1.Name = "MaterialCheckBox1";
            this.MaterialCheckBox1.Ripple = true;
            this.MaterialCheckBox1.Size = new System.Drawing.Size(150, 30);
            this.MaterialCheckBox1.TabIndex = 9;
            this.MaterialCheckBox1.Text = "MaterialCheckBox1";
            this.MaterialCheckBox1.UseVisualStyleBackColor = false;
            this.MaterialCheckBox1.Visible = false;
            // 
            // MaterialRadioButton1
            // 
            this.MaterialRadioButton1.AutoSize = true;
            this.MaterialRadioButton1.Depth = 0;
            this.MaterialRadioButton1.Font = new System.Drawing.Font("Roboto", 10F);
            this.MaterialRadioButton1.Location = new System.Drawing.Point(253, 57);
            this.MaterialRadioButton1.Margin = new System.Windows.Forms.Padding(0);
            this.MaterialRadioButton1.MouseLocation = new System.Drawing.Point(-1, -1);
            this.MaterialRadioButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialRadioButton1.Name = "MaterialRadioButton1";
            this.MaterialRadioButton1.Ripple = true;
            this.MaterialRadioButton1.Size = new System.Drawing.Size(163, 30);
            this.MaterialRadioButton1.TabIndex = 10;
            this.MaterialRadioButton1.TabStop = true;
            this.MaterialRadioButton1.Text = "MaterialRadioButton1";
            this.MaterialRadioButton1.UseVisualStyleBackColor = true;
            // 
            // TabPage2
            // 
            this.TabPage2.Location = new System.Drawing.Point(4, 34);
            this.TabPage2.Name = "TabPage2";
            this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage2.Size = new System.Drawing.Size(430, 80);
            this.TabPage2.TabIndex = 1;
            this.TabPage2.Text = "About";
            this.TabPage2.UseVisualStyleBackColor = true;
            // 
            // MaterialTabSelector1
            // 
            this.MaterialTabSelector1.BaseTabControl = this.MaterialTabControl1;
            this.MaterialTabSelector1.Depth = 0;
            this.MaterialTabSelector1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialTabSelector1.Location = new System.Drawing.Point(5, 73);
            this.MaterialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialTabSelector1.Name = "MaterialTabSelector1";
            this.MaterialTabSelector1.Size = new System.Drawing.Size(441, 32);
            this.MaterialTabSelector1.TabIndex = 27;
            this.MaterialTabSelector1.Text = "MaterialTabSelector1";
            // 
            // MaterialDivider1
            // 
            this.MaterialDivider1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.MaterialDivider1.Depth = 0;
            this.MaterialDivider1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.MaterialDivider1.Location = new System.Drawing.Point(2, 404);
            this.MaterialDivider1.MouseState = MaterialSkin.MouseState.HOVER;
            this.MaterialDivider1.Name = "MaterialDivider1";
            this.MaterialDivider1.Size = new System.Drawing.Size(458, 1);
            this.MaterialDivider1.TabIndex = 35;
            this.MaterialDivider1.Text = "MaterialDivider1";
            // 
            // materialLabel1
            // 
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(45, 424);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(75, 13);
            this.materialLabel1.TabIndex = 37;
            this.materialLabel1.Text = "materialLabel1";
            // 
            // materialLabel3
            // 
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(169, 349);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(113, 21);
            this.materialLabel3.TabIndex = 38;
            this.materialLabel3.Text = "materialLabel3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(450, 476);
            this.Controls.Add(this.materialLabel3);
            this.Controls.Add(this.materialLabel1);
            this.Controls.Add(this.ml);
            this.Controls.Add(this.MaterialCheckBox3);
            this.Controls.Add(this.MaterialFlatButton1);
            this.Controls.Add(this.MaterialRaisedButton2);
            this.Controls.Add(this.MaterialRadioButton4);
            this.Controls.Add(this.MaterialCheckBox2);
            this.Controls.Add(this.MaterialRadioButton3);
            this.Controls.Add(this.MaterialLabel2);
            this.Controls.Add(this.MaterialSingleLineTextField2);
            this.Controls.Add(this.MaterialTabControl1);
            this.Controls.Add(this.MaterialTabSelector1);
            this.Controls.Add(this.MaterialDivider1);
            this.Controls.Add(this.light_butt);
            this.Controls.Add(this.dark_butt);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Skin";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.materialContextMenuStrip1.ResumeLayout(false);
            this.MaterialTabControl1.ResumeLayout(false);
            this.TabPage1.ResumeLayout(false);
            this.TabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MaterialSkin.Controls.MaterialContextMenuStrip materialContextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sdsdsdToolStripMenuItem;
        private MaterialSkin.Controls.MaterialContextMenuStrip materialContextMenuStrip2;
        private MaterialSkin.Controls.MaterialFlatButton dark_butt;
        private MaterialSkin.Controls.MaterialFlatButton light_butt;
        internal MaterialSkin.Controls.MaterialLabel ml;
        internal MaterialSkin.Controls.MaterialCheckBox MaterialCheckBox3;
        internal MaterialSkin.Controls.MaterialFlatButton MaterialFlatButton1;
        internal MaterialSkin.Controls.MaterialRaisedButton MaterialRaisedButton2;
        internal MaterialSkin.Controls.MaterialRadioButton MaterialRadioButton4;
        internal MaterialSkin.Controls.MaterialCheckBox MaterialCheckBox2;
        internal MaterialSkin.Controls.MaterialRadioButton MaterialRadioButton3;
        internal MaterialSkin.Controls.MaterialLabel MaterialLabel2;
        internal MaterialSkin.Controls.MaterialSingleLineTextField MaterialSingleLineTextField2;
        internal MaterialSkin.Controls.MaterialTabControl MaterialTabControl1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal MaterialSkin.Controls.MaterialRadioButton MaterialRadioButton2;
        internal MaterialSkin.Controls.MaterialCheckBox MaterialCheckBox1;
        internal MaterialSkin.Controls.MaterialRadioButton MaterialRadioButton1;
        internal System.Windows.Forms.TabPage TabPage2;
        internal MaterialSkin.Controls.MaterialTabSelector MaterialTabSelector1;
        internal MaterialSkin.Controls.MaterialDivider MaterialDivider1;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
    }
}


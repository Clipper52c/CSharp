﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skin_pro
{
    public partial class Form1 : MaterialSkin.Controls.MaterialForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        MaterialSkin.MaterialSkinManager sm;

        private void Form1_Load(object sender, EventArgs e)
        {
        
            sm = MaterialSkin.MaterialSkinManager.Instance;
            sm.AddFormToManage(this);
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            sm.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Orange500,
                                                          MaterialSkin.Primary.Orange800,
                                                          MaterialSkin.Primary.Orange200,
                                                          MaterialSkin.Accent.Green400,
                                                          MaterialSkin.TextShade.BLACK);

            this.materialLabel1.Font = sm.ROBOTO_MEDIUM_10;
            this.Text = this.materialLabel1.Font.ToString();
            this.MaterialRadioButton2.Font = sm.ROBOTO_MEDIUM_12;
            this.materialLabel3.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            this.Text = this.materialLabel3.Font.ToString();
        }

        private void Light_butt_Click(object sender, EventArgs e)
        {
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
        }

        private void Dark_butt_Click(object sender, EventArgs e)
        {
            sm.Theme = MaterialSkin.MaterialSkinManager.Themes.DARK;
        }
    }
}

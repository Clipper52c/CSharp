using System.Collections.Generic;


/// <summary>
/// Note that every domain entity needs to have an Id field.
/// An ID field is the primary key and this is used to do your relationship mapping with another domain entity
/// </summary>

namespace Queries
{
    public class Author
    {
        public Author()
        {
            /* Allan Note: the reason you need to initiate Courses here is because, unlike those
               Single, First methods where they are static classes, the Courses property
               is an ICollection, not a static class where you can invoke at well.
               So this requires a separete initiation.
*/
            Courses = new HashSet<Course>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public virtual ICollection<Course> Courses { get; set; }
    }
}

using System.Collections.Generic;

/// <summary>
/// Note that every domain entity needs to have an Id field.
/// This ID field or an ID field is the primary key of this domain and this is used to do all your relationship mappings with another domain entity (if required)
///
/// An important concept to remember when working with relationship is, relationship only concerns with linking 2 tables. Once they are linked, it can be conceptually conceived as one table.
/// After the tables are linked, you can filtered based on any fields, you don't have to filter on the foreign key field just because you happened to link with this field.
/// Relationships linking and using the linked table afterward is 2 completely separate concepts.
/// </summary>


namespace Queries
{
    public class Course
    {
        public Course()
        {
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Level { get; set; }

        public float FullPrice { get; set; }

        public virtual Author Author { get; set; }      // note that this is a generic Author class but in and of itself has no unique key or Author ID to link an Author Object to a Course Collection in the Author class, the link comes in the next line.

        public int AuthorId { get; set; }               // need this entry to make the relationship work. This is the foreign key to the other table, the Author table.
                                                        // however, once this key is setup, you need to supply values to this field, or you will be trying to link blank values of AuthorId to a real primary key in the author table.
                                                        // It appears that Entity Framework knows how to treat this naming convention of AuthorId to mean a foreign key of the Author table.
                                                        // Note also that this field has to be called AuthorId, because this is the Entity Framework convention. If you call it Author123Id, or AllanId, it will not work.
                                                        // There is a way to get around this, it involves you setting the class property on the foreign key. Mosh Hamedani has a video showing you how to do this.

                                                        // Bottom line, you need the AuthorId foreign Id field in the Course table to get the relationship to work, then the "public virtual Author Author { get; set; }" is your navigation property.
                                                        // Without the AuthorId field, the "public virtual Author Author { get; set; }" will not be initiated, and this is why you keep seeing the null object error.

                                                        // So if you comment out the line "public int AuthorId { get; set; }" in this Course table, everything will build just fine, the C# project will build, entity framework will update your database,
                                                        // but you won't get the relationship to work, because you don't have a foreign key, hence, you will not get the 2 tables linked.

                                                        // you still need the line "public virtual Author Author { get; set; }" in the Course table, because after you get the 2 tables link, you will need this
                                                        // navigation property for you to move around in the other table.

    }
}

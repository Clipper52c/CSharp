using System.Collections.Generic;

namespace Queries
{
    public class Course
    {
        public Course()
        {
            /* Allan Note: the reason you need to initiate Tags here is because, unlike those
                           Single, First methods where they are static classes, the Tags property
                           is an ICollection, not a static class where you can invoke at well.
                           So this requires a separete initiation.
            */
            
            Tags = new HashSet<Tag>();
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Level { get; set; }

        public float FullPrice { get; set; }

        public virtual Author Author { get; set; }

        public int AuthorId { get; set; }

        public virtual ICollection<Tag> Tags { get; set; }

        public Cover Cover { get; set; }
    }
}

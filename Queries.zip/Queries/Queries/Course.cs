using System.Collections.Generic;

/// <summary>
/// Note that every domain entity needs to have an Id field.
/// An ID field is the primary key and this is used to do your relationship mapping with another domain entity
/// </summary>


namespace Queries
{
    public class Course
    {
        public Course()
        {
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Level { get; set; }

        public float FullPrice { get; set; }

        public virtual Author Author { get; set; }      // note that this is a generic Author class but has no unique key or Author ID to link a Author Object to a Course Collection in the Author class

        public int AuthorId { get; set; }               // need this entry to make the relationship work

    }
}

﻿using System.Data.Entity.ModelConfiguration;

/// <summary>
/// Need to study 3 files together: CourseConfiguration.cs, Author.cs, and Course.cs
/// Open 3 tabs and study them concurrently.
/// </summary>


namespace Queries.EntityConfigurations
{
    public class CourseConfiguration : EntityTypeConfiguration<Course>
    {
        public CourseConfiguration()
        {
            Property(c => c.Description)
                .IsRequired()
                .HasMaxLength(2000);

            Property(c => c.Name)
            .IsRequired()
            .HasMaxLength(255);

            HasRequired(c => c.Author)
            .WithMany(a => a.Courses)
            .HasForeignKey(c => c.AuthorId)   // this line here appear to be optional, you can comment this line out and it still works.
            .WillCascadeOnDelete(false);
        }
    }
}




/*
  
 * This is the custom Configuration.cs file
  
 * Note that you need to setup the AuthorID in the Author table and use this AuthorID in the Course table to establish a link; you can't rely on the Author Class in the Course table alone.


using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Queries.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Queries.PlutoContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Queries.PlutoContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.

            #region Add Authors
            var authors = new List<Author>
            {
                new Author
                {
                    Id = 1,     // this sets up the link to the Course table below
                    Name = "Mosh Hamedani"
                },
                new Author
                {
                    Id = 2,     // this sets up the link to the Course table below
                    Name = "Anthony Alicea"
                },
                new Author
                {
                    Id = 3,     // this sets up the link to the Course table below
                    Name = "Eric Wise"
                }
            };

            foreach (var author in authors)
                context.Authors.AddOrUpdate(a => a.Id, author);
            #endregion

            #region Add Courses
            var courses = new List<Course>
            {
                new Course
                {
                    Id = 1,
                    Name = "C# Basics",
                    FullPrice = 49,
                    AuthorId = 1,   // need this entry to make the relationship work
                    Description = "Description for C# Basics",
                    Level = 1
                },
                new Course
                {
                    Id = 2,
                    Name = "C# Intermediate",
                    FullPrice = 49,
                    AuthorId = 1,   // need this entry to make the relationship work
                    Description = "Description for C# Intermediate",
                    Level = 2
                },
                new Course
                {
                    Id = 4,
                    Name = "Javascript: Understanding the Weird Parts",
                    FullPrice = 149,
                    AuthorId = 2,   // need this entry to make the relationship work
                    Description = "Description for Javascript",
                    Level = 2
                }
            };

            foreach (var course in courses)
                context.Courses.AddOrUpdate(c => c.Id, course);
            #endregion
        }
    }
}

*/

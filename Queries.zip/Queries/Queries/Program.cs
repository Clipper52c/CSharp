﻿
using System;
using System.Linq;

namespace Queries
{
    class Program
    {
        static void Main1(string[] args)
        {
            var context = new PlutoContext();
            var courses = context.Courses;

            //foreach (var c in courses)
            //    Console.WriteLine(c.Name);

            var query =
                from c in courses
                where c.Author.Name == "Eric Wise"
                select c;

            foreach (var c in query)
            {
                Console.WriteLine(c.Name);
                Console.WriteLine(c.Description);
                Console.WriteLine(c.Author.Name);
                Console.WriteLine(c.FullPrice);
            }




        }
    }
}

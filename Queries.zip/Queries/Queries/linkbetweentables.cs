﻿
using System;
using System.Linq;

namespace Queries
{
    class linkbetweentables
    {
        static void Main(string[] args)
        {
            var context = new PlutoContext();
            var courses = context.Courses;

            //foreach (var c in courses)
            //    Console.WriteLine(c.Name);

            var query =
                from c in courses
                where c.Author.Name == "Anthony Alicea"
                select c;

            // var course = context.Courses.Where(c => c.Name.Contains("C#")).OrderBy(c => c.Name);

            var course = context.Courses
                .Where(c => c.Author.Name == "Anthony Alicea")
                .OrderBy(c => c.Name);

            foreach (var c in course)
            {
                Console.WriteLine(c.Name);
                Console.WriteLine(c.Description);
                Console.WriteLine(c.Author.Name);
                Console.WriteLine(c.FullPrice);
            }
        }
    }
}

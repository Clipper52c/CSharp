﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMXLoader
{
    public static class CustomTimer
    {
        public static Stopwatch sw;
        public static TimeSpan start;
        public static TimeSpan end;

        public static string Start()
        {
            if (sw == null)
            {
                sw = new Stopwatch();
            }

            sw.Start();
            start = sw.Elapsed;

            return sw.Elapsed.ToString();
        }

        public static string Stop()
        {
            sw.Stop();
            end = sw.Elapsed;
            
            return sw.Elapsed.ToString();
        }

        public static void Restart()
        {
            if(sw == null)
            {
                sw = new Stopwatch();
            }

            start = new TimeSpan();
            end = new TimeSpan();

            sw.Restart();
        }

        public static string toString()
        {
            return  (end - start).ToString();
        }
    }
}

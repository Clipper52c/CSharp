﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TMXLoader.Classes;

namespace TMXLoader
{
    class DataParser
    {
        // file contain date and time stamp
        // we sort by time first as the time is contained in a strin gof 15 digits
        // sort by date after time
        private static string[] sortFiles(string[] files)
        {
            Regex r = new Regex(@"\d{4}-\d{2}-\d{2}"); // regex to match date stamp
            Regex x = new Regex(@"\d{15}");

            // sort everything by the 15 digit containing the time
            files = files.OrderBy(f => x.Match(f).Success ? long.Parse(x.Match(f).Value) : 0).ToArray();
            // sort the previously sorted files by date
            files = files.OrderBy(f => r.Match(f).Success ? DateTime.Parse(r.Match(f).Value) : DateTime.Parse("1990-01-01")).ToArray();

            return files;
        }

        public static void parse(string[] files)
        {
            if(files.Count() <= 0)
            {
                Logger.Info("No files found.");
                return;
            }

            DataHelper.init(); // populate the meta (column definitions) and reason codelists
            FileUtil.create_dirs(); // create the directories defined in config if they do not exist

            if(files.Count() > 1)
                files = sortFiles(files); // sort files

            Logger.Info("Processing started.");
            DateTime start = DateTime.Now;

            long remaining = 1, linesFound = 0, linesLost = 0;


            foreach (string f in files)
            {
                // check if the file has already been loaded
                // remove file if already loaded to prevent primary key constraint errors
                if (DataHelper.isLoaded(f))
                {
                    Logger.Info("File has already been loaded: " + f);
                    File.Delete(f);
                    continue;
                }

                CustomTimer.Restart();

                Logger.Debug("Reading file: " + Path.GetFileName(f));
                Logger.Debug("Reading in file...");

                CustomTimer.Start();

                ReadObj obj = ZipHelper.read(f); // read contents of zip file

                if (obj == null)
                    continue;

                CustomTimer.Stop();
                Logger.Debug("Total time taken to read: " + CustomTimer.toString());

                CustomTimer.Restart();

                Logger.Debug(obj.getTable().Rows.Count + " row(s) being inserted...");
                CustomTimer.Start();

                int inserted = SqlCopyHelper.WriteToServer(obj); // Bulk insert into the database, return count of records inserted

                CustomTimer.Stop();
                Logger.Debug("Total time taken to insert: " + CustomTimer.toString());
                Logger.Info("Complete: " + Path.GetFileName(f));
                Logger.Info("Files remaining: " + (files.Count() - remaining));

                linesFound += obj.getLineCount();
                linesLost += (obj.getLineCount() - inserted); // finds number of lines lost


                DataHelper.updateCounts(Path.GetFileName(f), obj.getLineCount(), inserted); // updates counts in FileHistory table
                //File.Delete(f); // remove the file as it is prod data at rest

                ++remaining;
            }

            SqlCopyHelper.close();

            DateTime end = DateTime.Now;
            TimeSpan final = end - start;

            Logger.Info("Complete. See below for details.");
            Logger.Info("Time taken: " + final.ToString());
            Logger.Info("Files Processed: " + files.Count());
            Logger.Info("Files loaded: " + (files.Count() - TMXError.errorCount()));
            Logger.Info("Files with load errors: " + TMXError.errorCount());
            Logger.Info("Total lines lost: " + linesLost);
            Logger.Info("Total Lines found: " + (linesFound - remaining)); // subtract 1 for each file due to each file containing a header
            Logger.Info("Total lines written to database: " + (linesFound - linesLost));

            TMXError.notify(); // send email if there are any errors
        }
    }
}

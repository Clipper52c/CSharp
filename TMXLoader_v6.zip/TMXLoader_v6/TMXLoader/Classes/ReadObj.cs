﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMXLoader
{
    public class ReadObj
    {
        private string path;
        private DataTable table;
        private int lineCount;

        public ReadObj(string path, DataTable table, int lineCount)
        {
            this.path = path;
            this.table = table;
            this.lineCount = lineCount;
        }

        public DataTable getTable()
        {
            return table;
        }

        public string getPath()
        {
            return path;
        }

        public int getLineCount()
        {
            return lineCount;
        }

        public void linesLost(int count)
        {
            lineCount -= count;
        }
    }
}

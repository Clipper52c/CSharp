﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;

namespace TMXLoader
{
    public static class ConfigHelper
    {
        private static string badDir;
        private static string archiveDir;
        private static string schemaQuery;
        private static string reasonSelectQuery;
        private static string reasonInsertQuery;
        private static string destTable;
        private static string tmxDb;
        private static string columns;
        private static string updateHistory;
        private static string updateCounts;
        private static string fromEmail;
        private static string toEmail;
        private static string smtpHost;
        private static string errorMessageQuery;
        private static NameValueCollection formatting;
        private static string loadCheckQuery;
        private static string sourceTable;
        private static string comparedTable;
        private static string resultTable;
        private static string missingIDTable;

        static ConfigHelper()
        {
            badDir = ConfigurationManager.AppSettings["BAD_FILE_DIRECTORY"];
            archiveDir = ConfigurationManager.AppSettings["ARCHIVE_DIRECTORY"];
            schemaQuery = ConfigurationManager.AppSettings["SCHEMA_QUERY"];
            reasonSelectQuery = ConfigurationManager.AppSettings["REASON_SELECT_QUERY"];
            reasonInsertQuery = ConfigurationManager.AppSettings["REASON_INSERT_QUERY"];
            destTable = ConfigurationManager.AppSettings["DESTINATION_TABLE"];
            tmxDb = ConfigurationManager.AppSettings["DATABASE_TMX"];
            columns = ConfigurationManager.AppSettings["COLUMNS"];
            updateHistory = ConfigurationManager.AppSettings["UPDATE_HISTORY"];
            updateCounts = ConfigurationManager.AppSettings["UPDATE_COUNTS"];
            fromEmail = ConfigurationManager.AppSettings["FROM_EMAIL"];
            toEmail = ConfigurationManager.AppSettings["TO_EMAIL"];
            smtpHost = ConfigurationManager.AppSettings["SMTP_HOST"];
            errorMessageQuery = ConfigurationManager.AppSettings["UPDATE_ERROR_MESSAGE"];
            formatting = (NameValueCollection)ConfigurationManager.GetSection("Formatting");
            loadCheckQuery = ConfigurationManager.AppSettings["LOAD_CHECK_QUERY"];

            sourceTable = ConfigurationManager.AppSettings["SOURCE_TABLE"];
            comparedTable = ConfigurationManager.AppSettings["COMPARED_TABLE"];
            resultTable = ConfigurationManager.AppSettings["RESULT_TABLE"];
            missingIDTable = ConfigurationManager.AppSettings["MISSING_ID_TABLE"];
        }

        public static string getSourceTable() => sourceTable;

        public static string getComparedTable() => comparedTable;
        
        public static string getResultTable() => resultTable;

        public static string getMissingIDTable() => missingIDTable;

        public static string getBadDir() => badDir;
        
        public static string getArchiveDir() => archiveDir;

        public static string getSchemaQuery() => schemaQuery;

        public static string getReasonSelectQuery() => reasonSelectQuery;
    
        public static string getReasonInsertQuery() => reasonInsertQuery;

        public static string getDestTable() => destTable;
 
        public static string getTmxDb() => tmxDb;

        public static string[] getColumns() => columns.Split(',');

        public static string getUpdateHistory() => updateHistory;

        public static string getUpdateCounts() => updateCounts;

        public static string getFromEmail() => fromEmail;
 
        public static string getToEmail() => toEmail;

        public static string getSmtpHost() => smtpHost;

        public static string getErrorMessageQuery() => errorMessageQuery;

        public static NameValueCollection getFormatting() => formatting;

        public static String getLoadCheckQuery() => loadCheckQuery;

        public static string getDefault(string key) => ConfigurationManager.AppSettings[key].ToString();

    }
}

﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace TMXLoader
{
    public class CsvHelper
    {
        private static string[] header = ConfigHelper.getColumns();
        private static Dictionary<string, Type> meta = DataHelper.getMeta();
        private static Dictionary<string, int> codes = DataHelper.getReasonCodes();


        /// <summary>
        /// Note: this works because the Hashtable class implements the IEnumerable interface
        ///     and in the Enumerable Class, it states that this class
        ///     Provides a set of static (Shared in Visual Basic) methods for querying objects that implement IEnumerable<T>
        ///     within the Enumerable Class, there is a ToDictionary() method
        /// 
        /// </summary>
        private static Dictionary<string, string> translations =
            (ConfigurationManager.GetSection("ColumnTranslation") 
            as System.Collections.Hashtable)
            .Cast<System.Collections.DictionaryEntry>()
            .ToDictionary(t => t.Key.ToString(), t => t.Value.ToString());

        // create the DataTable containing the formated data for sqlBulkCopy
        public static DataTable createTable(CsvReader csv, string filename)
        {
            // remove the decrypted_ infront of the file name for lookup in file history
            string oFilename = filename.Replace("decrypted_", "");

            DataTable table = null;
            if (csv != null)
            {
                table = initTable(); // create new datatable based on the columns

                csv.Configuration.MissingFieldFound = null;

                csv.Read();
                csv.ReadHeader(); // ingest the header, same as skipping the first line

                while (csv.Read())
                {
                    DataRow row = table.NewRow();

                    foreach (string h in header)
                    {
                        // check if the csv file & destination database contains the field we are iterating on
                        if (csv.GetFieldIndex(translations[h]) > -1 && meta.ContainsKey(h))
                        {
                            string val = csv[translations[h]];

                            Formatter.format(h, ref val);

                            if (val.Length > 0)
                            {
                                // reason_code is a special case, we normalize and place it into it's own table
                                if (h.Equals("reason_code"))
                                {
                                    val = parseReasonCode(val);
                                    row[h] = val;
                                    continue;
                                }

                                if (meta[h] == typeof(DateTime))
                                {
                                    if (val.All(char.IsDigit))
                                    {
                                        row[h] = UnixTimeToDateTime(long.Parse(val));
                                        continue;
                                    }
                                    else
                                    {
                                        DateTime.TryParse(val.Replace("UTC", ""), out DateTime date);
                                        string test = date.ToString("yyyy-MM-dd HH:mm:ss.fff");
                                        row[h] = date.ToString("yyyy-MM-dd HH:mm:ss.fff"); // caution: if field is not datetime2 in SQL schema, milliseconds will be rounded
                                        continue;
                                    }
                                }
                                else if (meta[h] == typeof(Double))
                                {
                                    double.TryParse(val, out double d);
                                    row[h] = d;
                                    continue;
                                }
                                else if (meta[h] == typeof(Int32))
                                {
                                    int.TryParse(val, out int i);
                                    row[h] = i;
                                    continue;
                                }
                                else
                                {
                                    System.Text.RegularExpressions.Regex z = new System.Text.RegularExpressions.Regex("{|}|\"");
                                    row[h] = z.Replace(val, "");
                                    // row[h] = val;
                                }
                            }
                        }
                    }

                    // if addeddate and filename are defined within the config header & SQL schema then we will add it to the database
                    if (header.Contains("addeddate", StringComparer.OrdinalIgnoreCase))
                        row["AddedDate"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");

                    if (header.Contains("filename", StringComparer.OrdinalIgnoreCase))
                        row["FileName"] = oFilename;

                    table.Rows.Add(row);
                }
            }
            return table;
        }

        private static string parseReasonCode(string reasonCode)
        {
            List<int> results = new List<int>();
            foreach (string c in reasonCode.Split(','))
            {
                int code;
                if (codes.TryGetValue(c, out code))
                {
                    results.Add(code);
                }
                else
                {
                    KeyValuePair<string, int> newCode = DataHelper.addReasonCode(c);
                    codes.Add(newCode.Key, newCode.Value);
                }
            }

            if (results.Count > 0)
                return string.Join(",", results);
            else
                return "";
        }

        private static DataTable initTable()
        {
            DataTable table = new DataTable();
            foreach (string h in header)
                table.Columns.Add(h);

            return table;
        }

        public static DateTime UnixTimeToDateTime(long timestamp)
        {
            var dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            dateTime = dateTime.AddSeconds((double)timestamp);
            dateTime = dateTime.ToLocalTime();
            return dateTime;
        }
    }
}

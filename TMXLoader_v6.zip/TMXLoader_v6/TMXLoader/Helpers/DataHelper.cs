﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMXLoader
{

    public class DataHelper
    {
        private static Dictionary<string, Type> metadata;
        private static Dictionary<string, int> ReasonCodes;

        // initialize metadata and ReasonCodes to be used throughout the application
        public static void init()
        {
            Logger.Info("Initializing database information.");
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
                {
                    con.Open();

                    Logger.Debug("Initializing schema information.");

                    string query = String.Format(ConfigHelper.getSchemaQuery(),
                                                ConfigHelper.getDefault("COLUMNS"));

                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        using (SqlDataReader reader = com.ExecuteReader(CommandBehavior.SchemaOnly))
                        {

                            DataTable schemaTable = reader.GetSchemaTable();

                            metadata = new Dictionary<string, Type>();

                            foreach (DataRow colRow in schemaTable.Rows)
                            {
                                metadata.Add(colRow.Field<String>("ColumnName"), colRow.Field<Type>("DataType"));
                            }
                        }
                    }

                    Logger.Debug("Initializing schema information complete.");

                    Logger.Debug("Initializing reason information.");
                    using (SqlCommand com = new SqlCommand(ConfigHelper.getReasonSelectQuery(), con))
                    {

                        com.CommandTimeout = 300;

                        using (SqlDataReader reader = com.ExecuteReader())
                        {
                            ReasonCodes = new Dictionary<string, int>();

                            while (reader.Read())
                            {
                                ReasonCodes.Add((string)reader[1], (int)reader[0]);
                            }
                        }
                    }
                    Logger.Debug("Initializing reason information complete.");
                }
                Logger.Info("Initializing database information complete.");
            }
            catch (SqlException ex)
            {
                Logger.Error(ex.Message);
            }
        }

        // Add a new reason code to the database table
        public static KeyValuePair<string, int> addReasonCode(string code)
        {
            using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
            {
                using (SqlCommand cmd = new SqlCommand(ConfigHelper.getReasonInsertQuery(), con))
                {
                    cmd.Parameters.AddWithValue("@code", code);
                    con.Open();

                    int mod = (int)cmd.ExecuteNonQuery();

                    int key = -1;
                    if (mod == 1)
                    {
                        cmd.CommandText = "Select @@Identity";
                        key = Convert.ToInt32(cmd.ExecuteScalar());

                        Logger.Debug("New reason code added: " + key);
                    }

                    if (con.State == System.Data.ConnectionState.Open)
                        con.Close();

                    return new KeyValuePair<string, int>(code, key);
                }
            }
        }

        // Set the loaded flag in FileHistory to signify the file has been completely loaded
        public static bool flagLoaded(string name)
        {
            bool success = false;

            if (name != String.Empty)
                name = name.Replace("decrypted_", "");

            using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = ConfigHelper.getUpdateHistory();
                    cmd.Parameters.AddWithValue("@name", name);

                    try
                    {
                        cmd.Connection.Open();
                        int mod = (int)cmd.ExecuteNonQuery();

                        if (mod == 1)
                            success = true;
                    }
                    catch (SqlException ex)
                    {
                        Logger.Error("Error in DataHelper: ", ex);
                    }
                }
            }
            return success;
        }

        // Update the counts found in individual files and update records inserted into database
        public static bool updateCounts(string name, int file, int db)
        {
            bool success = false;

            if (name != String.Empty)
                name = name.Replace("decrypted_", "");

            using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = ConfigHelper.getUpdateCounts();
                    cmd.Parameters.AddWithValue("@filecount", file);
                    cmd.Parameters.AddWithValue("@dbcount", db);
                    cmd.Parameters.AddWithValue("@name", name);
           
                    try
                    {
                        cmd.Connection.Open();
                        int mod = (int)cmd.ExecuteNonQuery();

                        if (mod == 1)
                            success = true;
                    } catch(SqlException ex)
                    {
                        Logger.Error("Error in DataHelper: ", ex);
                    }
                }
            }
            return success;
        }

        // update erorr messages in FileHistory table
        public static bool updateErrorMessage(string name, string message)
        {
            bool success = false;

            if (message == null)
                return false;

            if (name != String.Empty)
                name = name.Replace("decrypted_", "");

            using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = ConfigHelper.getErrorMessageQuery();
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@message", message);

                    try
                    {
                        cmd.Connection.Open();
                        int mod = (int)cmd.ExecuteNonQuery();

                        if (mod == 1)
                            success = true;
                    } catch(SqlException ex)
                    {
                        Logger.Error("Error in DataHelper: ", ex);
                    }
                }
            }

            return success;
        }

        // check if file has already been loaded by application
        public static bool isLoaded(string name)
        {
            if (name != String.Empty)
                name = name.Replace("decrypted_", "");

            using (SqlConnection con = new SqlConnection(ConfigHelper.getTmxDb()))
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandText = ConfigHelper.getLoadCheckQuery();
                    cmd.Parameters.AddWithValue("@name", name);

                    try
                    {
                        cmd.Connection.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        while(reader.Read())
                        {
                            if (reader[0].ToString().ToUpper() == "TRUE")
                                return true;
                            else
                                return false;
                        }
                        reader.Close();
                    } catch (SqlException ex)
                    {
                        Logger.Error("Error in Datahelper: ", ex);
                    }
                }
            }
            return false;
        }

        public static Dictionary<string, Type> getMeta()
        {
            return metadata;
        }

        public static Dictionary<string, int> getReasonCodes()
        {
            return ReasonCodes;
        }
    }
}

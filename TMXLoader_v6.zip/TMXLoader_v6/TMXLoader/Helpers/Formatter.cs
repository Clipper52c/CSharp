﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMXLoader
{
    public static class Formatter
    {
        public static void format(string key, ref string data)
        {
            if (ConfigHelper.getFormatting().Get(key) == null)
                return;

            string[] values = ConfigHelper.getFormatting().GetValues(key)[0].Split(',');

            if (values.Count() == 1)
                data = data.Replace(values[0], "");
            else
                data = data.Replace(values[0], values[1]);
        }
    }
}
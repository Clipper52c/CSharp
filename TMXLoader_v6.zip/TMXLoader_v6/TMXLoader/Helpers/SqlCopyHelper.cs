﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using TMXLoader.Classes;

namespace TMXLoader
{
    public class SqlCopyHelper
    {
        private const int BATCH_SIZE = 10000;
        private static SqlBulkCopy sqlBulk = null;

        static SqlCopyHelper()
        {
            sqlBulk = new SqlBulkCopy(ConfigHelper.getTmxDb(), SqlBulkCopyOptions.CheckConstraints); // flag to check primary key for duplicates
            sqlBulk.DestinationTableName = ConfigHelper.getDestTable();
            //sqlBulk.BatchSize = BATCH_SIZE;
            sqlBulk.EnableStreaming = true;
            sqlBulk.NotifyAfter = 10000;
            sqlBulk.BulkCopyTimeout = 600;
            sqlBulk.SqlRowsCopied += (sender, e) => Logger.Debug("RowsCopied: " + e.RowsCopied);
        }

        public static int WriteToServer(ReadObj obj)
        {
            int rowsCopied = 0;

            try
            {
                sqlBulk.WriteToServer(obj.getTable());
                rowsCopied = GetRowsCopied(sqlBulk);
                DataHelper.flagLoaded(Path.GetFileName(obj.getPath())); // set the flag of loaded to true in FileHistory table
            }
            catch (Exception ex)
            {
                string msg = ex.Message;

                // custom handling to determine the column impacted
                if (ex.Message.Contains("colid"))
                {
                    // Get the column from error so we can display the column name based on the meta data
                    int x = Int32.Parse(ex.Message.Substring(ex.Message.IndexOf("colid") + 5).Replace(".", ""));
                    msg = "Invalid size of column: " + ConfigHelper.getColumns()[x - 1];
                }


                if (obj.getPath() != String.Empty)
                    FileUtil.bad_file(obj.getPath(), msg);
                else
                    Logger.Error(msg);

                TMXError.add(obj.getPath(), msg); // add filename and error message for email
            }

            return rowsCopied;
        }

        public static int GetRowsCopied(SqlBulkCopy bulkCopy)
        { 
            FieldInfo rowsCopied = typeof(SqlBulkCopy).GetField("_rowsCopied", BindingFlags.NonPublic | BindingFlags.GetField | BindingFlags.Instance);
            int copied = (int)rowsCopied.GetValue(bulkCopy);
            Logger.Debug("Number of rows copied: " + copied);
            return copied;
        }

        public static void close()
        {
            sqlBulk.Close();
        }
    }
}

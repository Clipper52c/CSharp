﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TMXLoader.Classes;

namespace TMXLoader
{
    class ZipHelper
    {
        public static ReadObj read(string path)
        {
            DataTable table = null;
            int lineCount = 0;
            using (FileStream zipToOpen = new FileStream(path, FileMode.Open))
            {
                using (ZipArchive archive = new ZipArchive(zipToOpen, ZipArchiveMode.Read)) // read contents of the ZIP file
                {
                    if (archive.Entries.Count == 1)
                    {
                        var entry = archive.Entries[0];

                        using (StreamReader reader = new StreamReader(entry.Open()))
                        {
                            lineCount = FileUtil.lineCounter(reader); // simply counts # of lines in the file
                        }

                        using (StreamReader reader = new StreamReader(entry.Open()))
                        {
                            CsvReader csv = new CsvReader(reader);

                            try
                            {
                                table = CsvHelper.createTable(csv, Path.GetFileName(path)); // populate the DataTable with column names and data formating
                            }
                            catch (FormatException ex)
                            {
                                FileUtil.bad_file(path, ex.Message); // move bad files to bad file archive defined in config
                                TMXError.add(path, ex.Message); // add bad filename and error message to email
                            }
                        }
                        return new ReadObj(path, table, lineCount); // create the ReadObj containing the information read
                    }
                }
            }
            return null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TMXLoader
{
    class Program
    {

        static void Main(string[] args)
        {

            Console.WriteLine("*******************************************");
            Console.WriteLine("*****************OPTIONS ******************");
            Console.WriteLine("*************TYPE 1 TO PARSE DATA**********");
            Console.WriteLine("*************TYPE 2 TO RUN COMPARISONS*****");
            Console.WriteLine("*******************************************");

            string x = Console.ReadLine();

            if (x == "1")
                Main_DataParser(args);
            
            else if (x == "2")
                Main_Build_ComparisonQueries(args);

        }

        static void Main_Build_ComparisonQueries(string[] args)
        {
            if (args.Length < 1)
                return;

            Logger.Info("Processing started.");
            DateTime start = DateTime.Now;
            CustomTimer.Restart();

            Logger.Info("Obtaining Columns Info From App.Config ...");

            // define database parameters ...
            string[] selectColumns = ConfigHelper.getDefault("COLUMNS").Split(',');         // these are the select columns
            string[] whereColumns = ConfigHelper.getDefault("COLUMNS").Split(',');          // these are the where columns
            string sourceTable = ConfigHelper.getSourceTable();
            string comparedTable = ConfigHelper.getComparedTable();
            string resultTable = ConfigHelper.getResultTable();
            string missingIDTable = ConfigHelper.getMissingIDTable();

            Logger.Info("Inserting Column Schema ...");

            for (int index = 0; index < selectColumns.Length; ++index)
            {
                selectColumns[index] = "CASE WHEN (ISNULL(" + sourceTable + "." + selectColumns[index] + ",'') = ISNULL(" + comparedTable + "." + selectColumns[index] + ", '')) THEN '' ELSE 'Not Matched' END " + selectColumns[index] + "1";
                whereColumns[index] = "ISNULL(" + sourceTable + "." + whereColumns[index] + ",'') = ISNULL(." + comparedTable + "." + whereColumns[index] + ", '')";
                if (index != selectColumns.Length - 1)
                    whereColumns[index] = whereColumns[index] + " AND";
            }

            Logger.Info("Buidling the Select Clause ...");
            string sqlText = "SELECT DISTINCT ";
            sqlText = sqlText + comparedTable;
            sqlText = sqlText + ".request_id,";
            sqlText = sqlText + string.Join(", ", selectColumns);
            sqlText = sqlText + " INTO ";
            sqlText = sqlText + resultTable;
            sqlText = sqlText + " FROM " + sourceTable + " INNER JOIN ";
            sqlText = sqlText + comparedTable;
            sqlText = sqlText + " ON " + sourceTable + ".request_id = " + comparedTable + ".request_id ";
            sqlText = sqlText + "WHERE (NOT (";
            sqlText = sqlText + string.Join(" ", whereColumns) + "))";


            Logger.Info("Drop Comparison Table if Exists ...");
            string DropComparisonTable = "IF OBJECT_ID('";
            DropComparisonTable = DropComparisonTable + resultTable;
            DropComparisonTable = DropComparisonTable + "', 'U') IS NOT NULL ";
            DropComparisonTable = DropComparisonTable + "DROP TABLE ";
            DropComparisonTable = DropComparisonTable + resultTable;

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigHelper.getTmxDb()))
            {
                con.Open();

                using (System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand(DropComparisonTable, con))
                {
                    com.ExecuteNonQuery();
                }

                Logger.Info("Buidling Comparison Table ...");
                using (System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand(sqlText, con))
                {
                    com.ExecuteNonQuery();
                }
            }

            /*
                SELECT u.request_id Union_id, l.request_id Left_Table, r.request_id Right_Table INTO dbo.MissingID
                FROM
                (SELECT dbo.ThreatMetrix1.request_id FROM ThreatMetrix1 
                UNION 
                SELECT dbo.ThreatMetrix2.request_id FROM ThreatMetrix2) u
                LEFT JOIN dbo.ThreatMetrix1 l on
                l.request_id = u.request_id
                LEFT JOIN dbo.ThreatMetrix2 r on
                r.request_id = u.request_id
                WHERE l.request_id is null or r.request_id is null
            */

            Logger.Info("Drop MissingID Table if Exists ...");
            string DropMissing_IDTable = "IF OBJECT_ID('";
            DropMissing_IDTable = DropMissing_IDTable + missingIDTable;
            DropMissing_IDTable = DropMissing_IDTable + "', 'U') IS NOT NULL ";
            DropMissing_IDTable = DropMissing_IDTable + "DROP TABLE ";
            DropMissing_IDTable = DropMissing_IDTable + missingIDTable;

            Logger.Info("Buidling MissingID Table ...");
            sqlText = "SELECT u.Request_id Union_id, l.request_id Left_Table, r.request_id Right_Table ";
            sqlText = sqlText + "INTO dbo.MissingID ";
            sqlText = sqlText + "FROM (SELECT " + sourceTable + ".request_id ";
            sqlText = sqlText + "FROM " + sourceTable + " ";
            sqlText = sqlText + "UNION SELECT " + comparedTable + ".request_id FROM " + comparedTable + ") u ";
            sqlText = sqlText + "LEFT JOIN " + sourceTable + " l ON ";
            sqlText = sqlText + "l.request_id = u.request_id ";
            sqlText = sqlText + "LEFT JOIN " + comparedTable + " r ON ";
            sqlText = sqlText + "r.request_id = u.request_id ";
            sqlText = sqlText + "WHERE l.request_id is null or r.request_id is null";

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(ConfigHelper.getTmxDb()))
            {
                con.Open();

                using (System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand(DropMissing_IDTable, con))
                {
                    com.ExecuteNonQuery();
                }

                using (System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand(sqlText, con))
                {
                    com.ExecuteNonQuery();
                }
            }


            CustomTimer.Stop();
            Logger.Debug("Total time taken to compare: " + CustomTimer.toString());
            Logger.Info("Complete ... ");



        }

        static void Main_DataParser(string[] args)
        {
            if (args.Length < 1)
                return;

            ThreatMetrix.Init(args[0]).begin();
        }

    }
}

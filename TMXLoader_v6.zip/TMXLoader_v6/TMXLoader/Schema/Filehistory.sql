﻿USE [ThreatMetrix]
GO

/****** Object:  Table [dbo].[FileHistory]    Script Date: 4/3/2019 3:30:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[FileHistory](
	[name] [varchar](150) NULL,
	[downloaded] [bit] NULL,
	[download_date] datetime NULL,
	[decrypted] [bit] NULL,
	[decrypted_date] datetime NULL,
	[loaded] [bit] NULL,
	[loaded_date] datetime NULL,
	[FileRecordCount] int NULL,
	[DBInsertCount] int NULL,
	[ErrorFlag] [bit] NULL,
	[ErrorStep] varchar(50) NULL,
	[ErrorMessage] varchar(max) NULL,
	[addeddate] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[FileHistory] ADD  CONSTRAINT [DF_FileHistory]  DEFAULT (getdate()) FOR [addeddate]
GO


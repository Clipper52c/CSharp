﻿/****** Object:  Table [dbo].[ThreatMetrixReasons]    Script Date: 5/23/2019 10:09:14 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ThreatMetrixReasons](
	[code] [int] IDENTITY(1,1) NOT NULL,
	[reason] [varchar](255) NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
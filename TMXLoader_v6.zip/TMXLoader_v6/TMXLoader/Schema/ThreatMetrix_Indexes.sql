USE [ThreatMetrix]
GO

/****** Object:  Index [account_index]    Script Date: 6/11/2019 10:50:40 AM ******/
CREATE NONCLUSTERED INDEX [account_index] ON [dbo].[ThreatMetrix]
(
	[account_number] ASC,
	[datetime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


USE [ThreatMetrix]
GO

/****** Object:  Index [api_call_datetime_index]    Script Date: 6/11/2019 10:50:46 AM ******/
CREATE NONCLUSTERED INDEX [api_call_datetime_index] ON [dbo].[ThreatMetrix]
(
	[api_call_datetime] ASC,
	[session_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

USE [ThreatMetrix]
GO

/****** Object:  Index [datetime_index]    Script Date: 6/11/2019 10:50:58 AM ******/
CREATE CLUSTERED INDEX [datetime_index] ON [dbo].[ThreatMetrix]
(
	[datetime] ASC,
	[session_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


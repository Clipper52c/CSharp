USE ThreatMetrix
GO

CREATE PROCEDURE dbo.TMX_CLEAN_UP as

DECLARE @deleteFrom date = (SELECT DATEADD(mm,-13,GETDATE()))

DELETE FROM ThreatMetrix.dbo.ThreatMetrix WHERE CONVERT(varchar,api_call_datetime,23) < @deleteFrom

GO
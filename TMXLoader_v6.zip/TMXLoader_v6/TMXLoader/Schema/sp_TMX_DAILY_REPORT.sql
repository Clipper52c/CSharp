use ThreatMetrix
go

CREATE PROCEDURE dbo.TMX_DAILY_REPORT as

set nocount on;

DECLARE @SUBJECT_CONTENT VARCHAR(50)

SET @SUBJECT_CONTENT = 'ThreatMetrix Daily Record Report' + CONVERT(VARCHAR,GETDATE(),110)


DECLARE @currDate date = GETDATE()
DECLARE @filesDownloaded int =    (SELECT COUNT(*) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate))
DECLARE @decryptedFiles int =	  (SELECT COUNT(*) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate) and decrypted = 1)
DECLARE @decryptedFilesErr int =  (SELECT COUNT(*) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate) and (decrypted = 0 or decrypted = NULL) and (Error IS NOT NULL or Error <> 0))
DECLARE @filesLoaded int =		  (SELECT COUNT(*) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate) and loaded = 1)
DECLARE @filesLoadedErr int =	  (SELECT COUNT(*) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate) and (loaded = 0 or loaded = NULL) and (Error IS NOT NULL or Error <> 0))
DECLARE @recordsInFiles int =     (SELECT SUM(FileRecordCount) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate))
DECLARE @recordsLoaded int =      (SELECT SUM(DBInsertCount) FROM ThreatMetrix.dbo.FileHistory WHERE convert(varchar, addeddate, 23) = DATEADD(dd, -1, @currDate))
DECLARE @totalRecords int =		  (SELECT COUNT(*) FROM ThreatMetrix.dbo.ThreatMetrix WHERE convert(varchar, api_call_datetime, 23) = DATEADD(dd, -1, @currDate))

DECLARE @HTML varchar(max) = '<!DOCTYPE HTML><HEAD><TITLE>&nbps;</TITLE>'
		+'<h4>ThreatMetrix Data Load report for ' + CONVERT(varchar, DATEADD(dd, -1, GETDATE()), 23) + '</h4>'
		+'<table style="swidth:100%">'
		+'<tr>'
		+'<td>Files Downloaded</td>'
		+'<td>' + CONVERT(varchar, @filesDownloaded) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Files Decrypted</td>'
		+'<td>' + CONVERT(varchar, @decryptedFiles) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Files with Decryption Errors</td>'
		+'<td>' + CONVERT(varchar, @decryptedfilesErr) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Files Loaded</td>'
		+'<td>' + CONVERT(varchar,@filesLoaded) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Files with Load Errors</td>'
		+'<td>' + CONVERT(varchar, @filesLoadedErr) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Records in Files</td>'
		+'<td>' + CONVERT(varchar,@recordsInFiles) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Records Loaded</td>'
		+'<td>' + CONVERT(varchar, @recordsLoaded) + '</td>'
		+'</tr>'
		+'<tr>'
		+'<td>Total Records Loaded for ' + convert(varchar, DATEADD(dd, -1, @currDate), 23)  + '</td>'
		+'<td>' + CONVERT(varchar, @totalRecords) + '</td>'
		+'</table>'

exec msdb.dbo.sp_send_dbmail 
@RECIPIENTS = 'FCFMG_Cyber-Fraud-Group@td.com;CS-TS-CFO@td.com',
@subject = @SUBJECT_CONTENT,
@body = @HTML,
@body_format = 'HTML';
go


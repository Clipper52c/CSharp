﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMXLoader
{
    public class ThreatMetrix
    {
        private static ThreatMetrix instance = null;
        private string path = null;

        private ThreatMetrix(string path)
        {
            this.path = path;
        }

        public static ThreatMetrix Init(string path)
        {
            if (instance == null)
                instance = new ThreatMetrix(path);
            return instance;
        }

        public void begin()
        {
            DataParser.parse(FileUtil.getAllFiles(instance.path));
        }
    }
}

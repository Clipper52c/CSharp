﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TMXLoader
{
    public static class FileUtil
    {
        public static string[] getAllFiles(string path)
        {
            if (Directory.Exists(path))
            {
                return Directory.GetFiles(path);
            }
            else
            {
                Logger.Error("Path does not exist");
            }

            return null;
        }

        public static void create_dirs()
        {
            if (!Directory.Exists(ConfigHelper.getArchiveDir()))
                Directory.CreateDirectory(ConfigHelper.getArchiveDir());

            if (!Directory.Exists(ConfigHelper.getBadDir()))
                Directory.CreateDirectory(ConfigHelper.getBadDir());
        }

        // (optional) not currently in use due to data at rest
        public static void archive(string file)
        {

            if (File.Exists(ConfigHelper.getArchiveDir() + "\\" + Path.GetFileName(file)))
                File.Delete(ConfigHelper.getArchiveDir() + "\\" + Path.GetFileName(file));

            if(File.Exists(file))
                Directory.Move(file, ConfigHelper.getArchiveDir() + Path.GetFileName(file));
        }
        
        // move files that have errors into a bad directory for further review
        // contains clear text data at rest
        public static void bad_file(string file, string message)
        {
            if (File.Exists(ConfigHelper.getBadDir() + "\\" + Path.GetFileName(file)))
                File.Delete(ConfigHelper.getBadDir() + "\\" + Path.GetFileName(file));

            if (File.Exists(file))
            {
                Directory.Move(file, ConfigHelper.getBadDir() + Path.GetFileName(file));
                Logger.Error(message);
                Logger.Error("Error: " + file);
                Logger.Error("File has been moved to bad file directory.");
            }
        }

        // find number of lines in a file to determine files vs database counts
        public static int lineCounter(TextReader reader)
        {
            int count = 0;
            while (reader.ReadLine() != null)
                ++count;
            return count;
        }
    }
}

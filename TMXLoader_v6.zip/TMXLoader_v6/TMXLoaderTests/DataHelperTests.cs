﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TMXLoader;

namespace DataHelperTests
{
    [TestClass]
    public class DataHelperTests
    {
        [TestMethod]
        public void TestInit()
        {
            TMXLoader.DataHelper.init();

            Assert.IsNotNull(DataHelper.getMeta());
            Assert.IsNotNull(DataHelper.getReasonCodes());
        }

        [TestMethod]
        public void TestFlagsAllFalse()
        {
            Assert.IsFalse(DataHelper.isLoaded("TEST_TEST_TEST_TEST_TEST_TEST_TEST_TEST"));
            Assert.IsFalse(DataHelper.flagLoaded("TEST_TEST_TEST_TEST_TEST_TEST_TEST_TEST"));
            Assert.IsFalse(DataHelper.updateCounts("TEST_TEST_TEST_TEST_TEST_TEST_TEST_TEST", 0, 0));
            Assert.IsFalse(DataHelper.updateErrorMessage("TEST_TEST_TEST_TEST_TEST_TEST_TEST_TEST", "TEST_MESSAGE"));
        }
    }
}

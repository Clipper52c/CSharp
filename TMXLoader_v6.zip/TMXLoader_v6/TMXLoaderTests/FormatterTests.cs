﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TMXLoader;

namespace FormatterTests
{
    class FormatterTests
    {
        [TestMethod]
        public void FormatRequestId()
        {
            string testVal = "1111-1111-111111111-11111-11111";
            string expected = "111111111111111111111111111";
            Formatter.format("request_id", ref testVal);

            Assert.Equals(testVal, expected);
        }
    }
}

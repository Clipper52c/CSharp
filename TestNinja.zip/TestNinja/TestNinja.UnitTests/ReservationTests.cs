﻿/*

Allan Lee Notes:

Notes on Unit Tests:

There are a few testing *frameworks* you can run. The most common frameworks are MSTest and NUnit Test.
MSTest is built into Visual Studio, watch the Video "005 The Tooling.mp4" at 00:15.
When you create a MSTest project, this framework will be installed by default, otherwise, the MSTest
framework can be found in NuGet package for separate installation.

at 00:27: all these *frameworks* give you a utility library to write your tests, and a test runner
which runs your tests, and gives you a report of passing and failing tests.

Watch the video "010 Using NUnit in Visual Studio.mp4" for proper installation of NUnit Test.

To install NUnit Test, just go to NuGet Package Manager, Manage NuGet Packages for Solution, type NUnit in the Search box in the Browse tab

The Test menu bar is always there, even when you don't have a test framework installed.

When you want to run your tests for the first time, you can't just go to the Test menu and choose Run All Tests (ctrl + R, A),
this is because Test(s) need to be built first, like any other Visual Studio projects.

To build your Test(s), choose the Test Explorer under the Test menu, the first time you launch the Test Explorer, 
you will see this message in the Test Explorer:

"Build your solution to discover all available test. Click "Run All" to build, discover, and run all tests in your solution."
So follow the instruction, click "Run All" to build your tests. Then the Run All Tests menu-item under the Test menu will be active.


Also note:

The idea of using Entity Framework, NUnit Test, etc., using the package manager console and fire commands inside the package manager console
such as (for Entity Framework operations) "enable-migrations", "add-migration InitialModel", etc. is because Entity Framework, as well as
NUnit Test, are NuGet packages. They are not part of Visual Studio, they are considered third party frameworks. Therefore, they must
be executed using the package manager console separately from visual studio for firing of commands.

For convenience, NUnit Test, and MSTest (default) are already installed properly in this solution.

Also note that to get the local server to work properly, we must include this line in the App.config:

	<connectionStrings>
		<add name="VideoContext" connectionString="data source=DESKTOP-FOO1EMG;initial catalog=TestNinja;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework" providerName="System.Data.SqlClient"/>
	</connectionStrings>

Note that you must matched "VideoContext" because this is the context, or the domain class that contained the Video database. (see VideoService.cs)

 */



using System;
//using NUnit.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestNinja.Fundamentals;

namespace TestNinja.UnitTests
{
    [TestClass]
    public class ReservationTests
    {
        [TestMethod]
        public void CanBeCancelledBy_AdminCancelling_ReturnsTrue()
        {
            // Arrange
            var reservation = new Reservation();

            // Act
            var result = reservation.CanBeCancelledBy(new User { IsAdmin = true });

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanBeCancelledBy_SameUserCancelling_ReturnTrue()
        {
            var user = new User();
            var reservation = new Reservation { MadeBy = user };

            var result = reservation.CanBeCancelledBy(user);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void CanBeCancelledBy_AnotherUserCancelling_ReturnFalse()
        {
            var reservation = new Reservation { MadeBy = new User() };

            var result = reservation.CanBeCancelledBy(new User());

            Assert.IsFalse(result);
        }
    }
}

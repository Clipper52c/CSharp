/*
c  anntest.c
c
c  Three tests of the neural network function library (libnn.c, libnn.h)
c  that verify its proper operation and demonstrate its use.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2008.  All rights reserved.
c  Scientific Consultant Services, Inc.
c
c  Revised: 2008.07.30
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#define IS_UNIX		/* tells libkbd how to handle keyboard */

#include "libkbd.c"	/* include keyboard library and headers */
#include "libnn.c"	/* include neural library and headers */

/*=========================================================================*/

/*
c  Data structure and function prototypes for factbase handling.
c
c  Note: Factbase handling was originally part of the neural network
c  function library.  However, since factbases are just databases that
c  are in no way unique to neural networks, all factbase-related data
c  structures, prototypes, and code were removed from the neural
c  network library and placed in this file along with the test code.
*/

typedef struct {
    FILE    *factfile;		/* factbase file pointer */
    int     nfacts;		    /* number of facts in factbase file */
    int     niv;		    /* number of independent (input) variables */
    int     ndv;		    /* number of dependent (target) variables */
    int     file_at_bottom;	/* file position test flag */
    char    file_name[256];	/* factbase filespec */
} FACTBASE;

FACTBASE * nt1fact_init (char *fbasename, int niv, int ndv);	/* create or open a factbase */
void  nt1fact_disp (FACTBASE *fb);				                /* free memory and close factbase */
int   nt1fact_kill (char *fbasename);				            /* delete a factbase file */
int   nt1fact_count (FACTBASE *fb);				                /* get number of facts in factbase */
int   nt1fact_niv (FACTBASE *fb);				                /* get number of independent variables */
int   nt1fact_ndv (FACTBASE *fb);				                /* get number of dependent variables */
int   nt1fact_addv (FACTBASE *fb, float *ivars, float *dvars);	/* append a fact to factbase */
int   nt1fact_getv (FACTBASE *fb, float *ivars, float *dvars);	/* retrieve a fact from factbase */
int   nt1fact_top (FACTBASE *fb);				                /* position to first fact */
int   nt1fact_shuffle (FACTBASE *fb, int seed);			        /* shuffle facts in factbase */

/*=========================================================================*/

/* Select the example or test that you wish to run (1, 2, or 3) */

#define EXAMPLE 3

/*=========================================================================*/

#if EXAMPLE == 1

/*
Example 1 demonstrates basic use of the neural network function library.  It
shows how to train a network with back propagation, but does not employ the
evolutionary extensions available in the library (these are demonstrated in
other examples).  Compile and run this example to verify proper operation of
the library and as a demonstration of how the library functions work.  To
compile on Linux or Unix, use:

    gcc -Wall anntest.c -o anntest -lm
    
We suggest that you run the program from another directory so that you do
not junk up ~/tropic with scratch files.  For example, create a scratch
directory, ~/scratch, and then run the program from there using:

    cd ~/scratch
    ~/tropic/anntest
*/

/*
Standard macros min and max are defined here using different names for
compatibility across compilers.  That is, some compilers have min and max
macros defined in stdlib.h, others do not.  By defining the macros here and
giving them unique names no assumptions about their presence in the
compiler's header files are required.
*/

#define qmax(a,b)  (((a) > (b)) ? (a) : (b))
#define qmin(a,b)  (((a) < (b)) ? (a) : (b))

/*-------------------------------------------------------------------------*/

static float rng (void)
{

/*
Simple random number generator used to create training data for our example. 
It returns floating point numbers between -1.0 and 1.0, a good range of
values when working with neural networks.
*/
	
	float randmax = RAND_MAX, result;
	result = 2.0 * (rand() / randmax - 0.5);
	return result;
}

/*-------------------------------------------------------------------------*/

static void fatal_error (void)
{

/*
Simple error handler that will retrieve the error code for any error,
display the associated error message to the user, and finally terminate the
programme.
*/
	int error_code;
	error_code = nt1errc ();
	printf ("\n%s!\n", nt1errm (error_code));
	printf ("Terminating due to error\n\n");
	exit (4);
}

/*-------------------------------------------------------------------------*/

int main (void)
{
	FACTBASE *fb;  NEURALNET *nn;
	int n[3], fact, run, i;
	float ivar[6], dvar[2], ivmin[6], ivmax[6], dvmin[2], dvmax[2];
/*
Eliminate any existing factbase file with the name factfile.dat so that our
example will behave as expected.
*/
	system ("rm -f factfile.dat");
/*
Create a factbase containing random test data.  Specify 6 independent or
input variables, and 2 dependent or target variables, for each fact.  Note
how creating a factbase is almost like opening a file using fopen.
*/
	if ((fb = nt1fact_init ("factfile.dat", 6, 2)) == NULL)
		fatal_error ();
/*
Display some information regarding the newly-created factbase
*/
	printf ("A new factbase has been created:\n");
	printf ("   No. facts in factbase = %d\n", nt1fact_count(fb));
	printf ("   No. independent variables = %d\n", nt1fact_niv(fb));
	printf ("   No. dependent variables = %d\n", nt1fact_ndv(fb));
/*
Add 500 facts consisting of random numbers to the factbase
*/
	for (fact = 0; fact < 500; fact++) {
		for (i = 0; i < nt1fact_niv(fb); i++)  ivar[i] = rng();
		for (i = 0; i < nt1fact_ndv(fb); i++)  dvar[i] = rng();
		if (nt1fact_addv (fb, ivar, dvar) != 0)  fatal_error ();
	}
/*
Display updated information regarding the factbase
*/
	printf ("Facts have been added to factbase.\n");
	printf ("   No. facts now in factbase = %d\n", nt1fact_count(fb));
	printf ("   No. independent variables = %d\n", nt1fact_niv(fb));
	printf ("   No. dependent variables = %d\n", nt1fact_ndv(fb));
/*
Shuffle the order of the facts in the factbase.  With random data, as in
this example, shuffling will have little effect on learning by the neural
network.  However, with real data, you would want to shuffle your factbase
in order to reduce the effects on learning of serial dependence amongst the
facts.
*/
	printf ("Facts are about to be shuffled\n");
	if (nt1fact_shuffle (fb, 22) != 0)  fatal_error ();
/*
Compute the minimums and maximums for each variable.  These will be used
later to specify the desired scaling.  The blocks of code that follow
accomplish the computation.
*/
	printf ("Minimums and maximums are about to be computed\n");

	/* initialize min and max vectors for independent variables */
	for (i = 0; i < nt1fact_niv(fb); i++) {
		ivmax[i] = -1.0E32;
		ivmin[i] = 1.0E32;
	}

	/* initialize min and max vectors for dependent variables */
	for (i = 0; i < nt1fact_ndv(fb); i++) {
		dvmax[i] = -1.0E32;
		dvmin[i] = 1.0E32;
	}

	/* position factbase to first fact */
	if (nt1fact_top (fb) != 0)  fatal_error ();

	/* loop through all facts computing the minimums and maximums */
	for (fact = 0; fact < nt1fact_count(fb); fact++) {
		if (nt1fact_getv (fb, ivar, dvar) != 0)  fatal_error ();
		for (i = 0; i < nt1fact_niv(fb); i++) {
			ivmax[i] = qmax (ivmax[i], ivar[i]);
			ivmin[i] = qmin (ivmin[i], ivar[i]);
		}
		for (i = 0; i < nt1fact_ndv(fb); i++) {
			dvmax[i] = qmax (dvmax[i], dvar[i]);
			dvmin[i] = qmin (dvmin[i], dvar[i]);
		}
	}
/*
Now we start working with the neurals.  First we create a new network to
train.  This will be a three-layer net with 6 input neurons, 4 middle-layer
neurons, and 2 output neurons.  All parameters will have default values.
*/
	printf ("New neural network about to be created\n");
	n[0] = 6;  n[1] = 4;  n[2] = 2;
	if ((nn = nt1new (3, n)) == NULL)  fatal_error ();
/*
Using the minimums and maximums computed earlier, specify the scaling for
the network inputs and outputs.  Note that min/max scaling is only one of
many kinds of scaling appropriate for such problems.
*/
	printf ("Scaling for inputs and outputs about to be set\n");
	for (i = 0; i < nt1fact_niv(fb); i++)
		nt1set_iscale (nn, i, ivmin[i], ivmax[i]);
	for (i = 0; i < nt1fact_ndv(fb); i++)
		nt1set_oscale (nn, i, dvmin[i], dvmax[i]);
/*
Set the global learning rate to 0.5 for faster learning, and the transfer
function for the first-layer neurons to linear.  Layers are numbered
beginning at 0, and 5 is the "identification number" for a linear transfer
function.
*/
	printf ("Setting the learning rate and transfer function\n");
	nt1set_lrate (nn, .5);
	nt1set_trfun (nn, 0, 5);
/*
Initialize the random number generator with the specified seed (55), and
then randomize the weights using the specified dispersion (1.5 standard
deviations).
*/
	nt1set_seed (55);
	nt1set_randw (nn, 1.5);
/*
Perform 20 training runs through the factbase.  Here we are actually
training the newly-created neural network.
*/
	printf ("About to begin fifty training runs through fact set\n");
	for (run = 0; run < 50; run++) {
/*
Clear all the statistics accumulators so that errors, correlations and other
statistics may be computed.  Also, position the factbase to the first fact.
*/
		nt1stat_clear (nn);
		nt1fact_top (fb);
/*
Loop through all facts in the factbase
*/
		for (fact = 0; fact < nt1fact_count(fb); fact++) {
/*
Retrieve a fact from the factbase
*/
			if (nt1fact_getv (fb, ivar, dvar) != 0)
				fatal_error ();
/*
Set the inputs and training target for the neural network, that is, feed the
net the fact just retrieved from the factbase
*/
			nt1set_inputv (nn, ivar);
			nt1set_targv (nn, dvar);
/*
Tell the neural network to learn from the fact (example) it has just been
given
*/
			if (nt1learn (nn) != 0)  fatal_error ();
/*
Accumulate statistics data
*/
			nt1stat_accum (nn);
/*
Do the next fact
*/
		}
/*
Compute and report the statistics for the current training pass
*/
		nt1stat_compute (nn);
		printf ("%5d %10.5f %8.4f  %8.3f %8.3f\n",
		   (run + 1),		/* run number 1..20 */
		   nt1get_mterrss(nn),  /* mean total error sum squares */
		   nt1get_rmean(nn),	/* mean correlation */
		   nt1get_rval(nn,0),	/* correlation for output #1 */
		   nt1get_rval(nn,1)	/* correlation for output #2 */
		);
/*
Do the next training pass through the fact set
*/
	}
/*
Save the partially-trained network to a file
*/
	printf ("Saving the trained network\n");
	if (nt1save (nn, "testnet.def") != 0)  fatal_error ();
/*
Dispose of the neural network.  This means free all memory structures that
constitute the network in RAM.  The file to which the network has been saved
above is not affected in any way.
*/
	printf ("Disposing of memory image of neural network\n");
	nt1disp (nn);
/*
Try loading the saved network and doing some additional training with a
different learning rate.  We do not need to set the scaling or other
parameters again as they are "remembered" as part of the saved network.
*/
	printf ("Re-loading net into memory from save file!\n");
	if ((nn = nt1load ("testnet.def")) == NULL)  fatal_error ();
	nt1set_lrate (nn, 0.25);	/* set a new learning rate */
	printf ("Beginning another fifty training runs\n");
	for (run = 0; run < 50; run++) {
		nt1stat_clear (nn);
		nt1fact_top (fb);
		for (fact = 0; fact < nt1fact_count(fb); fact++) {
			nt1fact_getv (fb, ivar, dvar);
			nt1set_inputv (nn, ivar);
			nt1set_targv (nn, dvar);
			nt1learn (nn);
			nt1stat_accum (nn);
		}
		nt1stat_compute (nn);
		printf ("%5d %10.5f %8.4f  %8.3f %8.3f\n",
			(run+1), nt1get_mterrss(nn), nt1get_rmean(nn),
			nt1get_rval(nn,0), nt1get_rval(nn,1) );
	}
	printf ("Saving neural net to file and disposing memory image\n");
	nt1save (nn, "testnet.def");	/* overwrite old network */
	nt1disp (nn);			/* clean up */
/*
Dispose of the factbase, in other words free the memory structures and close
the file involved.  The factbase file, one should note, remains on disk, and
can be re-opened using nt1fact_init in just the same manor as when creating
a new factbase.
*/
	printf ("Closing up the factbase\n");
	nt1fact_disp (fb);
/*
Return to the shell
*/
	printf ("Done!\n");
	return(0);
}

#endif /* Example 1 */

/*=========================================================================*/

#if EXAMPLE == 2

/*
Example 2 demonstrates use of the neural network function library.  It shows
how to evolve a network with a genetic algorithm (rather than training it
with backpropagation) by employing the evolutionary extensions available in
the library.  Compile and run this example to verify proper operation and to
learn how the library functions work.  For details on how to compile this
program, see Example 1.

Use this command to continue evolving an existing population of nets:

    ~/tropic/anntest
    
Use this command to create and begin evolving a new population of nets:

    ~/tropic/anntest 1
    
At any time during the evolutionary process, you can press 's' or 'S' to
cause the population of nets to be saved and the program to be terminated. 
Study the code and comments below.
*/

#define MAXPOP 35                       /* maximum population size */
#define MAXIV 10                        /* maximum independent variables */
#define MAXDV 1                         /* maximum dependent variables */

static NEURALNET *brains[MAXPOP+1];     /* population member neural nets */
static int npop = 25;                   /* total population size */
static int nnetlayers = 3;              /* number of layers in nets */
static int nnetsize[3] = {2, 6, 1};     /* numbers of neurons in nets */
static int niv = 2, ndv = 1;            /* numbers of variables */

static FACTBASE *fb_train, *fb_test;    /* testing and training facts */

#define xxmin(a,b) (((a)<(b))?(a):(b))  /* macro returns min of a, b */
#define xxmax(a,b) (((a)>(b))?(a):(b))  /* macro returns max of a, b */

/*
What follows is the crucial function that you will be customizing to your
problem.  It will, in general, take as input any net and/or vector that
constitutes an "individual", i.e., a population member.  It must return an
evaluation of the "fitness" of the specified individual.  Breeding for
maximum fitness can then take place.  As implemented below, member is an
index variable specifying the particular member of the population, and
testflag is used to specify whether the fitness is to be calculated for the
"training" data (on which a population is to be evolved, i.e., the
"environment" to which the population will adapt through mating and natural
selection) or the testing data (used to see how well the individuals perform
on data not used in the evolutionary, selective process).

In this example, we will define the fitness to be simply negative 1 times
the total error sums-of-squares between a single network's outputs and a set
of targets-- that is, we are using evolution to accomplish the same task
(minimizing the error sums-of-squares) usually accomplished through
back-propagation.  The evolutionary approach will be slower to converge, but
far less prone to getting caught in spurious local maxima.

Of course, since the fitness of a system can be almost anything, you are not
restricted to solving the kinds of problems solved by backprop when using
the evolutionary approach.  You can, for instance, have several nets,
feedback loops, rules (which you can turn on or off via vector-element
parameters), and more, and have the fitness be some highly nonlinear global
assessment of system performance (e.g., the overall profitability of a stock
trading system) that does not exist on a "fact-by-fact" basis as would
necessary in the world of standard supervised learning such as backprop.
*/

void calculate_fitness (int member, int testflag)
{
    static float ivars[MAXIV], dvars[MAXDV], fitness;
    static char extradata[50];
    FACTBASE *fb;
    int fact;
/*
Select the factbase to be used: testing or evolving (training)
*/
    if (testflag) fb = fb_test;
    else fb = fb_train;
/*
Clear the standard statistics accumulators (see example 1) and position the
factbase to the first fact.
*/
    nt1stat_clear (brains[member]);
    nt1fact_top (fb);
/*
Loop over all facts in the factbase
*/
    for (fact = 0; fact < nt1fact_count(fb); fact++) {
/*
Get the independent and dependent variables data for the current fact from
the desired factbase and feed these data to the neural network object.  No
scaling needs to be done as that is handled automatically by the net.  See
example 1 for more details.
*/
        nt1fact_getv (fb, ivars, dvars);
        nt1set_inputv (brains[member], ivars);
        nt1set_targv (brains[member], dvars);
/*
Now run the net on the data.  We use function nt1fire since it is identical
to nt1learn, except that we do not need to set the learning rate to zero for
no learning to occur.  That is, nt1fire only performs the feed-forward
operation, not the back-propagation (learning) step.
*/
        nt1fire (brains[member]);
/*
We can now accumulate the statistics since the net's output(s) are available
as a result of the call to nt1fire, and the targets are available as a
result of the call to nt1set_targv.
*/
        nt1stat_accum (brains[member]);
/*
We now proceed to the next fact.
*/
    }
/*
The fitness is now specified as -1 times the total mean-square error. We
need the minus sign, since we want less error to mean more fitness.
Basically, we are "simulating" back-prop by minimizing the square error.
*/
    nt1stat_compute (brains[member]);
    fitness = - nt1get_mterrss (brains[member]);
/*
Place the fitness result, and some information we will want to display to
the user, in the "extra data" area of the neural net object.  In this
instance, we place the string data in bytes 0..19 of the extra data field of
the network (if we are in "train" mode), or in bytes 24..43 (if we are in
test mode).  The fitness value is stored as a float in bytes 20..23 (train
mode) or 44..47 (test mode).
*/
    sprintf (extradata, "%7.3f %7.4f ",
        nt1get_rmean (brains[member]), nt1get_mterrss (brains[member]));
    if (testflag == 0) {
        nt1set_extra (brains[member], 20, 0, extradata);
        nt1set_extra (brains[member], sizeof(float), 20, &fitness);
    } else {
        nt1set_extra (brains[member], 20, 24, extradata);
        nt1set_extra (brains[member], sizeof(float), 44, &fitness);
    }
}

/*
The following function randomly selects two population members to mate. It
displays the selected pair near the bottom of the screen.  Mating of the
selected parents then takes place.  The "child" is saved in the net pointed
to by brains[npop], an extra net that is not used as an actual member of the
breeding population, but is used as temporary neural-network storage.  The
mutation rate has been set at 0.05, and the crossover rate at 0.20, both
reasonable values.  Function nt1randint(npop), used below, returns a random
integer in the range 0..npop-1
*/

void breed_new_net (void)
{
    int j, k;
    j = nt1randint (npop);
    do { k = nt1randint (npop); }  while (k == j);
    nt1cursor (22, 1);  printf ("MATING: A:%5d  B:%5d", j, k);
    nt1mate (brains[j], brains[k], brains[npop], 0.05, 0.20);
}

/*
Below we update the actual population of individuals (in this case,
individual neural networks).  Updating is accomplished by finding the worst
of the population members.  If the child produced by mating a randomly
selected pair of parent nets has a fitness that is greater than that of the
worst current population member, the child and worst population member are
swapped.  This means that the worst member is replaced by the more fit
offspring in the population, improving the population, and the extra net
used for temporary storage receives the less fit net, which can then be
written over by the next mating operation.  The operations are carried out
using pointers, for speed and convenience.
*/

void update_population (void)
{
    float worstfitness, trainfit;
    int worstmember, member;
    char trainextra[50], testextra[50];
    static int prevworstmember=-1;
    NEURALNET *nnptr;
/*
Here we determine the index and fitness of the least fit member of our
population of neural networks.
*/
    worstmember = 0;
    nt1get_extra (brains[0], sizeof(float), 20, &worstfitness);
    for (member = 1; member < npop; member++) {
        nt1get_extra (brains[member], sizeof(float), 20, &trainfit);
        if (trainfit < worstfitness) {
            worstfitness = trainfit;
            worstmember = member;
        }
    }
/*
We then retrieve some information from child's extra data field and display
it near the bottom of the screen for the user to examine.
*/
    nt1get_extra (brains[npop], 20, 0, trainextra);
    nt1get_extra (brains[npop], 20, 24, testextra);
    nt1cursor (23, 1);
    printf ("TRAIN:%s TEST:%s", trainextra, testextra);
/*
Finally, we retrieve the child's fitness from its extra data field, and
determine whether the child net is more fit than the least fit population
member.  If so, we update our breeding population by replacing (via a swap)
the least fit member of the population with the more fit child, thereby
improving the population.
*/
    nt1get_extra (brains[npop], sizeof(trainfit), 20, &trainfit);
    if (trainfit > worstfitness) {
        nnptr = brains[npop];                   /* we just swap pointers */
        brains[npop] = brains[worstmember];
        brains[worstmember] = nnptr;
/*
Don't forget to update the screen!  We want to show the updated population
with the just-replaced member highlighted.
*/
        if (worstmember < 18) nt1cursor (worstmember+1, 1);
        else nt1cursor (worstmember-17, 41);
        nt1attrib (7);                          /* set highlight mode */
        nt1get_extra (brains[worstmember], 20, 0, trainextra);
        nt1get_extra (brains[worstmember], 20, 24, testextra);
        printf ("%2d%s%s", worstmember, trainextra, testextra);
        nt1attrib (0);                          /* set normal text mode */
        if (prevworstmember >= 0 && prevworstmember != worstmember) {
            if (prevworstmember < 18) nt1cursor (prevworstmember+1, 1);
            else nt1cursor (prevworstmember-17, 41);
            nt1get_extra (brains[prevworstmember], 20, 0, trainextra);
            nt1get_extra (brains[prevworstmember], 20, 24, testextra);
            printf ("%2d%s%s", prevworstmember, trainextra, testextra);
        }
        prevworstmember = worstmember;
    }
}

/*
Finally, in the main routine, we initialize our factbases and create or load
a population of individuals (nets) depending on the command line parameters
(no parameters means we load an existing population, any parameter means we
create a new, random population).  When creating or loading a population,
note the "extra" net-- it is used for temporary storage of child nets as
they are bred.
*/

int main (int nargs, char **args)
{
    float utrain, utest, x, iv[2], dv[1];
    int member, count=0, i, npopx, kbd;
/*
We create our factbases.  To make sure we will not be adding facts to
existing factbases, we first delete any such factbases!
*/
    system ("rm -f tstfact.dat trnfact.dat");
    if ((fb_test = nt1fact_init ("tstfact.dat", 2, 1)) == NULL)
        nt1ftlerr (nt1errm (nt1errc ()));
    if ((fb_train = nt1fact_init ("trnfact.dat", 2, 1)) == NULL)
        nt1ftlerr (nt1errm (nt1errc ()));
/*
Now we create our example facts based on a trigonometric relationship. Let's
see if we can evolve a net to solve for cos(2x) based on cos(x) and sin(x). 
We prepare both testing and training factbases.
*/
    printf ("PREPARING FACTBASES\n");
    for (x = 0.0; x < 8.0; x += 0.01) {
        iv[0] = sin (x);
        iv[1] = cos (x);
        dv[0] = sin (2.0 * x);
        if (x < 6.28) nt1fact_addv (fb_train, iv, dv);
        else nt1fact_addv (fb_test, iv, dv);
    }
    printf ("NO FACTS = %d   NO I.V. = %d   NO D.V. = %d\n",
        nt1fact_count (fb_train), nt1fact_niv (fb_train),
        nt1fact_ndv (fb_train) );
/*
If there are no command-line arguments, then load an existing population of
networks.  If there are any command-line arguments, then create a new
population of networks and set the scaling and transfer functions as
desired.
*/
    if (nargs > 1) {
        printf ("CREATING NEW POPULATION\n");
        if (nt1pop_new (brains, npop+1, nnetlayers, nnetsize) != 0)
            nt1ftlerr (nt1errm (nt1errc ()));
        nt1pop_settf (brains, npop+1, 0, 5);    /* linear input layer */
        for (i = 0; i < niv; i++)
            nt1pop_iscale (brains, npop+1, i, -1.0, 1.0);
        for (i = 0; i < ndv; i++)
            nt1pop_oscale (brains, npop+1, i, -1.0, 1.0);
    } else {
        printf ("LOADING EXISTING POPULATION\n");
        npopx = npop + 1;
        if (nt1pop_load (brains, &npopx, npop, "GNNX") != 0)
            nt1ftlerr (nt1errm (nt1errc ()));
    }
/*
Do the initial computations for the population.
*/
    printf ("CALCULATING TRAINING FITNESS\n");
    for (member = 0; member < npop+1; member++)
        calculate_fitness (member, 0);
    printf ("CALCULATING TESTING FITNESS\n");
    for (member = 0; member < npop+1; member++)
        calculate_fitness (member, 1);
    printf ("PRESS ANY KEY TO CONTINUE\n");
    kb_getch_w ();
    nt1erase ();                                 /* clear the screen */
    for (member = 0; member < npop; member++) {  /* display the population */
        if (member < 18) nt1cursor (member+1, 1);
        else nt1cursor (member-17, 41);
        printf ("%2d%s%s", member,
            (char *) nt1get_edptr (brains[member]),
            (char *) nt1get_edptr (brains[member]) + 24);
    }
/*
Now begin the evolutionary loop!
*/
A1: count = count + 1;
/*
Calculate the fitness values and other data for each population member on
both the training and testing data.
*/
    calculate_fitness (npop, 0);  /* training */
    calculate_fitness (npop, 1);  /* testing */
/*
Update the breeding population based only on the fitness measured in the
training sample.
*/
    update_population ();
/*
Compute the average population fitness for the user dispaly.
*/
    utrain = utest = 0.0;
    for (member = 0; member < npop; member++) {
        utrain += *((float *)(nt1get_edptr(brains[member])+20));
        utest += *((float *)(nt1get_edptr(brains[member])+44));
    }
    utrain = utrain / npop;
    utest = utest / npop;
/*
Display the count (number of children bred so far), and the average fitness
data for the user near the bottom of the screen.
*/
    nt1cursor (24, 1);
    printf ("COUNT:%7d  TRAIN:%12.3f  TEST:%12.3f", count, utrain, utest);
    fflush(stdout);
/*
Breed a child net by mating a randomly selected pair of population members
(in this case simple nets).
*/
    breed_new_net ();
/*
Check for user input.  If the user pressed Q or q, then just quit.  If the
user pressed S or s, then save the population of nets (each is saved in
standard N-TRAIN format in its own file) and then quit.
*/
    if (kb_hit ()) {
        kbd = kb_getch_w ();
        nt1cursor (24, 1);  printf ("\n\n");
        if (kbd == 's' || kbd == 'S') {
            printf ("SAVING POPULATION\n");
            if (nt1pop_save (brains, npop+1, "GNNX") != 0)
                nt1ftlerr (nt1errm (nt1errc ()));
            goto A2;
        } else if (kbd == 'q' || kbd == 'Q') {
            goto A2;
        }
    }
/*
Continue evolving!
*/
    goto A1;
/*
Dispose of the population of nets (including the storage net used for
holding the child nets as they are produced).  Also close up the factbases. 
Then exit to the user's shell.
*/
A2: printf ("Cleaning up\n");
    nt1pop_disp (brains, npop+1);
    nt1fact_disp (fb_train);
    nt1fact_disp (fb_test);
    return(0);
}

#endif

/*=========================================================================*/

#if EXAMPLE == 3

/*
Example 3 shows how one might use the library to evolve a neural trading
system.  Much of the code is similar to that illustrated in Example 2,
above.  We have written a new fitness evaluation function specific to the
problem (this is the most important change), added a function to read some
S&P 500 price data, and broken out some functionality from main() into
seperate, small functions (create_population, save_population,
load_population and dispose_population) to make experimentation easier.  In
our system model we have defined a trading system which enters on the close
of the next bar and which is always in the market.  One might equally well
have evolved a system with two neural outputs that would set two limit
orders for the next day, a "buy" limit and a "sell" limit, with exit on
close. The point we are trying to make is that you can evolve systems of
almost any imaginable structure and complexity with these tools.

Use this command to continue working with an existing population of nets:

    ~/tropic/anntest
    
Use this command to create and train a new population of nets:

    ~/tropic/anntest 1
    
While evolving, you can press 's' or 'S' to cause the population of nets to
be saved.  Study the code and comments below.
*/

#define MAXPOP 30                       /* maximum population size */
#define MAXIV 30                        /* maximum independent variables */
#define MAXDV 2                         /* maximum dependent variables */
#define MAXBAR 600                      /* maximum bars of prices */

static NEURALNET *brains[MAXPOP+1];     /* population member brains */
static int npop = 35;                   /* total population size */
static int nnetlayers = 3;              /* number of layers in net */
static int nnetsize[3] = {5, 3, 1};     /* numbers of neurons in net */
static int niv = 5, ndv = 1;            /* numbers of variables */

static int nbars;                       /* number of bars (days) */
static long date[MAXBAR];               /* dates for bars */
static float opn[MAXBAR];               /* opening prices */
static float hi[MAXBAR];                /* high prices */
static float lo[MAXBAR];                /* low prices */
static float cls[MAXBAR];               /* closing prices */
static float accountequity[MAXBAR];
static int marpos[MAXBAR];

/*
The function below creates a new population of neural networks.  It also
defines their input-layer transfer functions to be linear (all other layers
are the default sigmoid) and specifies the required scaling.  Each of the
neural nets in the population has its weights initialized to different
random numbers with default dispersion.
*/

void create_population (void)
{
    int i;
    if (nt1pop_new (brains, npop+1, nnetlayers, nnetsize) != 0)
        nt1ftlerr (nt1errm (nt1errc ()));
    nt1pop_settf (brains, npop+1, 0, 5);   /* set linear inputs */
    for (i = 0; i < niv; i++)
        nt1pop_iscale (brains, npop+1, i, -1.0, 1.0); /* input scaling */
    for (i = 0; i < ndv; i++)
        nt1pop_oscale (brains, npop+1, i, -1.0, 1.0); /* output scaling */
}

/*
This function loads (from disk) a population of neural networks previously
saved using the function save_population.
*/

void load_population (void)
{
    int npopx;
    npopx = npop + 1;
    if (nt1pop_load (brains, &npopx, npop, "GNN2") != 0)
        nt1ftlerr (nt1errm (nt1errc ()));
}

/*
The following function saves a population of neural networks to disk so that
they can be re-loaded on subsequent executions of the programme, if desired.
*/

void calculate_fitness (int member, int testflag);

void save_population (void)
{
    FILE *fil;  int i;  char samp[4];
    if (nt1pop_save (brains, npop+1, "GNN2") != 0)
        nt1ftlerr (nt1errm (nt1errc ()));
    calculate_fitness (5, 2);
    fil = fopen ("trades.txt", "wt");
    strcpy(samp,"I");
    for (i = 0; i < 540; i++) {
        if(i==425) strcpy(samp,"O");
        fprintf (fil, "%s %6d  %8.3f  %2d  %8.2f\n",
                (char*)samp, (int)date[i], (float)cls[i], (int)marpos[i],
                (float)accountequity[i]);
    }
    fclose (fil);
}

/*
Finally, we have the function that frees the memory allocated to a
population of nets.  It is complementary to create_population and
load_population in the same way that free is complementary to malloc and
calloc.
*/

void dispose_population (void)
{
    nt1pop_disp (brains, npop+1);
}

/*
This function randomly selects a pair of individual nets from the breeding
population, mates them to obtain a child network, and displays for the user
the index numbers of the pair just mated. The mutation rate is set 0.20, and
the crossover rate to 0.15.
*/

void breed_new_net (void)
{
    int j, k;
    j = nt1randint (npop);
    do { k = nt1randint (npop); } while (k == j);
    nt1cursor (24, 1);  printf ("Mating: A:%5d  B:%5d", j, k);
    nt1mate (brains[j], brains[k], brains[npop], 0.22, 0.05);
}

/*
The most important and problem-specific function of all is the fitness
evaluation function shown below.  This is where the problem to be solved by
evolution is defined.  In this case, we have defined a trading system that
is long or short on the basis of the judgements of a neural network
regarding the market's current trend.  Note the global nature of the fitness
evaluation: there are no trial-by-trial or bar-by-bar targets as would be
required for training a net via backprop!  Because of this, we could just
as easily have defined a system containing several interconnected neural
nets, feedback loops, and rules turned on and off by parameters.  The
process of assessing the fitness of, and evolving, such a system would be
the same.
*/

void calculate_fitness (int member, int testflag)
{
    static float ivars[MAXIV], profit, nnout;
    static float peakequity, drawdown;
    static float barspertrade, penalty, fitness, nnoutv[MAXBAR];
    static int bar, k, numtrades, firstbar, lastbar;
    static char extradata[50];
/*
We first clear some data arrays and initialize some variables.
*/
    memset (marpos, 0, sizeof(marpos));
    memset (accountequity, 0, sizeof(accountequity));
    numtrades = 0;
    barspertrade = 0.0;
    penalty = 0.0;
    peakequity = 0.0;
    drawdown = 0.0;
/*
We then define the ranges of bars that will constitute our evolving
(training) and testing samples.
*/
    if (testflag == 0)  { firstbar = 65;   lastbar = 425; }     /* evolve */
    else if (testflag == 1)  { firstbar = 425;  lastbar = 533; } /* test */
    else { firstbar = 65;  lastbar = 533; }                     /* show */
/*
Then we trade the systems.  Of course, we will initially be trading what are
essentialy random systems.  They will trade very poorly.  But, as the
population evolves, we will find more and more good systems cropping up. 
Eventually we will have a breed of supertraders, one hopes!  To trade a
system, we loop through all bars of data on which we want the system to
trade (training bars or testing bars).
*/
    for (bar = firstbar-35; bar <= lastbar+3; bar++) {
/*
We feed the network its diet of massaged price history.  Of course, one
could feed the network your favorite indicators, fundamental data, or
whatever you think may be useful.
*/
        for (k = 0; k < 3; k++)
            ivars[k] = 100.0 * (cls[bar-k] / cls[bar-k-1] - 1.0);
        ivars[3] = marpos[bar-1];
        ivars[4] = nnoutv[bar-1];
        nt1set_inputv (brains[member], ivars);
/*
And tell the net to digest its data
*/
        nt1fire (brains[member]);
/*
Then we retrieve its output, i.e., its decision regarding whether to be long
or short on the next bar.  Of course, you might want to try something else,
say have the network pass judgement on whether or not to take a breakout on
the next bar should one occur, or suggest good placements for your stops. 
You could also apply smoothing to the output of the network.
*/
        nnout = nt1get_output (brains[member], 0);
        nnoutv[bar] = nnout;
/*
Next we compute the actual market positions.  In our example, we decide we
will be short if the output is less than 0.5, and long if it is greater than
0.5
*/
        if (nnout < 0.0) marpos[bar] = -1;
        if (nnout >= 0.0) marpos[bar] = 1;
/*
We now add up our wins and losses, calculate our peak equity and drawdown,
and tally the number of trades so that we can see how our trading system is
performing.  Remember, when looking at the code, that we are assuming
placing orders 1 day after the network signals a change in position.
*/
        if (marpos[bar] == -1) {                    /* we are now short */
            accountequity[bar+1] = accountequity[bar] -
                500.0 * (cls[bar+1] - cls[bar]);
            if (marpos[bar-1] != -1)  numtrades++;  /* previously long ? */
            barspertrade += 1.0;
        } else if (marpos[bar] == 1) {              /* we are now long */
            accountequity[bar+1] = accountequity[bar] +
                500.0 * (cls[bar+1] - cls[bar]);
            if (marpos[bar-1] != 1)  numtrades++;   /* previously short ? */
            barspertrade += 1.0;
        }
        if (accountequity[bar] > peakequity)
            peakequity = accountequity[bar];
        if (peakequity - accountequity[bar] > drawdown)
            drawdown = peakequity - accountequity[bar];
    }
/*
We have now left the data loop, so we can assess the trading results. First,
we finish calculating the average number of bars per trade, and the net
profit.
*/
    barspertrade = barspertrade / (numtrades + 0.01);
    profit = accountequity[lastbar] - accountequity[firstbar];
/*
Using the various performance statistics computed above, we compute our
overall fitness evaluation.  High overall fitness is what we shall be
evolving for.  As can be seen, we have defined fitness, i.e., our overall
measure of the "goodness" of a trading system, in terms of profit achieved
minus various penalties, e.g., for commissions and slippage, drawdown, etc.
*/
    /* fitness = profit - 5.0 * drawdown; */
    /* Actually, I prefer Sharpe ratios, so here is my new fitness */
    {
        int i, neq;  double ueq, seq, d;
        neq = 0;  ueq = seq = 0.0;
        for (i = firstbar; i <= lastbar; i++) {
            neq++;
            d = (double)(accountequity[i] - accountequity[i-1]);
            ueq += d;
            seq += d * d;
        }
        ueq = ueq / neq;
        seq = sqrt (1.E-8 + seq / neq - ueq * ueq);
        ueq = ueq / seq;
        fitness = sqrt (252.0 / neq) * ueq;  /* annualize the ratio */
    }    
/*
Finally, we stuff the fitness value just computed, and with regard to which
natural selection will occur, as well as some other information that we want
to display for the user, in the population member's extra data field (see
Example 2).
*/
    memset (extradata, 0, sizeof(extradata));
    sprintf (extradata, "%6d%4d%5.1f",
        (int)(fitness*100.0), numtrades, barspertrade);
    if (testflag == 0) {
        nt1set_extra (brains[member], 20, 0, extradata);
        nt1set_extra (brains[member], sizeof(float), 20, &fitness);
    } else {
        nt1set_extra (brains[member], 20, 24, extradata);
        nt1set_extra (brains[member], sizeof(float), 44, &fitness);
    }
}

/*
As in Example 2, the function below updates our population by replacing weak
population members with healthier offspring.  It also writes various data to
the screen so that the user can see evolution in action!
*/

void update_population (void)
{
    static char trainextra[50], testextra[50];
    static float worstfitness, trainfitness;
    static int worstmember, member, prevworstmember=-1;
    NEURALNET *nnptr;
/*
Determine least fit population member
*/
    worstmember = 0;
    nt1get_extra (brains[0], sizeof(float), 20, &worstfitness);
    for (member = 1; member < npop; member++) {
        nt1get_extra (brains[member], sizeof(float), 20, &trainfitness);
        if (trainfitness < worstfitness) {
            worstfitness = trainfitness;
            worstmember = member;
        }
    }
/*
Display data for child system
*/
    nt1cursor (20, 1);
    nt1get_extra (brains[npop], 20, 0, trainextra);
    nt1get_extra (brains[npop], 20, 24, testextra);
    printf ("TRAIN:%s TEST:%s", trainextra, testextra);
/*
If child system is healthier than weakest population member replace weakest
member by swapping places with child.  See Example 2.
*/
    nt1get_extra (brains[npop], sizeof(trainfitness), 20, &trainfitness);
    if (trainfitness > worstfitness) {
        nnptr = brains[npop];
        brains[npop] = brains[worstmember];
        brains[worstmember] = nnptr;
/*
Update displays.  One should note that in the tabular parts of our screen
display the first number is the population member index, the second number
is the evaluated fitness (divided by 100 and shown as an integer to conserve
space), the third number is the total number of trades taken, and the fourth
is the average number of bars in a trade.  These are the items that appear,
of course, because they are what we saved (as strings produced using sprintf
within the context of our fitness evaluation function) in the extra data
field of our neural net.
*/
        if (worstmember < 18) nt1cursor (worstmember+1, 1);
        else nt1cursor (worstmember-17, 41);
        nt1attrib (7);
        nt1get_extra (brains[worstmember], 20, 0, trainextra);
        nt1get_extra (brains[worstmember], 20, 24, testextra);
        printf ("%2d%s%s", worstmember, trainextra, testextra);
        nt1attrib (0);
        if (prevworstmember >= 0 && prevworstmember != worstmember) {
            if (prevworstmember < 18)
                nt1cursor (prevworstmember+1, 1);
            else nt1cursor (prevworstmember-17, 41);
            nt1get_extra (brains[prevworstmember], 20, 0, trainextra);
            nt1get_extra (brains[prevworstmember], 20, 24, testextra);
            printf ("%2d%s%s", prevworstmember, trainextra, testextra);
        }
        prevworstmember = worstmember;
    }
}

/*
The function below reads into global static storage some price data for the
S&P 500 that we have supplied with the example.  It can easily be modified
to read almost any standard ASCII price data format.  For convenience, we
have placed the demonstration data in a comment within the C source file;
this function reads it directly from there.
*/

void read_market_data (void)
{
    FILE *ifile;  int i, k;  float vo, oi;
    static char buf[256];
    if ((ifile = fopen ("/home/jkatz/tropic/anntest.c", "rt")) == NULL)
        nt1ftlerr ("Cannot open file anntest.c");
    nbars = 0;
    k = 0;
    while (fgets (buf, sizeof(buf), ifile) != NULL) {
        if (strncmp (buf, "END_DATA", 8) == 0)  k = 0;
        if (k == 1) {
            for (i = 0; buf[i] != 0; i++)
                if (buf[i] == ',') buf[i] = ' ';
            if (sscanf (buf, "%ld %f %f %f %f %f %f", &date[nbars],
                &opn[nbars], &hi[nbars], &lo[nbars], &cls[nbars],
                &vo, &oi) != 7)  nt1ftlerr ("Bad data");
            nbars++;
            if (nbars > MAXBAR-2) nt1ftlerr ("Too many data bars");
        }
        if (strncmp (buf, "BEGIN_DATA", 10) == 0)  k = 1;
    }
    fclose (ifile);
    nbars = nbars-1;
    if (nbars < 25) nt1ftlerr ("Too few bars");
    printf ("nbars=%d date=%ld cls=%f\n", nbars, date[nbars], cls[nbars]);
    printf ("Press 1 to continue, 0 to quit\n");
    if (kb_getch_w() == '0') nt1ftlerr ("User Abort");
}

/*
In the main function we read the market data into static global storage,
load an existing population of systems or create a new population, calculate
the initial results, and begin the process of evolutionary optimization.  We
provide for user interruption of the process with the ability to save the
population, if desired.
*/

int main (int nargs, char **args)
{
    float utrain, utest;  int member, count=0;
    volatile int kbd;
/*
Read in the market data
*/
    printf ("Reading market data\n");
    read_market_data ();
/*
If there are any command line arguments, then create a new population of
systems.  Otherwise, try to load an existing population created by an
earlier execution of this programme that was terminated by the user pressing
s or S.
*/
    if (nargs > 1) {
        printf ("Creating new population\n");
        create_population ();
    } else {
        printf ("Loading population\n");
        load_population ();
    }
/*
Do the initial assessment of each member of the population. Most members
will do quite poorly, but as the population evolves that will change.
*/
    printf ("Calculating training fitnesses\n");
    for (member = 0; member < npop+1; member++)
        calculate_fitness (member, 0);
    printf ("Calculating testing fitnesses\n");
    for (member = 0; member < npop+1; member++)
        calculate_fitness (member, 1);
    printf ("Press any key to continue\n");
    kb_getch_w ();
/*
Initialize the user display of the population with the initial assessments
computed immediately above.
*/
    nt1erase ();
    for (member = 0; member < npop; member++) {
        if (member < 18) nt1cursor (member+1, 1);
        else nt1cursor (member-17, 41);
        printf ("%2d%s%s", member,
            (char *) nt1get_edptr (brains[member]),
            (char *) nt1get_edptr (brains[member]) + 24);
    }
/*
Begin the evolutionary loop!
*/
A1: count = count + 1;
    breed_new_net ();             /* mate parents to get new child */
    calculate_fitness (npop, 0);  /* in-sample assessment */
    calculate_fitness (npop, 1);  /* out-of-sample (test) assessment */
    update_population ();         /* replacement strategy  */
    utrain = utest = 0.0;
    for (member = 0; member < npop; member++) {
        utrain += *((float *)(nt1get_edptr(brains[member])+20));
        utest += *((float *)(nt1get_edptr(brains[member])+44));
    }
    utrain = utrain / npop;  utest = utest / npop;
    nt1cursor (22, 1);
    printf ("Count:%7d  Utrain:%12.3f  Utest:%12.3f",
        count, utrain, utest);
    fflush(stdout);
/*
Check for user interruption
*/
    if (kb_hit () != 0) {
        kbd = kb_getch_w ();
        nt1cursor (24, 1);
        if (kbd == 's' || kbd == 'S') {
            printf ("Saving population\n");
            save_population ();
            goto A2;
        } else if (kbd == 'q' || kbd == 'Q') {
            goto A2;
        }
    }
    goto A1;
/*
Close up
*/
A2: printf ("Cleaning up\n");
    dispose_population ();
    return (0);
}

#endif /* Example 3 */

/*=========================================================================*/

/*
c  The functions below implement a simple database for facts (examples
c  for training or testing a neural network or regression model).
c  Facts may be stored, retrieved, and shuffled using these functions.
*/

FACTBASE * nt1fact_init (char *fbasename, int niv, int ndv)
{
	FACTBASE *fb;  int file_exists, nitems;

	/* allocate fact database structure */
	if ((fb = (FACTBASE *) calloc (1, sizeof(FACTBASE))) == NULL) {
		nt1seterrc (1);
		return NULL;
	}

	/* check to see whether file already exists */
	if ((fb->factfile = fopen (fbasename, "rb")) != NULL) {
		file_exists = -1;
		fclose (fb->factfile);
		fb->factfile = NULL;
	}
	else file_exists = 0;

	/* initialize using existing file */
	if (file_exists || (niv < 0 && ndv < 0)) {

		/* open fact database file for update */
		if ((fb->factfile = fopen (fbasename, "rb+")) == NULL) {
			free (fb);
			nt1seterrc (12);
			return NULL;
		}

		/* read header information */
		nitems = fread (&fb->niv, sizeof(int), 1, fb->factfile);
		nitems += fread (&fb->ndv, sizeof(int), 1, fb->factfile);
		nitems += fread (&fb->nfacts, sizeof(int), 1, fb->factfile);
		if (ferror (fb->factfile) || nitems != 3) {
			fclose (fb->factfile);
			free (fb);
			nt1seterrc (13);
			return NULL;
		}

		/* verify header information */
		if (niv >= 0 || ndv >= 0) {
			if (niv != fb->niv || ndv != fb->ndv) {
				fclose (fb->factfile);
				free (fb);
				nt1seterrc (14);
				return NULL;
			}
		}

	/* initialize using new file */
	} else {

		/* open new fact database file */
		if ((fb->factfile = fopen (fbasename, "wb+")) == NULL) {
			free (fb);
			nt1seterrc (12);
			return NULL;
		}

		/* initialize header information */
		fb->nfacts = 0;
		fb->niv = niv;
		fb->ndv = ndv;

		/* write header information */
		nitems = fwrite (&fb->niv, sizeof(int), 1, fb->factfile);
		nitems += fwrite (&fb->ndv, sizeof(int), 1, fb->factfile);
		nitems += fwrite (&fb->nfacts, sizeof(int), 1, fb->factfile);
		if (ferror (fb->factfile) || nitems != 3) {
			fclose (fb->factfile);
			free (fb);
			nt1seterrc (15);
			return NULL;
		}

        /* end if */
	}

	/* normal return */
	strcpy (fb->file_name, fbasename);
	fb->file_at_bottom = 0;
	return fb;
}

void nt1fact_disp (FACTBASE *fb)
{
	int nfacts;
	if (fb) {
	    if (fb->factfile) {
		fseek (fb->factfile, 2*sizeof(int), SEEK_SET);
		fread (&nfacts, sizeof(int), 1, fb->factfile);
		if (fb->nfacts != nfacts) {
		    fseek (fb->factfile, 2*sizeof(int), SEEK_SET);
		    fwrite (&fb->nfacts, sizeof(int), 1, fb->factfile);
		}
		fclose (fb->factfile);
	    }
	    free (fb);
	}
}

int nt1fact_kill (char *fbasename)
{
	if (remove (fbasename) != 0) {
		nt1seterrc (16);
		return -1;
	}
	return 0;
}

int nt1fact_count (FACTBASE *fb)
{
	return fb->nfacts;
}

int nt1fact_niv (FACTBASE *fb)
{
	return fb->niv;
}

int nt1fact_ndv (FACTBASE *fb)
{
	return fb->ndv;
}

int nt1fact_addv (FACTBASE *fb, float *ivars, float *dvars)
{
	int nitems;

	/* make sure file is positioned correctly */
	if (!fb->file_at_bottom) {
		fseek (fb->factfile, 0, SEEK_END);
		fb->file_at_bottom = -1;
	}

	/* add fact to factbase file */
	nitems = fwrite (ivars, sizeof(float), fb->niv, fb->factfile);
	nitems += fwrite (dvars, sizeof(float), fb->ndv, fb->factfile);

	/* check for errors */
	if (ferror (fb->factfile) || nitems != fb->niv + fb->ndv) {
		nt1seterrc (15);
		return -1;
	}

	/* normal return */
	fb->nfacts++;
	return 0;
}

int nt1fact_getv (FACTBASE *fb, float *ivars, float *dvars)
{
	int nitems;

	/* get fact from factbase file */
	nitems = fread (ivars, sizeof(float), fb->niv, fb->factfile);
	nitems += fread (dvars, sizeof(float), fb->ndv, fb->factfile);

	/* check for errors */
	if (ferror (fb->factfile) || feof (fb->factfile) ||
	    nitems != fb->niv + fb->ndv) {
		nt1seterrc (13);
		return -1;
	}

	/* normal return */
	return 0;
}

int nt1fact_top (FACTBASE *fb)
{
	int nfacts;

	/* write new fact count to factfile header */
	fseek (fb->factfile, 2*sizeof(int), SEEK_SET);
	fread (&nfacts, sizeof(int), 1, fb->factfile);
	if (fb->nfacts != nfacts) {
		fseek (fb->factfile, 2*sizeof(int), SEEK_SET);
		fwrite (&fb->nfacts, sizeof(int), 1, fb->factfile);
	}

	/* position factbase file to first fact */
	if (fseek (fb->factfile, 3*sizeof(int), SEEK_SET)) {
		nt1seterrc (17);
		return -1;
	}
	fb->file_at_bottom = 0;

	/* normal return */
	return 0;
}

int nt1fact_shuffle (FACTBASE *fb, int rngseed)
{
	FILE *ifile=NULL, *ofile=NULL;
	char *used=NULL, *fbuf=NULL;  float *vbuf=NULL;
	int fact, kf, bufsize=30*1024, nitems, nelts;
	char cmd[256];

	/* return if too few facts */
	if (fb->nfacts <= 2) return 0;

	/* close and rename factbase file */
	system ("rm -f f98hg56f.tmp");
	fclose (fb->factfile);
	fb->factfile = NULL;
	sprintf (cmd, "mv %s f98hg56f.tmp", fb->file_name);
	system (cmd);

	/* allocate local working memory */
	nelts = fb->niv + fb->ndv;
	used = (char *) calloc (fb->nfacts, sizeof(char));
	fbuf = (char *) calloc (bufsize, sizeof(char));
	vbuf = (float *) calloc (nelts, sizeof(float));

	/* check for sufficient memory */
	if (!used || !fbuf || !vbuf) {
		nt1seterrc (1);
		goto BAD;
	}

	/* open files */
	if ((ofile = fopen (fb->file_name, "wb")) == NULL) {
		nt1seterrc (18);
		goto BAD;
	}
	if ((ifile = fopen ("f98hg56f.tmp", "rb")) == NULL) {
		nt1seterrc (18);
		goto BAD;
	}

	/* buffer destination file */
	if (setvbuf (ofile, fbuf, _IOFBF, bufsize) != 0) {
		nt1seterrc (19);
		goto BAD;
	}

	/* write header to destination file */
	nitems = fwrite (&fb->niv, sizeof(int), 1, ofile);
	nitems += fwrite (&fb->ndv, sizeof(int), 1, ofile);
	nitems += fwrite (&fb->nfacts, sizeof(int), 1, ofile);
	if (ferror (ofile) || nitems != 3) {
		nt1seterrc (20);
		goto BAD;
	}

	/* seed the random number generator */
	srand (rngseed);

	/* loop through all facts */
	for (fact = 0; fact < fb->nfacts; fact++) {

		/* randomly select an unused fact */
		kf = (int) ((float)fb->nfacts * (float)rand () / RAND_MAX);
		if (kf < 0) kf = 0;
		if (kf >= fb->nfacts) kf = fb->nfacts - 1;
		while (used[kf]) {
			++kf;
			if (kf >= fb->nfacts) kf = 0;
		}
		used[kf] = 1;

		/* copy selected fact to destination file */
		fseek (ifile, 3 * sizeof(int) +
			nelts * sizeof(float) * kf, SEEK_SET);
		nitems = fread (vbuf, sizeof(float), nelts, ifile);
		if (nitems != nelts || ferror (ifile)) {
			nt1seterrc (21);
			goto BAD;
		}
		nitems = fwrite (vbuf, sizeof(float), nelts, ofile);
		if (nitems != nelts || ferror (ofile)) {
			nt1seterrc (20);
			goto BAD;
		}
	}

	/* close files and free memory */
	fclose (ofile);
	fclose (ifile);
	free (vbuf);
	free (fbuf);
	free (used);

	/* delete temporary file */
	system ("rm -f f98hg56f.tmp");

	/* re-open factbase file in normal manner */
	if ((fb->factfile = fopen (fb->file_name, "rb+")) == NULL) {
		nt1seterrc (12);
		return -1;
	}
	if (nt1fact_top (fb)) return -1;

	/* normal return */
	return 0;

	/* error return */
BAD:	if (fbuf) free (fbuf);
	if (vbuf) free (vbuf);
	if (used) free (used);
	if (ofile) fclose (ofile);
	if (ifile) fclose (ifile);
	return -1;
}

/*=========================================================================*/

/*
S&P 500 data used for running Example 3

BEGIN_DATA
891101   367.80   368.75   365.90   367.90   35150.0  125274.0
891102   367.40   367.40   362.80   364.10   37824.0  127904.0
891103   362.60   366.70   362.60   364.00   36433.0  127467.0
891106   362.80   362.80   357.80   358.00   39428.0  129484.0
891107   358.10   361.75   356.90   360.90   45485.0  127661.0
891108   361.40   366.35   361.40   364.55   39882.0  127324.0
891109   365.00   365.60   362.10   362.70   37829.0  127994.0
891110   363.90   366.40   363.70   366.25   30711.0  128520.0
891113   366.80   367.55   364.00   366.75   39355.0  128831.0
891114   366.70   367.40   363.10   364.40   40037.0  127720.0
891115   365.80   367.30   363.10   367.10   39401.0  127192.0
891116   367.60   367.60   364.80   366.40   39088.0  126391.0
891117   366.10   368.80   365.75   367.45   40903.0  126121.0
891120   367.60   368.10   363.80   365.70   43316.0  125224.0
891121   365.90   366.30   362.90   366.15   41313.0  124801.0
891122   366.50   367.95   365.80   367.15   27866.0  124445.0
891124   368.50   370.20   368.30   369.85   15640.0  125005.0
891127   369.90   372.30   369.80   371.30   43688.0  126506.0
891128   371.50   372.15   370.00   371.15   44354.0  123961.0
891129   370.40   371.00   368.70   369.75   40237.0  123040.0
891130   370.30   372.35   369.45   372.10   41949.0  124470.0
891201   372.60   377.90   372.60   376.10   53492.0  122633.0
891204   376.90   377.10   375.60   376.75   37029.0  122911.0
891205   376.20   377.90   374.55   374.90   46406.0  123912.0
891206   375.20   375.20   372.95   373.95   51455.0  123566.0
891207   373.60   375.40   370.40   373.45   58759.0  124932.0
891208   373.70   375.20   372.60   373.85   52071.0  127330.0
891211   373.60   374.50   371.10   374.05   56590.0  128538.0
891212   374.20   377.60   373.40   377.15   61272.0  128627.0
891213   377.40   379.50   376.75   378.00   62922.0  132616.0
891214   377.20   377.20   374.40   374.90   54622.0  137917.0
891215   376.70   376.70   376.70   376.70   44579.0  139099.0
891218   376.60   378.30   368.05   370.20   48189.0  101050.0
891219   370.15   371.15   365.85   369.75   48120.0  103462.0
891220   370.85   371.05   368.70   370.40   37805.0  104888.0
891221   370.75   372.30   370.10   372.00   20592.0  105508.0
891222   372.05   374.35   371.75   373.60   12670.0  106235.0
891226   374.00   374.45   372.25   373.00   15691.0  105757.0
891227   373.05   376.15   373.05   375.80   18865.0  105845.0
891228   376.00   377.50   375.25   377.40   14177.0  105480.0
891229   377.45   379.55   377.45   378.90   15967.0  107195.0
900102   378.95   385.40   378.05   385.05   33052.0  108696.0
900103   385.75   387.35   383.85   384.25   41456.0  109146.0
900104   384.05   385.15   378.65   382.40   45871.0  108025.0
900105   381.80   382.15   376.85   377.15   42786.0  106834.0
900108   376.70   380.95   376.15   380.10   41144.0  108884.0
900109   380.35   380.65   374.45   374.75   44695.0  107897.0
900110   374.45   375.75   369.25   373.85   57441.0  108766.0
900111   375.05   376.05   373.40   374.40   40235.0  108727.0
900112   370.55   370.55   362.40   363.50   54691.0  109585.0
900115   363.75   364.25   361.30   361.75   37450.0  111547.0
900116   358.05   365.55   357.85   364.65   52553.0  112116.0
900117   365.05   367.45   360.40   361.30   56889.0  110642.0
900118   359.55   363.80   358.55   363.40   56974.0  109990.0
900119   365.05   365.75   363.95   364.75   37202.0  109749.0
900122   364.55   365.30   352.85   353.95   57208.0  113068.0
900123   356.45   357.75   352.45   352.80   65077.0  113937.0
900124   347.80   356.30   346.05   355.65   58726.0  115006.0
900125   356.55   356.95   348.55   349.30   55040.0  116543.0
900126   350.05   353.05   344.75   349.35   57423.0  119048.0
900129   350.55   351.80   345.55   349.25   55802.0  120538.0
900130   349.75   350.45   343.30   347.75   62914.0  121990.0
900131   349.55   353.20   348.60   353.05   56175.0  117579.0
900201   353.35   353.90   351.45   352.65   38828.0  118611.0
900202   351.65   356.55   351.35   355.05   41584.0  118399.0
900205   355.05   356.15   354.05   355.95   32515.0  119099.0
900206   355.45   355.45   351.65   352.80   43993.0  119976.0
900207   350.55   358.45   349.90   358.35   63744.0  122148.0
900208   358.25   360.85   355.85   357.85   57581.0  122478.0
900209   358.35   359.05   356.15   356.95   40011.0  121341.0
900212   356.75   357.35   353.00   353.30   52184.0  121788.0
900213   353.95   356.05   351.05   355.20   55494.0  124067.0
900214   354.85   357.35   354.05   355.85   45207.0  122918.0
900215   355.75   359.00   355.35   358.70   38978.0  122619.0
900216   358.55   359.15   355.45   355.75   31637.0  120636.0
900220   350.75   352.85   349.05   351.30   48607.0  127381.0
900221   348.30   352.20   348.05   351.85   51073.0  128755.0
900222   352.35   354.75   348.55   349.30   57561.0  127893.0
900223   346.55   349.75   345.05   348.05   57011.0  130927.0
900226   348.25   352.55   347.55   352.40   57635.0  131823.0
900227   351.75   355.75   351.70   353.90   63073.0  130066.0
900228   353.55   357.35   353.45   355.50   61832.0  130380.0
900301   355.05   358.05   354.10   356.35   58936.0  131400.0
900302   356.60   359.00   356.05   358.45   51957.0  129924.0
900305   358.10   359.85   356.10   357.05   57991.0  130749.0
900306   357.05   361.85   356.35   361.75   60304.0  130535.0
900307   362.15   362.30   359.05   359.50   61905.0  132782.0
900308   360.55   364.30   359.70   363.10   58070.0  132957.0
900309   361.95   363.50   359.25   360.55   62511.0  133775.0
900312   359.55   362.45   358.65   361.20   50152.0  133356.0
900313   360.05   361.35   357.45   358.15   67804.0  136488.0
900314   358.45   360.80   357.25   359.95   63231.0  136468.0
900315   359.90   362.05   359.30   360.85   58395.0  140240.0
900316   362.35   364.80   361.95   363.90   43073.0  109321.0
900319   362.25   366.45   361.15   366.25   41356.0  109924.0
900320   365.35   367.80   362.70   364.25   54202.0  111635.0
900321   364.95   365.35   360.65   360.85   36480.0  111670.0
900322   360.85   362.45   354.95   357.75   52678.0  114762.0
900323   358.65   360.05   357.60   359.45   35715.0  113867.0
900326   361.15   362.50   359.65   360.40   30818.0  113502.0
900327   360.05   364.60   358.90   364.20   37938.0  111738.0
900328   363.85   365.40   362.40   364.55   35095.0  114678.0
900329   363.05   364.20   361.25   362.55   34867.0  113673.0
900330   362.25   363.95   359.75   360.10   39067.0  113762.0
900402   357.25   360.85   357.25   360.55   40169.0  115830.0
900403   360.90   366.55   360.70   366.00   48216.0  114343.0
900404   366.25   366.45   361.65   361.85   44769.0  113217.0
900405   363.35   365.30   361.90   362.90   36628.0  112155.0
900406   362.95   363.85   360.05   362.35   36556.0  113849.0
900409   361.65   363.90   361.65   363.05   26905.0  112936.0
900410   362.65   364.50   361.90   362.95   28590.0  112873.0
900411   363.55   364.95   362.15   363.85   29750.0  112391.0
900412   363.85   367.00   363.85   366.75   27486.0  114001.0
900416   368.15   369.45   364.85   365.50   40900.0  115810.0
900417   363.15   366.55   362.55   365.85   39584.0  116789.0
900418   366.45   366.55   360.45   361.55   46157.0  117074.0
900419   360.65   361.75   357.85   358.25   43353.0  117314.0
900420   358.05   359.10   353.15   355.05   54997.0  121633.0
900423   353.95   354.45   350.35   351.30   49106.0  125295.0
900424   352.35   353.85   349.85   351.10   43992.0  124823.0
900425   352.95   353.55   350.90   352.90   41069.0  125617.0
900426   353.70   354.45   350.55   353.95   46435.0  125903.0
900427   353.75   354.15   347.25   347.50   51819.0  127204.0
900430   347.90   351.55   347.25   350.75   42874.0  127944.0
900501   351.65   353.15   350.40   352.30   46287.0  128289.0
900502   351.75   355.75   351.65   355.60   45107.0  127751.0
900503   355.80   357.55   354.85   355.80   37990.0  127360.0
900504   356.75   359.25   354.90   358.55   47995.0  128031.0
900507   358.10   361.25   357.75   361.15   38777.0  126786.0
900508   360.85   364.00   359.90   363.75   36335.0  127364.0
900509   362.95   363.85   360.75   363.60   39793.0  128435.0
900510   363.65   365.60   362.75   363.70   41322.0  128148.0
900511   365.20   373.20   365.05   372.90   62819.0  129256.0
900514   373.90   379.65   372.75   375.55   70370.0  129088.0
900515   374.15   375.80   373.45   375.15   45247.0  127951.0
900516   375.05   375.35   371.80   374.00   42732.0  128252.0
900517   374.85   377.45   373.75   374.60   46326.0  127292.0
900518   373.90   374.40   372.15   374.25   39847.0  126144.0
900521   374.05   379.60   373.55   377.65   47377.0  127779.0
900522   379.65   380.35   375.65   379.45   55262.0  128412.0
900523   378.15   379.45   376.75   379.40   39161.0  126869.0
900524   379.65   379.75   377.35   378.50   34619.0  126140.0
900525   376.65   376.95   373.45   374.00   29665.0  128091.0
900529   374.30   382.05   374.10   381.25   47299.0  127673.0
900530   382.25   382.55   379.35   381.65   47924.0  126935.0
900531   380.40   381.95   379.95   380.40   44035.0  127765.0
900601   382.45   382.95   380.45   382.20   45903.0  128864.0
900604   382.15   388.00   381.45   387.40   49934.0  128486.0
900605   387.40   388.55   385.00   386.40   58946.0  128532.0
900606   386.05   386.35   383.95   384.60   49606.0  129102.0
900607   385.45   385.65   380.50   382.55   60103.0  132239.0
900608   382.45   383.05   376.05   378.05   63395.0  131257.0
900611   378.05   381.55   377.20   381.40   60365.0  130867.0
900612   380.90   387.05   379.70   385.10   63445.0  131204.0
900613   384.55   386.70   382.80   383.80   67249.0  131376.0
900614   383.45   383.55   380.20   381.95   58675.0  132830.0
900615   380.55   382.55   379.15   381.40   36382.0  105238.0
900618   380.15   380.65   374.60   375.35   45703.0  104098.0
900619   375.25   377.70   373.90   377.05   41943.0  105866.0
900620   377.15   378.75   374.80   377.85   36637.0  104733.0
900621   378.75   380.45   375.55   380.35   36275.0  106618.0
900622   380.50   381.90   371.95   373.60   39319.0  105066.0
900625   373.35   374.40   369.25   371.05   42159.0  104619.0
900626   372.95   374.30   368.95   369.40   43813.0  105246.0
900627   369.25   374.15   368.45   372.90   45173.0  107102.0
900628   373.15   375.90   372.60   375.60   34447.0  107124.0
900629   374.85   377.35   374.55   375.80   32179.0  105589.0
900702   375.95   377.95   374.85   377.85   25214.0  107823.0
900703   377.65   378.75   377.05   377.45   17415.0  107438.0
900705   376.45   376.45   371.65   373.25   31835.0  108835.0
900706   371.65   376.80   371.45   375.70   33685.0  110559.0
900709   375.35   377.95   374.95   376.55   29603.0  108481.0
900710   376.30   377.50   372.85   373.95   32124.0  106974.0
900711   374.70   379.15   374.15   378.85   36895.0  109169.0
900712   378.25   383.10   377.40   382.90   44650.0  110113.0
900713   382.80   387.25   382.80   384.35   46316.0  113812.0
900716   385.05   387.15   383.95   385.75   33866.0  113196.0
900717   385.95   386.55   381.45   383.85   40631.0  114584.0
900718   382.95   383.55   379.35   380.60   41767.0  116359.0
900719   379.95   382.20   377.60   381.90   39576.0  115633.0
900720   381.95   383.35   377.45   378.25   37188.0  114601.0
900723   376.95   377.25   365.85   371.25   56403.0  115614.0
900724   371.25   371.80   366.95   371.10   43589.0  115441.0
900725   371.35   373.95   370.55   373.10   32870.0  116798.0
900726   372.25   373.80   369.25   371.70   35411.0  115456.0
900727   371.25   371.95   367.65   368.95   35094.0  116984.0
900730   367.95   372.05   366.55   371.70   39246.0  118233.0
900731   371.70   373.90   368.85   372.05   38544.0  117966.0
900801   370.95   373.25   369.25   370.90   37091.0  115849.0
900802   367.75   369.35   364.45   367.35   45037.0  118684.0
900803   361.45   365.45   350.95   360.10   54513.0  118407.0
900806   348.10   355.10   347.25   347.85   42581.0  124952.0
900807   353.45   354.45   346.95   350.65   51632.0  126784.0
900808   349.95   354.75   349.95   353.00   38636.0  127380.0
900809   353.45   355.70   352.25   354.85   32162.0  126875.0
900810   354.65   354.65   348.55   350.75   40454.0  128462.0
900813   349.65   354.15   346.95   353.25   43735.0  127537.0
900814   353.25   356.45   351.95   354.20   42800.0  128077.0
900815   357.45   358.15   354.45   355.10   41742.0  129236.0
900816   351.95   353.35   344.95   345.20   48729.0  131683.0
900817   344.15   345.85   337.95   342.10   57772.0  133696.0
900820   342.95   345.35   342.25   343.15   41633.0  134067.0
900821   339.75   340.05   331.15   336.95   63493.0  135219.0
900822   337.75   338.75   330.55   330.65   64293.0  131903.0
900823   318.65   326.55   318.65   319.70   60563.0  141297.0
900824   326.20   326.65   319.95   326.45   53583.0  143784.0
900827   335.45   338.35   331.45   336.25   49898.0  142233.0
900828   334.25   336.70   333.95   336.10   41472.0  143664.0
900829   335.65   340.55   334.70   337.30   49729.0  145922.0
900830   337.65   338.40   331.45   332.00   50245.0  145498.0
900831   332.45   336.10   330.05   336.00   39227.0  147876.0
900904   332.45   337.85   332.45   337.70   42004.0  148212.0
900905   337.35   338.95   334.85   338.30   51250.0  149685.0
900906   337.25   337.85   332.65   334.20   51354.0  152043.0
900907   333.20   338.25   333.20   337.10   49818.0  152768.0
900910   341.45   341.45   333.65   334.90   55723.0  156853.0
900911   335.35   336.30   333.25   335.20   59574.0  155543.0
900912   335.45   336.05   332.95   335.60   63032.0  157360.0
900913   335.95   336.25   331.15   332.00   79521.0  164406.0
900914   330.05   330.65   327.85   329.60   71773.0  167790.0
900917   327.65   331.65   327.65   331.25   61401.0  170281.0
900918   328.70   332.55   327.15   331.75   68875.0  169957.0
900919   332.15   332.35   328.55   328.85   70695.0  173094.0
900920   327.15   327.80   322.65   324.55   72835.0  143556.0
900921   324.95   325.75   320.40   324.75   51067.0  146822.0
900924   323.15   323.15   315.25   317.45   56544.0  152633.0
900925   319.65   321.70   317.20   321.45   45081.0  149080.0
900926   321.30   321.85   315.55   318.45   52040.0  149810.0
900927   320.95   321.55   311.05   312.85   58664.0  152919.0
900928   307.85   318.45   307.45   316.90   55453.0  152851.0
901001   320.15   328.65   318.95   328.40   63445.0  153498.0
901002   329.55   333.65   327.70   328.50   58818.0  147551.0
901003   328.05   330.05   322.95   323.85   50839.0  150893.0
901004   323.15   326.95   321.35   325.45   47196.0  150186.0
901005   320.45   328.45   318.35   325.00   52601.0  150711.0
901008   328.15   328.55   325.25   327.55   28556.0  150916.0
901009   324.15   324.70   315.15   315.90   48125.0  150179.0
901010   317.55   319.45   310.05   312.35   61994.0  150643.0
901011   312.15   314.45   305.75   307.50   58375.0  152188.0
901012   309.30   314.40   307.65   311.85   54562.0  152788.0
901015   313.15   317.65   307.15   316.15   57029.0  154140.0
901016   316.15   317.05   309.60   311.40   54623.0  154172.0
901017   310.75   314.35   309.65   310.75   55481.0  154302.0
901018   312.25   318.65   311.70   318.30   61869.0  154165.0
901019   323.30   324.10   320.35   323.20   55905.0  153402.0
901022   323.40   328.80   322.55   325.65   50356.0  151635.0
901023   325.85   327.65   323.15   323.95   43262.0  149084.0
901024   322.65   326.05   322.05   325.60   39126.0  151625.0
901025   325.35   325.95   321.05   321.55   41713.0  151367.0
901026   319.35   320.65   315.90   316.40   39978.0  151426.0
901029   316.95   319.65   311.55   314.15   53123.0  153202.0
901030   313.65   316.75   310.35   316.35   57936.0  153526.0
901031   317.55   318.05   313.40   316.95   44988.0  154189.0
901101   315.95   319.55   312.55   318.60   48306.0  157761.0
901102   318.55   324.00   318.25   323.35   43428.0  158112.0
901105   324.15   326.75   322.85   325.55   43872.0  156390.0
901106   325.35   327.00   321.75   321.95   47742.0  157049.0
901107   322.25   322.90   316.95   317.40   49164.0  157689.0
901108   317.40   322.00   315.95   319.95   55532.0  159459.0
901109   321.95   326.55   320.30   325.70   50500.0  158249.0
901112   327.35   331.55   327.25   330.65   45890.0  159334.0
901113   330.15   331.55   328.35   329.30   47278.0  160009.0
901114   329.25   333.90   328.55   331.85   53400.0  159000.0
901115   330.65   331.25   327.15   328.20   47200.0  155986.0
901116   329.95   330.95   325.95   329.45   59306.0  158427.0
901119   330.65   331.60   329.10   331.30   47595.0  155885.0
901120   331.05   331.55   326.65   326.95   48337.0  156929.0
901121   328.15   328.65   323.55   328.00   42246.0  156278.0
901123   327.55   329.25   325.40   325.65   17295.0  155931.0
901126   323.15   328.65   321.55   328.35   50587.0  155768.0
901127   327.95   330.15   326.40   329.80   56963.0  156030.0
901128   329.35   331.40   328.45   329.40   52711.0  154789.0
901129   328.60   329.40   325.30   326.90   54186.0  157764.0
901130   326.90   335.05   326.25   334.20   72396.0  159403.0
901203   335.65   336.10   333.65   334.55   57770.0  159403.0
901204   334.15   339.15   332.75   338.35   60613.0  162667.0
901205   337.55   342.15   336.35   341.95   61322.0  161337.0
901206   345.65   345.65   339.25   340.65   72041.0  164913.0
901207   339.95   340.65   336.95   338.40   67622.0  169431.0
901210   338.05   340.45   336.85   339.80   56470.0  169672.0
901211   339.45   339.45   336.35   338.70   54458.0  168274.0
901212   338.25   342.10   337.65   341.70   71220.0  165994.0
901213   341.15   342.00   339.25   340.10   62876.0  170378.0
901214   338.95   338.95   335.55   337.35   76565.0  171382.0
901217   335.80   337.10   335.00   336.85   49256.0  168885.0
901218   337.20   342.20   336.85   340.80   60571.0  169841.0
901219   340.00   341.15   339.30   339.60   57327.0  167804.0
901220   334.95   340.85   334.95   340.55   67019.0  168383.0
901221   341.20   342.60   340.00   342.45   32197.0  169650.0
901224   341.30   341.45   338.60   338.90   11236.0  138131.0
901226   339.70   342.45   339.70   341.45   14421.0  140483.0
901227   340.60   341.60   337.60   338.50   15251.0  139357.0
901228   338.40   339.50   336.70   339.35   15937.0  139082.0
901231   339.60   339.80   337.25   338.35   11646.0  140146.0
910102   338.30   341.30   334.40   334.55   34604.0  142812.0
910103   335.50   336.05   331.20   331.85   42353.0  141624.0
910104   332.50   332.80   327.70   330.95   47530.0  139901.0
910107   327.70   329.60   324.90   325.25   52695.0  144981.0
910108   325.70   327.00   323.10   324.90   60495.0  145226.0
910109   326.70   330.90   317.70   320.35   64542.0  147036.0
910110   322.70   324.20   320.60   323.70   39158.0  144644.0
910111   323.20   324.30   322.20   323.90   26224.0  144618.0
910114   320.70   322.20   317.50   322.05   40524.0  146103.0
910115   321.80   322.40   320.30   322.05   28821.0  144578.0
910116   321.30   326.70   321.10   325.85   39224.0  145557.0
910117   337.70   342.70   330.85   339.70   61844.0  151505.0
910118   337.95   342.00   337.00   341.60   59946.0  146475.0
910121   339.20   341.40   338.35   340.65   30148.0  148636.0
910122   339.80   340.55   336.40   337.55   43532.0  150867.0
910123   338.20   340.40   337.30   339.10   34543.0  152264.0
910124   340.25   345.10   340.20   344.50   44478.0  152712.0
910125   344.20   346.20   342.55   345.60   43979.0  152764.0
910128   345.40   346.40   344.10   344.45   30163.0  153787.0
910129   344.00   344.60   342.80   344.40   31691.0  153703.0
910130   344.70   350.15   344.70   349.95   50443.0  153581.0
910131   349.50   352.50   349.15   352.35   41596.0  155103.0
910201   350.70   353.40   348.35   351.10   52202.0  159486.0
910204   351.00   357.80   350.90   356.65   53368.0  156878.0
910205   356.45   360.60   355.70   360.50   63766.0  159769.0
910206   359.50   367.70   358.50   367.55   72590.0  163291.0
910207   368.20   372.70   364.20   365.60   78319.0  167451.0
910208   365.00   368.70   364.50   368.40   48955.0  168184.0
910211   368.70   378.20   368.40   377.60   68337.0  169726.0
910212   376.45   379.70   373.80   374.00   72610.0  171447.0
910213   374.20   378.95   373.40   377.95   51875.0  172772.0
910214   377.70   379.60   371.10   373.05   57255.0  171161.0
910215   373.80   378.70   372.70   377.15   54791.0  170879.0
910219   376.70   379.25   375.20   377.85   54206.0  170051.0
910220   376.20   376.20   372.85   374.20   52138.0  170497.0
910221   374.80   376.00   372.70   373.60   44696.0  172007.0
910222   372.30   380.40   372.20   374.55   61509.0  173471.0
910225   378.70   378.95   373.20   375.75   55825.0  174257.0
910226   373.70   374.35   370.55   371.50   59647.0  173612.0
910227   372.20   377.30   371.35   376.80   63552.0  173162.0
910228   378.00   379.10   374.00   374.50   60321.0  172685.0
910301   371.10   379.20   371.10   378.95   62480.0  170898.0
910304   379.90   380.35   376.70   377.35   57294.0  167398.0
910305   378.30   386.30   377.85   385.05   96928.0  173179.0
910306   386.60   388.15   383.10   384.30   88932.0  168931.0
910307   384.30   385.50   383.20   383.35   77488.0  170541.0
910308   383.90   387.00   381.80   383.05   75690.0  173779.0
910311   383.50   383.50   380.40   381.20   61550.0  174347.0
910312   380.60   382.95   377.30   378.55   75324.0  177085.0
910313   378.70   383.55   378.00   383.50   77164.0  175656.0
910314   383.90   386.50   379.20   381.30   89620.0  174642.0
910315   382.60   382.60   382.60   382.60   50565.0  177255.0
910318   381.65   384.85   379.05   383.05   48178.0  141022.0
910319   379.05   379.75   375.05   377.05   44357.0  142042.0
910320   377.05   379.65   375.85   378.45   40132.0  141798.0
910321   380.05   381.55   376.25   376.70   39736.0  142295.0
910322   376.25   378.55   375.15   378.25   35284.0  143062.0
910325   377.15   381.50   376.85   379.90   36814.0  143353.0
910326   379.35   386.95   378.85   386.75   44478.0  142759.0
910327   387.95   388.90   384.05   385.60   47050.0  140934.0
910328   386.80   387.20   383.05   383.30   31067.0  138922.0
910401   383.45   384.20   379.45   380.65   35092.0  139837.0
910402   381.30   389.65   381.30   389.10   52796.0  144992.0
910403   389.55   391.55   387.55   387.70   46915.0  144518.0
910404   388.75   392.05   386.40   389.05   46918.0  142784.0
910405   389.55   391.20   382.95   384.45   51090.0  145575.0
910408   384.30   388.35   383.35   388.15   36515.0  144393.0
910409   387.45   388.75   381.95   382.65   48736.0  145264.0
910410   382.85   384.25   379.80   382.85   48823.0  146372.0
910411   384.05   388.85   384.05   388.15   50909.0  146587.0
910412   389.05   390.80   385.25   389.45   48572.0  146174.0
910415   390.45   391.75   387.20   389.45   45927.0  146400.0
910416   388.55   396.95   387.95   396.20   56936.0  149797.0
910417   396.35   400.55   395.80   399.20   58427.0  149407.0
910418   397.35   400.40   396.55   397.80   48206.0  150429.0
910419   395.80   396.45   392.55   393.40   43374.0  150213.0
910422   392.80   393.25   388.85   390.35   48780.0  152294.0
910423   391.95   392.55   387.70   389.80   50070.0  151797.0
910424   390.45   392.00   387.95   390.80   44102.0  151158.0
910425   390.05   391.25   386.45   387.25   47934.0  150825.0
910426   385.65   388.95   384.90   387.15   44249.0  151449.0
910429   387.95   389.70   382.15   382.50   49929.0  153815.0
910430   382.30   386.45   381.25   382.95   60936.0  154272.0
910501   383.30   388.95   383.30   388.65   51852.0  153444.0
910502   389.35   390.35   387.35   388.45   38244.0  151294.0
910503   388.45   389.45   386.30   388.85   39464.0  151974.0
910506   387.95   388.65   385.35   387.90   33647.0  151028.0
910507   388.05   389.35   383.85   384.05   38404.0  151540.0
910508   384.55   388.05   383.95   387.10   45841.0  153329.0
910509   387.50   392.25   386.70   391.65   51467.0  154756.0
910510   392.05   392.05   382.05   383.05   54803.0  156069.0
910513   384.85   385.05   382.25   384.80   45266.0  152962.0
910514   383.30   383.45   378.25   379.65   61668.0  157727.0
910515   379.95   380.95   373.55   376.70   65343.0  160614.0
910516   378.25   380.85   377.70   379.90   51843.0  158252.0
910517   378.15   381.65   377.00   381.35   49117.0  159133.0
910520   380.85   382.20   379.05   380.45   34721.0  159167.0
910521   380.45   385.15   380.45   384.05   50719.0  161320.0
910522   383.30   384.85   382.20   384.55   44742.0  162208.0
910523   384.55   386.45   381.05   382.90   47327.0  161635.0
910524   384.25   386.75   383.25   385.45   27857.0  159892.0
910528   386.20   390.65   384.55   389.85   50161.0  160181.0
910529   390.15   392.05   389.20   391.20   54739.0  158893.0
910530   390.95   396.45   390.45   394.55   57666.0  159734.0
910531   395.05   397.65   393.05   396.75   53761.0  161127.0
910603   396.15   398.05   394.65   395.40   45687.0  155736.0
910604   394.80   396.05   392.55   395.65   50090.0  158927.0
910605   396.30   396.40   392.20   392.95   53812.0  157195.0
910606   393.35   394.15   390.65   391.40   47406.0  157378.0
910607   389.55   390.45   386.20   387.25   66165.0  158775.0
910610   387.55   387.80   385.15   385.70   52046.0  156341.0
910611   386.25   389.60   385.95   389.15   56106.0  156814.0
910612   387.55   387.55   381.25   384.15   85052.0  160815.0
910613   384.90   385.85   383.45   385.35   64055.0  159267.0
910614   387.05   389.95   386.05   389.35   61997.0  161529.0
910617   389.05   389.75   387.45   387.95   43796.0  159287.0
910618   387.75   389.85   384.65   386.10   58905.0  160525.0
910619   383.95   384.35   381.30   382.15   77577.0  161344.0
910620   381.75   383.95   380.65   382.85   68781.0  163333.0
910621   384.25   384.95   382.35   384.80   33450.0  138083.0
910624   382.80   382.80   377.25   377.75   41425.0  139945.0
910625   379.45   379.65   376.75   378.10   40097.0  143299.0
910626   378.25   380.05   375.45   379.60   45040.0  140375.0
910627   380.25   381.70   379.85   381.60   36306.0  139785.0
910628   380.45   380.65   374.35   376.50   52019.0  140709.0
910701   382.00   385.00   380.00   384.75   49343.0  139425.0
910702   384.35   385.15   383.85   384.90   29381.0  139711.0
910703   382.15   382.15   378.25   380.25   31199.0  139902.0
910705   378.25   382.75   378.25   380.45   23616.0  139715.0
910708   378.55   384.75   376.65   384.50   48312.0  141728.0
910709   384.45   385.40   381.25   382.85   39497.0  138987.0
910710   383.75   387.45   380.75   382.80   47503.0  140156.0
910711   384.45   384.75   381.30   384.55   42911.0  141031.0
910712   385.75   388.45   381.40   386.85   46350.0  141418.0
910715   387.25   389.50   386.60   388.75   37547.0  142353.0
910716   388.75   389.75   386.85   388.65   34949.0  142220.0
910717   387.75   389.50   387.05   387.60   34464.0  142498.0
910718   387.25   391.95   386.95   391.00   43148.0  145352.0
910719   391.75   391.75   389.25   390.85   39188.0  144602.0
910722   390.15   390.95   387.30   389.40   34643.0  143618.0
910723   390.25   391.35   384.85   385.85   42075.0  144568.0
910724   386.25   386.65   383.75   385.00   39270.0  145550.0
910725   385.35   387.30   383.85   386.10   36141.0  144851.0
910726   386.25   387.50   385.05   386.20   26699.0  143571.0
910729   386.35   389.15   385.70   388.70   28820.0  143836.0
910730   389.35   392.85   388.95   392.35   40005.0  146093.0
910731   392.50   393.30   391.55   392.65   31309.0  147454.0
910801   392.15   393.40   391.55   393.20   30567.0  146512.0
910802   394.05   395.05   391.05   392.70   36965.0  147990.0
910805   392.25   392.90   389.75   390.95   29174.0  147611.0
910806   390.15   396.70   389.45   395.95   54694.0  152944.0
910807   396.05   397.25   395.15   396.20   41301.0  153317.0
910808   395.25   397.45   393.30   394.40   40606.0  152834.0
910809   394.75   395.45   391.95   392.10   38889.0  151899.0
910812   392.05   394.05   390.85   393.55   30560.0  151147.0
910813   394.25   398.00   393.35   394.35   49469.0  152211.0
910814   396.25   397.55   394.25   395.45   45646.0  152640.0
910815   395.25   397.45   394.35   395.20   42834.0  152911.0
910816   394.95   396.15   387.30   391.10   56420.0  151050.0
910819   386.10   386.10   379.10   383.10   60038.0  151259.0
910820   384.25   385.30   381.40   384.75   51204.0  151657.0
910821   389.75   396.75   388.75   396.50   55472.0  151838.0
910822   397.45   397.95   395.05   396.60   42129.0  151876.0
910823   394.95   401.15   394.95   398.90   48787.0  153211.0
910826   399.10   399.70   397.85   398.75   28410.0  153061.0
910827   398.65   399.30   396.65   398.80   31482.0  153683.0
910828   398.65   402.20   398.15   401.05   37535.0  154787.0
910829   401.50   402.15   399.65   401.25   36067.0  156208.0
910830   401.05   401.70   398.05   399.80   34816.0  154842.0
910903   400.55   402.85   396.35   396.95   46758.0  156338.0
910904   397.35   397.40   393.15   395.45   52310.0  154689.0
910905   395.75   396.00   393.25   394.00   38776.0  153733.0
910906   395.05   395.70   391.65   393.70   51927.0  153227.0
910909   393.55   394.45   392.35   392.90   35365.0  151018.0
910910   393.25   393.45   388.25   389.35   67722.0  154368.0
910911   389.95   390.35   388.20   388.95   64852.0  154109.0
910912   390.25   392.10   390.10   391.95   64435.0  158248.0
910913   393.05   393.05   387.15   387.75   78846.0  161415.0
910916   388.25   390.80   387.05   390.50   64732.0  158996.0
910917   389.60   391.60   389.15   389.80   61649.0  160492.0
910918   388.60   391.05   388.30   390.75   44588.0  160406.0
910919   390.60   394.15   390.25   391.50   75097.0  160970.0
910920   392.60   393.10   390.30   391.90   41079.0  136579.0
910923   391.70   393.00   389.30   390.80   33413.0  136463.0
910924   390.60   393.00   388.30   391.90   41704.0  136817.0
910925   392.35   392.90   389.90   390.85   33535.0  137253.0
910926   389.40   392.80   388.90   391.40   35746.0  138640.0
910927   391.30   393.50   388.40   390.35   39068.0  139551.0
910930   389.90   392.60   388.00   391.90   42467.0  139740.0
911001   393.10   393.90   392.20   393.25   35120.0  139055.0
911002   393.70   394.20   390.90   391.05   42845.0  140724.0
911003   390.85   391.40   387.20   387.30   40244.0  141165.0
911004   388.20   389.10   383.80   384.00   37800.0  141418.0
911007   384.10   385.15   382.15   383.60   37352.0  141876.0
911008   383.90   385.15   382.70   383.65   43857.0  142243.0
911009   383.60   384.15   379.20   379.90   43761.0  142697.0
911010   380.60   384.40   379.50   383.90   30246.0  142437.0
911011   384.10   384.80   382.90   384.40   33422.0  141601.0
911014   385.00   390.30   384.70   390.15   46777.0  141559.0
911015   390.10   395.10   389.05   393.80   47004.0  142930.0
911016   394.30   396.80   393.30   396.20   48495.0  143592.0
911017   395.10   397.45   393.35   395.35   35165.0  145357.0
911018   395.85   396.45   394.50   396.15   37330.0  145172.0
911021   395.30   395.35   391.90   393.90   40425.0  145542.0
911022   393.30   394.55   390.20   391.00   38828.0  146843.0
911023   391.50   391.80   389.10   391.45   46839.0  147121.0
911024   390.90   391.20   386.35   387.90   45621.0  148412.0
911025   387.80   389.05   385.20   386.90   46351.0  149092.0
911028   388.25   392.50   387.60   392.20   50892.0  148683.0
911029   392.30   394.85   389.25   394.50   44463.0  147367.0
911030   394.80   395.80   393.05   395.35   36277.0  146860.0
911031   395.10   395.40   393.75   394.90   56624.0  145972.0
911101   394.70   397.30   391.50   393.40   42067.0  146882.0
911104   392.40   393.70   390.25   393.45   50797.0  146680.0
911105   393.65   395.35   390.50   391.30   49000.0  147103.0
911106   390.90   392.85   389.85   392.65   51411.0  146765.0
911107   393.10   396.05   392.15   395.90   44709.0  146751.0
911108   398.30   399.35   394.80   395.05   27692.0  147024.0
911111   395.20   396.50   394.60   395.85   45520.0  147071.0
911112   397.40   400.00   396.65   398.90   46145.0  147987.0
911113   396.60   400.10   395.90   399.90   47044.0  146876.0
911114   400.80   400.80   398.10   399.55   65092.0  146963.0
911115   399.80   399.80   380.60   385.10   54047.0  151800.0
911118   386.60   387.90   381.60   387.65   76253.0  153611.0
911119   384.90   385.10   375.65   382.55   57490.0  158521.0
911120   383.60   383.80   379.75   380.00   62747.0  156819.0
911121   379.10   383.75   378.55   382.85   65731.0  160051.0
911122   381.50   382.25   376.05   377.10   53030.0  163302.0
911125   378.10   379.70   376.15   378.15   68156.0  164883.0
911126   379.70   381.20   373.70   381.10   44983.0  168175.0
911127   380.40   381.00   378.00   378.70   25524.0  164415.0
911129   377.70   378.65   376.35   377.30   71043.0  164996.0
911202   373.60   383.90   372.70   383.80   51057.0  166186.0
911203   383.00   384.00   382.10   382.15   63235.0  163656.0
911204   383.00   383.70   379.90   382.15   57703.0  164064.0
911205   381.50   382.20   378.15   379.75   77903.0  163723.0
911206   377.85   384.60   377.45   381.05   74892.0  162650.0
911209   381.60   383.50   379.20   380.45   69175.0  168426.0
911210   379.60   382.20   378.20   380.20   78152.0  166656.0
911211   381.40   381.90   376.70   379.55   78596.0  168171.0
911212   381.60   384.25   381.00   383.20   62852.0  168297.0
911213   385.20   387.10   384.90   386.40   56854.0  166536.0
911216   386.20   388.05   385.85   386.65   55654.0  167788.0
911217   386.50   386.75   384.50   384.65   60082.0  170631.0
911218   384.90   385.80   382.60   385.55   74897.0  170973.0
911219   384.55   385.65   382.00   384.60   58551.0  173127.0
END_DATA
*/

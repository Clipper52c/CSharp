/*
c  booka.c
c
c  Testing module like those used for the Options book.  The code here
c  is intended for various specialized tests or analyses.  To compile,
c  simply use "gcc booka.c -lm -o booka" (or whatever is equivalent
c  for your compiler); the libraries are brought in with #include
c  statements, so they do not have to be linked.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2006.  All rights reserved.
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libpff.c"             /* stockmarket database component */
#include "librgrs.c"            /* regression component */
#include "libbspm.c"            /* Black-Scholes pricing model */
#include "libmisc.c"            /* miscellaneous functions */
#include "libodb.c"             /* option database component */

/*---------------------------------------------------------------------------
c  Option pricing in terms of factors beyond implied volatility,
c  e.g., fitting implied volatilities in a chain using a polynomial.
*/

void SkewModel (void) {

    ODBFILE *odb;
    ODBCHAIN oc;
    long i, k, m, n, istk, iday, iopt, iexpdate;
    static float stock[200], strike[200], price[200], timeleft[200];
    static float vltyimp[200], vltyfit[200], x[200], coeff[12];

    void fitpolymodel (float x[], float y[], float yhat[],
        float coeff[], int m, int n);

    /* open options market database */
    odb=odb_open("../mktdata/optdbmp/indexopts",0);

    /* determine database index for desired symbol */
    istk=odb_stkno(odb,"QQQQ");
    if(istk<0) misc_ftlerr("ticker not found");

    /* for each bar ... */
    for(iday=0; iday<odb_nday(odb); iday++) {

        /* read options chain for given symbol and bar */
        odb_read(odb, istk, iday, &oc);
        if(oc.valid<=0) continue;  /* no chain found */

        /* extract and calculate needed data from options chain */
        for(n=0, iopt=0; iopt<oc.nopt; iopt++) {
            iexpdate=1+misc_nthned(oc.date,1);	/* nearest expiration */
            if(misc_month(iexpdate)!=oc.expmo[iopt]) continue;
            if(oc.otype[iopt]!=1) continue;	/* 0=call, 1=put */
            stock[n]=oc.stkcls;			/* raw stock price */
            strike[n]=oc.strike[iopt];		/* option strike price */
            if(oc.bid[iopt]<0.03) continue;
            price[n]=0.5*(oc.bid[iopt]+oc.ask[iopt]);	/* option price */
            if(price[n]>15.5 || price[n]<0.06+strike[n]-stock[n]) continue;
            timeleft[n]=misc_datetoser(iexpdate)-misc_datetoser(oc.date);
            vltyimp[n]=100.0*bspiv(0.10+price[n],stock[n],
                strike[n],timeleft[n],0.05)/sqrt(365.25);
            n++;	/* count of options selected for modelling */
        }
        if(n==0) continue;

        /* fit model to implied volatilities of each option in chain */
        for(i=0; i<n; i++) vltyfit[i]=0.0;
        if(n>1) {
            if(n==2) m=1; if(n==3) m=2; if(n==4) m=2;
            if(n==5) m=3; if(n==6) m=3; if(n>=7) m=4;
            for(i=0; i<n; i++) x[i]=stock[i]-strike[i];
            fitpolymodel(x,vltyimp,vltyfit,coeff,m,n);
            fprintf(stdout,"COEFF: ");
            for(k=0; k<=m; k++) fprintf(stdout,"%9.3f ",(float)coeff[k]);
            fprintf(stdout,"\n");
        }
        else fprintf(stdout,"NO MODEL\n");
        fflush(stdout);

        /* display results */
        for(i=0; i<n; i++) {
            fprintf(stdout, "%8ld %7.2f %7.2f %4ld %7.2f %7.2f  %7.2f\n",
               19000000L+(long)oc.date, (float)stock[i], (float)strike[i],
               (long)timeleft[i], (float)price[i], (float)vltyimp[i],
               (float)vltyfit[i]
            );
            fflush(stdout);
        }
        fprintf(stdout,"\n");
        fflush(stdout);

    } /* next bar */

    /* close options database */
    odb_close(odb);
}

void fitpolymodel (float x[], float y[], float yhat[], float coeff[],
int m, int n) {
    /* Fits a polynomial of order m to the n data points in x and y.
    .  Said another way, this function determines P such that the
    .  sum (over i) of (y[i]-P(x[i]))**2 is a minimum.
    .  x     - array [0..n-1] of x values
    .  y     - array [0..n-1] of y values
    .  yhat  - array [0..n-1] of P(x) values
    .  coeff - array [0..m] of coefficients defining the polynomial
    .  m     - order of the desired polynomial
    .  n     - number of data points 
    */
    REGRESSION *rgrs;
    long i, k;
    float xvec[20];
    /* create a regression object */
    rgrs=rgrs_init(m+1);
    /* calculate least-squares regression model */
    for(i=0; i<n; i++) {
        xvec[0]=1.0;
        /* regress using raw data */
        for(k=1; k<=m; k++) xvec[k]=pow(x[i],k);
        rgrs_accum(rgrs,xvec,y[i]);
        #if 1==1
            /* We can also use interpolates as a "regularization"
            .  to reduce oscillations when fitting large polynomials.
            .  Only do this if (1) one expiration date is being
            .  analyzed, and (2) strikes (in x[]) are in strict
            .  ascending or descending order!  If these two
            .  conditions are not satisfied, the interpolates
            .  calculated below will not be valid.
            */
            for(k=1; k<=m; k++) xvec[k]=pow(0.5*(x[i]+x[i-1]),k);
            rgrs_accum(rgrs,xvec,0.5*(y[i]+y[i-1]));
        #endif
    }
    rgrs_calc(rgrs);
    /* retrieve regression weights from regression object */    
    rgrs_weights(rgrs,coeff);
    /* calculate values of P(x[i]) for all i using regression
    .  weights as coefficients for the various powers of x[i]
    */
    for(i=0; i<n; i++) {
        xvec[0]=1.0;
        for(k=1; k<=m; k++) xvec[k]=pow(x[i],k);
        yhat[i]=rgrs_yhat(rgrs,xvec);
    }
}

/*---------------------------------------------------------------------------
c  Calendar (seasonality) analysis of volatility and returns.
*/

void Clndr (void) {

    PORTFOLIODATA *pff;
    int i,j,k, kdm, ndiy, n;
    float *andps,*anwins,*tret,*tvx, cc,aa, tiny=1.0E-32;

    /* open stock quotes database */
    pff=pff_open("../mktdata/dbases/bigdiv",1,0);
    printf("NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);

    /* allocate array memory */
    ndiy=31*12;
    andps=(float*)misc_malloc(sizeof(float)*ndiy);
    anwins=(float*)misc_malloc(sizeof(float)*ndiy);
    tret=(float*)misc_malloc(sizeof(float)*ndiy);
    tvx=(float*)misc_malloc(sizeof(float)*ndiy);
    for(i=0; i<ndiy; i++) andps[i]=anwins[i]=tret[i]=tvx[i]=0.0;

    /* load desired quote series */
    pff_seekquotes(pff,0);  /* for file bigdiv: 0=QQQQ 1=SPY */

    /* loop over bars or days */
    for(n=0, i=2; i<pff->nbar; i++) {

        /* determine index into seasonal arrays */
        kdm=(misc_dayofmonth(pff->ldt[i])-1)+31*(misc_month(pff->ldt[i])-1);
        if(kdm>ndiy-1) kdm=ndiy-1;
        if(kdm<0) kdm=0;

        /* accumulate returns, volatility, total counts, and win counts */
        tret[kdm] += (cc = log (pff->cls[i] / pff->cls[i-1]));
        tvx[kdm] +=  cc * cc;
        andps[kdm] += 1.0;
        if(cc > 0.0) anwins[kdm] += 1.0;

        /* count bars per year */
        n++;
        if(misc_year(pff->ldt[i]) != misc_year(pff->ldt[i-1])) {
            fprintf(stdout,"N=%d\n",(int)n);
            n=0;
        }
    }

    /* print out results */
    for(i=0; i<ndiy; i++) {
        for(aa=0.0, k= i-2; k<=i+2; k++) {
            if(k<0) j=k+ndiy;
            if(k>=ndiy) j=k-ndiy;
            else j=k;
            aa+=(tret[j]/(andps[j]+tiny));
        }
        aa=aa/5.0;
        fprintf(stdout, "%02d %02d %6d %6d %12.4f %12.4f %12.4f\n",
            (int)((i%31)+1),			/* day of month */
            (int)(i/31+1),			/* month of year */
            (int)andps[i],			/* event count */
            (int)anwins[i],			/* win count */
            (float)(tret[i]/(andps[i]+tiny)),	/* return */
            (float)aa,				/* average return */
            (float)(100.0*sqrt((252./365.)*	/* average volatility */
                tvx[i]/(andps[i]+tiny))) );
        fflush(stdout);
    }

    /* close up */
    free(andps);
    free(anwins);
    free(tret);
    free(tvx);
    pff_close(pff);
}

/*---------------------------------------------------------------------------
c  Plasmode to analyze Parkinson's and other historical volatility models.
c  This routine also serves as a good test of the historical volatility
c  functions in files libbspm.c and libbspm.h.
*/

void Park (void) {

    float *opn, *hi, *lo, *cls, *ser;
    double acoeff, r, an, ux, sx, d;
    int itck, ibar, nbar, imode;

    /* allocate arrays */
    nbar=99000;
    opn=(float*)misc_malloc(sizeof(float)*nbar);
    hi=(float*)misc_malloc(sizeof(float)*nbar);
    lo=(float*)misc_malloc(sizeof(float)*nbar);
    cls=(float*)misc_malloc(sizeof(float)*nbar);
    ser=(float*)misc_malloc(sizeof(float)*nbar);

    /* prepare test data using a psuedo-random number generator */
    d=100.0;
    for(ibar=0; ibar<nbar; ibar++) {
        #if 1==0
            /* non-market hours */
            acoeff=1.0+0.023/sqrt(1140);
            for(itck=0; itck<(1440-375); itck++) {
                r=randflt();
                if(r>0.5) d*=acoeff;
                else d/=acoeff;
            }
        #endif
        #if 1==1
            /* weekends and holidays */
            if((ibar%5)==0 || (ibar%47)==0) {
                acoeff=1.0+0.023/sqrt(3375);
                for(itck=0; itck<2*3375; itck++) {
                    r=misc_randflt();
                    if(r>0.5) d*=acoeff;
                    else d/=acoeff;
                }
            }
        #endif
        acoeff=1.0+0.023/sqrt(3375);
        opn[ibar]=d;
        hi[ibar]=d;
        lo[ibar]=d;
        for(itck=0; itck<3375; itck++) {
            /* market hours */
            r=misc_randflt();
            if(r>0.5) d*=acoeff;
            else d/=acoeff;
            hi[ibar]=max(hi[ibar],d);
            lo[ibar]=min(lo[ibar],d);
        }
        cls[ibar]=d;
    }

    /* calculate and display historical volatilities */
    for(imode=1; imode<=6; imode++) {
        bsvltyser(hi,lo,cls,nbar,ser,30,imode);
        for(ux=sx=an=0.0, ibar=100; ibar<nbar; ibar+=30) {
            ux+=ser[ibar]; sx+=ser[ibar]*ser[ibar]; an+=1.0;
        }
        ux=ux/an; sx=sqrt(sx/an-ux*ux);
        fprintf(stdout,"Mode=%d   SerVx=%9.5lf (%8.3lf)   ",imode,ux,sx);
        for(ux=sx=an=0.0, ibar=100; ibar<nbar; ibar+=30) {
            d=bsvltybar(hi,lo,cls,ibar,30,imode);
            ux+=d; sx+=d*d; an+=1.0;
        }
        ux=ux/an; sx=sqrt(sx/an-ux*ux);
        fprintf(stdout,"BarVx=%9.5lf (%8.3lf)\n",ux,sx);
        fflush(stdout);
    }

    /* free memory */
    free(ser);
    free(cls);
    free(hi);
    free(lo);
    free(opn);
}

/*---------------------------------------------------------------------------
c  Analyzes average returns as a function of any two factors.
*/

#if 1==0
  void Test3 (float p1, float p2, float p3) {

    PORTFOLIODATA *pff;  REGRESSION *rgrs;
    int ibar,imkt, mperh,mperf, nlvl1,nlvl2,nsts, k1,k2,i;
    float *rfi,*hvx, bmn1,bmx1,bmn2,bmx2, x1,x2,y, vin[6];
    double *bdqq, an;

    /* open stockmarket database */
    pff=pff_open("../mktdata/dbases/bigdiv",1,0);
    printf("NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);

    /* create regression object */
    rgrs=rgrs_init(5);

    /* initialize parameters */
    mperh=30;     /* period in bars for historical volatility */
    mperf=18;     /* period in bars for calculating returns */
    nlvl1=14;     /* number of x1 levels or bins */
    nlvl2=10;     /* number of x2 levels or bins */
    nsts=2;       /* number of statistics per bin (always 2) */
    bmn1=0.05;    /* center value for lowest x1 bin */
    bmx1=0.60;    /* center value for highest x1 bin */
    bmn2=0.70;    /* center value for lowest x2 bin */
    bmx2=1.50;    /* center value for highest x2 bin */

    /* allocate and initialize vectors and matrices */
    rfi=misc_malloc(sizeof(float)*pff->nbar);
    hvx=misc_malloc(sizeof(float)*pff->nbar);
    bdqq=misc_malloc(sizeof(float)*nlvl1*nlvl2*nsts);    
    memset(bdqq,0,sizeof(*bdqq)*nlvl1*nlvl2*nsts);
    #define bd(i,j,k) bdqq[(i)+nlvl1*((j)+nlvl2*(k))]

    /* read risk free interest rates */
    bsrdrfi("../mktdata/dbases/wgs3mo.txt",pff->nbar,pff->dt,rfi);

    /* loop over all stocks in database */
    for(imkt=0; imkt<pff->nmkt; imkt++) {

        /* read current stock and display progress */
        if(imkt%10==0) printf("PROC IMKT=%d\r",(int)imkt);
        pff_seekquotes(pff,imkt);

        /* skip all except active optionable NASD stocks */
        i=(int)pff->sf[0];
        if((i%10)!=1) goto L1;           /* not a stock */
        if(((i/10)%10)!=1) goto L1;      /* not active */
        if(((i/100)%10)!=0) goto L1;     /* not optionable */
        if(((i/1000)%10)!=3) goto L1;    /* not NASD */

        /* skip bad or deleted stocks */
        for(ibar=0; ibar<pff->nbar; ibar++)
            if(pff->cls[ibar]<0.001) goto L1;

        /* calculate historical volatility */
        if(p1==1) i=1;                  /* standard deviation */
        else if(p1==2) i=6;             /* average hi-lo range */
        else ftlerr("invalid mode 1s digit");
        vltyser(pff->hi,pff->lo,pff->cls,pff->nbar,hvx,mperh,i);

        /* loop over bars leaving room at both ends */
        for(ibar=mperh+3; ibar<pff->nbar-mperf-3; ibar++) {

            /* analyze active stocks that have no original */
            /* (not split-corrected) price < $2 in recent past */
            if( dayofweek(pff->dt[ibar+1]) != (int)p2 ) goto L2;
            /* if( dayofmonth(pff->dt[ibar+1]) < 21 ) goto L2; */
            if( pff->vol[ibar+mperf] < 0.001 ) goto L2;
            if( pff->vol[ibar-mperh] < 0.001 ) goto L2;
            for(i=ibar-mperh; i<=ibar; i++)
                if( pff->cls[i] * pff->sf[i] < 1.0 ) goto L2;
            if( pff->cls[ibar] * pff->sf[ibar] > 15.0 ) goto L2;

            /* determine independent variables */
            /* x2=Highest(pff->cls,5,ibar)/Average(pff->cls,20,ibar-5); */
            x2 = pff->cls[ibar] / Average(pff->cls,20,ibar-1);
            x1 = hvx[ibar];

            /* determine dependent variable, here mperf-bar return */
            /* y=log(pff->cls[ibar+mperf]/pff->cls[ibar+1]); */
            /* y=log(Average(pff->cls,5,ibar+5)/pff->cls[ibar+1]); */
            if(!( pff->lo[ibar+1] < Lowest(pff->cls,20,ibar) )) goto L2;
            y = Average(pff->cls,5,ibar+mperf) /
                        Lowest(pff->cls,20,ibar) - 1.0;

            /* restrict range of independent variables */
            if(x1<bmn1 || x1>bmx1) goto L2;
            if(x2<bmn2 || x2>bmx2) goto L2;

            /* accumulate binned statistics */
            k1=(int)(0.5+(nlvl1-1)*(x1-bmn1)/(bmx1-bmn1));
            k2=(int)(0.5+(nlvl2-1)*(x2-bmn2)/(bmx2-bmn2));
            bd(k1,k2,0)+=((double)y);   /* for bin mean */
            bd(k1,k2,1)+=1.0;           /* for bin case count */

            /* accumulate regression statistics */
            vin[0]=1.0;                 /* intercept variable */
            vin[1]=x1;                  /* independent variable 1 */
            vin[2]=x1*x1;
            vin[3]=x2;                  /* independent variable 2 */
            vin[4]=x2*x2;
            vin[5]=x1*x2;               /* interaction term */
            rgrs_accum(rgrs,vin,y);

            /* next bar (ibar) */
            L2:;
        }

        /* next stock (imkt) */
        L1:;
        if(imkt>29999) break;     /* debug use only */
    }
    printf("\n");

    /* finish calculating statistics */
    for(k1=0; k1<nlvl1; k1++) {
        for(k2=0; k2<nlvl2; k2++) {
            an=bd(k1,k2,1);                 /* bin case count */
            if(an<10.0) bd(k1,k2,0)=0.0;    /* bin mean */
            else bd(k1,k2,0)/=an;
        }
    }
    rgrs_calc(rgrs);

    /* print histogram bin and regression statistics to file */
    {
        FILE *fp;  float x,s,n,w;  int id1,id2;
        fp=fopen("book.txt","at");
        if(!fp) ftlerr("Cannot open output file");
        fprintf(fp,"TEST3 p1=%.3f p2=%.3f p3=%.3f\nBIN_STATISTICS\n",
            (float)p1,(float)p2,(float)p3);
        fprintf(fp,"MEANS\n%6s%6s\n%6s","X1","X2"," ");
        for(k2=1; k2<nlvl2-1; k2++)
            fprintf(fp,"%6.2f",(float)(bmn2+(k2*(bmx2-bmn2))/(nlvl2-1)));
        fprintf(fp,"\n");
        for(k1=1; k1<nlvl1-1; k1++) {
            fprintf(fp,"%6.2f",(float)(bmn1+(k1*(bmx1-bmn1))/(nlvl1-1)));
            for(k2=1; k2<nlvl2-1; k2++) {
                /* apply kernel smoothing */
                s=n=0.0;
                for(id1= -1;id1<=1;id1++)
                    for(id2= -1;id2<=1;id2++) {
                        w=1.0/(1+id1*id1+id2*id2);
                        if((x=bd(k1+id1,k2+id2,0))!=0.0) {
                            s+=w*x; n+=w;  } }
                if(n>0.0) fprintf(fp,"%6.2f",(float)(s/n));
                else fprintf(fp,"      ");
            }
            fprintf(fp,"\n");
        }
        fprintf(fp,"CASES\n%6s%6s\n%6s","X1","X2"," ");
        for(k2=1; k2<nlvl2-1; k2++)
            fprintf(fp,"%6.2f",(float)(bmn2+(k2*(bmx2-bmn2))/(nlvl2-1)));
        fprintf(fp,"\n");
        for(k1=1; k1<nlvl1-1; k1++) {
            fprintf(fp,"%6.2f",(float)(bmn1+(k1*(bmx1-bmn1))/(nlvl1-1)));
            for(k2=1; k2<nlvl2-1; k2++) {
                /* apply kernel smoothing */
                s=n=0.0;
                for(id1= -1;id1<=1;id1++) for(id2= -1;id2<=1;id2++) {
                    w=1.0/(1+id1*id1+id2*id2);
                    if((x=bd(k1+id1,k2+id2,0))!=0.0) {
                        s+=w*bd(k1+id1,k2+id2,1); n+=w;  } }
                if(n>0.0) fprintf(fp,"%6d",(int)(s/n));
                else fprintf(fp,"      ");
            }
            fprintf(fp,"\n");
        }
        fprintf(fp,"\nREGRESSION_STATISTICS\n");
        rgrs_print(rgrs,fp); fprintf(fp,"\n\n");
        fclose(fp);
    }

    /* free memory and close database */
    #undef bd
    free(bdqq);
    free(hvx);
    free(rfi);
    rgrs_free(rgrs);
    pff_close(pff);
  }
#endif

/*---------------------------------------------------------------------------
c  Analyzes average returns as a function of any single factor.
*/

#if 1==0
  void Test2 (int mode) {

    PORTFOLIODATA *pff;  REGRESSION *rgrs;
    int ibar,imkt, mperh,mperf, nlvl,nsts, i,k,mm;
    float *rfi, *hvx, bmn,bmx, x,y, vin[3];
    double *bdqq, an;

    /* open stock database file */
    pff=pff_open("../mktdata/dbases/bigdiv",1,0);
    printf("NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);

    /* create regression object */
    rgrs=rgrs_init(3);

    /* initialize parameters */
    mperh=30;   /* period in bars for historical volatility */
    mperf=10;   /* period in bars for calculating returns */
    nlvl=20;    /* number of levels or bins */
    nsts=4;     /* number of variables per bin (always 4) */
    bmn=0.10;   /* center value for lowest bin */
    bmx=2.00;   /* center value for highest bin */

    /* allocate and initialize vectors and matrices */
    rfi=misc_malloc(sizeof(float)*pff->nbar);
    hvx=misc_malloc(sizeof(float)*pff->nbar);
    bdqq=misc_malloc(sizeof(float)*nlvl*nsts);
    #define bd(i,j) bdqq[(i)+nlvl*(j)]
    memset(bdqq,0,sizeof(*bdqq)*nlvl*nsts);

    /* read risk free interest rates */
    bsrdrfi("../mktdata/dbases/wgs3mo.txt",pff->nbar,pff->dt,rfi);

    /* loop over all stocks in database */
    for(imkt=0; imkt<pff->nmkt; imkt++) {

        /* read current stock and display progress */
        if(imkt%10==0) printf("PROCESSING IMKT=%d\r",(int)imkt);
        pff_seekquotes(pff,imkt);

        /* skip all except active optionable NASD stocks */
        k=(int)pff->sf[0];
        if((k%10)!=1) goto L1;           /* not a stock */
        if(((k/10)%10)!=1) goto L1;      /* not active */
        if(((k/100)%10)!=1) goto L1;     /* not optionable */
        if(((k/1000)%10)!=3) goto L1;    /* not NASD */

        /* skip bad or deleted stocks */
        for(ibar=0; ibar<pff->nbar; ibar++)
            if(pff->cls[ibar]<0.001) goto L1; /* bad or deleted */

        /* calculate historical volatility */
        if((mm=mode%10)==0) k=1;        /* standard deviation */
        else if(mm==1) k=6;             /* average hi-lo range */
        else ftlerr("invalid mode 1s digit");
        vltyser(pff->hi,pff->lo,pff->cls,pff->nbar,hvx,mperh,k);

        /* loop over bars leaving room at both ends */
        for(ibar=mperh+3; ibar<pff->nbar-mperf-3; ibar++) {

            /* analyze active stocks that have no original */
            /* (not split-corrected) price < $2 in recent past */
            if(pff->vol[ibar+mperf]<0.0001) goto L2;
            if(pff->vol[ibar-mperh]<0.0001) goto L2;
            for(i=ibar-mperh; i<=ibar; i++)
                if(pff->cls[i]*pff->sf[i]<2.0) goto L2;
            if(pff->cls[ibar]*pff->sf[ibar]>35.0) goto L2;
            if(hvx[ibar]<bmn || hvx[ibar]>bmx) goto L2;

            if(Highest(pff->cls, 5, ibar) >
                0.95 * Average(pff->cls, 20, ibar-5)) goto L2;
            /* extract independent and dependent variables */
            x=hvx[ibar];                /* historical mperh-bar volatility */
            y=log(pff->cls[ibar+mperf]/pff->cls[ibar+1]);  /* avg return */

            /* accumulate binned statistics */
            k=(int)(0.5+(nlvl-1)*(x-bmn)/(bmx-bmn));
            k=(k<0)?(0):(k>nlvl-1)?(nlvl-1):k;
            bd(k,0)+=((double)x);       /* for bin mean of x */
            bd(k,1)+=((double)y);       /* for bin mean of y */
            bd(k,2)+=((double)y*y);     /* for bin stdev of y */
            bd(k,3)+=1.0;               /* for bin case count */

            /* accumulate regression statistics */
            vin[0]=1.0;                 /* intercept variable */
            vin[1]=x;                   /* independent variable 1 */
            vin[2]=x*x;                 /* independent variable 2 */
            rgrs_accum(rgrs,vin,y);

            /* next bar (ibar) */
            L2:;
        }

        /* next stock (imkt) */
        L1:;
        if(imkt>29999) break;           /* debug use only */
    }
    printf("\n");

    /* finish calculating statistics */
    for(k=0; k<nlvl; k++) {
        an=bd(k,3);             /* case count */
        if(an<4.0) {            /* insufficient bin data */
            bd(k,0)=0.0; bd(k,1)=0.0; bd(k,2)=0.0;
            continue;
        }
        bd(k,0)/=an;            /* x-variable bin mean */
        bd(k,1)/=an;            /* y-variable bin mean */
        bd(k,2)=(an/(an-1.0))*(bd(k,2)/an-bd(k,1)*bd(k,1));
        bd(k,2)=sqrt(bd(k,2));  /* y-variable bin stddev */
    }
    rgrs_calc(rgrs);

    /* print and plot statistics to file */
    {
        static char *clbl[]={"BIN","BCTR","XMEAN","YMEAN",
            "SMOOTH","YSDEV","NCAS"};
        FILE *fp;  float *x, *y, smd;
        fp=fopen("book.txt","at");
        if(!fp) ftlerr("Cannot open output file");
        x=(float*)misc_malloc(sizeof(float)*nlvl);
        y=(float*)misc_malloc(sizeof(float)*nlvl);
        fprintf(fp,"TEST2_MODE=%d\nBIN_STATISTICS\n",(int)mode);
        for(k=0; k<7; k++) fprintf(fp,"%10s",(char*)clbl[k]);
        fprintf(fp,"\n");
        for(k=0; k<nlvl; k++) {
            if(k==0) smd=(bd(k,1)+0.5*bd(k+1,1))/1.5;
            else if(k==nlvl-1) smd=(bd(k,1)+0.5*bd(k-1,1))/1.5;
            else smd=(bd(k,1)+0.5*(bd(k+1,1)+bd(k-1,1)))/2.0;
            fprintf(fp,"%10d%10.2f%10.2f%10.2f%10.2f%10.2f%10.1f\n",
                (int)k, (float)(bmn+(k*(bmx-bmn))/(nlvl-1)),
                (float)bd(k,0), (float)bd(k,1), smd,
                (float)bd(k,2), (float)bd(k,3)
            );
            x[k]=bd(k,0);
            y[k]=smd;
        }
        fprintf(fp,"\nREGRESSION_STATISTICS\n");
        rgrs_print(rgrs,fp); fprintf(fp,"\n");
        textplot(fp,x,y,nlvl);
        free(y);
        free(x);
        fclose(fp);
    }
    /* free memory and close database file */
    #undef bd
    free(bdqq);
    free(hvx);
    free(rfi);
    rgrs_free(rgrs);
    pff_close(pff);
  }
#endif

/*---------------------------------------------------------------------------
c  Main program entry.  We call the desired routine(s) from here.
*/

int main (void) {
    /* SkewModel(); */
    Park();
    /* float p1; */
    /* Clndr(); */
    /* for(p1=1; p1<=5; p1++) Test3(1,p1,0); */
    return(0);
}



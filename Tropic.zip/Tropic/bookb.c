/*
c  bookb.c
c
c  Testing module like those used for the Options book.  The code here is
c  intended for various specialized tests or demonstrations.  Code under
c  development to later be included in the lib* libraries also appears
c  in this module.  To compile, simply use "gcc bookb.c -lm -o bookb"
c  (or the equivalent for your compiler); libraries are included via
c  #include statements, so there is no need to link them into the
c  executable (that is why you see #include "libpff.c" rather than
c  the more usual #include "libpff.h" in the code below).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2008.  All rights reserved.
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libpff.c"             /* stock database component */
#include "libodb.c"             /* option database component */
#include "libbspm.c"            /* Black-Scholes pricing model */
#include "libmisc.c"            /* miscellaneous functions */

/*---------------------------------------------------------------------------
c  Plasmode that tests Delta-neutral Gamma scalping.
*/

void gammascalp (float poval[], float tleft[], float sprice[],
    float vlty[], long npts) {

    /* Simulates a delta-neutral gamma-scalping strategy involving
    .  positions in options and stocks.
    .  Arguments:
    .    poval	- total position values [0..npts-1], output
    .    tleft	- days (time) left [0..npts-1], input
    .    sprice	- stock prices [0..npts-1], input
    .    vlty	- annualized volatilities [0..npts-1], input
    .	 npts	- number of data or rebalance points, input
    .  Note 1:
    .    Each data point represents an instance where a rebalancing
    .    of the position is performed.  The data points, consisting
    .    of time left, stock price, and volatility (for Black-Scholes),
    .    need not adhere to any particular spacing in time or in price
    .    as long as they are in time order (most time left to least
    .    time left).
    .  Note 2:
    .    Total position values (poval) are relative, always starting
    .    at zero when the position is put on and moving up with gains
    .    and down with losses.
    .  Requires: libbspm (bscalc)
    */

    BSPMQQ bs;
    long k;
    float sec1price, sec1delta, sec1size, sec1size_prev;
    float sec2price, sec2delta, sec2size, sec2size_prev;
    float cashvalue;

    /* initialize */
    cashvalue= 0.0;
    sec1size_prev= 0.0;
    sec2size_prev= 0.0;
    bs.rfi= 0.05;
    bs.sk= floor(0.5 + sprice[0]);

    /* for each data or rebalancing point ... */
    for(k= 0; k< npts; k++) {

            /* determine price, delta, and size for first security */
            bs.sp= sprice[k];
            bs.vx= vlty[k];
            bs.tl= tleft[k];
            bscalc( &bs );
            sec2price= bs.vput;
            sec2delta= bs.dput;
            sec2size= 100.0;

            /* determine price, delta, and size for second security */
            sec1price= sprice[k];
            sec1delta= 1.0;
            sec1size= - sec2delta * sec2size;

            /* determine cash payout from rebalancing transactions */
            cashvalue= cashvalue
                - (sec1size - sec1size_prev) * sec1price
                - (sec2size - sec2size_prev) * sec2price;

            /* save previous security position sizes */
            sec1size_prev= sec1size;
            sec2size_prev= sec2size;
  
            /* determine total relative position value */
            poval[k]= cashvalue + sec1size * sec1price
                                + sec2size * sec2price;

            /* #define GSMDEBUG */
            #ifdef GSMDEBUG
              /* display debugging data if required */
              printf("%9.2f %9.2f %9.2f %9.2f %9.2f %9.2f %9.2f\n",
                  sec1price, sec2price, sec1size, sec2size,
                  sec2delta, cashvalue, poval[k] );
            #endif
    }
}

void test_gammascalp (void) {

    static long m, k, npts, ntsts;
    static float uval, sval, evx, aevx, fac;
    static float poval[100], tleft[100], vlty[100], sprice[100];
    
    /* repeat tests many times to obtain statistics */
    uval= 0.0;
    sval= 0.0;
    npts= 20;		/* no. data or rebalancing points */
    ntsts= 5000;	/* no. times to repeat tests */
    scanf("%f", &fac);	/* volatility multiplier for skew */
    for(m= 0; m< ntsts ; m++) {

        /* create end-of-day test data with random numbers */
        evx= 1.15;		/* effective daily volatility */
        aevx= sqrt(365.0) * evx / 100.0;
        for(k= 0; k< npts; k++) {
            if(k==0) sprice[k]=53.0;
            else sprice[k]= exp(log(sprice[k-1]) + 0.01*evx*misc_randgau());
            tleft[k]= npts - k;
            vlty[k]= fac * aevx;
        }

        /* run a gamma scalp on the generated test data */
        gammascalp(poval, tleft, sprice, vlty, npts);
        
        /* report the test results if desired */
        #if 1==0        
        fprintf(stdout, "test: %5d  price: %10.2f  value: %10.2f\n",
            (int)(m+1), (float)sprice[npts-1], (float)poval[npts-1]);
        #endif
        
        /* accumulate statistics over all tests */
        uval+= poval[npts-1];
        sval+= poval[npts-1] * poval[npts-1];    
    }
    
    /* finish and report statistics based on repeated tests */
    uval= uval / ntsts;				/* mean profit */
    sval= sqrt(sval / ntsts - uval * uval);	/* stdev profit */
    fprintf(stdout, "NTSTS: %5d   UVAL: %10.3f   SVAL: %10.3f\n",
        (int)ntsts, (float)uval, (float)sval);    
}

/*---------------------------------------------------------------------------
c  Looks at future behaviour of stocks with options having very high
c  levels of implied volatility and time value.
*/

void HighIVOptions (void) {

    PORTFOLIODATA *pff;
    ODBFILE *odb;
    ODBCHAIN oc;

    /* open stock and option databases */
    pff= pff_open( "../mktdata/dbases/nasdbig", 1, 0 );
    odb= odb_open( "../mktdata/dbases/master", 0 );


    /***** code to be added here *****/


    /* close stock and option databases */
    odb_close( odb );
    pff_close( pff );
}

/*---------------------------------------------------------------------------
c  Miscelaneous routines under development
*/

long nelapsed_secs (long ldt_start, long ltm_start, long ldt_stop,
    long ltm_stop) {
  
    /* Calculates the elapsed time in seconds from the starting
    .  date and time (ldt_start and ltm_start) to the stopping
    .  date and time (ldt_stop and ltm_stop).  Note that there
    .  86400 seconds in a 24-hour day.
    */
    
    long ndays, nhours, nminutes, nseconds, nelapsed;
    ndays= misc_datetoser(ldt_stop) - misc_datetoser(ldt_start);
    nhours= ((ltm_stop/10000) % 100) - ((ltm_start/10000) % 100);
    nminutes= ((ltm_stop/100) % 100) - ((ltm_start/100) % 100);
    nseconds= ((ltm_stop) % 100) - ((ltm_start) % 100);
    nelapsed= 86400*ndays + 3600*nhours + 60*nminutes + nseconds;
    return( nelapsed );
}

#define DEMO_LIBNN 1
#if DEMO_LIBNN == 1
/* demonstration and test of neural network functions */
#include "libnn.c"	/* neural network library */
void demo_libnn (void) {

    fprintf(stdout, "Test of NN\n");


}
#endif

/*---------------------------------------------------------------------------
c  Main program entry point.  We call desired routine(s) from here.
*/

int main (void) {
    /* HighIVOptions(); */
    /* test_gammascalp(); */
    demo_libnn();
    exit( EXIT_SUCCESS );
    return( 0 );
}


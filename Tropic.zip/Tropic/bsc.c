/*
c  bsc.c
c
c  Simple Black-Scholes Calculator.
c  Build with "gcc bsc.c -lm -o bsc" (no need to link libraries).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2006.  All rights reserved.
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libbspm.c"            /* Black-Scholes pricing library */

int main (void) {

	#if 1==0
	float rfi=0.05, vx, sp, sk, tl, op, theta;	
	printf("TIME LEFT: "); scanf("%f",&tl);
	while(-1) {
		printf("DLY VOLATILITY: "); scanf("%f",&vx);
		vx=sqrt(365.25)*vx/100.0;
		printf("STOCK PRICE: "); scanf("%f",&sp);
		for(sk=(int)(sp-5.5); sk<=(int)(sp+6.0); sk+=.5) {
			op=bscall(sp,sk,tl,rfi,vx);
			printf("STRIKE:%6.1f   CALL:%7.2f",
				(float)sk, (float)op);
			op=bsput(sp,sk,tl,rfi,vx);
			theta=op-bsput(sp,sk,tl-1.0,rfi,vx);
			printf("   PUT:%7.2f   THETA:%7.3f\n",
				(float)op, (float)theta);
		}
	}
	#endif
	
	#if 1==1
	BSPMQQ bsm, bs;
	float theta, cenp, shrs, range;
	while(-1) {
		printf("TIME LEFT: "); scanf("%lf",&bs.tl);
		printf("DLY VOLATILITY: "); scanf("%lf",&bs.vx);
		printf("STRIKE: "); scanf("%lf",&bs.sk);
		printf("SHARES: "); scanf("%f",&shrs);
		printf("STOCK PRICE: "); scanf("%f",&cenp);
		printf("RANGE (+ or -): "); scanf("%f",&range);
		bs.vx=sqrt(365.0)*bs.vx/100.0;
		bs.rfi=0.055;
		memcpy(&bsm, &bs, sizeof(BSPMQQ));
		bsm.sp= cenp;
		bscalc(&bsm);
		for(bs.sp=cenp-range; bs.sp<=cenp+range; bs.sp+=.1*range) {
			bscalc(&bs);
			theta=bsput(bs.sp,bs.sk,bs.tl-1.0,bs.rfi,bs.vx)-
				bs.vput;
			/* strike price */
			printf("SP:%8.2f ", (float)(bs.sp));
			/* theoretical B-S option price */
			printf("OP:%8.2f ", (float)(bs.vput));
			/* theoretical put Delta */
			printf("DL:%11.2f ", (float)(shrs*bs.dput));
			/* theoretical Theta */
			printf("TH:%11.2f ", (float)(shrs*theta));
			/* Gamma scalp price (stock + option value) */
			printf("STK+OPT:%11.2f", 
			    (float)(shrs*(  (bs.vput-bsm.vput) -
			    	bsm.dput*(bs.sp-cenp)  )) );
			printf("\n");			
		}
	}
	#endif
}


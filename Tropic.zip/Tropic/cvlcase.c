/*
c  cvlcase.c
c
c  Converts the names of all items specified on the command line to
c  lower case.  Wildcards may be used if the shell supports their
c  expansion.  Works on both Unix/Linux and on Windows/DOS.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2005. All Rights Reserved.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

void ftlerr (char msg[]) {
        /* Handles fatal errors */
        fprintf (stderr, "ERROR: %s\n", msg);
        exit (EXIT_FAILURE);
}

char* strlwrqq (char *str) {
        /* Converts strings to lower case */
        char *p;
        for (p = str; *p; p++) *p = tolower (*p);
        return str;
}

int main (int nargs, char **args) {

        static char fnew[256], *fold;
        static int i;

        printf("File count = %d\n", (int)(nargs-1));

        /* rename the files in lower case */
        for (i = 1; i < nargs; i++) {
                fold = args[i];
                strcpy (fnew, fold);
                strlwrqq (fnew);
                rename (fold, fnew);
                fprintf(stdout, "Renaming (%s) to (%s)\n",
                    (char*)fold, (char*)fnew);
                fflush(stdout); 
        }

        exit (EXIT_SUCCESS);
}



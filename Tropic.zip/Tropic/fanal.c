/*
c  fanal.c
c
c  Extracts principal components factors from end-of-day stock price data.
c  In other words, performs the first step (factor extraction) in the
c  factor analysis of correlations between stock price changes over time.
c  Factor analysis of stock returns enables factor-homogenous clusters of
c  stocks to be found.  It also helps locate stocks that are independent,
c  in the sense of being relatively uncorrelated with other stocks, when
c  putting together a diversified portfolio.  The factors produced by this
c  program may be rotated using any of the standard methods, e.g.,
c  Orthoblique.
c
c  Note:  Because the matrices are so large, the diagonal elements have
c  negligible impact on the results; consequently, we can safely use basic
c  Principal Components analysis, as if it were factor analysis,
c  without bothering about communality estimates.
c
c  To compile, use "gcc fanal.c -lm -o fanal" (or the equivalent for
c  your compiler.  There is no need to link in libraries; they are
c  brought in via #include statements.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2005.  All rights reserved.
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libpff.c"             /* stockmarket database component */
#include "libmisc.c"            /* miscellaneous functions */

/* forward references */
void eigenrsm (float r[], float a[], long n, long m);
void eigenrsg (float *r, float *e, float *v2, float *w, long n);

/*---------------------------------------------------------------------------
c  Main principal component factor extraction routine.  We use a Q-type
c  procedure to determine standard R-type factors.  This is done
c  since there are normally far fewer days in the sample than there
c  are stocks; by using the method employed below, we save on time and
c  storage requirements as well as benefit from improved numerical
c  stability.
*/

int main (int nargs, char **args) {

    PORTFOLIODATA *pff;
    long imkt,ibar, i,j,ij,k, nv,nc,nf;
    float *qr,*a,*g, d,*x,u,s;
    FILE *fp;

    /* open stockmarket database */
    pff=pff_open("../mktdata/dbases/nasdbig",1,0);
    fprintf(stdout,"NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);
    fflush(stdout);

    /* initialize parameters */
    nv=pff->nmkt;       /* number of variables (stocks) */
    nc=pff->nbar;       /* number of cases (bars) */
    nf=60;              /* number of factors */

    /* allocate arrays */
    qr=(float*)misc_malloc(sizeof(float)*((nc*nc+nc)/2)); 
    a=(float*)misc_malloc(sizeof(float)*nv*nf);
    g=(float*)misc_malloc(sizeof(float)*nc*nf);
    x=(float*)misc_malloc(sizeof(float)*nc);
    memset(qr,0,sizeof(float)*(nc*nc+nc)/2);	/* Q correlations */
    memset(a,0,sizeof(float)*nv*nf);		    /* factor loadings */
    memset(g,0,sizeof(float)*nc*nf);		    /* factor scores */
    memset(x,0,sizeof(float)*nc);		        /* scratch array */
    
    /* compute Q-type correlation array */
    for(imkt=0; imkt<pff->nmkt; imkt++) {
        /* read raw price data */
        if(imkt%10==0) {
                fprintf(stdout,"PROC1 IMKT=%d\r",(int)imkt);
                fflush(stdout);
        }
        pff_seekquotes(pff,imkt);
        /* compute price changes, means, and standard deviations */
        u=s=0.0;
        for(k=0, ibar=0; ibar<pff->nbar; ibar++, k++) {
            if(pff->opn[ibar]>0.0) x[k]=log(pff->cls[ibar]/pff->opn[ibar]);
                else x[k]=0.0;
            if(x[k]>0.2) x[k]=0.2;
                else if(x[k]< -0.2) x[k]= -0.2;
            u+=x[k];
            s+=x[k]*x[k];
        }
        if(k!=nc) misc_ftlerr("k!=nc");
        u=u/nc;
        s=sqrt(max(s/nc-u*u,0.0));
        /* normalize price changes */
        for(k=0; k<nc; k++) x[k]=((s>0.0)?((x[k]-u)/s):(0.0))/sqrt(nc);
        /* accumulate cross products */
        for(ij=i=0; i<nc; i++) for(j=0; j<=i; j++) qr[ij++]+=x[i]*x[j];
    }
    fprintf(stdout,"\n");
    fflush(stdout);

    /* compute factor scores (eigenvectors) from Q-type correlations */
    eigenrsm(qr,g,nc,nf);

    /* compute standard R-type factor loadings from factor scores */
    for(imkt=0, i=0; imkt<pff->nmkt; imkt++, i++) {
        /* read raw price data */
        if(imkt%10==0) {
                fprintf(stdout,"PROC2 IMKT=%d\r",(int)imkt);
                fflush(stdout);
        }
        pff_seekquotes(pff,imkt);
        /* compute price changes, means, and standard deviations */
        u=s=0.0;
        for(ibar=0, k=0; ibar<pff->nbar; ibar++, k++) {
            if(pff->opn[ibar]>0.0) x[k]=log(pff->cls[ibar]/pff->opn[ibar]);
                else x[k]=0.0;
            if(x[k]>0.2) x[k]=0.2;
                else if(x[k]< -0.2) x[k]= -0.2;
            u+=x[k];
            s+=x[k]*x[k];
        }
        if(k!=nc) misc_ftlerr("k!=nc");
        u=u/nc;
        s=sqrt(max(s/nc-u*u,0.0));
        /* normalize price changes */
        for(k=0; k<nc; k++) x[k]=((s>0.0)?((x[k]-u)/s):(0.0))/sqrt(nc);
        /* compute factor loadings */
        for(k=0; k<nf; k++) {
            for(d=0.0, j=0; j<nc; j++) d+=g[j+nc*k]*x[j];
            a[i+nv*k]=d;
        }
    }
    fprintf(stdout,"\n");
    fflush(stdout);

    /* write statistics and verifications */
    fp=fopen("fxvue.dat","wt");
    fprintf(fp,"NF=%5d  NV=%5d  NC=%5d\n",(int)nf,(int)nv,(int)nc);
    for(u=s=0.0, k=0; k<nf; k++) {
        for(d=0.0, i=0; i<nv; i++) d+=a[i+nv*k]*a[i+nv*k];
        u+=d;
        fprintf(fp,"K=%5d  VCALC=%10.3f  VREP=%10.3f  CUM=%10.3f"
                   "  DIFF=%10.3f\n",
                (int)k, (float)qr[k+(k*k+k)/2], (float)d,
                (float)u, (float)(s-d) );
        s=d;
    }
    fclose(fp);

    /* write unrotated factor matrix */
    fp=fopen("fxufm.dat","wt");
    fprintf(fp,"GENERAL MATRIX\n%6d%6d\n",(int)nv,(int)nf);
    for(i=0; i<nv*nf; i++) {
        fprintf(fp,"%10.6f",(float)a[i]);
        if((i+1)%6==0) fprintf(fp,"\n");
    }
    fprintf(fp,"\n");
    fclose(fp);

    /* write variable descriptor list with communalities and some factors */
    fp=fopen("fxdes.dat","wt");
    for(i=0; i<nv; i++) {
        pff_seeksymbol(pff,i);
        for(d=0.0, k=0; k<nf; k++) d+=a[i+nv*k]*a[i+nv*k];
        fprintf(fp, "%6s %5.2f %6.2f%6.2f%6.2f %s\n",
            (char*)pff->symbol, (float)d,
            (float)a[i+nv*0], (float)a[i+nv*1],
            (float)a[i+nv*2], (char*)pff->name );
    }
    fclose(fp);

    /* close stock database and free memory */
    pff_close(pff);
    free(x);
    free(qr);
    free(g);
    free(a);
    exit(EXIT_SUCCESS);
    return(0);
}

/*---------------------------------------------------------------------------
c  Eigenvectors and eigenvalues of a real symetric matrix.
*/

void eigenrsm (float r[], float a[], long n, long m) {

    /* Determines the m largest eigenvalues and corresponding
    .  eigenvectors of a real symetric matrix of order n.
    .  Arguments:
    .    r   - Symetric matrix of order n whose eigenvectors and
    .            eigenvalues are to be found (input).  It is
    .            returned with the eigenvalues in the diagonal.
    .    a   - Matrix of dimension n by m containing, as columns,
    .            the eigenvectors of r in descending order of
    .            associated eigenvalue (output).
    .    n   - Order of symetric matrix (input).
    .    m   - Number of eigenvector-eigenvalue pairs desired (input).
    .  Notes: Designed for symetric, positive definite matrices only.
    .  Subroutines called: eigenrsg
    */

    float *e,*w,*v;  long i,j,k, ij;

    e=(float*)misc_malloc(sizeof(float)*n);
    w=(float*)misc_malloc(sizeof(float)*n);
    v=(float*)misc_malloc(sizeof(float)*m);

    for(k=0; k<m; k++) {
        eigenrsg(r,e,&v[k],w,n);
        for(i=0;i<n;i++) a[i+n*k]=e[i];
        for(ij=i=0;i<n;i++) for(j=0;j<=i;j++) r[ij++] -= e[i]*e[j]*v[k];
    }
    for(k=0;k<m;k++) r[k+(k*k+k)/2]=v[k];

    free(v);
    free(w);
    free(e);
}

void eigenrsg (float *r, float *e, float *v2, float *w, long n) {

    /* Determines the largest eigenvalue and corresponding eigenvector
    .  of a real symetric matrix using an accelerated iterative
    .  method developed in 1981 by Jeffrey Owen Katz, Ph.D.  Adapted
    .  from the original Fortran code.
    .  Arguments:
    .    r   -  Matrix of order n whose largest eigenvalue and
    .             corresponding eigenvector are to be
    .             found (input, symetric storage layout).
    .		  It is returned unaltered.
    .    e   -  Eigenvector of length n (output).
    .    v2  -  Eigenvalue (output, via pointer).
    .    w   -  Work vector of length n (scratch).
    .    n   -  Order of matrix to be analyzed (input).
    .  Notes:
    .    Console display of convergence data is controlled by
    .      define statements appearing in the code.
    .    Arrays passed to this routine are assumed zero-based.
    .    Largest eigenvalue is assumed to be positive.
    .  Subroutines called: None.
    */

    long i, j, ij, jj, iter;
    float emax, ak, vx, v1, sum, d1, d2;

    /* adjust pointers so unit based array indices may be used */
    /* inside this function */
    r = r - 1;
    e = e - 1;
    w = w - 1;

    /* calculate sums-of-squares for each column of r[] */
    jj = 1;
    for (j = 1; j <= n; j++) {
        sum = 0.0;
        ij = jj;
        for (i = 1; i <= n; i++) {
            sum += r[ij] * r[ij];
            if (i < j) ij += 1;
            else ij += i;
        }
        e[j] = sum;
        jj = jj + j;
    }

    /* find column of r[] with largest sum-of-squares */
    emax = -1.0;
    for (i = 1; i <= n; i++) {
        if (e[i] > emax) {
            emax = e[i];
            j = i;
        }
    }

    /* copy that column of r[] to vector e[] */
    for (i = 1; i <= n; i++) {
        if (i < j) ij = i + (j * j - j) / 2;
        else ij = j + (i * i - i) / 2;
        e[i] = r[ij];
    }

    /* begin iteration loop */
    iter = 0;
LOOP20: iter += 1;

        /* normalize vector e[] */
        vx = 0.0;
        for (i = 1; i <= n; i++)  vx += e[i] * e[i];
        vx = sqrt (vx);
        for (i = 1; i <= n; i++)  e[i] /= vx;

        /* calculate w[] = r[] * e[] as matrices */
        jj = 1;
        for (j = 1; j <= n; j++) {
            sum = 0.0;
            ij = jj;
            for (i = 1; i <= n; i++) {
                sum += r[ij] * e[i];
                if (i < j) ij += 1;
                else ij += i;
            }
            w[j] = sum;
            jj += j;
        }

        /* normalize vector w[] */
        v1 = 0.0;
        for (i = 1; i <= n; i++)  v1 += w[i] * w[i];
        v1 = sqrt (v1);
        for (i = 1; i <= n; i++)  w[i] /= v1;

        /* determine distance between vectors e[] and w[] */
        d1 = 0.0;
        for (i = 1; i <= n; i++)
            d1 += (w[i] - e[i]) * (w[i] - e[i]);
        d1 = sqrt (d1);

        /* calculate e[] = r[] * w[] as matrices */
        jj = 1;
        for (j = 1; j <= n; j++) {
            sum = 0.0;
            ij = jj;
            for (i = 1; i <= n; i++) {
                sum += r[ij] * w[i];
                if (i < j) ij += 1;
                else ij += i;
            }
            e[j] = sum;
            jj += j;
        }

        /* normalize vector e[] */
        *v2 = 0.0;
        for (i = 1; i <= n; i++)  *v2 += e[i] * e[i];
        *v2 = sqrt (*v2);
        for (i = 1; i <= n; i++)  e[i] /= (*v2);

        /* determine distance between vectors e[] and w[] */
        d2 = 0.0;
        for (i = 1; i <= n; i++)
            d2 += (w[i] - e[i]) * (w[i] - e[i]);
        d2 = sqrt (d2);

        /* compute correction (relaxation) coefficient */
        ak = (d2 * d2) / max (d1 - d2, 5.0 * d2 * d2);

        /* print iteration results to screen */
        #ifdef SHOWITERATIONS
            if ((iter % 20) == 1)
                fprintf (stdout, "%5s %11s %11s %11s %11s\n",
                        "iter", "v2", "v1", "d2", "ak");
            fprintf (stdout, "%5d %11.5f %11.5f %11.5f %11.5f\n",
                     iter, *v2, v1, d2, ak);
            fflush(stdout);
        #endif

        /* perform correction and check for convergence */
        if (d2 > 0.5E-5 && iter < 250) {
            ak = 0.75 * ak / d2;
            for (i = 1; i <= n; i++)
                e[i] += ak * (e[i] - w[i]);
            goto LOOP20;  /* not converged, do another iteration */
        }

    /* print final result to screen */
    #define SHOWFINAL
    #ifdef SHOWFINAL
        fprintf(stdout, "Iter=%5ld  V2=%10.2f  D2=%12.5f\n",
            (long)iter, (float)(*v2), (float)d2);
        fflush(stdout);
    #endif
}


/*
c  jkfix.c
c
c  Revised 2006.12.13
c
c  Removes stray spaces, unwanted line terminators, and ^Z characters 
c  from text files.  Can also replace spaces with tabs.	 Used to make 
c  files edited with Windows and DOS editors UNIX-compatible when run 
c  under BSD or Linux.	Multiple files may be specified on the command 
c  line and wildcards are supported automatically under most shells.
c
c  Copyright (C) 2004.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------
c  Helper functions.
*/

char* strip (char *buf) {
	/* strips newline, carriage return, and CTRL-Z characters */
	char *p;
	for(p=buf; *p; p++) {
		if(*p==(char)13 || *p==(char)10 || *p==(char)26)
			*p=(char)0;
	}
	return(buf);
}

void ftlerr (char *msg) {
	/* handles fatal errors */
	fprintf(stderr, "\nERROR: %s\n", msg);
	exit(EXIT_FAILURE);
}

/*---------------------------------------------------------------------------
c  Main entry function.
*/

int main (int nargs, char **args) {

	FILE *fpin, *fpout;
	char buf[2048], cmd[2048];
	int j, iusetabs;       

	/* verify and parse command arguments */
	iusetabs=0;
	if(nargs<2 || strcmp(args[1],"--help")==0) {
		fprintf(stdout, "Usage:\n  jkfix [-t] file[s]\n"
			"Where:\n  -t	 = use tabs\n");
		fflush(stdout);
		exit(EXIT_FAILURE);
	}
	if(strcmp(args[1],"-t")==0) {
		if(nargs<3) ftlerr("No files specified");
		iusetabs=1;
	}
		
	/* for each file ... */
	for(j=1; j<nargs; j++) {
	
		/* do not process switches as files */
		if(args[j][0]=='-') continue;
	
		/* display progress */
		fprintf(stdout, "FIXING: %s\n", (char*)args[j]);
		
		/* re-write file with Unix-style line terminators */
		if((fpin=fopen(args[j],"rt"))== NULL) 
			ftlerr("Input file not found");
		fpout=fopen("a724736.tmp","wt");
		while(fgets(buf, sizeof(buf), fpin)) {
			strip(buf);
			fprintf(fpout, "%s\n", (char*)buf);
		}
		fclose(fpin);
		fclose(fpout);
		
		/* finish up */
		sprintf(cmd, "rm %s\n", (char*)args[j]);
		system(cmd);
		if(iusetabs==0)
		    sprintf(cmd, "mv a724736.tmp %s\n", (char*)args[j]);
		else
		    sprintf(cmd, "expand a724736.tmp | unexpand -a > %s;"
			"rm a724736.tmp\n", (char*)args[j]);
		system(cmd);
	}

	/* done */
	exit(EXIT_SUCCESS);
	return(0);
}


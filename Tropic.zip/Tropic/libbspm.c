/*
c  libbspm.c
c
c  Revised 2007.07.02
c
c  Module contains routines for calculating Black-Scholes theoretical
c  price for calls and puts, for determining implied volatility for
c  calls, puts and straddles, for reading interest rates from a
c  FRED-format "wgs3mo.txt" file, and for estimating historical
c  volatility.  This module is self-contained; the only external
c  routines called are those provided by the standard C library.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2007.  All rights reserved.
*/

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "libbspm.h"

#define BSTINY	1.E-5		/* used to avoid divide-by-zero */

/*-------------------------------------------------------------------------*/

double bscall (double sp, double sk, double tl, double r, double vx) {
    /* Returns Black-Scholes theoretical call price.
    .  Arguments:
    .    sp   - stock price
    .    sk   - option strike price
    .    tl   - time left in calendar days
    .    r    - risk free interest (5% annual is 0.05)
    .    vx   - volatility (50% annual is 0.50)
    .  Functions called: bscnrmp
    */
    double d1, d3;
    d3 = (vx = vx + BSTINY) * sqrt(tl = 0.00273785079 * (tl + BSTINY));
    d1 = (log(sp / sk) + tl * (r + 0.5 * vx * vx)) / d3;
    return bscnrmp(d1) * sp - exp(-tl * r) * sk * bscnrmp(d1 - d3);
}

double bsput (double sp, double sk, double tl, double r, double vx) {
    /* Returns Black-Scholes theoretical put price.
    .  Arguments:
    .    sp   - stock price
    .    sk   - option strike price
    .    tl   - time left in calendar days
    .    r    - risk free interest (5% annual is 0.05)
    .    vx   - volatility (50% annual is 0.50)
    .  Functions called: bscnrmp
    */
    double d1, d3;
    d3 = (vx = vx + BSTINY) * sqrt(tl = 0.00273785079 * (tl + BSTINY));    
    d1 = (log(sp / sk) + tl * (r + 0.5 * vx * vx)) / d3;
    return (bscnrmp(d1) - 1.0) * sp + exp(-r * tl) * sk * bscnrmp(d3 - d1);
}

double bsciv (double op, double sp, double sk, double tl, double r) {
    /* Returns Black-Scholes implied call volatility.
    .  Arguments:
    .    op   - call option price
    .    sp   - stock price
    .    sk   - option strike price
    .    tl   - time left in calendar days
    .    r    - risk free interest (5% annual is 0.05)
    .  Functions called: bscall, bscnrmp
    */
    double vxh, vxl, vx;
    vxl = 1.E-3;
    vxh = 15.0;
    while (vxh - vxl > 1.E-5) {
        if (bscall(sp, sk, tl, r, vx = 0.5 * (vxh + vxl)) >= op) vxh = vx;
        else vxl = vx;
    }
    return 0.5 * (vxl + vxh);
}

double bspiv (double op, double sp, double sk, double tl, double r) {
    /* Returns Black-Scholes implied put volatility.
    .  Arguments:
    .    op   - put option price
    .    sp   - stock price
    .    sk   - option strike price
    .    tl   - time left in calendar days
    .    r    - risk free interest (5% annual is 0.05)
    .  Functions called: bsput, bscnrmp
    */
    double vxh, vxl, vx;
    vxl = 1.E-3;
    vxh = 15.0;
    while (vxh - vxl > 1.E-5) {
        if (bsput(sp, sk, tl, r, vx = 0.5 * (vxh + vxl)) >= op) vxh = vx;
        else vxl = vx;
    }
    return 0.5 * (vxl + vxh);
}

double bssriv (double op, double sp, double sk, double tl, double r) {
    /* Returns Black-Scholes implied volatility for a straddle.
    .  Arguments:
    .    op   - straddle price
    .    sp   - stock price
    .    sk   - straddle strike price
    .    tl   - time left in calendar days
    .    r    - risk free interest (5% annual is 0.05)
    .  Functions called: bsput, bscall, bscnrmp
    */
    double vxh, vxl, vx;
    vxl = 1.E-3;
    vxh = 15.0;
    while (vxh - vxl > 1.E-5) {
        vx = 0.5 * (vxh + vxl);
        if (bsput(sp,sk,tl,r,vx) + bscall(sp,sk,tl,r,vx) >= op) vxh = vx;
        else vxl = vx;
    }
    return 0.5 * (vxl + vxh);
}

double bscnrmp (double x) {
    /* Calculates cumulative normal probability of x */
    #if 1==1
        /* original method with roughly 7 significant digits */
        double xv, zx, t, p;
        xv = fabs (x);
        zx = 0.39894228 * exp (-0.5 * xv * xv);
        t = 1.0 / (1.0 + 0.2316419 * xv);
        p = 1.0 - zx * (t * (0.319381530 + t * (-0.356563782 + t *
              (1.781477937 + t * (-1.821255978 + t * 1.330274429)))));
        if (x <= 0.0) p = 1.0 - p;
        return p;
    #else
        /* algorithm AS66 with more than 12 significant digits */
        return bsalnorm (x, 0);
    #endif
}

void bscalc (BSPMQQ *bs) {
    /* Calculates Black-Scholes option prices using the standard formulas
    .  presented in Options as a Strategic Investment (McMillan) for calls,
    .  and Black-Scholes and Beyond (Chriss) for puts.  The only
    .  differences between this function and bsput() and bscall() above
    .  are that both calls and puts are analyzed within one routine and
    .  that arguments are passed and returned via a structure as follows:
    .     bs->sp     - stock price (input)
    .     bs->sk     - option strike price (input)
    .     bs->tl     - time left in calendar days (input)
    .     bs->rfi    - risk free interest rate (input)
    .     bs->vx     - annualized volatility (input)
    .     bs->vcall  - theoretical call price (output)
    .     vs->vput   - theoretical put price (output)
    .     bs->dcall  - theoretical call delta (output)
    .     bs->dput   - theoretical put delta (output)
    .  Functions called: bscnrmp
    */
    double vly, tly, d1, d3, d4, d5;
    d3 = (vly = bs->vx + BSTINY) * sqrt (tly = (bs->tl + BSTINY) / 365.25);
    d1 = (log (bs->sp / bs->sk) + tly * (bs->rfi + 0.5 * vly * vly)) / d3;
    bs->dput = (bs->dcall = bscnrmp (d1)) - 1.0;
    d4 = bscnrmp (d1 - d3);
    d5 = exp (-tly * bs->rfi);
    bs->vcall = bs->sp * bs->dcall - bs->sk * d5 * d4;
    bs->vput = bs->dput * bs->sp + d5 * bs->sk * (1.0 - d4);
}

void bsrdrfi (char fn[], long nbar, long ldt[], float rfi[]) {
    /* Reads interest rates from federal reserve (FRED) data files such
    .  as file wgs3mo.txt.  Synchronizes this data to dates in array
    .  ldt[0..nbar-1] so that rates in rfi[0..nbar-1] will be aligned with
    .  stock prices.  Fills in empty data points with nearest previous
    .  values so that all data points in array rfi[0..nbar-1] will be
    .  non-zero.  Dates in ldt[0..nbar-1] are assumed to be in YYYYMMDD
    .  form (e.g., 20020522 is 2002.05.22) and in ascending order
    .  (ldt[k+1] >= ldt[k]).  Interest rates are returned in decimal
    .  form (e.g., 0.125 represents an annual rate of 12.5 percent)
    .  in rfi[0..nbar-1].
    */
    FILE *fp; char *buf; long k,iyyyy,imm,idd,n,nbuf; float rate;
    buf=(char*)bsbmalloc(sizeof(char)*(nbuf=128));
    for(k=0; k<nbar; k++) rfi[k]=0.0;
    if((fp=fopen(fn,"rt"))==NULL)
        bsftlerr("bsrdrfi: interest rate file not found");
    for(k=0; k<20; k++) fgets(buf,nbuf,fp);  /* skip header lines */
    while(fgets(buf,nbuf,fp)) {
        if(sscanf(buf,"%ld-%ld-%ld %f",&iyyyy,&imm,&idd,&rate)!=4) continue;
        if(iyyyy<1950 || iyyyy>2025 || idd<1 || idd>31 || imm<1 ||
            imm>12 || rate<0.3 || rate>25.0)
                bsftlerr("bsrdrfi: interest rate data problem");
        if((n=10000*iyyyy+100*imm+idd)<ldt[0] || n>ldt[nbar-1]) continue;
        if((k=bsfindlong(ldt,nbar,n))>=0 && k<nbar) rfi[k]=0.01*rate;
    }
    fclose(fp);
    free(buf);
    for(n=0, k=1; k<nbar; k++) {
        if(rfi[k]<1.E-5) rfi[k]=rfi[k-1];
        else n++;
    }
    for(k=nbar-2; k>=0; k--) if(rfi[k]<1.E-5) rfi[k]=rfi[k+1];
    k=12*(ldt[nbar-1]/10000-ldt[0]/10000) + (((ldt[nbar-1]/100)%100) -
            ((ldt[0]/100)%100));  /* total months of data */
    #if 1==1
        fprintf(stdout,"BSRDRFI: LASTRFI=%.4f NRFI=%d NMON=%d NBAR=%d\n",
            (float)rfi[nbar-1], (int)n, (int)k, (int)nbar );
    #endif            
    if(n < k/5) bsftlerr("bsrdrfi: interest rate data insufficiency");    
}

long bsfindlong (long iarr[], long n, long ival) {
    /* Finds k such that iarr[k] <= ival < iarr[k+1], if this is
    .  possible.  Assumes that iarr[0..n-1] is sorted in
    .  ascending order.  Returns k with 0 <= k < n.  In the case
    .  of ties, returned index k points to the last tied element.
    */
    long ia,ib,k;
    if(ival<iarr[ia=0]) return(ia);
    if(ival>=iarr[ib=n-1]) return(ib);
    while(ib-ia>1) {
        if(iarr[k=(ia+ib)>>1]>ival) ib=k;
        else ia=k;
    }
    if(ival==iarr[ib]) return(ib);
    return(ia);
}

void bsvltyser (float hi[], float lo[], float cls[], long nb,
float ser[], long per, long mode) {
    /* Returns a series of annualized historical volatilities as
    .  estimated using the model specified by mode.  Assumes
    .  daily bars as seen with standard end-of-day data.
    .  Arguments:
    .    hi, lo, cls - price series [0..nb-1]
    .    nb          - number of bars in price series
    .    ser         - returned historical volatilities [0..nb-1]
    .    per         - averaging period to use
    .    mode        - method for computing historical volatility
    .                    1 - standard unbiased close-to-close
    .                    2 - exponential close-to-close
    .                    3 - standard average range
    .                    4 - exponential average range
    .                    5 - standard Parkinson's
    .                    6 - exponential Parkinson's
    .  Functions called: bsftlerr
    */
    float ux,sx,t,tb,vx,cp,acoeff;
    long i;
    #define daysperyear (365.25)
    #define barsperyear (252.0)
    switch(mode) {
      case 1:
        /* standard unbiased close-to-close volatility */
        acoeff=sqrt(barsperyear/(per*(per-1.0)));
        for(i=1, ux=sx=0.0; i<=per; i++) {
            t=log(cls[i]/cls[i-1]);
            ux+=t; sx+=t*t;
        }
        for(i=per+1; i<nb; i++) {
            t=log(cls[i]/cls[i-1]);
            tb=log(cls[i-per]/cls[i-per-1]);
            ux+=(t-tb); sx+=(t*t-tb*tb);
            vx=per*sx-ux*ux;
            ser[i]=(vx>0.0)?(acoeff*sqrt(vx)):(0.0);
        }
        for(i=0; i<=per; i++) ser[i]=ser[per+1];
        break;
      case 2:
        /* exponential close-to-close volatility */
        acoeff=sqrt(barsperyear);
        cp=2.0/(1.0+per);
        for(i=1, ux=sx=0.0; i<nb; i++) {
            t=log(cls[i]/cls[i-1]);
            ux+=cp*(1.0-ux);
            sx+=cp*(t*t-sx);
            ser[i]=acoeff*sqrt(sx/ux);
        }
        ser[0]=ser[1];
        break;
      case 3:
        /* standard average range volatility (robust Parkinson's) */
        acoeff=0.627*sqrt(daysperyear)/per;
        for(i=1, ux=0.0; i<=per; i++)
            ux+=log(hi[i]/lo[i]);
        for(i=per+1; i<nb; i++) {
            ux+=(log(hi[i]/lo[i])-log(hi[i-per]/lo[i-per]));
            ser[i]=acoeff*ux;
        }
        for(i=0; i<=per; i++) ser[i]=ser[per+1];
        break;
      case 4:
        /* exponential average range volatility */
        acoeff=0.627*sqrt(daysperyear);
        cp=2.0/(1.0+per);
        for(i=0, ux=sx=0.0; i<nb; i++) {
            t=log(hi[i]/lo[i]);
            ux+=cp*(1.0-ux);
            sx+=cp*(t-sx);
            ser[i]=acoeff*sx/ux;
        }
        break;
      case 5:
        /* standard Parkinson's volatility */
        acoeff=sqrt(daysperyear/(4.0*per*log(2.0)));
        for(i=1, ux=0.0; i<=per; i++) {
            t=log(hi[i]/lo[i]);
            ux+=t*t;
        }
        for(i=per+1; i<nb; i++) {
            tb=log(hi[i-per]/lo[i-per]);
            t=log(hi[i]/lo[i]);
            ux+=(t*t-tb*tb);
            ser[i]=acoeff*sqrt(ux);
        }
        for(i=0; i<=per; i++) ser[i]=ser[per+1];
        break;
      case 6:
        /* exponential Parkinson's volatility */
        acoeff=sqrt(daysperyear/(4.0*log(2.0)));
        cp=2.0/(1.0+per);
        for(i=0, ux=sx=0.0; i<nb; i++) {
            t=log(hi[i]/lo[i]);
            ux+=cp*(1.0-ux);
            sx+=cp*(t*t-sx);
            ser[i]=acoeff*sqrt(sx/ux);
        }
        break;
      default:
        bsftlerr("bsvltyser: invalid mode");
    }
    #undef barsperyear
    #undef daysperyear
}

float bsvltybar (float hi[], float lo[], float cls[], long cb,
long per, long mode) {
    /* Returns the annualized historical volatility at a given bar
    .  as estimated using the model specified by mode.  Assumes
    .  daily bars as seen with standard end-of-day data.
    .  Arguments:
    .    hi     - array [0..cb..] of high prices
    .    lo     - array [0..cb..] of low prices
    .    cls    - array [0..cb..] of closing prices
    .    cb     - current or reference bar
    .    per    - period for volatility calculation
    .    mode   - method used to estimate historical volatility
    .               1 - standard close-to-close
    .               2 - exponential close-to-close
    .               3 - standard average range
    .               4 - exponential average range
    .               5 - standard Parkinson's
    .               6 - exponential Parkinson's
    .    return - annualized historical volatility
    .  Functions called: bsftlerr
    */
    float ans,ux,sx,cp,an,t;
    long i,k;
    ans= 0.0;
    #define daysperyear (365.25)
    #define barsperyear (252.0)
    switch(mode) {
      case 1:
        /* standard unbiased close-to-close volatility */
        for(i=k=max(1,cb-per+1), ux=sx=0.0; i<=cb; i++) {
            t=log(cls[i]/cls[i-1]);
            ux+=t; sx+=t*t;
        }
        an=cb-k+1; ux=ux/an; sx=sx/an-ux*ux;
        ans=(sx>0.0)?(sqrt(barsperyear*an*sx/(an-1.0))):(0.0);
        break;
      case 2:
        /* exponential close-to-close volatility */
        cp=2.0/(1.0+per);
        for(i=max(1,cb-4*per), sx=an=0.0; i<=cb; i++) {
            t=log(cls[i]/cls[i-1]);
            sx+=cp*(t*t-sx); an+=cp*(1.0-an);
        }
        ans=sqrt(barsperyear*sx/an);
        break;
      case 3:
        /* standard average range volatility (robust Parkinson's) */
        for(sx=0.0, i=k=max(0,cb-per+1); i<=cb; i++)
            sx+=log(hi[i]/lo[i]);
        ans=sqrt(daysperyear)*0.627*sx/(cb-k+1);
        break;
      case 4:
        /* exponential average range volatility */
        cp=2.0/(1.0+per);
        for(an=sx=0.0, i=max(0,cb-3*per); i<=cb; i++) {
            sx+=cp*(log(hi[i]/lo[i])-sx);
            an+=cp*(1.0-an);
        }
        ans=sqrt(daysperyear)*0.627*sx/an;
        break;
      case 5:
        /* standard Parkinson's with filter for zero-range days */
        for(k=0, sx=an=0.0, i=max(0,cb-per+1); i<=cb; i++) {
            if(hi[i]<=lo[i]) continue;
            t=log(hi[i]/lo[i]);
            sx+=t*t; an+=1.0;
        }
        if(2*an>per) ans=sqrt(daysperyear*sx/(4.0*an*log(2.0)));
        else ans=0.0;
        break;
      case 6:
        /* exponential Parkinson's volatility */
        cp=2.0/(1.0+per);
        for(an=sx=0.0, i=max(0,cb-3*per); i<=cb; i++) {
            t=log(hi[i]/lo[i]);
            sx+=cp*(t*t-sx);
            an+=cp*(1.0-an);
        }
        ans=sqrt(daysperyear*sx/(4.0*an*log(2.0)));
        break;
      default:
        bsftlerr("bsvltybar: invalid mode");
    }
    return(ans);
    #undef daysperyear
    #undef barsperyear
}

void* bsbmalloc (size_t n) {
    /* Safely allocates memory */
    void *ptr;
    if((ptr=(void*)malloc(n))==NULL)
        bsftlerr("bsbmalloc: out of memory");
    return(ptr);
}

void bsftlerr (char msg[]) {
    /* Handles fatal errors */
    fprintf(stderr,"\nERROR: %s\n",(char*)msg);
    exit(EXIT_FAILURE);
}

/*---------------------------------------------------------------------------
c  Debugging and test code.
*/

#if 1==0
    /* debugging and testing code for option pricing models */
    /* booka.c contains code for testing volatility calculations */
    int main (void) {
        static BSPMQQ bs;
        double sp, sk, tl, r, vx, pp, cp, pvx, cvx, dlp, dlc;
        /* bs.sp=sp=52.0; bs.sk=sk=50.0; bs.tl=tl=11.0;
           bs.rfi=r=0.03; bs.vx=vx=0.82; */
        bs.sp=sp=26.0; bs.sk=sk=27.5; bs.tl=tl=8.0;
        bs.rfi=r=0.04; bs.vx=vx=0.585;
        cp=bscall(sp, sk, tl, r, vx);
        dlc=5.0*(bscall(sp+.1,sk,tl,r,vx)-bscall(sp-.1,sk,tl,r,vx));
        pp=bsput(sp, sk, tl, r, vx);
        dlp=5.0*(bsput(sp+.1,sk,tl,r,vx)-bsput(sp-.1,sk,tl,r,vx));
        printf("CALCULATED WITH BSPUT AND BSCALL\n");
        printf("Call price = %.6f\nPut price = %.6f\n",(float)cp,(float)pp);
        printf("Call delta = %.6f\nPut delta = %.6f\n",(float)dlc,(float)dlp);
        bscalc(&bs);
        printf("CALCULATED WITH BSCALC\n");
        printf("Call price = %.6f\nPut price = %.6f\n",
            (float)bs.vcall,(float)bs.vput);
        printf("Call delta = %.6f\nPut delta = %.6f\n",
            (float)bs.dcall,(float)bs.dput);
        printf("CALCULATED WITH BSCIV AND BSPIV\n");
        pvx=bspiv(pp, sp, sk, tl, r);
        cvx=bsciv(cp, sp, sk, tl, r);
        printf("Call ivx = %.6f\nPut ivx = %.6f\n",(float)cvx,(float)pvx);
        printf("STRADDLE PRICE AND IMPLIED VOLATILITY\n");
        sp=50.0; sk=50.0; tl=10; r=0.05;
        for(pp=0.0; pp<=15.0; pp+=0.5) {
            pvx=bssriv(pp, sp, sk, tl, r);
            printf("%14.3f %14.3f\n",(float)pp,(float)pvx); }
        printf("Enter VX and SP\n");
        while(-1) {
            scanf("%lf %lf",&vx,&sp);  if(vx<0.0 || sp<0.0) break;
            printf("%lf\n",(double)bscall(sp,25.0,12.0,0.0,vx)); }
        return(EXIT_SUCCESS);
    }
#endif

/*-------------------------------------------------------------------------*/

/* Algorithm AS 66
 * The Normal Integral, by I. D. Hill, 1973.
 * Applied Statistics 22(3):424-427.
 *
 * Translation to C by James Darrell McCauley, mccauley@ecn.purdue.edu.
 *
 * Calculates the upper or lower tail area of the standardized normal
 * curve corresponding to any given argument.
 *
 * x - the argument value
 * upper:  1 -> the area from x to \infty
 *         0 -> the area from -\infty to x
 *
 * Notes:
 * The constant LTONE should be set to the value at which the
 * lower tail area becomes 1.0 to the accuracy of the machine.
 * LTONE=(n+9)/3 gives the required value accurately enough, for a
 * machine that produces n decimal digits in its real numbers.
 *
 * The constant UTZERO should be set to the value at which the upper
 * tail area becomes 0.0 to the accuracy of the machine. This may be
 * taken as the value such that exp(-0.5 * UTZERO * UTZERO) /
 * (UTZERO * sqrt(2*M_PI)) is just greater than the smallest allowable
 * real numbers.
 *
 * JK: Seems to be accurate to about 11 or 12 significant digits, and
 * performs even better for extreme values of x.  This routine may
 * replace the one currently used in libbspm.c for calculating option
 * prices and implied volatilities if greater accuracy is desired.
*/

#define LTONE 8.0
#define UTZERO 18.66

double bsalnorm (double x, long upper)  {
   double ret, z, y;
   long up;

   up = upper;
   z = x;
   if (x < 0.0) {
     up = up == 0 ? 1 : 0;
     z = -x;
   }

   if (!(z <= LTONE || (up == 1 && z <= UTZERO)))
     ret = 0.0;
   else {
     y = 0.5 * z * z;
     if (z <= 1.28)
       ret = 0.5 - z * (0.398942280444 - 0.399903438504 * y /
                        (y + 5.75885480458 - 29.8213557808 /
                         (y + 2.62433121679 + 48.6959930692 /
                          (y + 5.92885724438))));
     else
       ret = 0.398942280385 * exp (-y) /
         (z - 3.8052e-8 + 1.00000615302 /
          (z + 3.98064794e-4 + 1.98615381364 /
           (z - 0.151679116635 + 5.29330324926 /
            (z + 4.8385912808 - 15.1508972451 /
             (z + 0.742380924027 + 30.789933034 /
              (z + 3.99019417011))))));
   }

   if (up == 0)
     ret = 1.0 - ret;
   return ret;
}

#undef LTONE
#undef LTZERO

#if 1==0
    /* debugging and test code for bsalnorm() */
    #include <stdio.h>
    int main (void) {
        double x;
        while(-1) {
            scanf("%lf",&x);
            if(x< -99) break;
            printf("P = %20.16lf %20.16lf %20.16f\n",
                (double)(bscnrmp(x)), (double)(bsalnorm(x,0)),
                (double)(bscnrmp(x)-bsalnorm(x,0)));
        }
        return(EXIT_SUCCESS);
    }
#endif


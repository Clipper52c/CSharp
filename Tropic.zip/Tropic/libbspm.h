#ifndef LIBBSPM_H
#define LIBBSPM_H

/*
c  libbspm.h
c
c  Header file for libbspm.c (Black-Scholes, interest rates, volatility).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2007.  All rights reserved.
*/

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double  sp;         /* stock price */
    double  sk;         /* strike price */
    double  tl;         /* time left */
    double  rfi;        /* risk-free interest */
    double  vx;         /* volatility */
    double  vcall;      /* theoretical call price */
    double  vput;       /* theoretical put price */
    double  dcall;      /* theoretical call delta */
    double  dput;       /* theoretical put delta */
} BSPMQQ;

double  bscall (double sp, double sk, double tl, double r, double vx);
double  bsput (double sp, double sk, double tl, double r, double vx);
double  bsciv (double op, double sp, double sk, double tl, double r);
double  bspiv (double op, double sp, double sk, double tl, double r);
double  bssriv (double op, double sp, double sk, double tl, double r);
double  bscnrmp (double x);
double  bsalnorm (double x, long upper);
void    bscalc (BSPMQQ *bs);
void    bsrdrfi (char fn[], long nbar, long ldt[], float rfi[]);
long    bsfindlong (long iarr[], long n, long ival);
void    bsvltyser (float hi[], float lo[], float cls[], long nb,
		float ser[], long per, long mode);
float   bsvltybar (float hi[], float lo[], float cls[], long cb,
		long per, long mode);
void*   bsbmalloc (size_t n);
void    bsftlerr (char msg[]);

#ifndef max
    #define max(a,b) (((a)>(b))?(a):(b))
    #define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifdef __cplusplus
};
#endif

#endif /* LIBBSPM_H */

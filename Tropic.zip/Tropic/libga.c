/*
c  libga.c
c
c  Genetic optimizer component (c++ class) - Version 1.22
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2005.  All Rights Reserved.
*/

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "libga.h"

/*-------------------------------------------------------------------------*/

GENOPT::GENOPT(void) {
    // constructor initializes all array pointers to NULL
    f=NULL;
    v=NULL;
    vc=NULL;
    ub=NULL;
    lb=NULL;
    mc=NULL;
}

GENOPT::~GENOPT(void) {
    // destructor frees all allocated array memory
    clear();
}

long GENOPT::setup(long nvec, long npop) {
    // method called to initialize a genetic optimizer instance
    long k;
    clear();		// reset genetic optimizer instance
    np=npop;		// set population size
    nv=nvec;		// set vector size
    // allocate all arrays
    if((v=(float**)calloc(np,sizeof(float*)))==NULL) goto GOERR;
    for(k=0; k<np; k++)
	if((v[k]=(float*)calloc(nv,sizeof(float)))==NULL) goto GOERR;
    if((vc=(float*)calloc(nv,sizeof(float)))==NULL) goto GOERR;
    if((f=(float*)calloc(np,sizeof(float)))==NULL) goto GOERR;
    if((ub=(float*)calloc(nv,sizeof(float)))==NULL) goto GOERR;
    if((lb=(float*)calloc(nv,sizeof(float)))==NULL) goto GOERR;
    if((mc=(float*)calloc(nv,sizeof(float)))==NULL) goto GOERR;
    // set parameters to default values
    for(k=0; k<nv; k++) {
	ub[k]=1.0;	    // upper bound for variable (vector element)
	lb[k]=0.0;	    // lower bound for variable
	mc[k]=0.0;	    // mutation creep for variable (no creep)
    }
    mr=0.3;		    // mutation rate
    cr=0.2;		    // crossover rate
    chnk=1;		    // chunk size (allele size in vector elements)
    devf=0.5;		// differential evolution factor
    alg=GONORMAL;	// algorithm to use
    randomize(93);	// create initial random population
    return(0);		// indicate successful initialization
GOERR:
    // handle out-of-memory error condition
    clear();		// free any memory that was allocated
    return(-1);		// indicate insufficient memory condition
}

void GENOPT::clear(void) {
    // method frees all arrays and resets all array pointers to NULL
    long k;
    if(v) {
	for(k=0; k<np; k++)
	    if(v[k]) free(v[k]);
	free(v);
    }
    if(f) free(f);
    if(vc) free(vc);
    if(ub) free(ub);
    if(lb) free(lb);
    if(mc) free(mc);
    f=NULL;
    v=NULL;
    vc=NULL;
    ub=NULL;
    lb=NULL;
    mc=NULL;
}

void GENOPT::scale(long k, float vmin, float vmax) {
    // method sets lower and upper bounds for variables
    // (alleles, vector elements)
    lb[k]=vmin;
    ub[k]=vmax;
}

float GENOPT::rng(long &iseed) {
    // high-quality random number generator (used internally)
    long j, k;  float temp;
    if(iseed<=0) {
        iseed=(iseed==0)?(1):(-iseed);
        rngiseed2=iseed;
	for(j=39; j>=0; j--) {
            k=iseed/53668;
            iseed=40014*(iseed-k*53668)-k*12211;
	    if(iseed<0) iseed+=2147483563;
	    if(j<32) rngiv[j]=iseed;
	}
	rngiy=rngiv[0];
    }
    k=iseed/53668;
    iseed=40014*(iseed-k*53668)-k*12211;
    if(iseed<0) iseed+=2147483563;
    k=rngiseed2/52774;
    rngiseed2=40692*(rngiseed2-k*52774)-k*3791;
    if(rngiseed2<0) rngiseed2+=2147483399;
    j=rngiy/67108862;
    rngiy=rngiv[j]-rngiseed2;
    rngiv[j]=iseed;
    if(rngiy<1) rngiy+=2147483562;
    temp=(1.0/2147483563)*rngiy;
    return((temp>=1.0)?(0.99999):(temp));
}

void GENOPT::randinit(long seed) {
    // method initializes (seeds) the random number generator
    float dummy;
    rngiseed2=123456789;
    rngiy=0;
    urs= (seed==0) ? (-666) : (seed>0) ? (-seed) : (seed);
    dummy=rng(urs);
}

float GENOPT::randflt(void) {
    // method generates a uniformly distributed random floating point
    // number between 0.0 and 1.0
    return(rng(urs));
}

long GENOPT::randint(long n) {
    // method generates a uniformly distributed random integer between
    // 0 and n-1
    long rn=(long)(randflt()*n);
    if(rn>=n) rn=n-1;
    return(rn);
}

void GENOPT::randomize(long seed) {
    // method randomizes the breeding population in preparation
    // for an evolutionary run
    long i, k;
    // seed the random number generator
    randinit(seed);
    // initialize all elements (alleles) of all vectors (breeding
    // population members) to random values
    for(i=0; i<np; i++)
	for(k=0; k<nv; k++)
	    v[i][k]=randflt();
    // initialize other variables in preperation for breeding
    for(i=0; i<np; i++)
	f[i]=GOMINFIT;
    bmf=GOMINFIT;
    amf=GOMINFIT;
    cmf=GOMINFIT;
    crnt=GOMINFIT;
    ng=0;
}

void GENOPT::receive_vector(float *vec) {
    // method returns a "guess" solution (child vector) from
    // the breeding population
    long i, j, k, mtgt, m1, m2, m3, tgl;
    float nrnd, v1, v2, rsq;
    if(alg==GONORMAL) {
        // use standard algorithm for breeding
	i=randint(np);
	do { j=randint(np); } while(j==i);
	tgl=(randflt()>0.5)?(1):(-1);
	for(k=0; k<nv; k++) {
	    if((k%chnk)==0) { if(randflt()<cr) tgl=(-tgl); }
	    vc[k]=(tgl>0)?(v[i][k]):(v[j][k]);
	    if(randflt()<mr) {
		if(mc[k]>0.0) {
		    do {
			v1=2.0*randflt()-1.0;
			v2=2.0*randflt()-1.0;
			rsq=v1*v1+v2*v2;
		    } while(rsq>=1.0 || rsq==0.0);
		    nrnd=v2*sqrt(-2.0*log(rsq)/rsq);
		    vc[k]+=(mc[k]/(ub[k]-lb[k]))*nrnd;
		}
		else {
		    vc[k]+=randflt();
		    if(vc[k]>1.0) vc[k] -= 1.0;
		}
	    }
	    if(vc[k]>1.0) vc[k]=1.0;
	    else if(vc[k]<0.0) vc[k]=0.0;
	    vec[k]=lb[k]+(ub[k]-lb[k])*vc[k];
	}
    }
    if(alg==GODIFFERENTIAL) {
        // use new differential algorithm as reported
        // in Dr. Dobbs Journal for breeding
	mtgt=(ng % np);
	do { m1=randint(np); } while(m1==mtgt);
	do { m2=randint(np); } while(m2==m1 || m2==mtgt);
	do { m3=randint(np); } while(m3==m1 || m3==m2 || m3==mtgt);
	j=randint(nv);
	for(k=0; k<nv; k++) {
	    tgl=(randflt()<cr||k==j)?(1):(-1);
	    if(tgl>0) vc[k]=v[m3][k]+devf*(v[m1][k]-v[m2][k]);
	    else vc[k]=v[mtgt][k];
	    if(vc[k]>1.0) vc[k]=1.0;
	    else if(vc[k]<0.0) vc[k]=0.0;
            vec[k]=lb[k]+(ub[k]-lb[k])*vc[k];
	}
    }
}

void GENOPT::send_fitness(float fit) {
    // method used to report the fitness of a "guess" solution
    // (obtained from GENOPT::receive_vector) back to a genetic
    // optimizer instance
    long k, iworst, mtgt, namf;
    float fworst, *vptr, gmin;
    gmin=GOMINFIT;
    cmf=fit;
    if(alg==GONORMAL) {
	fworst=1.0E32;
	iworst=0;
	for(k=0; k<np; k++) {
	    if(f[k]<fworst) {
		fworst=f[k];
		iworst=k;
	    }
	}
	if(cmf>fworst) {
	    vptr=v[iworst];
	    v[iworst]=vc;
	    vc=vptr;
	    f[iworst]=cmf;
	}
    }
    if(alg==GODIFFERENTIAL) {
	mtgt=(ng % np);
	if(cmf>f[mtgt]) {
	    vptr=v[mtgt];
	    v[mtgt]=vc;
	    vc=vptr;
	    f[mtgt]=cmf;
	}
    }
    if(cmf>bmf) bmf=cmf;
    crnt=fit;
    namf=0;
    amf=0.0;
    for(k=0; k<np; k++) {
	if(f[k]>gmin) {
	    amf+=f[k];
	    namf++;
	}
    }
    amf=(namf>0)?(amf/namf):(gmin);
    ng++;
}

void GENOPT::mostfitvector(float *vec) {
    // method returns most fit vector (solution) in breeding population
    long k, ibest;
    float fbest;
    ibest=0;
    fbest=GOMINFIT;
    for(k=0; k<np; k++) {
	if(f[k]>fbest) {
	    fbest=f[k];
	    ibest=k;
	}
    }
    for(k=0; k<nv; k++)
	vec[k]=lb[k]+(ub[k]-lb[k])*v[ibest][k];
    crnt=fbest;
}

float GENOPT::membervecelt(long k, long i) {
    // method returns value of i-th allele in k-th population member
    return(lb[i]+(ub[i]-lb[i])*v[k][i]);
}


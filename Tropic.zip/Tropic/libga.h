#ifndef LIBGA_H
#define LIBGA_H

/*
c  libga.h
c
c  Header file for libga.c (c++ genetic optimizer - version 1.22)
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 1997, 1998, 2005.  All Rights Reserved.
*/

#define GONORMAL	(1)
#define GODIFFERENTIAL	(2)
#define GOMINFIT 	(-1.0E32)

class GENOPT {
private:
    long    np;         // population size
    long    nv;         // vector size
    long    ng;         // generation count
    float   **v;        // population member vectors
    float   *f;         // population member fitnesses
    float   *vc;        // child vector
    float   cmf;        // child fitness
    float   crnt;       // current fitness
    float   *ub;        // upper scaling bounds
    float   *lb;        // lower scaling bounds
    float   bmf;        // best member fitness
    float   amf;        // average member fitness
    float   mr;         // mutation rate
    float   *mc;        // mutation creep
    float   cr;         // crossover rate
    long    chnk;       // chunk size for crossovers
    long    alg;	    // evolutionary algorithm selector
    float   devf;	    // differential evolution factor
    long    urs;        // rng internal
    long    rngiseed2;	// rng internal
    long    rngiy;	    // rng internal
    long    rngiv[32];	// rng internal
private:
    float rng(long &iseed);
    void randinit(long seed);
    float randflt(void);
    long randint(long n);
public:
    GENOPT(void);
    ~GENOPT(void);
    long setup(long nvec, long npop);
    void clear(void);
    void scale(long k, float vmin, float vmax);
    void mutation(float mut) { mr=mut; };
    void creep(long k, float mutc) { mc[k]=mutc; };
    void crossover(float cross) { cr=cross; };
    void chunk(long k) { chnk=k; };
    void algorithm(long m) { alg=m; };
    void differential(float fac) { devf=fac; };
    void randomize(long seed);
    void receive_vector(float *vec);
    void send_fitness(float fit);
    float scale_ub(long k) { return ub[k]; };
    float scale_lb(long k) { return lb[k]; };
    float mutation(void) { return mr; };
    float creep(long k) { return mc[k]; };
    float crossover(void) { return cr; };
    long chunk(void) { return chnk; };
    long algorithm(void) { return alg; };
    float differential(void) { return devf; };
    float memberfitness(long k) { return f[k]; }
    float membervecelt(long k, long i);
    void mostfitvector(float *vec);
    float bestfitness(void) { return bmf; };
    float averagefitness(void) { return amf; };
    float currentfitness(void) { return crnt; };
    long generations(void) { return ng; };
    long population(void) { return np; };
    long vectorsize(void) { return nv; };
};

#endif /* LIBGA_H */

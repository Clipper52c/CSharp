/*
c  libkbd.c
c
c  Revised: 2006.12.08
c
c  Provides the functions kb_hit() and kb_getch_w() regardless of
c  whether one is running Unix/Linux or Dos/Windows.  This library
c  has been tested on Dos/Windows, Debian, and FreeBSD systems.
c
c  Define IS_UNIX when compiling under Linux, BSD, or some other flavour 
c  of Unix; define IS_DOS when compiling under Dos or Windows.  This 
c  module must be compiled as ordinary C, not as C++.
*/

/*------------------------ Unix implementations ---------------------------*/

#ifdef IS_UNIX

#include <stdio.h>
#include <termios.h>
#include <poll.h>
#include <unistd.h>

#if sun
  #include <sys/filio.h>
#elif linux
  #include <sys/ioctl.h>
#endif

#ifndef STDIN_FILENO
  #define STDIN_FILENO 0
#endif

int kb_hit (void)
{
    int ret, hit;
    struct termios orig;
    struct termios changed;
    static struct pollfd poll_set = {0, POLLIN};

    ret = tcgetattr (STDIN_FILENO, &orig);
    if (ret < 0) return 0;

    changed = orig;
    changed.c_lflag = ~(ICANON | ECHO);
    changed.c_cc[VMIN] = 1;
    changed.c_cc[VTIME] = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &changed);
    if (ret < 0) return 0;

    hit = poll (&poll_set, 1, 0);
    if (hit < 0) hit = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &orig);
    if (ret < 0) return 0;

    return hit;
}

unsigned char kb_getch_w(void) 
{
    int ret;
    unsigned char c;
    struct termios orig;
    struct termios changed;

    ret = tcgetattr (STDIN_FILENO, &orig);
    if (ret < 0) return (unsigned char) 0;

    changed = orig;
    changed.c_lflag = ~(ICANON | ECHO);
    changed.c_cc[VMIN] = 1;
    changed.c_cc[VTIME] = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &changed);
    if (ret < 0) return (unsigned char) 0;

    ret = read (STDIN_FILENO, &c, 1);
    if (ret != 1) c = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &orig);
    if (ret < 0) return (unsigned char) 0;

    return c;
}

unsigned char kb_getch_nw(void)
{
    int ret;
    unsigned char c;
    struct termios orig;
    struct termios changed;

    if (kb_hit () == 0) return (unsigned char ) 0;

    ret = tcgetattr (STDIN_FILENO, &orig);
    if (ret < 0) return (unsigned char) 0;

    changed = orig;
    changed.c_lflag = ~(ICANON | ECHO);
    changed.c_cc[VMIN] = 1;
    changed.c_cc[VTIME] = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &changed);
    if (ret < 0) return (unsigned char) 0;

    ret = read (STDIN_FILENO, &c, 1);
    if (ret != 1) c = 0;

    ret = tcsetattr (STDIN_FILENO, TCSANOW, &orig);
    if (ret < 0) return (unsigned char) 0;

    return c;
}

int kb_getbytes_toread (void)
{
    int bytes;

    #if defined(linux) || defined(sun)

        int ret;
        struct termios orig;
        struct termios changed;

        ret = tcgetattr (STDIN_FILENO, &orig);
        if (ret < 0) return 0;

        changed = orig;
        changed.c_lflag = ~(ICANON | ECHO);
        changed.c_cc[VMIN] = 1;
        changed.c_cc[VTIME] = 0;

        ret = tcsetattr (STDIN_FILENO, TCSANOW, &changed);
        if (ret < 0) return 0;

        ret = ioctl (STDIN_FILENO, FIONREAD, &bytes);
        if (ret < 0) bytes = ret;

        ret = tcsetattr (STDIN_FILENO, TCSANOW, &orig);
        if (ret < 0) return (unsigned char) 0;

    #else

        bytes = kb_hit ();

    #endif

    return bytes;
}

#ifdef TEST_MAIN
    int main () {
        fprintf (stdout, "has data[%d]\n", kb_hit ());
        fprintf (stdout, "wait read char[%c]\n", kb_getch_w());
        sleep (3);
        fprintf (stdout, "has data[%d]\n", kb_hit ());
        fprintf (stdout, "no. of bytes[%d]\n", kb_getbytes_toread ());
        fprintf (stdout, "has data[%d]\n", kb_hit ());
        fprintf (stdout, "read char[%c]\n", kb_getch_nw());
    }
#endif

#endif  /* IS_UNIX */

/*-------------------- Dos / Windows implementations ----------------------*/

#ifdef IS_DOS

#include <conio.h>

int kb_hit (void) {
    return ( kbhit() );
}

unsigned char kb_getch_w (void) {
    return ( getch() );
}

#endif /* IS_DOS */


#ifndef LIBKBD_H
#define LIBKBD_H

#ifdef __cplusplus
extern "C" {
#endif

int kb_hit (void);
unsigned char kb_getch_w (void);
unsigned char kb_getch_nw (void);
int kb_getbytes_toread (void);
    
#ifdef __cplusplus
};
#endif

#endif /* LIBKBD_H */



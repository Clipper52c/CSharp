/*
c  libmisc.c
c
c  Revised 2009.06.02
c
c  Library containing functions for allocating memory and handling errors,
c  sorting and searching, working with dates and times, calculating basic
c  moving averages and technical indicators, determining probabilities and
c  generating psuedorandom numbers, drawing text-based plots, and other
c  miscellaneous tasks.  May be compiled as C or C++.
c
c  Note that some functions are not fully thread-safe due to the use of
c  static variables (e.g., the random number functions).  All affected
c  functions contain the comment "This function is not thread-safe"
c  in their descriptive headers.
c
c  Copyright (C) 2008.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

#include "libmisc.h"

/*---------------------------------------------------------------------------
c  Error handling and memory allocation functions.
*/

void misc_ftlerr (char msg[]) {
    /* Handles fatal errors by displaying message and terminating */
    fprintf(stderr,"\nERROR: %s\n",(char*)msg);
    exit(EXIT_FAILURE);
}

void* misc_malloc (size_t n) {
    /* Safely allocates memory */
    void *ptr;
    if((ptr=(void*)malloc(n))==NULL)
        misc_ftlerr("misc_malloc: out of memory");
    return(ptr);
}

/*---------------------------------------------------------------------------
c  String handling functions.
*/

char* misc_strtrim (char str[]) {
    /* Trims whitespace characters from end of string */
    char *p;
    for(p=str+strlen(str)-1; p>=str && isspace(*p); --p) *p='\0';
    return(str);
}

char* misc_strupr (char str[]) {
    /* Converts string to uppercase */
    char *p;
    for(p=str; *p; ++p) *p=toupper(*p);
    return(str);
}

char* misc_strlwr (char str[]) {
    /* Converts string to lowercase */
    char *p;
    for(p=str; *p; ++p) *p=tolower(*p);
    return(str);
}

double misc_strdbl (char buf[], long n) {
    /* Converts first n characters in buf into a double (0.0 if no
    .  conversion possible).  Null termination is not required.
    */
    char tmp[22];
    if(n<0 || n>20) misc_ftlerr("misc_strdbl: bad n");
    strncpy(tmp, buf, n);
    tmp[n]='\0';
    return(atof(tmp));
}

long misc_strlng (char buf[], long n) {
    /* Converts first n characters in buf into a long (0 if no
    .  conversion possible).  Null termination is not required.
    */
    char tmp[16];
    if(n<0 || n>14) misc_ftlerr("misc_strlng: bad n");
    strncpy(tmp, buf, n);
    tmp[n]='\0';
    return(atol(tmp));
}

/*---------------------------------------------------------------------------
c  Sorting and searching functions.
*/

long misc_kfinddtm (long dt[], long tm[], long n, long edt, long etm) {
    /* Returns k such that 0 <= k <= n-1 with, if possible,
    .  (dt[k], tm[k]) <= (edt, etm) < (dt[k+1], tm[k+1]).  Dates
    .  must be in YYYYMMDD or serial form (less than 8 integer digits),
    .  and times in HHMMSS form.  Doubles must be able to precisely
    .  represent integers of up to 14 digits.
    .  Arguments:
    .    dt  - YYYYMMDD date vector [0..n-1] of a (date, time) series
    .    tm  - HHMMSS time vector [0..n-1] of a (date, time) series    
    .    n   - number of bars in series dt[] and tm[]
    .    edt - YYYYMMDD date of (date, time) to locate in series
    .    etm - HHMMSS time of (date, time) to locate in series    
    .  Procedure assumes that (dt[0], tm[0]) <= (dt[1], tm[1]) <= ...
    .  <= (dt[n-1], tm[n-1]) in a temporal sense.  In the case of ties,
    .  the returned index k points to the last tied element.
    */
    double edtm;
    long ka, kb, k;
    #define dtmqq(kk) (1000000.0*(double)dt[(kk)]+(double)tm[(kk)])
    edtm=1000000.0*(double)edt+(double)etm;
    ka=0;
    kb=n-1;
    if(edtm<dtmqq(ka)) return(ka);
    if(edtm>=dtmqq(kb)) return(kb);
    while(kb-ka>1) {
        k=(ka+kb)>>1;
        if(dtmqq(k)>edtm) kb=k;
        else ka=k;
    }
    if(edtm==dtmqq(kb)) return(kb);
    return(ka);    
    #undef dtmqq
}

long misc_kfindflt (float arr[], long n, float val) {
    /* Finds k such that 0 <= k <= n-1 with, if possible,
    .  arr[k] <= val < arr[k+1].  Assumes arr[0..n-1] has
    .  ascending sort order.  In the case of ties, returned
    .  index k points to the last tied element.
    */
    long ia, ib, k;
    if(val<arr[ia=0]) return(ia);
    if(val>=arr[ib=n-1]) return(ib);
    while(ib-ia>1) {
        if(arr[k=(ia+ib)>>1]>val) ib=k;
        else ia=k;
    }
    if(val==arr[ib]) return(ib);
    return(ia);
}

long misc_kfindlng (long iarr[], long n, long ival) {
    /* Finds k such that 0 <= k <= n-1 with, if possible,
    .  iarr[k] <= ival < iarr[k+1].  Assumes iarr[0..n-1] has
    .  ascending sort order.  In the case of ties, returned
    .  index k points to the last tied element.
    */
    long ia, ib, k;
    if(ival<iarr[ia=0]) return(ia);
    if(ival>=iarr[ib=n-1]) return(ib);
    while(ib-ia>1) {
        if(iarr[k=(ia+ib)>>1]>ival) ib=k;
        else ia=k;
    }
    if(ival==iarr[ib]) return(ib);
    return(ia);
}

long misc_hunt (float d[], long n, float x, long k) {
    /* Returns i such that d[i] <= x < d[i+1] when d[0] <= x < d[n-1],
    .  0 when x < d[0], and n-1 when x >= d[n-1].  Assumes that
    .  d[0] <= d[1] <= ... <= d[n-1] and that the previous value of i
    .  (or a guess as to a nearby value) is provided (as argument k).
    .  This routine is faster than misc_kfindflt (see above) when
    .  repeated searches are performed and the successive values
    .  of i and k are correlated.
    .
    .  Note: This routine needs to be verified!  Instrument with
    .  test code and operations counts and run tests with extensive
    .  random inputs for k and x using a good test series d[].
    */
    long stride, ia, ib;
    if(x<d[ia=0]) return(ia);
    if(x>=d[ib=n-1]) return(ib);
    if(k<2) k=2;
    else if(k>n-3) k=n-3;
    stride=1;
    if(x < d[k]) {
        do {
	    if((k -= stride) < 0) {
	        ia= 0;
		ib= k + stride;
		goto BIS;
            }
            stride += stride;
	} while(x < d[k]);
        ib= (ia= k) + (stride >> 2);
    } else {
	do {
	    if((k += stride) > n - 1) {
                ia= k - stride;
	        ib= n - 1;
	        goto BIS;
            }
            stride += stride;
	} while(x > d[k]);
	ia= (ib= k) - (stride >> 2);
    }
    BIS:
    while(ib-ia>1) {
        if(d[k=(ia+ib)>>1]>x) ib=k;
	else ia=k;
    }
    if(x==d[ib]) return(ib);
    return(ia);
}

void misc_sndxflt (float farr[], long n, long nndx[]) {
    /* Determines index nndx[0..n-1] into array d[0..n-1] such
    .  that d[nndx[0]] <= d[nndx[1]] <= ... <= d[nndx[n-1]].
    .  Based on "Implementing Quicksort Programs", Comm. ACM,
    .  Oct. 1978, and Corrigendum, Comm. ACM, June 1979.
    */
    #define NSTACK 68
    #define NTHRESH 7
    #define ISWAP(a,b)  itemp=(a), (a)=(b), (b)=itemp
    long stack[NSTACK], *sp, i, j, k, ia, ib, itemp, *ndx;
    float xa, *d;
    d = farr - 1;
    ndx = nndx - 1;    
    ib = (ia = 1) + n;
    sp = stack;
    for (i = 1; i <= n; i++) ndx[i] = i;
    for (;;) {
        if (ib - ia > NTHRESH) {
            k = ((ib - ia) >> 1) + ia;
            ISWAP (ndx[k], ndx[ia]);
            i = ia + 1;
            j = ib - 1;
            if (d[ndx[i]] > d[ndx[j]]) ISWAP (ndx[i], ndx[j]);
            if (d[ndx[ia]] > d[ndx[j]]) ISWAP (ndx[ia], ndx[j]);
            if (d[ndx[i]] > d[ndx[ia]]) ISWAP (ndx[i], ndx[ia]);
            for (;;) {
                xa = d[ndx[ia]];
                do { i++; } while (d[ndx[i]] < xa);
                do { j--; } while (d[ndx[j]] > xa);
                if (i > j) break;
                ISWAP (ndx[i], ndx[j]);
            }
            ISWAP (ndx[ia], ndx[j]);
            if (j + i - ia > ib) {
		*sp = ia;
		*(sp+1) = j;
                ia = i;
            }
            else {
		*sp = i;
		*(sp+1) = ib;
                ib = j;
            }
            sp += 2;
            if(sp - stack > NSTACK - 4)
                misc_ftlerr("misc_sndxflt2: stack size exceeded");
        }
        else {
            for (j = ia, i = j + 1; i < ib; j = i, i++) {
                for (; d[ndx[j]] > d[ndx[j+1]]; j--) {
                    ISWAP (ndx[j], ndx[j+1]);
                    if (j == ia) break;
                }
            }
            if (sp != stack) {
                sp -= 2;
		ia = *sp;
		ib = *(sp+1);
            }
            else break;
        }
    }
    #undef ISWAP
    #undef NTHRESH    
    #undef NSTACK
    for (i = 1; i <= n; i++) ndx[i] -= 1;
}

/*---------------------------------------------------------------------------
c  Statistical functions.
*/

void misc_percentiles (long n, float arr[], long indx[], float pct[]) {
    /* Converts raw scores in arr[0..n-1] to percentiles in 
    .  pct[0..n-1] and a sorted index in indx[0..n-1] (in 
    .  ascending order).  The returned percentiles are in
    .  decimal form (they range from 0.0 to 1.0, not from 
    .  0.0 to 100.0).  Requires function misc_sndxflt which
    .  is implemented above.
    */
    long i;
    misc_sndxflt(arr, n, indx);
    for(i=0; i<n; i++) {
        pct[indx[i]]=(i+0.5)/n;    /* calculated percentile scores */
    }
}

void misc_moment (float data[], long n, float *ave, float *adev,
float *sdev, float *var, float *skew, float *curt) {
    /* Calculates the first four statistical moments of a data set as
    .  well as the average deviation.  Unlike the Numerical Recipes 
    .  routine, this one employs zero-based arrays and double
    .  precision internal arithmetic.
    */
    long j;
    double dep, ds, dp, dave, dadev, dvar, dskew, dcurt, dsdev;
    if(n<5) misc_ftlerr("misc_moment: n<5");
    for(j=0, ds=0.0; j<n; j++) ds+=((double)data[j]);
    dave=ds/n;				/* mean */
    dadev=dep=dvar=dskew=dcurt=0.0;
    for(j=0; j<n; j++) {
        dadev+=fabs(ds=(double)data[j]-dave);
        dep+=ds;
        dvar+=(dp=ds*ds);
        dskew+=(dp*=ds);
        dcurt+=(dp*ds);
    }
    dadev/=n;				            /* average deviation */
    dvar=(dvar-dep*dep/n)/(n-1);	    /* unbiased variance */
    if(dvar>0.0) {
        dsdev=sqrt(dvar);		        /* unbiased standard deviation */    
        dskew/=(n*dvar*dsdev);		    /* skew */
        dcurt=dcurt/(n*dvar*dvar)-3.0;	/* kurtosis */
    } else { dadev=0.0; dvar=0.0;  dsdev=0.0;  dskew=0.0;  dcurt=0.0; }
    *ave=(float)dave;  *adev=(float)dadev;  *sdev=(float)dsdev;
    *var=(float)dvar;  *skew=(float)dskew;  *curt=(float)dcurt;
}

void misc_mommdr (float ans[], float cls[], long m, long n, long icb) {
    /* Calculates statistical moments for the distribution of historical
    .  m-day returns in a price-like data series.
    .  ans   - array used to return the results
    .             ans[0] = number of returns analyzed
    .             ans[1] = mean of returns
    .             ans[2] = standard deviation of returns (unbiased)
    .             ans[3] = average deviation of returns
    .             ans[4] = skew of returns
    .             ans[5] = kurtosis of returns
    .             ans[6] = variance of returns (unbiased)
    .  cls   - closing (or other) prices [0..icb..]
    .  m     - holding period (in bars) for each return
    .  n     - number of past returns to analyze
    .  icb   - current or reference bar
    */
    long i, ni, ia, ib;
    float *d;
    d=(float*)malloc(sizeof(float)*n);
    if(d==NULL) misc_ftlerr("misc_mommdr: out of memory");
    for(i=0, ni=0; i<n; i++) {
        if((ia=(ib=icb-i)-m)<0) break;
        d[i]=log(cls[ib]/cls[ia]);  /* logarithmic m-bar return */
        ni++;                       /* number of returns */
    }
    ans[0]=(float)ni;
    misc_moment(d,ni,ans+1,ans+3,ans+2,ans+6,ans+4,ans+5);
    free(d);
}

float misc_cumnrml (float x) {
    /* Cumulative normal probability of x to 7 significant digits */
    double xv, zx, p, t;
    xv=fabs((double)x);
    zx=0.39894228*exp(-0.5*xv*xv);
    t=1.0/(1.0+0.2316419*xv);
    p=1.0-zx*(t*(0.319381530+t*(-0.356563782+t*(1.781477937
        +t*(-1.821255978+t*1.330274429)))));
    return((float)((x>0.0)?(p):(1.0-p)));
}

float misc_invcumnrml (float p) {
    /* Returns x such that p is the cumulative normal probability
    .  of x.  This is the inverse of the cumulative normal
    .  probability function.
    */
    float px, a, b, t, x;
    px=(p>=0.5)?(1.0-p):(p);
    t=sqrt(-log(px*px));
    a=2.515517+t*(0.802853+t*0.010328);
    b=1.0+t*(1.432788+t*(0.189269+t*0.001308));
    x=(p>=0.5)?(t-a/b):(a/b-t);
    return(x);
}

void misc_mhist (float bc[], float bf[], float bmin, float bmax,
long nb, float d[], long nd) {
    /* Calculates a frequency distribution histogram for a set 
    .  of data points.
    .  bc    - vector [0..nb-1] of bin centers (output)
    .  bf    - vector [0..nb-1] of bin counts (output)
    .  bmin  - first (lowest) bin center (input)
    .  bmax  - last (highest) bin center (input)
    .  nb    - number of bins desired (input)
    .  d     - vector [0..nd-1] of data points (input)
    .  nd    - number of data points (input)
    */
    long i, k;
    for(i=0; i<nb; i++) {
        bf[i]=0.0;
        bc[i]=bmin+i*(bmax-bmin)/(nb-1.0);
    }
    if(nd<=0) return;		/* there are no data points */
    for(i=0; i<nd; i++) {
        k=(long)((nb-1)*(d[i]-bmin)/(bmax-bmin)+0.5);
        if(k<0) k=0;
        if(k>nb-1) k=nb-1;
        bf[k]+=1.0;
    }
}

/*---------------------------------------------------------------------------
c  Random number generators.
*/

static long misc_ran2seed= -666;  /* used by random number generators */

static float misc_ran2 (long *idum) {
    /* Internal function returns uniformly distributed psuedorandom
    .  numbers.  Initialize by calling with *idum set to a negative
    .  integer (the seed value).  Code modified from Numerical Recipes
    .  in C, 2nd Edition.  Assumes 32-bit (or greater) integers.
    .  This function is not thread-safe.
    */
    #define IM1 2147483563
    #define IM2 2147483399
    #define AM (1.0/IM1)
    #define IMM1 (IM1-1)
    #define IA1 40014
    #define IA2 40692
    #define IQ1 53668
    #define IQ2 52774
    #define IR1 12211
    #define IR2 3791
    #define NTAB 32
    #define NDIV (1+IMM1/NTAB)
    #define EPS 1.2e-7
    #define RNMX (1.0-EPS)
    long j, k;
    static long idum2=123456789;
    static long iy=0;
    static long iv[NTAB];
    float temp;
    if(*idum <= 0) {
        if(-(*idum) < 1) *idum=1;
        else *idum = -(*idum);
        idum2=(*idum);
        for(j=NTAB+7;j>=0;j--) {
            k=(*idum)/IQ1;
            *idum=IA1*(*idum-k*IQ1)-k*IR1;
            if(*idum < 0) *idum += IM1;
            if(j < NTAB) iv[j] = *idum;
        }
        iy=iv[0];
    }
    k=(*idum)/IQ1;
    *idum=IA1*(*idum-k*IQ1)-k*IR1;
    if(*idum < 0) *idum += IM1;
    k=idum2/IQ2;
    idum2=IA2*(idum2-k*IQ2)-k*IR2;
    if(idum2<0) idum2+=IM2;
    j=iy/NDIV;
    iy=iv[j]-idum2;
    iv[j]= *idum;
    if(iy<1) iy+=IMM1;
    if((temp=AM*iy)>RNMX) return RNMX;
    else return temp;
    #undef IM1
    #undef IM2
    #undef AM
    #undef IMM1
    #undef IA1
    #undef IA2
    #undef IQ1
    #undef IQ2
    #undef IR1
    #undef IR2
    #undef NTAB
    #undef NDIV
    #undef EPS
    #undef RNMX
}

static float misc_gasdev (long *idum) {
    /* Internal function returns normally-distributed psuedorandom
    .  numbers based on polar variant of Cox-Muller algorithm (see
    .  Wikipedia).  This function is not thread-safe.
    */
    static long k=0;
    static float xs;
    float s, r, x, y;
    if(k==0) {
        k=1;
        do {
            x=2.0*misc_ran2(idum)-1.0;
            y=2.0*misc_ran2(idum)-1.0;
        } while ((r=x*x+y*y)>=1.0 || r==0.0);
        xs=x*(s=sqrt(-2.0*log(r)/r));
        return(y*s);
    }
    k=0;
    return(xs);
}

void misc_randseed (long iseed) {
    /* Seeds the psuedorandom number generator.  Use negative iseed
    .  for default seeding, positive iseed for user-specified seeding.
    .  This function is not thread-safe.
    */
    if(iseed>0) misc_ran2seed= -iseed;  /* user supplied seed */
    else misc_ran2seed= -666;           /* or default seed */
}

float misc_randgau (void) {
    /* Returns normally distributed (Gaussian) psuedorandom
    .  numbers with mean of 0 and sigma of 1.  This function
    .  is not thread-safe.
    */
    return(misc_gasdev(&misc_ran2seed));
}

long misc_randint (long m, long n) {
    /* Returns uniformly distributed psuedorandom integers
    .  between m and n.  This function is not thread-safe.
    */
    long ans;
    ans=(long)(m+(n+1-m)*misc_ran2(&misc_ran2seed));
    if(ans>n) ans=n;
    if(ans<m) ans=m;
    return(ans);
}

float misc_randflt (void) {
    /* Returns uniformly distributed psuedorandom real numbers
    .  between 0.0 and 1.0, exclusive of the lower endpoint.
    .  This function is not thread-safe.
    */
    return(misc_ran2(&misc_ran2seed));
}

void misc_randtest (void) {
    /* Verifies proper psuedorandom number generator operation */
    long k, m, kk;
    static long mc[8]={194,831,693,931,265,459,319,88};
    misc_randseed(0);
    for(kk=0, k=0; k<8; k++) {
        if((m=misc_randint(1,1000)) != mc[k]) {
            fprintf(stderr, "%6ld %6ld\n", (long)m, (long)mc[k]);
            kk=k+1;
        }
    }
    if(kk) misc_ftlerr("misc_randtest: random number malfunction");
}

/*---------------------------------------------------------------------------
c  Date and calendar functions.
*/

long misc_julday (long mm, long idd, long iyyyy) {
    /* Returns the Julian day number given a calendar date (month,
    .  day, and 4-digit year).  Valid for dates after Jan 1, 1584.
    .  Verified against equivalent (but much slower) routine in
    .  Numerical Recipes.
    .  mm     - month, 1..12
    .  idd    - day, 1..31
    .  iyyyy  - year, 1584..
    */
    long mc, iyc, jd;
    iyc = (iyyyy - (mc = (18 - mm) >> 4)) / 100;
    jd = (36525 * (iyyyy - mc)) / 100
        + (306001 * (mm + 1 + 12 * mc)) / 10000
        + idd + (iyc >> 2) - iyc + 1720997;
    return(jd);
}

void misc_caldat (long julian, long *mm, long *idd, long *iyyyy) {
    /* Returns (via pointer variables) the calendar date (month,
    .  day, and 4-digit year) given a Julian day number.
    .  Accurate for dates after Jan 1, 1584.  This routine is the
    .  mathematical inverse of the misc_julday routine above, and has
    .  been verified against the equivalent (but slower) routine
    .  in Numerical Recipes.
    */
    long k, n;
    n = ((k = julian + 68569) << 2) / 146097;
    *iyyyy = (4000 * ((k = k - ((146097 * n + 3) >> 2)) + 1)) / 1461001;
    *mm = (80 * (k = k - ((1461 * *iyyyy) >> 2) + 31)) / 2447;
    *idd = k - (2447 * *mm) / 80;
    *mm = *mm + 2 - 12 * (k = *mm / 11);
    *iyyyy = 100 * (n - 49) + *iyyyy + k;
}

long misc_datetoser (long ldt) {
    /* Converts YYYYMMDD date to serial (days since Jan 1, 1900) */
    return(misc_julday((ldt/100)%100,ldt%100,ldt/10000)-2415021);
}

long misc_sertodate (long jd) {
    /* Converts serial date (days since Jan 1, 1900) to YYYYMMDD */
    long iyyyy, mm, idd;
    misc_caldat(jd+2415021,&mm,&idd,&iyyyy);
    return(10000*iyyyy+100*mm+idd);
}

long misc_nthned (long ldt, long n) {
    /* Returns the n-th nearest third-Friday option expiration date.
    .  Uses functions misc_julday and misc_caldat.
    .    ldt    - current date in YYYYMMDD integer form
    .    n      - desired expiration (0=last, 1=next, 2=2nd out, ...)
    .    return - computed expiration (3rd Friday) date in YYYYMMDD form
    .  Note: Some exchanges and databases treat options as expiring on
    .  the Saturday that follows the third Friday.  To obtain the date
    .  of such expirations, simply add 1 to the value returned by
    .  this function.
    */
    long idd, imm, iyyyy, jd;
    jd=misc_julday(imm=(ldt/100)%100,1,iyyyy=ldt/10000);
    while((jd%7)!=4) jd++;
    if(misc_julday(imm,idd=ldt%100,iyyyy)>jd+14)
        if(++imm > 12) { iyyyy++; imm=1; }
    while(n>1) {
        n--;
        if(++imm > 12) { iyyyy++; imm=1; }
    }
    while(n<=0) {
        n++;
        if(--imm < 1) { iyyyy--; imm=12; }
    }
    jd=misc_julday(imm,1,iyyyy);
    while((jd%7)!=4) jd++;
    misc_caldat(jd+14,&imm,&idd,&iyyyy);
    return(10000*iyyyy+100*imm+idd);
}

long misc_daysleft (long lcurdate, long mm, long iyyyy) {
    /* Calculates the number of calendar days remaining before option
    .  expiration (3rd Friday).  The year and month of expiration are 
    .  specified in iyyyy (2001, 2002, ...) and mm (1, 2, ... 12), 
    .  the current date in lcurdate (in YYYYMMDD integer form).  
    .  Uses function misc_julday.  This function is not thread-safe.
    */
    static long jdc, jde, lpcur=0, lpmm=0, lpyyyy=0;
    if(lcurdate!=lpcur) {
        jdc=misc_julday((lcurdate/100)%100,lcurdate%100,lcurdate/10000);
        lpcur=lcurdate;
    }
    if(mm!=lpmm || iyyyy!=lpyyyy) {
        jde=misc_julday(mm,1,iyyyy);
        while((jde%7)!=4) jde++;   /* find first Friday of month */
        jde+=14;                   /* then determine third Friday */
        lpmm=mm;
        lpyyyy=iyyyy;
    }
    return(jde-jdc);          /* calendar days till third Friday */
}

long misc_incmonth (long ldt) {
    /* Increments a YYYYMMDD date by exactly one month */
    ldt+=100;
    if(((ldt/100)%100)>12) ldt+=8800;
    return ldt;
}

long misc_nextbusday (long ldt) {
    /* Returns the next business or trading day as YYYYMMDD date */
    long jd, idd, mm, iyyyy;
    jd=misc_julday((ldt/100)%100,ldt%100,ldt/10000)+1;
    while(((jd+2)%7)<2) jd++;
    misc_caldat(jd,&mm,&idd,&iyyyy);
    return(idd+100*mm+10000*iyyyy);
}

long misc_dayofweek (long ldt) {
    /* Given YYYYMMDD date, returns day of week: 0=Sunday, 1=Monday, ...
    .  Valid for Gregorian calendar, that is, dates after Jan 1, 1584.
    */
    #if 1==1	/* original algorithm */
        return((misc_julday((ldt/100)%100,ldt%100,ldt/10000)+1)%7);
    #else	/* alternative algorithm */
        long ka, ky, km, kmonth;
        ky=ldt/10000-(ka=(14-(kmonth=(ldt/100)%100))/12);
        km=kmonth+12*ka-2;
        return(((ldt%100)+ky+(ky>>2)-ky/100+ky/400+(31*km)/12)%7);
    #endif
}

long misc_dayofyear (long ldt) {
    /* Given YYYYMMDD date, returns day of year (Jan 1st == day 1) */
    long ldx, iyyyy;
    ldx=misc_julday((ldt/100)%100,ldt%100,(iyyyy=ldt/10000));
    return(ldx-misc_julday(1,1,iyyyy)+1);
}

/* given YYYYMMDD date, return month, day, or year */
long misc_month (long ldt)	{ return((ldt/100)%100); }   /* 1..12 */
long misc_dayofmonth (long ldt)	{ return(ldt%100); }     /* 1..31 */
long misc_year (long ldt)	{ return(ldt/10000); }       /* YYYY */

/* given 24-hour HHMMSS time, return hour, minute, or second */
long misc_hour (long ltm)	{ return((ltm/100)%100); }   /* 0..23 */
long misc_minute (long ltm)	{ return(ltm%100); }         /* 0..59 */
long misc_second (long ltm)	{ return(ltm/10000); }       /* 0..59 */

long misc_thirdfriday (long ldt) {
    /* Given YYYYMMDD date, returns date of next 3rd Friday */
    long jd, mm, dd, iyyyy, jd1;
    jd=jd1=misc_julday(mm=(ldt/100)%100,1,iyyyy=ldt/10000);
    while(((jd+1)%7)!=5) jd++;
    jd+=14;
    if((dd=ldt%100) > jd-jd1+1) {
        if(++mm>12) { mm-=12; iyyyy+=1; }
        jd=misc_julday(mm,1,iyyyy);
        while(((jd+1)%7)!=5) jd++;
        jd+=14;
    }
    misc_caldat(jd,&mm,&dd,&iyyyy);
    return(10000*iyyyy+100*mm+dd);
}

long misc_reldate (long ldt, long n) {
    /* Calculates YYYYMMDD date a specified number of days forward
    .  (n > 0) or back (n < 0) relative to given YYYYMMDD date (ldt).
    */
    return(misc_sertodate(misc_datetoser(ldt)+n));
}

static char *misc_monthabbr[12] =
    { "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
      "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

static char *misc_dayabbr[7] =
    { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };

long misc_imon (char cmon[]) {
    /* Given a three-letter uppercase abbreviation for month (need
    .  not be NULL terminated), returns month-representing integer.
    .  Returns -1 if abbreviation is invalid.
    .  cmon   - month as abbreviation (JAN, FEB, ... DEC)
    .  return - month as integer (1, 2, ... 12) or error (-1)
    */
    int i;
    for (i=0; i<12; i++) {
	if(strncmp(cmon,misc_monthabbr[i],3)==0) return(i+1);
    }
    return(-1);
}

char* misc_cmon (long imon) {
    /* Returns a three-letter uppercase abbreviation for month
    .  specified by integer (imon, 1..12).  This is the inverse
    .  of function misc_imon (see above).
    */
    if(imon<1 || imon>12) misc_ftlerr("misc_cmon: bad imon");
    return(misc_monthabbr[imon-1]);
}

long misc_iday (char cday[]) {
    /* Given day as a three-letter uppercase abbreviation (need
    .  not be NULL terminated), returns day-representing integer.
    .  Returns -1 for invalid abbreviation.
    .  cday   - day as abbreviation (SUN, MON, ... SAT)
    .  return - day as integer (0, 1, ... 6) or error (-1)
    */
    int i;
    for(i=0; i<7; i++) {
	if(strncmp(cday,misc_dayabbr[i],3)==0) return(i);
    }
    return(-1);
}

char* misc_cday (long iday) {
    /* Returns a three-letter uppercase abbreviation for day
    .  specified by integer (iday, 0..6).  This is the inverse
    .  of function misc_iday (see above).
    */
    if(iday<0 || iday>6) misc_ftlerr("misc_cday: bad iday");
    return(misc_dayabbr[iday]);
}

long misc_timediff (long dta, long tma, long dtb, long tmb) {
    /* Calculates the time, in seconds, from (dta, tma) to (dtb, tmb).
    .  dta     - "a" date in YYYYMMDD form
    .  tma     - "a" time in 24-hour HHMMSS form
    .  dtb     - "b" date in YYYYMMDD form
    .  tmb     - "b" time in 24-hour HHMMSS form
    .  return  - calculated (dtb, tmb) - (dta, tma) in seconds
    .  Due to the use of a 32-bit integer return value, this routine
    .  is valid only for time differences that are less than about
    .  24800 days (68 years).  Note that 86400 seconds pass each day.
    */
    long dsec, dday;
    dsec = misc_hmstosec(tmb) - misc_hmstosec(tma);
    if (dtb != dta) {
        dday = misc_datetoser(dtb) - misc_datetoser(dta);
        if(abs(dday) > 24800)
            misc_ftlerr("misc_timediff: interval > 24800 days");
        dsec += 86400 * dday;
    }
    return(dsec);
}

void misc_reldttm (long *ymd, long *hms, long sec) {
    /* Adds (sec > 0) or subtracts (sec < 0) a specified number of
    .  seconds from the given date and time.  The new date and time
    .  are returned in place.  Note that 86400 seconds pass each day.
    .  ymd   - input date (YYYYMMDD); returned with output date
    .  hms   - input time (24-hour HHMMSS); returned with output time
    .  sec   - seconds to add (+) or subtract (-)
    */
    long seconds;
    seconds = misc_hmstosec(*hms) + sec;
    while (seconds >= 86400) {
        seconds -= 86400;
        *ymd = misc_reldate (*ymd, 1);   /* increment date one day */
    }
    while (seconds < 0) {
        seconds += 86400;
        *ymd = misc_reldate (*ymd, -1);  /* decrement date one day */
    }
    *hms = misc_sectohms(seconds);
}

long misc_hmstosec (long ltm) {
    /* Converts 24-hour HHMMSS time to seconds since midnight */
    return(3600*(ltm/10000)+60*((ltm/100)%100)+(ltm%100));
}

long misc_sectohms (long lsec) {
    /* Converts seconds since midnight (0..86399) to HHMMSS time */
    return(10000*(lsec/3600)+100*((lsec/60)%60)+(lsec%60));
}

/*---------------------------------------------------------------------------
c  Functions implementing indicators on series.
*/

void AvgTrueRangeS (float ans[], float hi[], float lo[], float cls[],
long m, long n) {
    /* Average true range of period m on an n-bar data series */
    long i;
    float *tr, r1, r2, r3;
    tr=(float*)malloc(sizeof(float)*n);
    if(tr==NULL) misc_ftlerr("AvgTrueRangeS: out of memory");
    tr[0]=hi[0]-lo[0];
    for(i=1; i<n; i++) {
        r1=hi[i]-lo[i];
        r2=hi[i]-cls[i-1];
        r3=cls[i-1]-lo[i];
        tr[i]=max(r1,max(r2,r3));
    }
    AverageS(ans,tr,m,n);
    free(tr);
}

void XAverageS (float ans[], float v[], long p, long n) {
    /* Exponential moving average of period p on an n-bar data series */
    long i;  double sum1, sum2, fac;
    for(i=0, sum1=sum2=0.0, fac=2.0/(1.0+p); i<n; i++) {
        sum1+=(fac*((double)v[i]-sum1));
        sum2+=(fac*(1.0-sum2));
        ans[i]=(float)(sum1/sum2);
    }
}

void AverageS (float ans[], float v[], long p, long n) {
    /* Simple moving average of period p on an n-bar data series */
    long i;  double sum;
    for(i=0, sum=0.0; i<p; i++) {
        sum+=(double)v[i];
        ans[i]=(float)(sum/(i+1));
    }
    for(i=p; i<n; i++) {
        sum+=(double)(v[i]-v[i-p]);
        ans[i]=(float)(sum/p);
    }
}

void StandardDevS (float ans[], float b[], long p, long n) {
    /* Standard deviation of period p on an n-bar data series */
    long i;  double bi, bip, ub, sb, x;
    for(i=0, ub=sb=0.0; i<p; i++) {
        bi=(double)(b[i]-b[n-1]); ub+=bi; sb+=(bi*bi);
        x=(i+1)*sb-ub*ub;
        ans[i]=(float)((i>1 && x>0.0)?(sqrt(x)/(i+1)):(0.0));
    }
    for(i=p; i<n; i++) {
        bi=(double)(b[i]-b[n-1]); bip=(double)(b[i-p]-b[n-1]);
        ub+=(bi-bip); sb+=(bi*bi-bip*bip);
        x=p*sb-ub*ub;
        ans[i]=(float)((x>0.0)?(sqrt(x)/p):(0.0));
    }
}

void FastD (float fd[], float hi[], float lo[], float cls[],
long m, long n) {
    /* Lane's Stochastic of period m on an n-bar data series */
    float num[3], den[3], temp1, temp2;  long i, j;
    for(i=0; i<3; i++) {
        num[i]=0.5;
        den[i]=1.0;
    }
    for(i=0; i<n; i++) {
        temp1=lo[i]; temp2=hi[i];
        for(j=0; j<m && i-j>=0; j++) {
            if(hi[i-j]>temp2) temp2=hi[i-j];
            if(lo[i-j]<temp1) temp1=lo[i-j];
        }
        for(j=0; j<2; j++) {
            num[j]=num[j+1];
            den[j]=den[j+1];
        }
        num[2]=(cls[i]-temp1)+0.5E-5;
        den[2]=(temp2-temp1)+1.0E-5;
        fd[i]=(num[0]+num[1]+num[2])/(den[0]+den[1]+den[2]);
    }
}

void OnBalanceVol (float cls[], float vol[], float obv[], long nb) {
    /* Granville's On Balance Volume indicator */
    long i;  float sum, a, b;
    for(sum=0.0, obv[0]=0.0, i=1; i<nb; i++) {
        if((a=cls[i]) > (b=cls[i-1])) sum += vol[i];
        else if(a < b) sum -= vol[i];
        obv[i]=sum;
    }
}

void AvgDirMov (float hi[], float lo[], float cls[], long nb,
long len, float adx[]) {
    /* Wells Wilder's traditional ADX indicator */
    long i;  float tiny, coeff, r1, r2, r3, tr, plusdm, minusdm;
    float trlen, plusdmlen, minusdmlen, plusdi, minusdi;
    float didiff, disum, dx, avgdx;
    tiny=1.0E-10; coeff=(len-1.0)/len; adx[0]=0.0;
    trlen=0.0; plusdmlen=0.0; minusdmlen=0.0; avgdx=0.0;
    for(i=1; i<nb; i++) {
        r1=hi[i]-lo[i]; r2=hi[i]-cls[i-1]; r3=cls[i-1]-lo[i];
        tr=max(r1,max(r2,r3)); plusdm=0.0; minusdm=0.0;
        if(hi[i]-hi[i-1]>lo[i-1]-lo[i]) plusdm=max(hi[i]-hi[i-1],0.0);
        if(lo[i-1]-lo[i]>hi[i]-hi[i-1]) minusdm=max(lo[i-1]-lo[i],0.0);
        trlen=coeff*trlen+tr;
        plusdmlen=coeff*plusdmlen+plusdm;
        minusdmlen=coeff*minusdmlen+minusdm;
        plusdi=floor(100.0*plusdmlen/(trlen+tiny));
        minusdi=floor(100.0*minusdmlen/(trlen+tiny));
        didiff=fabs(plusdi-minusdi); disum=plusdi+minusdi;
        dx=floor(100.0*didiff/(disum+tiny));
        avgdx=floor(((len-1.0)*avgdx+dx)/len);
        adx[i]=avgdx;
    }
}

/*---------------------------------------------------------------------------
c  Functions implementing indicators on individual bars.
*/

float AvgTrueRange (float hi[], float lo[], float cls[], long m, long cb) {
    /* Computes the average true range, a measure of volatility.
    .  hi     - in:  series hi[0..cb..] of high prices
    .  lo     - in:  series lo[0..cb..] of low prices
    .  cls    - in:  series cls[0..cb..] of closing prices
    .  m      - in:  period used for average
    .  cb     - in:  current bar (for which result is desired)
    .  return - out: average true range at the current bar
    */
    long i, k;  float ans, tr, r1, r2, r3;
    for(ans=0.0, i=k=max(1,cb-m+1); i<=cb; i++) {
        r1=hi[i]-lo[i];
        r2=hi[i]-cls[i-1];
        r3=cls[i-1]-lo[i];
        tr=max(r1,max(r2,r3));
        ans+=tr;
    }
    return(ans/(cb-k+1));
}

float Average (float v[], long n, long cb) {
    /* Simple n-period moving average at bar cb */
    long i, k;  double sum;
    for(sum=0.0, i=k=max(0,cb-n+1); i<=cb; i++) sum+=(double)v[i];
    return((float)(sum/(cb-k+1)));
}

float XAverage (float v[], long n, long cb) {
    /* Exponential n-period moving average at bar cb */
    long i;  double fac, sum1, sum2;
    for(sum1=sum2=0.0, fac=2.0/(1.0+n), i=max(0,cb-3*n); i<=cb; i++) {
        sum1+=(fac*((double)v[i]-sum1));
        sum2+=(fac*(1.0-sum2));
    }
    return((float)(sum1/sum2));
}

float Highest (float v[], long n, long cb) {
    /* Highest value in past n bars relative to bar cb */
    float ans;  long i;
    for(ans=v[cb], i=max(0,cb-n+1); i<cb; i++) { if(v[i]>ans) ans=v[i]; }
    return(ans);
}

float Lowest (float v[], long n, long cb) {
    /* Lowest value in past n bars relative to bar cb */
    float ans;  long i;
    for(ans=v[cb], i=max(0,cb-n+1); i<cb; i++) { if(v[i]<ans) ans=v[i]; }
    return(ans);
}

long HighestBar (float v[], long n, long cb) {
    /* Bar with highest value in last n bars relative to bar cb */
    long ans, i;  float a;
    for(a=v[cb], ans=cb, i=max(0,cb-n+1); i<cb; i++)
        { if(v[i]>=a) { a=v[i]; ans=i; } }
    return(ans);
}

long LowestBar (float v[], long n, long cb) {
    /* Bar with lowest value in last n bars relative to bar cb */
    long ans, i;  float a;
    for(a=v[cb], ans=cb, i=max(0,cb-n+1); i<cb; i++)
        { if(v[i]<=a) { a=v[i]; ans=i; } }
    return(ans);
}

long Compare (float a, float b, float op) {
    /* Tests for a > b when op > 0 and a < b when op < 0 */
    return((op>0.0)?((a>b)?(1):(0)):((a<b)?(1):(0)));
}

float RangePercent (float v[], float x, long n, long cb) {
    /* Location of x in n-bar range of v[] on scale from 0 to 1 */
    long i;  float hi, lo;
    for(hi=lo=v[cb], i=max(0,cb-n+1); i<cb; i++) {
        if(v[i]>hi) hi=v[i];
        if(v[i]<lo) lo=v[i];
    }
    return(((hi-lo)>0.0)?((x-lo)/(hi-lo)):(0.5));
}

float TLValue (float b1, float p1, float b2, float p2, float bx) {
    /* Point value of a trendline, exactly as in TradeStation */
    return(p1+(bx-b1)*(p2-p1)/(b2-b1));
}

float RoundUp (float x, float r) { return(r*ceil(x/r)); }
float RoundDn (float x, float r) { return(r*floor(x/r)); }
float RoundNr (float x, float r) { return(r*floor(0.5+x/r)); }

float TSRound (float a, long n) {
    /* TradeStation-like rounding function */
    switch(n) {
        case 0: return floor(a+0.5);
        case 1: return floor(10.0*a+0.5)/10.0;
        case 2: return floor(100.0*a+0.5)/100.0;
        case 3: return floor(1000.0*a+0.5)/1000.0;
        case 4: return floor(10000.0*a+0.5)/10000.0;
        default: misc_ftlerr("TSRound: invalid n");
    }
    return(0.0);
}

float Correlation (float a[], float b[], long n, long cb) {
    /* At reference bar cb, the n-bar correlation between a and b */
    double ai,bi,ua,ub,sa,sb,rab;  long i;
    for(ua=ub=sa=sb=rab=0.0, i=max(0,cb-n+1); i<=cb; i++) {
        ai=(double)(a[i]-a[cb]); bi=(double)(b[i]-b[cb]);
        ua+=ai; ub+=bi; sa+=ai*ai; sb+=bi*bi; rab+=ai*bi;
    }
    n=cb-max(0,cb-n+1)+1;
    ua=ua/n; ub=ub/n; sa=sa/n-ua*ua; sb=sb/n-ub*ub;
    if(sa>0.0 && sb>0.0) rab=(rab/n-ua*ub)/(sqrt(sa)*sqrt(sb));
    else rab=0.0;
    return((float)rab);
}

float StandardDev (float v[], long n, long cb) {
    /* At reference bar cb, the n-bar standard deviation of v */
    double u,s,t;  long i;
    for(u=s=0.0, i=max(0,cb-n+1); i<=cb; i++) {
        t=(double)(v[i]-v[cb]);
        u+=t; s+=t*t;
    }
    n=cb-max(0,cb-n+1)+1;
    u=u/n; s=s/n-u*u;
    return((float)((s>0.0)?(sqrt(s)):(0.0)));
}

long SwingBar (float *val, float price[], long icb, long mtype,
long ioccur, long istrength, long length) {
    /* Finds a swing high or swing low and returns the bar index
    .  and value.  Works exactly like TradeStation's SwingHigh,
    .  SwingLow, SwingHighBar, and SwingLowBar functions.
    .
    .  Arguments:
    .  val       - out: price at bar where swing high or low was found
    .  price     - in:  series [0..icb..] of prices or data points
    .  icb       - in:  index of current or reference bar
    .  mtype     - in:  swing type sought: 1=high, 2=low
    .  ioccur    - in:  1=most recent, 2=next most recent, etc.
    .  istrength - in:  number of bars on either side of swing bar
    .  length    - in:  number of trailing bars to examine
    .
    .  Returns index of bar at which swing high or swing low was
    .  found; if no swing bar was identified, function returns -1.
    .
    .  Routines called: misc_ftlerr
    */
    long j, found, counter, x, truth, ibar;
    float price1, fac;
    fac=0.0;
    price1=(-1.0);
    switch(mtype) {
	case 1: fac=1.0; break;
	case 2: fac=(-1.0); break;
	default: misc_ftlerr("SwingBar: invalid mtype"); }
    j=istrength; found=FALSE;
    if(j>0) {
	counter=0;
	while(j<length && found==FALSE) {
	    price1=price[icb-j];
	    x=j+1; truth=TRUE;
	    while(truth && x-j<=istrength) {
		if(0.0 < fac*(price[icb-x]-price1)) truth=FALSE;
		x++; }
	    x=j-1;
	    while(truth && j-x<=istrength) {
		if(0.0 <= fac*(price[icb-x]-price1)) truth=FALSE;
		x--; }
	    if(truth) counter++;
	    if(counter>=ioccur) found=TRUE;
	    j++; } }
    if(found) { ibar=icb-(j-1); *val=price1; }
    else { ibar=(-1); *val=0.0; }
    return(ibar);
}

/*---------------------------------------------------------------------------
c  Text plotting functions.
*/

void misc_textplot (FILE *fil, float x[], float y[], long n) {
    /* Writes a simple text-based plot of y[0..n-1] as a function 
    .  of x[0..n-1] to console, pipe, or file.
    */
    char *row[24];
    float ymin, ymax, xmin, xmax;
    long ir, ic, nr=24, nc=78, i;
    /* determine ranges for x and y */
    xmax=xmin=x[0];
    ymax=ymin=y[0];
    for(i=1; i<n; i++) {
        xmax=max(xmax, x[i]);
        xmin=min(xmin, x[i]);
        ymax=max(ymax, y[i]);
        ymin=min(ymin, y[i]);
    }
    /* report any error */
    if(xmax<=xmin) {
        fprintf(fil,"textplot: xmax=%f <= xmin=%f\n",
            (float)xmax, (float)xmin);
        return;
    }
    if(ymax<=ymin) {
        fprintf(fil,"textplot: ymax=%f <= ymin=%f\n",
            (float)ymax, (float)ymin);
        return;
    }
    /* create text drawing area */
    for(ir=0; ir<nr; ir++) {
        row[ir]=(char*)malloc(sizeof(char)*nc);
        if(row[ir]==NULL) misc_ftlerr("textplot: out of memory");
        for(ic=0; ic<=nc-2; ic++) row[ir][ic]=' ';
        row[ir][nc-1]='\0';
    }
    /* draw header row or line */
    sprintf(row[nr-1],"X = %.2f to %.2f   Y = %.2f to %.2f",
        (float)xmin, (float)xmax, (float)ymin, (float)ymax);
    /* draw bottom axis with tickmarks */
    for(ic=0; ic<nc-1; ic++) {
        if(ic%5==0) row[0][ic]='+';
        else row[0][ic]='-';
    }
    /* draw left axis with tickmarks */
    for(ir=0; ir<nr-1; ir++) {
        if(ir%5==0) row[ir][0]='+';
        else row[ir][0]='|';
    }
    /* draw data points */
    for(i=1; i<n; i++) {
        ic=(long)(1.0+(nc-2)*(x[i]-xmin)/(xmax-xmin));
        if(ic>nc-2) ic=nc-2;  if(ic<1) ic=1;
        ir=(long)(1.0+(nr-2)*(y[i]-ymin)/(ymax-ymin));
        if(ir>nr-2) ir=nr-2;  if(ir<1) ir=1;
        row[ir][ic]='*'; /* data point */
    }
    /* write drawing to file, pipe, or console */
    for(ir=nr-1; ir>=0; ir--)
        fprintf(fil,"%s\n",(char*)misc_strtrim(row[ir]));
    /* free drawing area */
    for(ir=0; ir<nr; ir++) free(row[ir]);
}

/*---------------------------------------------------------------------------
c  Miscelaneous mathematical and vector functions.
*/

float misc_trim (float a, float b, float c) {
    /* Clips b to range of a to c */
    if(b<a) return(a);
    if(b>c) return(c);
    return(b);
}

long misc_kgcdeuc (long m, long n) {
    /* Greatest common divisor of m and n by Euclid's method */
    long k;
    while(m>0) {
        if(n>m) { k=m; m=n; n=k; }
        m -= n;
    }
    return(n);
}

long misc_insb (float v[], long nb, long m, long k) {
    /* Inserts new bars (elements) into a data series (vector).
    .  The new bars or data points are initialized to zero.
    .  v      - in:  original data series, v[0..nb-1]
    .           out: updated data series, v[0..nb+m-1]
    .  nb     - in:  number of bars in original series
    .  m      - in:  number of new bars to be inserted
    .  k      - in:  bar at which to begin insertion
    .  return - out: number of bars in updated (output) series
    */
    long j;
    if(nb<0) misc_ftlerr("misc_insb: bad nb");
    if(k<0 || k>=nb) misc_ftlerr("misc_insb: bad k");
    if(m<1) misc_ftlerr("misc_insb: bad m");
    if(k<nb) memmove(v+k+m, v+k, sizeof(float)*(nb-k));
    for(j=0; j<m; j++) v[j+k]= 0.0;
    return(nb+m);
}

double misc_fdis (float x[], float y[], long n) {
    /* Euclidean distance between two vectors */
    double sum, diff;  long i;
    for (sum=0.0, i=0; i<n; i++) {
    	diff=(double)x[i]-(double)y[i];
    	sum+=diff*diff;
    }
    return(sqrt(sum));
}

double misc_fdot (float x[], float y[], long n) {
    /* Dot or scalar product of two vectors */
    double sum;  long i;
    for(sum=0.0, i=0; i<n; i++)
        sum+=(double)x[i]*(double)y[i];
    return(sum);
}

/*---------------------------------------------------------------------------
c  ANSI screen handling functions.
*/

void misc_cmove (int row, int col) {
    /* Moves cursor to specified row and column */
    fprintf(stdout,"\x1B[%d;%dH",(int)row,(int)col);
}

void misc_clrsc (void) {
    /* Clears console screen */
    fprintf(stdout,"\x1B[2J");
}

void misc_attrb (int attrib) {
    /* Sets character attributes:
    .     Reset: 0=Reset (Clears all previously set attributes)
    .     Non-colour attributes: 1=Bright, 2=Dim, 3=Italic, 4=Underline,
    .         5=Blink On, 7=Reverse On, 25=Blink Off, 27=Reverse Off
    .     Colour attributes: Red 31=Fg 41=Bg, Green 32=Fg 42=Bg,
    .         Amber 33=Fg 43=Bg, Blue 34=Fg 44=Bg, Pink 35=Fg 45=Bg,
    .         Turqoise 36=Fg 46=Bg (Fg=Foreground, Bg=Background)
    .  Other than 0, which resets all attributes to their default values,
    .  settings are cumulative.  Note that not all attributes will work
    .  (or work the same way) on all systems or terminal emulators.
    .  Also note that this routine can mung up your console (e.g., if
    .  your console does not like some attribute); should this happen on
    .  Linux, the "reset" command will restore normal console behaviour.
    */
    fprintf(stdout,"\x1B[%dm",(int)attrib);
}

/*---------------------------------------------------------------------------
c  Testing and debugging code (normally turned off with #if 1==0).
*/

#if 1==0
  int main (int nargs, char **args) {
    #if 1==0
      /* user-interactive spot check of misc_julday */
      int mm, md, my;
      while(-1) {
        scanf(stdin,"%d %d %d",&mm,&md,&my);
        printf(stdout,"\n%d\n",misc_julday(mm,md,my));
      }
    #endif
    #if 1==1
      /* test search functions */
      long karr[]={2,2,2,3,3,4,5,5,7,9,10,11,11,11,12,12,12,12,14};
      float farr[19], f; long n= 19, k, kk, kf, i;
      fprintf(stdout,"TESTING: misc_findflt, misc_findlng\n");
      for(i=0; i<n; i++) farr[i]=karr[i];
      for(k=-1; k<18; k+=1) {
        kf=misc_kfindflt(farr,n,f=(float)k);
        if(kf==0 && f<farr[kf]) continue;
        else if(kf==n-1 && f>=farr[kf]) continue;
        else if(f>=farr[kf] && f<farr[kf+1]) continue;
        fprintf(stdout,"Error (misc_kfindflt): %.4f %8d\n",f,kf);
      }
      for(k=-1; k<18; k+=1) {
        kk=misc_kfindlng(karr,19,k);
        if(kk==0 && k<karr[kk]) continue;
        else if(kk==n-1 && k>=karr[kk]) continue;
        else if(k>=karr[kk] && k<karr[kk+1]) continue;
        fprintf(stdout,"Error (misc_kfindlng): %.4f %8ld\n",k,kk);
      }
    #endif
    #if 1==0
      /* test random number and sort functions */
      static long k, n, ndx[1200000], kerr1, kerr2;
      static float f[1200000];
      n=atol(args[1]);			/* size of sort for test */
      misc_randtest();			/* basic test of RNG */
      for(k=0; k<n; k++) f[k]=misc_randflt();
      misc_sndxflt(f, n, ndx);		/* perform sort */
      for(kerr1=kerr2=0, k=1; k<n; k++) {	/* verify sort */
          if(f[ndx[k]]<=f[ndx[k-1]] || ndx[k]<0 || ndx[k]>=n) {
              if(f[ndx[k]]<f[ndx[k-1]] || ndx[k]<0 || ndx[k]>=n)
                  fprintf(stdout, "ERROR: %7ld %7ld %13.8f %13.8f\n",
                      (long)k, (long)ndx[k],
                      (float)f[ndx[k]], (float)f[ndx[k-1]] );
              kerr1++;
              if(ndx[k]<0 || ndx[k]>=n) kerr2++;
          }
      }
      fprintf(stdout,"COUNT KERR1=%d (TIES)\n",(int)kerr1);
      fprintf(stdout,"COUNT KERR2=%d (MUST BE 0)\n",(int)kerr2);
      fflush(stdout);
    #endif
    #if 1==0
      /* user interactive test of routine lgcdeuc */
      long m, n;
      while(-1) {
        fprintf(stdout,"Enter two numbers: ");
        fflush(stdout);
        fscanf(stdin,"%ld %ld",&m,&n);
        fprintf(stdout,"Greatest Common Divisor= %ld\n",
                (long)misc_kgcdeuc(m,n));
        fflush(stdout);
      }
    #endif
    #if 1==0
      /* test some date-related functions */
      /* when modifying change misc_caldat first, test, then misc_julday */
      long iyyyy,mm,idd,k,jd,jda,jdz,iymd;
      jda=misc_julday(1,1,1590);
      jdz=misc_julday(1,1,2270);
      for (k=jda; k<=jdz; k++) {
          misc_caldat(k,&mm,&idd,&iyyyy);
          jd=misc_julday(mm,idd,iyyyy);
          if(k!=jd) {
              fprintf(stdout, "ERROR: k != jd\n  %ld %ld %ld %ld %ld\n",
                  (long)k,(long)jd,(long)mm,(long)idd,(long)iyyyy);
              exit(EXIT_FAILURE);
          }
          iymd=10000*iyyyy+100*mm+idd;
          fprintf(stdout, "%9ld %3ld %3ld %6ld %3ld %3ld %3ld %3ld\n",
            (long)k,(long)mm,(long)idd,(long)iyyyy,
            (long)(misc_datetoser(iymd)-misc_datetoser(misc_nthned(iymd,0))),
            (long)(misc_datetoser(misc_nthned(iymd,1))-misc_datetoser(iymd)),
            (long)(misc_datetoser(misc_nthned(iymd,2))-misc_datetoser(iymd)),
            (long)(misc_dayofweek(10000*iyyyy+100*mm+idd)));
      }
      fflush(stdout);
    #endif
    #if 1==0
      /* test some time related functions */
      long i, j, k, m= 0, ijk, n;
      for(i=0; i<24; i++) {
          for(j=0; j<60; j++) {
              for(k=0; k<60; k++) {
                  ijk= 10000*i + 100*j + k;
                  n= misc_hmstosec(ijk);
                  if(m != n) {
                      fprintf(stdout,"%ld %ld %ld %ld %ld\n",
                          i, j, k, ijk, n, m); }
                  if(ijk != misc_sectohms(n)) {
                      fprintf(stdout,"%ld %ld %ld %ld %ld\n",
                          i, j, k, ijk, n, m); }
                  m++;
              } } }
      fprintf(stdout,"misc_sectohms and misc_hmstosec tested ok\n");
      fflush(stdout);
    #endif
    #if 1==0
      /* test ANSI screen handling functions */
      int k= 0; 
      misc_clrsc(); misc_cmove(5,60); fprintf(stdout,"TEST5\n");
      misc_cmove(7,55); fprintf(stdout,"TEST7\n");
      while(k>=0) {
          fscanf(stdin,"%d",&k);
          misc_attrb(k); fprintf(stdout,"ATTRIB= %d",k);
          fprintf(stdout, "\n");
      }
    #endif
    exit(0);
    return(0);
  }  
#endif


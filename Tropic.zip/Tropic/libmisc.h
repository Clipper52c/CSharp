#ifndef LIBMISC_H
#define LIBMISC_H

/*
c  libmisc.h
c
c  Header file for libmisc.c (utility and misc. functions library).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2008.  All rights reserved.
*/

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/* macros and defines */
#ifndef max
    #define max(a,b) (((a)>(b))?(a):(b))
    #define min(a,b) (((a)<(b))?(a):(b))
#endif
#ifndef TRUE
    #define TRUE (1)
    #define FALSE (0)
#endif

/* error handling and memory functions */
void    misc_ftlerr (char msg[]);
void*   misc_malloc (size_t n);

/* string functions */
char*   misc_strtrim (char str[]);
char*   misc_strupr (char str[]);
char*	misc_strlwr (char str[]);
double	misc_strdbl (char buf[], long n);
long	misc_strlng (char buf[], long n);

/* sorting and searching functions */
long	misc_kfinddtm (long dt[], long tm[], long n, long edt, long etm);
long    misc_kfindflt (float arr[], long n, float val);
long    misc_kfindlng (long iarr[], long n, long ival);
long	misc_hunt (float d[], long n, float x, long k);
void	misc_sndxflt (float farr[], long n, long nndx[]);

/* statistical functions */
void    misc_percentiles (long n, float arr[], long indx[], float pct[]);
void    misc_moment (float data[], long n, float *ave, float *adev,
                float *sdev, float *var, float *skew, float *curt);
void    misc_mommdr (float ans[], float cls[], long m, long n, long icb);
float   misc_cumnrml (float x);
float   misc_invcumnrml (float p);
void    misc_mhist (float bc[], float bf[], float bmin, float bmax,
                long nb, float d[], long nd);

/* psuedorandom number generators */
void    misc_randseed (long iseed);
float   misc_randgau (void);
long    misc_randint (long m, long n);
float   misc_randflt (void);
void	misc_randtest (void);

/* date and time functions */
long    misc_julday (long mm, long idd, long iyyyy);
void    misc_caldat (long julian, long *mm, long *idd, long *iyyyy);
long    misc_datetoser (long ldt);
long    misc_sertodate (long jd);
long    misc_nthned (long ldt, long n);
long    misc_daysleft (long lcurdate, long mm, long iyyyy);
long    misc_incmonth (long ldt);
long    misc_nextbusday (long ldt);
long    misc_dayofweek (long ldt);
long    misc_month (long ldt);
long    misc_dayofmonth (long ldt);
long	misc_dayofyear (long ldt);
long    misc_year (long ldt);
long    misc_hour (long ltm);
long    misc_minute (long ltm);
long    misc_second (long ltm);
long    misc_thirdfriday (long ldt);
long	misc_reldate (long ldt, long n);
long	misc_imon (char cmon[]);
char*	misc_cmon (long imon);
long	misc_iday (char cday[]);
char*	misc_cday (long iday);
long	misc_timediff (long dta, long tma, long dtb, long tmb);
void	misc_reldttm (long *ymd, long *hms, long sec);
long	misc_hmstosec (long ltm);
long	misc_sectohms (long sec);

/* series-based (vectorized) indicator functions */
void    AvgTrueRangeS (float ans[], float hi[], float lo[], float cls[],
                  long m, long n);
void    XAverageS (float ans[], float v[], long p, long n);
void    AverageS (float ans[], float v[], long p, long n);
void    StandardDevS (float ans[], float b[], long p, long n);
void    FastD (float fd[], float hi[], float lo[], float cls[],
                  long m, long n);
void	OnBalanceVol (float cls[], float vol[], float obv[], long nb);
void    AvgDirMov (float hi[], float lo[], float cls[],
                  long nb, long len, float adx[]);

/* single-point indicator and other related functions */
float   AvgTrueRange (float hi[], float lo[], float cls[], long m, long cb);
float   Average (float v[], long n, long cb);
float   XAverage (float v[], long n, long cb);
float   Highest (float v[], long n, long cb);
float   Lowest (float v[], long n, long cb);
long    HighestBar (float v[], long n, long cb);
long    LowestBar (float v[], long n, long cb);
long    Compare (float a, float b, float op);
float   RangePercent (float v[], float x, long n, long cb);
float   TLValue (float b1, float p1, float b2, float p2, float bx);
float   RoundUp (float x, float r);
float   RoundDn (float x, float r);
float   RoundNr (float x, float r);
float   TSRound (float a, long n);
float   Correlation (float a[], float b[], long n, long cb);
float   StandardDev (float v[], long n, long cb);
long	SwingBar (float *val, float price[], long icb, long mtype,
                  long ioccur, long istrength, long length);

/* simple text-based plotting functions */
void    misc_textplot (FILE *fil, float x[], float y[], long n);

/* miscelaneous mathematical and vector functions */
float	misc_trim (float a, float b, float c);
long	misc_kgcdeuc (long m, long n);
long	misc_insb (float v[], long nb, long m, long k);
double	misc_fdis (float x[], float y[], long n);
double	misc_fdot (float x[], float y[], long n);

/* ANSI screen handling functions */
void	misc_cmove (int row, int col);
void	misc_clrsc (void);
void	misc_attrb (int attrib);

#ifdef __cplusplus
};
#endif

#endif /* LIBMISC_H */


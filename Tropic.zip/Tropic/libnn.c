/*
c  libnn.c
c
c  Neural network and neurogenetic function library.
c
c  Note that not all routines are thread-safe due to the
c  use of nt1errno, a module-global static variable used to
c  store error codes.  This can be easily modified.
c
c  Revised: 2008.07.24
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 1993, 2008.  All Rights Reserved.
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "libnn.h"

/*---------------------------------------------------------------------------
c  ANSI screen handling functions.
*/

void nt1erase (void)
{
    /* Clears console screen */
    fprintf(stdout,"\x1B[2J");
}

void nt1cursor (int row, int col)
{
    /* Moves cursor to specified row and column */
    fprintf(stdout,"\x1B[%d;%dH",(int)row,(int)col);
}

void nt1attrib (int attrib)
{
    /* Sets character attributes for subsequent writes to screen:
    .     Reset: 0=Reset (Clears all previously set attributes)
    .     Non-colour attributes: 1=Bright, 2=Dim, 3=Italic, 4=Underline,
    .         5=Blink On, 7=Reverse On, 25=Blink Off, 27=Reverse Off
    .     Colour attributes: Red 31=Fg 41=Bg, Green 32=Fg 42=Bg,
    .         Amber 33=Fg 43=Bg, Blue 34=Fg 44=Bg, Pink 35=Fg 45=Bg,
    .         Turqoise 36=Fg 46=Bg (Fg=Foreground, Bg=Background)
    .  Other than 0, which resets all attributes to their default values,
    .  settings are cumulative.  Note that not all attributes will work
    .  (or work the same way) on all systems or terminal emulators.
    .  Also note that this routine can mung up your console (e.g., if
    .  your console does not like some attribute); should this happen on
    .  Linux, the "reset" command will restore normal console behaviour.
    */
    fprintf(stdout,"\x1B[%dm",(int)attrib);
}

/*---------------------------------------------------------------------------
c  Error handler functions.
*/

void nt1ftlerr (char *msg)
{
    /* Displays error message and terminates program */
    fprintf (stderr, "\nERROR: %s\n", (char*)msg);
    exit (EXIT_FAILURE);
}

/* Internal variable used to hold error code */
static int nt1errno = 0;

void nt1seterrc (int errc)
{
    /* Sets internal error code */
    nt1errno = errc;
}

int nt1errc (void)
{
    /* Returns internal error code and then clears it.  This is how
    .  one checks for errors in previous function calls.  A non-zero
    .  error code (return value) implies an error has occurred.
    .  The error description can be obtained by passing the
    .  error code to nt1errm (implemented immediately below).
    */
    int errc;
    errc = nt1errno;
    nt1errno = 0;
    return errc;
}

char* nt1errm (int errc)
{
    /* Returns an error description given the error code */
    switch (errc) {
	case 0:  return "No error detected";
	case 1:  return "Insufficient memory available";
	case 2:  return "Cannot open definition file for reading";
	case 3:  return "Error reading definition file";
	case 4:  return "Too many or few layers have been specified";
	case 5:  return "Data missing from definition file";
	case 6:  return "Cannot open definition file for writing";
	case 7:  return "Error writing definition file";
	case 8:  return "Too few neurons specified for some layer";
	case 9:  return "Null pointer argument error";
	case 10: return "Invalid transfer function specified";
	case 11: return "Invalid error function specified";
	case 12: return "Cannot open or create factbase file";
	case 13: return "Error reading from factbase file";
	case 14: return "Parameter mismatch in factbase initialization";
	case 15: return "Error writing to factbase file";
	case 16: return "Error deleting factbase file";
	case 17: return "Error positioning factbase file";
	case 18: return "Cannot open temporary file";
	case 19: return "Error buffering file";
	case 20: return "Error writing temporary file";
	case 21: return "Error reading temporary file";
	case 22: return "Argument to function out-of-range";
	case 23: return "Cannot open vector file for writing";
	case 24: return "Error writing vector file";
	case 25: return "Cannot open vector file for reading";
	case 26: return "Mismatched vector sizes";
	case 27: return "Error reading vector file";
    }
    return "Invalid error code";
}

/*---------------------------------------------------------------------------
c  Mathematical functions (scalar or inner product).
*/

double nt1sp (double *x, double *y, int n)
{
    /* Returns the scalar (dot) product of vectors x[] and y[] */
    double sum = 0.0;
    while (n--)
	sum += *x++ * *y++;
    return sum;
}

double nt1spm (double *x, double *y, int n, int mx, int my)
{
    /* Returns the scalar (dot) product of x[] and y[] with
    .  strides mx and my
    */
    double sum = 0.0;
    while (n--) {
    	sum += *x * *y;
	x += mx;
	y += my;
    }
    return sum;
}

/*---------------------------------------------------------------------------
c  General neural network functions.
*/

void nt1disp (NEURALNET *nn)
{
    /* Disposes of the neural network pointed to by nn (previously
    .  created using nt1new or nt1load).  In other words, frees all
    .  allocated memory and closes any open files.
    */
    int l;

    /* check for null pointer */
    if (nn == NULL) return;

    /* close definition file */
    if (nn->def_file) fclose (nn->def_file);

    /* free vector memory */
    if (nn->t)		free (nn->t);
    if (nn->errss)	free (nn->errss);
    if (nn->rsq)	free (nn->rsq);
    if (nn->u_out)	free (nn->u_out);
    if (nn->s_out)	free (nn->s_out);
    if (nn->u_tgt)	free (nn->u_tgt);
    if (nn->s_tgt)	free (nn->s_tgt);
    if (nn->phits)	free (nn->phits);
    if (nn->ivmin)	free (nn->ivmin);
    if (nn->ivmax)	free (nn->ivmax);
    if (nn->ovmin)	free (nn->ovmin);
    if (nn->ovmax)	free (nn->ovmax);

    /* free layer-by-vector memory */
    for (l = 0; l < nn->nl; l++) {
	if (nn->d[l])	free (nn->d[l]);
	if (nn->v[l])	free (nn->v[l]);
    }

    /* free layer-by-matrix memory */
    for (l = 0; l < nn->nl-1; l++) {
	if (nn->w[l])	free (nn->w[l]);
    }

    /* free neural structure memory */
    free (nn);
}


#define MINLAYERS		2
#define MINNEURONSINLAYER	1
#define DEFAULTDISPERSION	1.0

#define error_return(a) 	\
{ 				\
    nt1disp (nn);		\
    nt1seterrc (a);		\
    return NULL;		\
}

static void random_weights (NEURALNET *nn, double disp)
{
    /* Sets all connection weights to initial (random) values.  That is,
    .  this routine erases the network's memory making it ready for new
    .  learning.
    */
    double weight, randmax, sum, bias;  int l, ij, cnt, nelts;

    /* compute random connection weight matrices */
    randmax = RAND_MAX;
    for (l = 0; l < nn->nl-1; l++) {
	nelts = (nn->n[l]+1) * (nn->n[l+1]);
	bias = 0.0;
	for (ij = 0; ij < nelts; ij++) {
	    sum = 0.0;
	    for (cnt = 0; cnt < 9; cnt++) sum += (rand () / randmax);
	    weight = disp * (sum - 4.5) / 0.84;
	    nn->w[l][ij] = weight;
	    bias += weight;
	}
	bias /= (double) nelts;
	for (ij = 0; ij < nelts; ij++) nn->w[l][ij] -= bias;
    }
}

NEURALNET* nt1new (int nl, int *n)
{
    /* Returns a pointer to a new neural network with default properties.
    .  A null pointer is returned if the network cannot be created.
    .  Arguments:
    .    nl   - number of layers (input)
    .    n    - array containing the number of neurons in each layer
    .             beginning with the input layer neuron count in n[0]
    .             and finishing with the output layer neuron count
    .             in n[nl-1] (input)
    */
    NEURALNET *nn;  int l, i, nelts;

    /* allocate neural network structure */
    if ((nn = (NEURALNET *) calloc (1, sizeof(NEURALNET))) == NULL)
	error_return (1);

    /* copy size information into structure */
    if (nl < MINLAYERS || nl > MAXLAYERS) error_return (4);
    nn->nl = nl;
    for (l = 0; l < nl; l++) {
	if (n[l] < MINNEURONSINLAYER) error_return (8);
	nn->n[l] = n[l];
    }

    /* allocate arrays and vectors */
    nelts = nn->n[nn->nl-1];
    nn->errss = (double *) calloc (nelts, sizeof(double));
    nn->rsq   = (double *) calloc (nelts, sizeof(double));
    nn->u_out = (double *) calloc (nelts, sizeof(double));
    nn->s_out = (double *) calloc (nelts, sizeof(double));
    nn->u_tgt = (double *) calloc (nelts, sizeof(double));
    nn->s_tgt = (double *) calloc (nelts, sizeof(double));
    nn->phits = (double *) calloc (nelts, sizeof(double));
    nn->t     = (double *) calloc (nelts, sizeof(double));
    nn->ovmin = (double *) calloc (nelts, sizeof(double));
    nn->ovmax = (double *) calloc (nelts, sizeof(double));
    if (!nn->errss || !nn->rsq || !nn->u_out || !nn->s_out ||
      !nn->u_tgt || !nn->s_tgt || !nn->phits || !nn->t ||
      !nn->ovmin || !nn->ovmax)
	error_return (1);
    nelts = nn->n[0];
    nn->ivmin = (double *) calloc (nelts, sizeof(double));
    nn->ivmax = (double *) calloc (nelts, sizeof(double));
    if (!nn->ivmin || !nn->ivmax) error_return (1);
    for (l = 0; l < nn->nl; l++) {
	nelts = nn->n[l] + 1;
	nn->v[l] = (double *) calloc (nelts, sizeof(double));
	nn->d[l] = (double *) calloc (nelts, sizeof(double));
	if (!nn->v[l] || !nn->d[l]) error_return (1);
    }
    for (l = 0; l < nn->nl-1; l++) {
	nelts = (nn->n[l]+1) * (nn->n[l+1]);
	nn->w[l] = (double *) calloc (nelts, sizeof(double));
	if (!nn->w[l]) error_return (1);
    }

    /* set default parameters */
    nn->maxruns = 12000;	/* maximum number of runs through facts */
    nn->lrate_dynamic = 0;      /* dynamic learning adaptation flag (off) */
    nn->lrate = 0.25;           /* global learning rate */
    nn->lrlimit = 1.25;         /* learning rate limit */
    nn->tol = 0.10;             /* error tolerance for hit counts */
    nn->ovrlrnthrsh = 0.0;      /* overlearning threshold (off) */
    nn->traintol = 0.0;         /* training tolerance (off) */
    nn->efs = 1;                /* error function selector (sums-of-squares) */
    nn->lasttrainr = -9.99;     /* last training r value (none) */
    nn->lasttestr = -9.99;      /* last testing r value (none) */
    nn->r_stop = 1.0;           /* r value at which to stop training (none) */

    /* randomize weights */
    random_weights (nn, DEFAULTDISPERSION);

    /* set default layer-specific learning rate multipliers */
    for (l = 0; l < nn->nl-1; l++)
	nn->lrmul[l] = pow (1.189207115, (nn->nl-2-l));

    /* set default transfer function selectors */
    for (l = 0; l < nn->nl; l++) {
	if (l == 0) nn->tfs[l] = 5;	/* linear inputs */
	else nn->tfs[l] = 1;		/* standard sigmoids */
    }

    /* set default input variable scaling */
    for (i = 0; i < nn->n[0]; i++) {
	nn->ivmin[i] = -1.0;
	nn->ivmax[i] = 1.0;
    }

    /* set default output (target) variable scaling */
    for (i = 0; i < nn->n[nn->nl-1]; i++) {
	nn->ovmin[i] = 0.0;
	nn->ovmax[i] = 1.0;
    }

    /* normal return */
    return nn;
}

#undef error_return

#define error_return(a) 	\
{ 				\
    nt1disp (nn);		\
    nt1seterrc (a);		\
    return NULL;		\
}

static int defrderr (NEURALNET *nn)
{
    /* Used internally by nt1load, below */
    int rc, test;
    rc = fscanf (nn->def_file, "%d", &test);
    if (feof(nn->def_file) || ferror(nn->def_file)) return -1;
    if (rc != 1 || test != 9999) return -1;
    return 0;
}

NEURALNET* nt1load (char *fname)
{
    /* Loads a neural network from the specified file (fname),
    .  previously created using nt1save, and returns a pointer
    .  to the newly loaded neural network.    
    */
    NEURALNET *nn;  char lnbuf[80];
    int readcount, l, ij, i, nelts, niv, ntv, itemp;

    /* allocate neural network structure */
    if ((nn = (NEURALNET *) calloc (1, sizeof(NEURALNET))) == NULL)
	error_return (1);

    /* open network definition file */
    if ((nn->def_file = fopen (fname, "rt")) == NULL)
	error_return (2);

    readcount = 0;

    /* loop through file extracting data */
    while (fscanf (nn->def_file, "%s", lnbuf) == 1) {

	/* read network size and allocate array memory */
	if (strcmp (lnbuf, "LAYERS") == 0) {
	    fscanf (nn->def_file, "%d", &nn->nl);
	    if (defrderr (nn)) error_return (3);
	    if (nn->nl < MINLAYERS || nn->nl > MAXLAYERS) error_return (4);
	    readcount++;
	}
	if (strcmp (lnbuf, "NEURONS") == 0) {
	    for (l = 0; l < nn->nl; l++)
		fscanf (nn->def_file, "%d", &nn->n[l]);
	    if (defrderr (nn)) error_return (3);
	    nelts = nn->n[nn->nl-1];
	    nn->errss = (double *) calloc (nelts, sizeof(double));
	    nn->rsq   = (double *) calloc (nelts, sizeof(double));
	    nn->u_out = (double *) calloc (nelts, sizeof(double));
	    nn->s_out = (double *) calloc (nelts, sizeof(double));
	    nn->u_tgt = (double *) calloc (nelts, sizeof(double));
	    nn->s_tgt = (double *) calloc (nelts, sizeof(double));
	    nn->phits = (double *) calloc (nelts, sizeof(double));
	    nn->t     = (double *) calloc (nelts, sizeof(double));
	    nn->ovmin = (double *) calloc (nelts, sizeof(double));
	    nn->ovmax = (double *) calloc (nelts, sizeof(double));
	    if (!nn->errss || !nn->rsq || !nn->u_out || !nn->s_out ||
	      !nn->u_tgt || !nn->s_tgt || !nn->phits || !nn->t ||
	      !nn->ovmin || !nn->ovmax)
		error_return (1);
	    nelts = nn->n[0];
	    nn->ivmin = (double *) calloc (nelts, sizeof(double));
	    nn->ivmax = (double *) calloc (nelts, sizeof(double));
	    if (!nn->ivmin || !nn->ivmax) error_return (1);
	    for (l = 0; l < nn->nl; l++) {
		nelts = nn->n[l] + 1;
		nn->v[l] = (double *) calloc (nelts, sizeof(double));
		nn->d[l] = (double *) calloc (nelts, sizeof(double));
		if (!nn->v[l] || !nn->d[l]) error_return (1);
	    }
	    for (l = 0; l < nn->nl-1; l++) {
		nelts = (nn->n[l]+1) * (nn->n[l+1]);
		nn->w[l] = (double *) calloc (nelts, sizeof(double));
		if (!nn->w[l]) error_return (1);
	    }
	    readcount++;
	}

	/* read connection weight matrices */
	if (strcmp (lnbuf, "WEIGHTS") == 0) {
	    for (l = 0; l < nn->nl-1; l++) {
		nelts = (nn->n[l]+1) * (nn->n[l+1]);
		for (ij = 0; ij < nelts; ij++)
		    fscanf (nn->def_file, "%lf", nn->w[l]+ij);
	    }
	    if (defrderr (nn)) error_return (3)
	    readcount++;
	}

	/* read learning parameters */
	if (strcmp (lnbuf, "LEARNPARMS") == 0) {
	    fscanf (nn->def_file, "%d", &nn->lrate_dynamic);
	    fscanf (nn->def_file, "%lf", &nn->lrlimit);
	    fscanf (nn->def_file, "%lf", &nn->lrate);
	    for (l = 0; l < nn->nl-1; l++)
		fscanf (nn->def_file, "%lf", &nn->lrmul[l]);
	    if (defrderr (nn)) error_return (3);
	    readcount++;
	}

	/* read transfer function selectors */
	if (strcmp (lnbuf, "TRANSFERS") == 0) {
	    for (l = 0; l < nn->nl; l++)
		fscanf (nn->def_file, "%d", &nn->tfs[l]);
	    if (defrderr (nn)) error_return (3);
	    readcount++;
	}

	/* read error function selector */
	if (strcmp (lnbuf, "ERRORFUN") == 0) {
	    fscanf (nn->def_file, "%d", &nn->efs);
	    if (defrderr (nn)) error_return (3);
	    readcount++;
	}

	/* read miscelaneous parameters */
	if (strcmp (lnbuf, "MISCPARMS") == 0) {
	    fscanf (nn->def_file, "%d", &nn->maxruns);
	    fscanf (nn->def_file, "%lf", &nn->r_stop);
	    fscanf (nn->def_file, "%lf", &nn->tol);
	    fscanf (nn->def_file, "%lf", &nn->ovrlrnthrsh);
	    fscanf (nn->def_file, "%lf", &nn->traintol);
	    fscanf (nn->def_file, "%lf", &nn->lasttrainr);
	    fscanf (nn->def_file, "%lf", &nn->lasttestr);
	    if (defrderr (nn)) error_return (3);
	    readcount++;
	}

	/* read scaling data */
	if (strcmp (lnbuf, "SCALING") == 0) {
	    fscanf (nn->def_file, "%d %d", &niv, &ntv);
	    if (niv != nn->n[0] || ntv != nn->n[nn->nl-1]) error_return (3);
	    for (i = 0; i < niv; i++) {
		fscanf (nn->def_file, "%d %lg %lg",
		    &itemp, nn->ivmin+i, nn->ivmax+i);
		if (itemp != i+1) error_return (3);
	    }
	    for (i = 0; i < ntv; i++) {
		fscanf (nn->def_file, "%d %lg %lg",
		    &itemp, nn->ovmin+i, nn->ovmax+i);
		if (itemp != i+1) error_return (3);
	    }
	    if (defrderr (nn)) error_return (3);
	    readcount++;
	}

    /* end of data extraction loop */
    }

    /* check that all data have been read */
    if (readcount != 8) error_return (5);

    /* close internal network definition file and return */
    fclose (nn->def_file);
    nn->def_file = NULL;
    return nn;
}

#undef error_return

#define error_return(a)				\
{						\
    nt1seterrc (a);				\
    if (nn->def_file) fclose (nn->def_file);	\
    nn->def_file = NULL;			\
    return -1;					\
}

int nt1save (NEURALNET *nn, char *fname)
{
    /* Saves a neural network pointed to by nn to the file specified
    .  by fname.  A saved neural network may later be loaded from
    .  the file using nt1load.
    */
    int l, i, ij, nelts;

    /* check for null pointer */
    if (nn == NULL) {
	nt1seterrc (9);
	return -1;
    }

    /* open definition file and write network size */
    if ((nn->def_file = fopen (fname, "wt")) == NULL)
	error_return (6);
    fprintf (nn->def_file, "DEFINITION\nLAYERS\n");
    fprintf (nn->def_file, "%d\n", nn->nl);
    fprintf (nn->def_file, "9999\n");
    fprintf (nn->def_file, "NEURONS\n");
    for (l = 0; l < nn->nl; l++)
	fprintf (nn->def_file, "%d\n", nn->n[l]);
    fprintf (nn->def_file, "9999\n");

    /* write connection weight matrices */
    fprintf (nn->def_file, "WEIGHTS\n");
    for (l = 0; l < nn->nl-1; l++) {
	nelts = (nn->n[l]+1) * (nn->n[l+1]);
	for (ij = 0; ij < nelts; ij++) {
	    fprintf (nn->def_file, "%.7lf\n", nn->w[l][ij]);
	}
    }
    fprintf (nn->def_file, "9999\n");

    /* write learning parameters */
    fprintf (nn->def_file, "LEARNPARMS\n");
    fprintf (nn->def_file, "%d\n", nn->lrate_dynamic);
    fprintf (nn->def_file, "%.7lf\n", nn->lrlimit);
    fprintf (nn->def_file, "%.7lf\n", nn->lrate);
    for (l = 0; l < nn->nl-1; l++)
	fprintf (nn->def_file, "%.7lf\n", nn->lrmul[l]);
    fprintf (nn->def_file, "9999\n");

    /* write transfer function selectors */
    fprintf (nn->def_file, "TRANSFERS\n");
    for (l = 0; l < nn->nl; l++)
	fprintf (nn->def_file, "%d\n", nn->tfs[l]);
    fprintf (nn->def_file, "9999\n");

    /* write error function selector */
    fprintf (nn->def_file, "ERRORFUN\n");
    fprintf (nn->def_file, "%d\n", nn->efs);
    fprintf (nn->def_file, "9999\n");

    /* write other parameters */
    fprintf (nn->def_file, "MISCPARMS\n");
    fprintf (nn->def_file, "%d\n", nn->maxruns);
    fprintf (nn->def_file, "%.7lf\n", nn->r_stop);
    fprintf (nn->def_file, "%.7lf\n", nn->tol);
    fprintf (nn->def_file, "%.7lf\n", nn->ovrlrnthrsh);
    fprintf (nn->def_file, "%.7lf\n", nn->traintol);
    fprintf (nn->def_file, "%.7lf\n", nn->lasttrainr);
    fprintf (nn->def_file, "%.7lf\n", nn->lasttestr);
    fprintf (nn->def_file, "9999\n");

    /* write scaling information */
    fprintf (nn->def_file, "SCALING\n");
    fprintf (nn->def_file, "%d\n%d\n", nn->n[0], nn->n[nn->nl-1]);
    for (i = 0; i < nn->n[0]; i++)
	fprintf (nn->def_file, "%5d %20.10g %20.10g\n",
	    i+1, nn->ivmin[i], nn->ivmax[i]);
    for (i = 0; i < nn->n[nn->nl-1]; i++)
	fprintf (nn->def_file, "%5d %20.10g %20.10g\n",
	    i+1, nn->ovmin[i], nn->ovmax[i]);
    fprintf (nn->def_file, "9999\n");

    /* test for error and close definition file */
    if (ferror (nn->def_file)) error_return (7);
    fclose (nn->def_file);
    nn->def_file = NULL;
    return 0;
}

#undef error_return

/*---------------------------------------------------------------------------
c  Property get and set functions.
*/

void nt1set_seed (int seed)
{
    /* Seeds the random number generator */
    srand (seed);
}

void nt1set_randw (NEURALNET *nn, double disp)
{
    /* Generates random connection weights to initialize the neural
    .  network.  Also used to wipe a network's memory or learning.
    */
    double weight, randmax, sum, bias;  int l, ij, cnt, nelts;

    if (nn == NULL) return;

    /* randomize connection weight matrices */
    randmax = RAND_MAX;
    for (l = 0; l < nn->nl-1; l++) {
        nelts = (nn->n[l]+1) * (nn->n[l+1]);
        bias = 0.0;
        for (ij = 0; ij < nelts; ij++) {
            sum = 0.0;
            for (cnt = 0; cnt < 9; cnt++) sum += (rand () / randmax);
            weight = disp * (sum - 4.5) / 0.84;
            nn->w[l][ij] = weight;
            bias += weight;
        }
        bias /= (double) nelts;
        for (ij = 0; ij < nelts; ij++) nn->w[l][ij] -= bias;
    }
}

void nt1set_lrate (NEURALNET *nn, double lrate)
{
    /* Sets the learning rate */
    if (nn == NULL) return;
    nn->lrate = lrate;
}

void nt1set_lrmul (NEURALNET *nn, int layer, double lrmul)
{
    /* Sets the learning rate multiplier for the specified layer */
    if (nn == NULL) return;
    if (layer >= 0 || layer < nn->nl-1)  nn->lrmul[layer] = lrmul;
}

void nt1set_ldyn (NEURALNET *nn, int ldyn_flag)
{
    /* Sets the dynamic learning rate adjustment flag */
    if (nn == NULL) return;
    nn->lrate_dynamic = ldyn_flag;
}

void nt1set_lrlim (NEURALNET *nn, double lrlim)
{
    /* Sets an upper limit on the learning rate.  Useful with
    .  dynamic learning rate adjustment.
    */
    if (nn == NULL) return;
    nn->lrlimit = lrlim;
}

void nt1set_errfun (NEURALNET *nn, int errfun_id)
{
    /* Sets the error function used for training feedback */
    if (nn == NULL) return;
    nn->efs = errfun_id;
}

void nt1set_trfun (NEURALNET *nn, int layer, int trfun_id)
{
    /* Sets the transfer function used in the specified layer */
    if (nn == NULL) return;
    if (layer >= 0 && layer < nn->nl)  nn->tfs[layer] = trfun_id;
}

void nt1set_olt (NEURALNET *nn, double olt)
{
    /* Sets the overlearning threshold */
    if (nn == NULL) return;
    nn->ovrlrnthrsh = olt;
}

void nt1set_tt (NEURALNET *nn, double tt)
{
    /* Sets the training tolerance */
    if (nn == NULL) return;
    nn->traintol = tt;
}

void nt1set_tol (NEURALNET *nn, double tol)
{
    /* Sets the tolerance used when reporting statistics */
    if (nn == NULL) return;
    nn->tol = tol;
}

void nt1set_test (NEURALNET *nn, int test_flag)
{
    /* Sets the test-versus-train flag */
    if (nn == NULL) return;
    nn->testmode = test_flag;
}

void nt1set_iscale (NEURALNET *nn, int neuron, double ivmin, double ivmax)
{
    /* Sets the scaling for the specified input neuron */
    if (nn == NULL) return;
    if (neuron >= 0 && neuron < nn->n[0]) {
        nn->ivmin[neuron] = ivmin;
        nn->ivmax[neuron] = ivmax;
    }
}

void nt1set_oscale (NEURALNET *nn, int neuron, double ovmin, double ovmax)
{
    /* Sets the scaling for the specified output neuron */
    if (nn == NULL) return;
    if (neuron >= 0 && neuron < nn->n[nn->nl-1]) {
        nn->ovmin[neuron] = ovmin;
        nn->ovmax[neuron] = ovmax;
    }
}

void nt1set_inputv (NEURALNET *nn, float *ivars)
{
    /* Feeds data vector ivar[] to the input layer */
    int i;  double temp;
    if (nn == NULL) return;
    for (i = 0; i < nn->n[0]; i++) {
        temp = nn->ivmax[i] - nn->ivmin[i];
        if (temp <= 0.0) nn->v[0][i] = 0.0;
        else nn->v[0][i] = 2.0 * (ivars[i] - nn->ivmin[i]) / temp - 1.0;
        /* if (nn->v[0][i] < -5.0) nn->v[0][i] = -5.0; */
	/* if (nn->v[0][i] > 5.0) nn->v[0][i] = 5.0; */
    }
}

void nt1set_targv (NEURALNET *nn, float *dvars)
{
    /* Sets the target vector against which the network is trained.
    .  This vector will be of length 1 for a network with only
    .  one output neuron.
    */
    int i;  double temp;
    if (nn == NULL) return;
    for (i = 0; i < nn->n[nn->nl-1]; i++) {
        temp = nn->ovmax[i] - nn->ovmin[i];
        if (temp <= 0.0) nn->t[i] = 0.0;
        else nn->t[i] = (dvars[i] - nn->ovmin[i]) / temp;
        /* if (nn->t[i] < 0.0) nn->t[i] = 0.0; */
        /* if (nn->t[i] > 1.0) nn->t[i] = 1.0; */
    }
}

void nt1set_extra (NEURALNET *nn, int nbyte, int pos, void *ed)
{
    /* Sets any extra data you want associated with the network */
    if (nn == NULL) return;
    if (pos >= 0 && pos + nbyte <= MAXED)
        memcpy (nn->exdata + pos, ed, nbyte);
    else
        memset (ed, 0, nbyte);
}

int nt1get_nlayers (NEURALNET *nn)
{
    /* Returns the number of layers in the neural network */
    if (nn == NULL) return -1;
    return nn->nl;
}

int nt1get_neurons (NEURALNET *nn, int layer)
{
    /* Returns the number of neurons in the specified layer */
    if (nn == NULL) return -1;
    if (layer >= 0 && layer < nn->nl) return nn->n[layer];
    else return 0;
}

int nt1get_trfun (NEURALNET *nn, int layer)
{
    /* Returns the transfer function employed for the specified layer */
    if (nn == NULL) return -1;
    if (layer >= 0 && layer < nn->nl) return nn->tfs[layer];
    else return 0;
}

int nt1get_errfun (NEURALNET *nn)
{
    /* Returns the error feedback function */
    if (nn == NULL) return -1;
    return nn->efs;
}

int nt1get_nfacts (NEURALNET *nn)
{
    /* Returns the number of facts on which the neural network
    .  has been tested or trained.
    */
    if (nn == NULL) return -1;
    return nn->nfacts;
}

int nt1get_ldyn (NEURALNET *nn)
{
    /* Returns the dynamic learning rate adjustment flag */
    if (nn == NULL) return -1;
    return nn->lrate_dynamic;
}

double nt1get_lrate (NEURALNET *nn)
{
    /* Returns the current learning rate */
    if (nn == NULL) return 0.0;
    return nn->lrate;
}

double nt1get_lrmul (NEURALNET *nn, int layer)
{
    /* Returns the learning rate for the specified layer */
    if (nn == NULL) return 0.0;
    if (layer >= 0 && layer < nn->nl-1) return nn->lrmul[layer];
    else return 0.0;
}

double nt1get_lrlim (NEURALNET *nn)
{
    /* Returns the learning rate limit */
    if (nn == NULL) return 0.0;
    return nn->lrlimit;
}

double nt1get_olt (NEURALNET *nn)
{
    /* Returns the overlearning threshold */
    if (nn == NULL) return 0.0;
    return nn->ovrlrnthrsh;
}

double nt1get_tt (NEURALNET *nn)
{
    /* Returns the training tolerance */
    if (nn == NULL) return 0.0;
    return nn->traintol;
}

double nt1get_tol (NEURALNET *nn)
{
    /* Returns the statistics tolerance */
    if (nn == NULL) return 0.0;
    return nn->tol;
}

int nt1get_test (NEURALNET *nn)
{
    /* Returns the test mode setting */
    if (nn == NULL) return -1;
    return nn->testmode;
}

double nt1get_output (NEURALNET *nn, int outn)
{
    /* Returns output from the specified output neuron */
    if (nn == NULL) return 0.0;
    if (outn >= 0 && outn < nn->n[nn->nl-1])
	return (nn->ovmax[outn] - nn->ovmin[outn]) *
		nn->v[nn->nl-1][outn] + nn->ovmin[outn];
    else return 0.0;
}

double nt1get_target (NEURALNET *nn, int outn)
{
    /* Returns the target for the specified output neuron */
    if (nn == NULL) return 0.0;
    if (outn >= 0 && outn < nn->n[nn->nl-1])
	return (nn->ovmax[outn] - nn->ovmin[outn]) *
		nn->t[outn] + nn->ovmin[outn];
    else return 0.0;
}

double nt1get_mterrss (NEURALNET *nn)
{
    /* Returns the total error sums-of-squares */
    if (nn == NULL) return 0.0;
    return nn->toterrss;
}

double nt1get_merrss (NEURALNET *nn, int outn)
{
    /* Returns error sums-of-squares for specified output neuron */
    if (nn == NULL) return 0.0;
    if (outn >= 0 && outn < nn->n[nn->nl-1]) return nn->errss[outn];
    else return 0.0;
}

double nt1get_rmean (NEURALNET *nn)
{
    /* Returns the average correlation over all output neurons */
    if (nn == NULL) return 0.0;
    return nn->totrsq;
}

double nt1get_rval (NEURALNET *nn, int outn)
{
    /* Returns the correlation with the target for the specified
    .  output neuron
    */
    if (nn == NULL) return 0.0;
    if (outn >= 0 && outn < nn->n[nn->nl-1]) return nn->rsq[outn];
    else return 0.0;
}

double nt1get_pxhits (NEURALNET *nn)
{
    /* Returns percent hits on target over all output neurons */
    if (nn == NULL) return 0.0;
    return nn->pxhits;
}

double nt1get_phits (NEURALNET *nn, int outn)
{
    /* Returns percent hits on target for specified output neuron */
    if (nn == NULL) return 0.0;
    if (outn >= 0 && outn < nn->n[nn->nl-1]) return nn->phits[outn];
    else return 0.0;
}

int nt1get_wgtdist (NEURALNET *nn, int layer, int range)
{
    /* Returns distribution of connection weights */
    if (nn == NULL) return -1;
    if (layer >= 0 && layer < nn->nl-1 && range >= -9 && range <= 9)
	return nn->wtd[layer][range+9];
    else return 0;
}

void nt1get_extra (NEURALNET *nn, int nbyte, int pos, void *ed)
{
    /* Returns extra data saved with net by user */
    if (nn == NULL) return;
    if (pos >= 0 && pos + nbyte <= MAXED)
	memcpy (ed, nn->exdata + pos, nbyte);
    else
	memset (ed, 0, nbyte);
}

char * nt1get_edptr (NEURALNET *nn)
{
    /* Returns a pointer to a net's extra data field */
    if (nn == NULL) return NULL;
    return nn->exdata;
}

/*---------------------------------------------------------------------------
c  Internal neural functions.
*/

static int transfer_v (double *v, int n, int sel)
{
    /* Implements neural transfer function without derivatives.
    .  Used by function nt1fire when running data through an
    .  already-trained network without producing further training.
    */
    double tp, x, tx, cons;  int hundreds;

    /* set threshold neuron */
    hundreds = (sel / 100) % 10;
    if (hundreds == 0) v[n] = 1.0;
    else if (hundreds == 1) v[n] = 0.0;
    else if (hundreds == 2) v[n] = -1.0;
    else return -1;

    switch (sel % 100) {

        /* standard short-tailed sigmoid transfer function */
        case 1:
            while (n--) {
                *v = 1.0 / (exp (-*v) + 1.0);
                v++;
            }
            return 0;

        /* long-tailed sigmoid transfer function */
        case 2:
            while (n--) {
                if (*v > 0.0) {
                    tx = 1.0 / (1.0 + *v);
                    tp = 0.5 + *v;
                    *v++ = tp * tx;
                } else {
                    tx = 1.0 / (1.0 - *v);
                    *v++ = 0.5 * tx;
                }
            }
            return 0;

        /* medium-tailed sigmoid transfer function */
        case 3:
            cons = 1.0 / 6.0;
            while (n--) {
                if (*v < 0.0) {
                    x = - *v;
                    tp = 1.0 / (2.0 + x * (1.0 + x * (0.5 + x * cons)));
                    *v++ = tp;
                } else {
                    x = *v;
                    tp = 1.0 / (2.0 + x * (1.0 + x * (0.5 + x * cons)));
                    *v++ = 1.0 - tp;
                }
            }
            return 0;

        /* approximated gaussian transfer function */
        case 4:
            while (n--) {
                x = *v;
                tx = x * x;
                tp = 1.0 / (1.0 + tx * (0.5 + 0.125 * tx));
                *v++ = tp;
            }
            return 0;

        /* linear transfer function */
        case 5:
            while (n--) {
                *v *= 0.25;
                v++;
            }
            return 0;

        /* shifted linear transfer function */
        case 6:
            while (n--) {
                *v = 0.25 * (1.0 + *v);
                v++;
            }
            return 0;

        /* sigmoid with output centered at zero */
        case 7:
            while (n--) {
                *v = 2.0 * (1.0 / (exp (-*v) + 1.0) - 0.5);
                v++;
            }
            return 0;

        /* sigmoid with input shifted up */
        case 8:
            while (n--) {
                *v = 1.0 / (exp (1.0 - *v) + 1.0);
                v++;
            }
            return 0;

        /* invalid transfer function specification */
        default:
            return -1;
    }
}

static int network_fire (

int     nl,             /* number of layers in network */
int     *n,             /* number of neurons in each layer */
double  **v,            /* neural outputs for each layer */
double  **w,            /* connection weight matrices */
int     *tfs            /* transfer function selectors */

) {
    /* Runs the neural network on input data to obtain its output
    .  without training it.
    */
    int j, l, l1, ij;

    /* apply transfer function to input data */
    if (transfer_v (v[0], n[0], tfs[0]))  return -1;

    /* work forward through layers computing results */
    for (l = 0, l1 = 1; l < nl-1; l++, l1++) {
        for (j = 0; j < n[l1]; j++) {
            ij = (n[l] + 1) * j;
            v[l1][j] = nt1sp (v[l], w[l]+ij, n[l]+1);
        }
        if (transfer_v (v[l1], n[l1], tfs[l1]))  return -1;
    }

    /* normal return */
    return 0;
}

int nt1fire (NEURALNET *nn)
{
    /* Used to call network_fire (just above) with a NEURALNET pointer */
    int rc;

    /* process data through network */
    rc = network_fire (
        nn->nl,                 /* number of layers */
        nn->n,                  /* neurons per layer */
        nn->v,                  /* neural node vectors */
        nn->w,                  /* weight matrices */
        nn->tfs                 /* transfer function selectors */
    );

    /* check for any error */
    if (rc < 0) {
        nt1seterrc (10);
        return -1;
    }

    /* normal return */
    return 0;
}

static int transfer_vd (double *v, double *d, int n, int sel)
{
    /* Implements neural tranfer function and calculates derivatives.
    .  This function is called by network_train when training a
    .  neural network with backpropagation.
    */
    double emv, onepemv, tp, x, tx, cons;  int hundreds;

    /* set threshold neuron */
    hundreds = (sel / 100) % 10;
    if (hundreds == 0) v[n] = 1.0;
    else if (hundreds == 1) v[n] = 0.0;
    else if (hundreds == 2) v[n] = -1.0;
    else return -1;
    d[n] = 0.0;

    switch (sel % 100) {

	/* standard short-tailed sigmoid transfer function */
        case 1:
            while (n--) {
                emv = exp (-*v);
                onepemv = 1.0 / (emv + 1.0);
                *d++ = emv * onepemv * onepemv;
                *v++ = onepemv;
            }
	    return 0;

	/* long-tailed sigmoid transfer function */
        case 2:
            while (n--) {
                if (*v > 0.0) {
		    tx = 1.0 / (1.0 + *v);
		    tp = 0.5 + *v;
		    *d++ = tx * (1.0 - tp * tx);
		    *v++ = tp * tx;
                } else {
		    tx = 1.0 / (1.0 - *v);
		    tp = 0.5 - *v;
		    *d++ = tx * (1.0 - tp * tx);
		    *v++ = 0.5 * tx;
                }
            }
	    return 0;

	/* medium-tailed sigmoid transfer function */
        case 3:
            cons = 1.0 / 6.0;
            while (n--) {
                if (*v < 0.0) {
                    x = - *v;
                    tp = 1.0 / (2.0 + x * (1.0 + x * (0.5 + x * cons)));
                    *v++ = tp;
                    *d++ = (1.0 + x * (1.0 + x * 0.5)) * tp * tp;
                } else {
                    x = *v;
                    tp = 1.0 / (2.0 + x * (1.0 + x * (0.5 + x * cons)));
                    *v++ = 1.0 - tp;
                    *d++ = (1.0 + x * (1.0 + x * 0.5)) * tp * tp;
                }
            }
	    return 0;

        /* approximated gaussian transfer function */
        case 4:
            while (n--) {
                x = *v;
                tx = x * x;
                tp = 1.0 / (1.0 + tx * (0.5 + 0.125 * tx));
                *v++ = tp;
                *d++ = - (x + 0.5 * x * tx) * tp * tp;
            }
	    return 0;

        /* linear transfer function */
        case 5:
            while (n--) {
		*v = 0.25 * *v;
		*d++ = 0.25;
		v++;
            }
	    return 0;

        /* shifted linear transfer function */
        case 6:
            while (n--) {
		*v = 0.25 * (1.0 + *v);
		*d++ = 0.25;
		v++;
            }
	    return 0;

	/* sigmoid with output centered at zero */
	case 7:
	    while (n--) {
		emv = exp (-*v);
		onepemv = 1.0 / (emv + 1.0);
		*d++ = 2.0 * emv * onepemv * onepemv;
		*v++ = 2.0 * (onepemv - 0.5);
	    }
	    return 0;

	/* sigmoid with input shifted up */
	case 8:
	    while (n--) {
		emv = exp (1.0 - *v);
		onepemv = 1.0 / (emv + 1.0);
		*d++ = emv * onepemv * onepemv;
		*v++ = onepemv;
	    }
	    return 0;

	/* invalid transfer function specification */
        default:
	    return -1;
    }
}

static int network_train (

int     nl,     	/* number of layers in network */
int     *n,    	 	/* number of neurons per layer */
double  *t,     	/* target (dependent variables) vector */
double  **v,    	/* neural outputs for each layer */
double  **d,    	/* deriatives of neural inputs w.r.t. error */
double  **w,    	/* connection weight matrices */
double  *lrm,   	/* layer-specific learning rate multiplier */
double  lr,     	/* learning rate */
double  olt,    	/* overlearning threshold */
double  tet,    	/* training error tolerance */
int     *tfs,   	/* transfer function selector */
int     efs     	/* error function selector */

) {
    /* Trains the network on a single fact.  This function is called
    .  repeatedly while training a neural network on a set of facts.
    */
    int i, j, l, l1, nl1, nl2, ij;  double temp, temp2;

    nl1 = nl - 1;
    nl2 = nl1 - 1;

    /* apply transfer function to input data */
    if (transfer_vd (v[0], d[0], n[0], tfs[0]))  return -1;

    /* work forward through layers computing results */
    for (l = 0, l1 = 1; l < nl1; l++, l1++) {
        for (j = 0; j < n[l1]; j++) {
            ij = (n[l] + 1) * j;
	    v[l1][j] = nt1sp (v[l], w[l]+ij, n[l]+1);
        }
	if (transfer_vd (v[l1], d[l1], n[l1], tfs[l1]))  return -1;
    }

    /* return if no learning is to be done */
    if (lr < 1.0E-20) return 0;
    
    /* calculate largest error */
    temp = 0.0;
    for (i = 0; i < n[nl1]; i++) {
	temp2 = fabs (v[nl1][i] - t[i]);
        if (temp2 > temp) temp = temp2;
    }
    if (temp < tet) return 0;

    /* compute deriative of last layer inputs w.r.t. error */
    switch (efs) {

	/* standard least-squares error function */
	case 1:
	case 4:
            for (i = 0; i < n[nl1]; i++)
                d[nl1][i] *= 2.0 * (v[nl1][i] - t[i]);
            break;

        /* least deviations approximation error function */
        case 2:
            for (i = 0; i < n[nl1]; i++) {
                temp = v[nl1][i] - t[i];
                if (temp >= 0.0)
                    d[nl1][i] *= (1.5 * sqrt (temp));
                else
                    d[nl1][i] *= (-1.5 * sqrt (-temp));
            }
            break;

        /* least-fourth-powers error function */
        case 3:
            for (i = 0; i < n[nl1]; i++) {
                temp = v[nl1][i] - t[i];
                d[nl1][i] *= 4.0 * temp * temp * temp;
            }
	    break;

	/* asymetric error functions */
	case 5:
	case 7:
	    for (i = 0; i < n[nl1]; i++) {
		temp = v[nl1][i] - t[i];
		if (temp > 0.0)
		    d[nl1][i] *= 2.0 * temp;
		else
		    d[nl1][i] *= 0.4 * temp;
	    }
	    break;

	case 6:
	case 8:
	    for (i = 0; i < n[nl1]; i++) {
		temp = v[nl1][i] - t[i];
		if (temp < 0.0)
		    d[nl1][i] *= 2.0 * temp;
		else
		    d[nl1][i] *= 0.4 * temp;
	    }
	    break;

	/* invalid error function specification */
	default:
	    return -2;

	/* end of switch */
    }

    /* work back through layers computing deriatives */
    /* exclude the first layer as it is not needed */
    for (l = nl2, l1 = nl1; l1 > 1; l--, l1--) {
        for (i = 0; i < n[l]; i++) {
	    d[l][i] *= nt1spm (w[l]+i, d[l1], n[l1], n[l]+1, 1);
        }
    }

    /* apply corrections (learning) to weight matrices */
    if (olt < 1.0E20) goto A1;
    else goto A2;

    /* simple back-propagation learning rule */
A1: for (l = 0, l1 = 1; l < nl1; l++, l1++) {
        for (i = 0; i < n[l]+1; i++) {
             temp = lrm[l] * lr * v[l][i];
              for (j = 0; j < n[l1]; j++) {
                   ij = i + (n[l]+1) * j;
                    w[l][ij] -= (temp * d[l1][j]);
              }
        }
    }
    return 0;

    /* back-propagation with overlearning effect */
A2: for (l = 0, l1 = 1; l < nl1; l++, l1++) {
        for (i = 0; i < n[l]+1; i++) {
	    temp = lrm[l] * lr * v[l][i];
            for (j = 0; j < n[l1]; j++) {
		ij = i + (n[l]+1) * j;
		temp2 = w[l][ij] - temp * d[l1][j];
		if (temp2 > olt) temp2 = olt;
		else if (temp2 < -olt) temp2 = -olt;
		w[l][ij] = temp2;
            }
        }
    }
    return 0;
}

/*---------------------------------------------------------------------------
c  Other neural functions.
*/

int nt1learn (NEURALNET *nn)
{
    /* Used to call network_train (above) with a NEURALNET pointer */
    int rc;  double lrate;

    /* set up for training or testing mode */
    if (nn->testmode)  lrate = 0.0;
    else  lrate = nn->lrate;

    /* perform the learning or testing step */
    rc = network_train (
	nn->nl,			/* number of layers */
	nn->n,			/* neurons per layer */
	nn->t,			/* target vector */
	nn->v,			/* neural node vectors */
	nn->d,			/* neural deriative vectors */
	nn->w,			/* weight matrices */
	nn->lrmul,		/* layer rate multipliers */
	lrate,			/* global learning rate */
	nn->ovrlrnthrsh,	/* overlearning threshold */
	nn->traintol,		/* training error tolerance */
	nn->tfs,		/* transfer function selectors */
	nn->efs			/* error function selector */
    );

    /* check for any error */
    if (rc < 0) {
	if (rc == -1)  nt1seterrc (10);
	if (rc == -2)  nt1seterrc (11);
	return -1;
    }

    /* normal return */
    return 0;
}

void nt1dlra (NEURALNET *nn)
{
    /* Used to dynamically adjust the global learning rate */
    if (nn->prevpreverrss && nn->lrate_dynamic && !nn->testmode) {
	if (nn->toterrss < nn->preverrss &&
	  nn->preverrss < nn->prevpreverrss) {
            nn->lrate *= 1.05;
        } else {
            nn->lrate *= 0.50;
	}
	if (nn->lrate > nn->lrlimit)  nn->lrate = nn->lrlimit;
    }

    /* keep log of earlier error measurements */
    nn->prevpreverrss = nn->preverrss;
    nn->preverrss = nn->toterrss;
}

void nt1stat_clear (NEURALNET *nn)
{
    /* Clear statistics from a previous training or testing run */
    int i;

    if (nn == NULL) return;

    for (i = 0; i < nn->n[nn->nl-1]; i++) {
	nn->errss[i] = 0.0;
	nn->rsq[i] = 0.0;
	nn->u_out[i] = 0.0;
	nn->s_out[i] = 0.0;
	nn->u_tgt[i] = 0.0;
	nn->s_tgt[i] = 0.0;
	nn->phits[i] = 0.0;
    }

    nn->pxhits = 0.0;
    nn->nfacts = 0;
}

void nt1stat_accum (NEURALNET *nn)
{
    /* Accumulate statistics data during a testing or training run */
    int i, nhits;  double target, forecast, error;

    if (nn == NULL) return;

    for (i = nhits = 0; i < nn->n[nn->nl-1]; i++) {
	target = nn->t[i] - 0.5;
	forecast = nn->v[nn->nl-1][i] - 0.5;
	error = fabs (forecast - target);
	switch (nn->efs) {
	    case 1:  nn->errss[i] += error * error;	break;
	    case 2:  nn->errss[i] += pow (error, 1.5);  break;
	    case 3:  nn->errss[i] += pow (error, 4);	break;
	    default: nn->errss[i] += error * error;	break;
	}
	if (error < nn->tol) {
	    nn->phits[i] += 1.0;
	    nhits += 1;
	}
	nn->rsq[i] += target * forecast;
	nn->u_out[i] += forecast;
	nn->s_out[i] += forecast * forecast;
	nn->u_tgt[i] += target;
	nn->s_tgt[i] += target * target;
    }
    if (nhits == nn->n[nn->nl-1])  nn->pxhits += 1.0;
    nn->nfacts += 1;
}

void nt1stat_compute (NEURALNET *nn)
{
    /* Use accumulated data to finish calculating statistics */
    int i, nout;  double sx, sy, sxy;

    if (nn == NULL) return;

    nout = nn->n[nn->nl-1];
    nn->toterrss = 0.0;
    nn->totrsq = 0.0;
    for (i = 0; i < nout; i++) {
	nn->errss[i] /= (double) nn->nfacts;
	nn->toterrss += nn->errss[i];
	sx = nn->nfacts * nn->s_out[i] - nn->u_out[i] * nn->u_out[i];
	sy = nn->nfacts * nn->s_tgt[i] - nn->u_tgt[i] * nn->u_tgt[i];
	sxy = nn->nfacts * nn->rsq[i] - nn->u_out[i] * 	nn->u_tgt[i];
	if (sx > 0.0 && sy > 0.0)
	    nn->rsq[i] = sxy / (sqrt(sx) * sqrt(sy));
	else
	    nn->rsq[i] = 0.0;
	nn->totrsq += nn->rsq[i];
	nn->phits[i] /= (double) nn->nfacts;
    }
    nn->pxhits /= (double) nn->nfacts;
    nn->toterrss /= (double) nout;
    nn->totrsq /= (double) nout;

    if (nn->testmode) nn->lasttestr = nn->totrsq;
    else nn->lasttrainr = nn->totrsq;
}

void nt1stat_wgtdist (NEURALNET *nn)
{
    /* Calculate the distribution of connection weights */
    int k, l, ij;

    if (nn == NULL) return;

    /* clear distribution statistics */
    for (l = 0; l < nn->nl-1; l++) {
	for (k = 0; k < 19; k++) {
	    nn->wtd[l][k] = 0;
	}
    }

    /* accumulate distribution statistics */
    for (l = 0; l < nn->nl-1; l++) {
	for (ij = 0; ij < (nn->n[l]+1)*(nn->n[l+1]); ij++) {
	    k = (int) floor (nn->w[l][ij] + 9.5);
	    if (k > 18) k = 18;
	    if (k < 0) k = 0;
	    nn->wtd[l][k] += 1;
	}
    }
}

/*---------------------------------------------------------------------------
c  Neurogenetic functions for evolving neural networks.
*/

#define DISPERSION 1.0

int nt1pop_new (NNPTR *brains, int npop, int nl, int *n)
{
    /* Creates a whole population of new neural networks.
    .  Arguments:
    .    brains - array [0..npop-1..] of neural network pointers
    .    npop   - number of networks to create (population size)
    .    nl     - number of layers in each network
    .    n      - array [0..nl-1] with number of neurons in each layer
    */
    int i, err;

    /* initialize all network (brain) pointers to NULL */
    for (i = 0; i < npop; i++)  brains[i] = NULL;

    /* create a population of neural networks */
    for (i = 0; i < npop; i++) {
	if ((brains[i] = nt1new (nl, n)) == NULL) {
	    err = nt1errc ();
	    goto ERR;
	}
	nt1set_randw (brains[i], DISPERSION);
    }

    /* normal return */
    return 0;

    /* error return (free any networks, set error code and return) */
    ERR:
    nt1pop_disp (brains, npop);
    nt1seterrc (err);
    return -1;
}

int nt1pop_load (NNPTR *brains, int *npop, int maxpop, char *name)
{
    /* Loads a population of neural networks from files.  If *npop
    .  is greater than the number of files, this routine adds members
    .  to the population by loading the first file (net) repeatedly,
    .  each time randomizing its connection weights.
    .  Arguments:
    .    brains - array [0..maxpop-1] of neural network pointers
    .    npop   - specifies number of files to load (or 0 for all)
    .                 returned with number of files loaded
    .    maxpop - the maximum number of files (== dimension of brains)
    .    name   - all of filespec except for constructed part (see code)
    */
    char fname[80];  int i, err;

    /* initialize all neural network pointers to NULL */
    for (i = 0; i < maxpop; i++)  brains[i] = NULL;

    /* load a specified number of neural networks */
    if (*npop > 0) {
	for (i = 0; i < *npop; i++) {
	    sprintf (fname, "%s%03d.pop", name, i);
	    if ((brains[i] = nt1load (fname)) == NULL) {
	        err = nt1errc ();
	        if (err == 2) {
	 	    sprintf (fname, "%s000.pop", name);
		    if ((brains[i] = nt1load (fname)) == NULL) {
		        err = nt1errc ();
			goto ERR;
		    }
		    nt1set_randw (brains[i], DISPERSION);
		}
		else {
		    goto ERR;
		}
	    }
	}
    } 
    else {
	*npop = 0;
	for (i = 0; i < maxpop; i++) {
	    sprintf (fname, "%s%03d.pop", name, i);
	    if ((brains[i] = nt1load (fname)) == NULL) {
	        err = nt1errc ();
	        if (err == 2) break;
	        else goto ERR;
	    }
	    *npop = *npop + 1;
	}
    }

    /* normal return */
    return 0;

    /* error cleanup and return */
    ERR:
    nt1pop_disp (brains, maxpop);
    nt1seterrc (err);
    return -1;
}

int nt1pop_save (NNPTR *brains, int npop, char *name)
{
    /* Saves a population of neural networks to files, each file
    .  having a constructed, unique name.
    */
    char fname[80];  int i;

    for (i = 0; i < npop; i++) {
	sprintf (fname, "%s%03d.pop", name, i);
        if (nt1save (brains[i], fname) != 0)  return -1;
    }

    /* normal return */
    return 0;
}

void nt1pop_disp (NNPTR *brains, int npop)
{
    /* Disposes of a population of neural networks */
    int i;

    for (i = 0; i < npop; i++) {
	if (brains[i] != NULL)  nt1disp (brains[i]);
	brains[i] = NULL;
    }
}

void nt1mate (NNPTR par1, NNPTR par2, NNPTR child, double mut, double cross)
{
    /* Mates two neural networks in order to obtain a child.  Uses
    .  the specified mutation and crossover rates.
    */
    int l, j, ij, i, flag;  double temp, randmax=RAND_MAX;

    /* initialize crossover flag */
    if (rand()/randmax > 0.5) flag = 1;
    else flag = -1;

    /* mate the parent nets to produce a child net */
    for (l = 0; l < par1->nl-1; l++) {
	for (i = 0; i < par1->n[l]+1; i++) {
	    for (j = 0; j < par1->n[l+1]; j++) {
	        ij = i + (par1->n[l]+1) * j;
		if (rand()/randmax < cross) flag = -flag;
		if (flag > 0) temp = par1->w[l][ij];
		else temp = par2->w[l][ij];
		if (rand()/randmax < mut)
		    temp += 3.0 * (rand()/randmax - 0.5);
		if (temp > 8.0) temp = 8.0;
		if (temp < -8.0) temp = -8.0;
		child->w[l][ij] = temp;
	    }
	}
    }
}

int nt1randint (int num)
{
    /* Generates a random integer between 0 and num-1 */
    double rn;

    rn = (double) rand () / (double) RAND_MAX;
    return (int) floor (0.99999 * num * rn);
}

void nt1pop_settf (NNPTR *brains, int npop, int layer, int tfid)
{
    /* Sets the tranfer function for a population of nets */
    int i;
    for (i = 0; i < npop; i++)
	if (brains[i]) nt1set_trfun (brains[i], layer, tfid);
}

void nt1pop_randw (NNPTR *brains, int npop, double disp)
{
    /* Randomizes the connection weights in a population of nets */
    int i;
    for (i = 0; i < npop; i++)
	if (brains[i]) nt1set_randw (brains[i], disp);
}

void nt1pop_iscale (NNPTR *brains, int npop, int neuron,
double ivmin, double ivmax)
{
    /* Scales the specified input neuron in a population of nets */
    int i;
    for (i = 0; i < npop; i++)
	if (brains[i]) nt1set_iscale (brains[i], neuron, ivmin, ivmax);
}

void nt1pop_oscale (NNPTR *brains, int npop, int neuron,
double ovmin, double ovmax)
{
    /* Scales the specified output neuron in a population of nets */
    int i;
    for (i = 0; i < npop; i++)
	if (brains[i]) nt1set_oscale (brains[i], neuron, ovmin, ovmax);
}

double nt1vd (double *x, double *y, int n)
{
    /* Euclidean vector distance */
    double sum, tmp;
    sum = 0.0;
    while (n--) {
	tmp = *x++ - *y++;
	sum += tmp * tmp;
    }
    return sum;
}

double nt1rxy (double *x, double *y, int n)
{
    /* Pearson Product-Moment Correlation between x[] and y[] */
    double sumx, sumy, sumxx, sumxy, sumyy, vn;
    sumx = sumy = sumxx = sumyy = sumxy = 0.0;
    vn = n;
    while (n--) {
        sumx += *x;
	sumy += *y;
	sumxx += *x * *x;
	sumyy += *y * *y;
	sumxy += *x * *y;
	x++;
	y++;
    }
    sumx = sumx / vn;
    sumy = sumy / vn;
    sumxx = sumxx / vn - sumx * sumx;
    sumyy = sumyy / vn - sumy * sumy;
    sumxy = sumxy / vn - sumx * sumy;
    return sumxy / sqrt (sumxx * sumyy + 1.0E-32);
}

double nt1comp (NNPTR net1, NNPTR net2, int mode)
{
    /* Compare two neural nets for overall similarity */
    double sumxx, sumyy, sumxy, diffxy;  int nsd, n, l;
    if (mode == 1) {
    	/* correlation similarity measure */
        sumxx = 0.0;  sumyy = 0.0;  sumxy = 0.0;
	for (l = 0; l < net1->nl-1; l++) {
	    nsd = (net1->n[l] + 1) * (net1->n[l+1]);
	    sumxx += nt1sp (net1->w[l], net1->w[l], nsd);
	    sumyy += nt1sp (net2->w[l], net2->w[l], nsd);
	    sumxy += nt1sp (net1->w[l], net2->w[l], nsd);
	}
	return sumxy / sqrt (sumxx * sumyy);
    }
    else if (mode == 2) {
        /* Euclidean distance similarity model */
        diffxy = 0.0;  n = 0;
        for (l = 0; l < net1->nl-1; l++) {
 	    nsd = (net1->n[l] + 1) * (net1->n[l+1]);
	    diffxy += nt1vd (net1->w[l], net2->w[l], nsd);
	    n += nsd;
	}
	return sqrt (diffxy / n);
    }
    else {
        /* Invalid mode argument */
        return 0.0;
    }
}

/*---------------------------------------------------------------------------
c  Genetic operations with vectors.  For this, one is better off using
c  the more modern implementation of a genetic algorithm in libga.c and
c  libga.h as a C++ class.
*/

double * nt1vcreate (int n)
{
    double *pvec;  int i;  double randmax=RAND_MAX;
    if ((pvec = (double *) calloc (n, sizeof(double))) == NULL) {
        nt1seterrc (1);
        return NULL;
    }
    for (i = 0; i < n; i++)
        pvec[i] = rand() / randmax;   /* range = 0.0..1.0 */
    return pvec;
}

double * nt1vload (int n, char *fname)
{
    FILE *ifile;  double *pvec, dn;  int i;
    if ((pvec = (double *) calloc (n, sizeof(double))) == NULL) {
	nt1seterrc (1);
	return NULL;
    }
    if ((ifile = fopen (fname, "rt")) == NULL) {
	nt1seterrc (25);
	nt1vdisp (pvec);
	return NULL;
    }
    fscanf (ifile, "%lf", &dn);
    if ((int)dn != n || ferror (ifile)) {
	if ((int)dn != n) nt1seterrc (26);
	else nt1seterrc (27);
	nt1vdisp (pvec);
	fclose (ifile);
	return NULL;
    }
    for (i = 0; i < n; i++) {
	if (fscanf (ifile, "%lf", pvec+i) != 1) {
	    nt1seterrc (27);
	    fclose (ifile);
	    nt1vdisp (pvec);
	    return NULL;
	}
    }
    fclose (ifile);
    return pvec;
}

int nt1vsave (double *pvec, int n, char *fname)
{
    FILE *ofile;
    if ((ofile = fopen (fname, "wt")) == NULL) {
	nt1seterrc (23);
	return -1;
    }
    fprintf (ofile, "%.1lf\n", (double) n);
    while (n--)
        fprintf (ofile, "%.6lf\n", *pvec++);
    if (ferror (ofile)) {
	nt1seterrc (24);
	fclose (ofile);
	return -1;
    }
    fclose (ofile);
    return 0;
}

void nt1vdisp (double *pvec)
{
    if (pvec) free (pvec);
}

void nt1vmate (double *par1v, double *par2v, double *childv, int n,
double mr, double cr, double disp)
{
    int i, flag;  double temp, randmax=RAND_MAX;

    /* initialize crossover flag */
    if (rand()/randmax > 0.5) flag = 1;
    else flag = -1;

    /* mate parent vectors to produce a child vector */
    for (i = 0; i < n; i++) {
	if (rand()/randmax < cr) flag = -flag;
	if (flag > 0) temp = par1v[i];
	else temp = par2v[i];
	if (rand()/randmax < mr) {
	    temp += disp * (rand() / randmax);
	    while (temp > 1.0) temp -= 1.0;
	}
	childv[i] = temp;
    }
}

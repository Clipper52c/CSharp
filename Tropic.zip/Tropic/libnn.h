#ifndef LIBNN_H
#define LIBNN_H

/*
c  libnn.h
c
c  Header file for libnn.c (neural network and neurogenetic library).
c
c  Copyright (C) 1993, 2002, 2007.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
*/

#ifdef __cplusplus
extern "C" {
#endif

#define MAXLAYERS	6		/* maximum number of layers */
#define MAXED		256		/* maximum bytes extra data */

/* structure representing a neural network object */
typedef struct {
    double  lrate;			    /* current global learning rate */
    double  lrlimit;			/* learning rate limit */
    double  ovrlrnthrsh;		/* overlearning threshold */
    double  traintol;			/* training tolerance */
    double  toterrss;			/* mean total error sum-of-squares */
    double  preverrss;			/* previous toterrss value */
    double  prevpreverrss;		/* previous preverrss value */
    double  totrsq;			    /* mean r for all targets */
    double  pxhits;			    /* average percentage correct */
    double  tol;			    /* error tolerance */
    double  lasttrainr;			/* last training r value */
    double  lasttestr;			/* last testing r value */
    double  r_stop;			    /* r value at which training stops */
    double  lrmul[MAXLAYERS-1];	/* layer-specific rate multiplier */
    double  *t;				    /* training target vector */
    double  *v[MAXLAYERS];		/* layer output vectors */
    double  *d[MAXLAYERS];		/* gradients at layer inputs */
    double  *w[MAXLAYERS-1];	/* connection weight matrices */
    double  *errss;			    /* mean error ss for each target */
    double  *rsq;			    /* r (correlation) for each target */
    double  *u_out;			    /* output sums */
    double  *s_out;			    /* output sums-of-squares */
    double  *u_tgt;			    /* target sums */
    double  *s_tgt;			    /* target sums-of-squares */
    double  *phits;			    /* percentage correct each target */
    double  *ivmin;			    /* input variable scale minimum */
    double  *ivmax;			    /* input variable scale maximum */
    double  *ovmin;			    /* output variable scale minimum */
    double  *ovmax;			    /* output variable scale maximum */
    int     nl;				    /* number of layers */
    int     n[MAXLAYERS];		/* number of neurons per layer */
    int     tfs[MAXLAYERS];		/* transfer function selectors */
    int     efs;			    /* error function selector */
    int     nfacts;			    /* total number of facts per run */
    int     lrate_dynamic;		/* flag for dynamic lrate fixup */
    int     wtd[MAXLAYERS-1][19];	/* distributions of weights */
    int     testmode;			/* testing-v-training mode flag */
    int     maxruns;			/* maximum number of runs */
    FILE    *def_file;			/* network definition save file */
    char    exdata[MAXED];		/* extra data associated with a net */
} NEURALNET;

typedef NEURALNET* NNPTR;		/* alternative declaration */

double  nt1sp (double *x, double *y, int n);			        /* basic scalar product */
double  nt1spm (double *x, double *y, int n, int mx, int my);	/* scalar product with stride */

void    nt1seterrc (int errc);					/* set error code */
int     nt1errc (void);						    /* get error code */
char*   nt1errm (int errc);					    /* get error message */
void    nt1ftlerr (char *msg);					/* text-based fatal error handler */

NNPTR   nt1new (int nl, int *n);				/* create new neural network */
NNPTR   nt1load (char *fname);					/* load network from file */
int     nt1learn (NNPTR nn);					/* train or run network on fact */
int     nt1fire (NNPTR nn);					    /* run network on a fact */
void    nt1dlra (NNPTR nn);					    /* dynamic lrate adjustment */
int     nt1save (NNPTR nn, char *fname);		/* save network to file */
void    nt1disp (NNPTR nn);					    /* dispose network memory */

void    nt1stat_clear (NNPTR nn);				/* clear neural statistics */
void    nt1stat_accum (NNPTR nn);				/* accumulate statistics */
void    nt1stat_compute (NNPTR nn);				/* compute statistics */
void    nt1stat_wgtdist (NNPTR nn);				/* compute weight distributions */

void    nt1set_seed (int seed);					            /* set random number seed */
void    nt1set_randw (NNPTR nn, double disp);			    /* randomize weights */
void    nt1set_lrate (NNPTR nn, double lrate);			    /* set global learning rate */
void    nt1set_lrmul (NNPTR nn, int layer, double lrmul);	/* set layer rate multipliers */
void    nt1set_ldyn (NNPTR nn, int ldyn_flag);			    /* set dynamic lrate flag */
void    nt1set_lrlim (NNPTR nn, double lrlim);			    /* set learning rate limit */
void    nt1set_errfun (NNPTR nn, int errfun_id);		    /* set error function */
void    nt1set_trfun (NNPTR nn, int layer, int trfun_id);	/* set layer transfer function */
void    nt1set_olt (NNPTR nn, double olt);			        /* set overlearning threshold */
void    nt1set_tt (NNPTR nn, double tt);			        /* set training tolerance */
void    nt1set_tol (NNPTR nn, double tol);			        /* set error tolerance */
void    nt1set_test (NNPTR nn, int test_flag);			    /* set test-train mode flag */
void    nt1set_iscale (NNPTR nn, int neuron, double ivmin,
		double ivmax);					                    /* set neural input scaling */
void    nt1set_oscale (NNPTR nn, int neuron, double ovmin,
		double ovmax);					                    /* set neural output scaling */
void    nt1set_inputv (NNPTR nn, float *ivars);			    /* set neural inputs using vector */
void    nt1set_targv (NNPTR nn, float *dvars);			    /* set targets using vector */
void    nt1set_extra (NNPTR nn, int nbyte, int pos, void *ed);	/* save data in extra data buffer */

int     nt1get_test (NNPTR nn);					/* get test-mode flag */
int     nt1get_nlayers (NNPTR nn);				/* get number of layers */
int     nt1get_neurons (NNPTR nn, int layer);	/* get number of neurons in layer */
int     nt1get_trfun (NNPTR nn, int layer);		/* get transfer function id number */
int     nt1get_errfun (NNPTR nn);				/* get error function id number */
int     nt1get_nfacts (NNPTR nn);				/* get number facts used for stats */
int     nt1get_ldyn (NNPTR nn);					/* get dynamic lrate adjust flag */
double  nt1get_lrate (NNPTR nn);				/* get global learning rate */
double  nt1get_lrmul (NNPTR nn, int layer);		/* get rate multiplier for layers */
double  nt1get_lrlim (NNPTR nn);				/* get learning rate limit */
double  nt1get_olt (NNPTR nn);					/* get overlearning threshold */
double  nt1get_tt (NNPTR nn);					/* get training tolerance */
double  nt1get_tol (NNPTR nn);					/* get error tolerance */
double  nt1get_output (NNPTR nn, int outn);		/* get specified neural output */
double  nt1get_target (NNPTR nn, int outn);		/* get specified training target */
double  nt1get_mterrss (NNPTR nn);				/* get mean total error ss */
double  nt1get_merrss (NNPTR nn, int outn);		/* get mean error ss for an output */
double  nt1get_rmean (NNPTR nn);				/* get mean correlation */
double  nt1get_rval (NNPTR nn, int outn);		/* get correlation for an output */
double  nt1get_pxhits (NNPTR nn);				/* get average percentage hits */
double  nt1get_phits (NNPTR nn, int outn);		/* get percent hits for given target */
int     nt1get_wgtdist (NNPTR nn, int layer, int range);	    /* get weight histogram data */
void    nt1get_extra (NNPTR nn, int nbyte, int pos, void *ed);	/* retrieve extra data */
char*   nt1get_edptr (NNPTR nn);				/* return pointer to extra data */

int     nt1pop_new (NNPTR *brains, int npop, int nl, int *n);	/* create a population of nets */
int     nt1pop_load (NNPTR *brains, int *npop, int maxpop,
		char *name);					/* load a population of nets */
int     nt1pop_save (NNPTR *brains, int npop, char *name);	/* save a population of nets */
void    nt1pop_disp (NNPTR *brains, int npop);			    /* dispose of a population of nets */
void    nt1mate (NNPTR par1, NNPTR par2, NNPTR child,
		double mut, double cross);			    /* mate parents to get child net */
int     nt1randint (int num);					/* generate random integers < num */
void    nt1pop_settf (NNPTR *brains, int npop, int layer,
		int tfid);					/* set population transfer function */
void    nt1pop_iscale (NNPTR *brains, int npop, int neuron,
		double ivmin, double ivmax);			/* set population input scaling */
void    nt1pop_oscale (NNPTR *brains, int npop, int neuron,
		double ovmin, double ovmax);			/* set population output scaling */
void    nt1pop_randw (NNPTR *brains, int npop, double disp);	/* randomize population weights */
double  nt1vd (double *x, double *y, int n);			/* compute squared vector distance */
double  nt1rxy (double *x, double *y, int n);			/* compute correlation coefficient */
double  nt1comp (NNPTR net1, NNPTR net2, int mode);		/* compare two nets */
double* nt1vcreate (int n);					            /* create a parameter vector */
double* nt1vload (int n, char *fname);				    /* load a parameter vector */
int     nt1vsave (double *pvec, int n, char *fname);	/* save a parameter vector */
void    nt1vdisp (double *pvec);				        /* dispose of a parameter vector */
void    nt1vmate (double *par1v, double *par2v, double *childv,
		int n, double mr, double cr, double disp);	    /* mate two vectors to get child */

void    nt1erase (void);					            /* ANSI clear screen */
void    nt1cursor (int row, int col);				    /* ANSI position cursor */
void    nt1attrib (int attrib);					        /* ANSI set attribute */

#ifdef __cplusplus
};
#endif

#endif  /* LIBNN_H */

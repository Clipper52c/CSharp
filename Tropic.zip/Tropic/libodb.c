/*
c  libodb.c
c
c  Revised 2007.01.28
c
c  Library of routines for reading a type 939337 compressed options
c  database file with an associated type 939338 index file.
c
c  This code assumes the use of a standard 32-bit compiler and that
c  integer types have Intel byte ordering (least significant to most
c  significant).  It also assumes that the database and index files
c  reside in the same directory and differ only in their extensions.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2006, 2007.  All Rights Reserved.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>

#include "libodb.h"

/*---------------------------------------------------------------------------
c  Forward declarations for public functions.
*/

ODBFILE* odb_open (char fn[], long lbufsize);
void odb_close (ODBFILE *odb);
long odb_nday (ODBFILE *odb);
long odb_nstk (ODBFILE *odb);
long odb_stkno (ODBFILE *odb, char symbol[]);
long odb_dayno (ODBFILE *odb, long idate);
char* odb_usym (ODBFILE *odb, long istk);
long odb_date (ODBFILE *odb, long iday);
void odb_read (ODBFILE *odb, long istk, long iday, ODBCHAIN *oc);
long odb_find (ODBCHAIN *oc, long itype, long iexpdt, float strike);
void odb_typechain (FILE *fil, ODBCHAIN *oc);

/*---------------------------------------------------------------------------
c  Local data and forward declarations for private functions.
*/

static void odb_readchn (FILE *fp, ODBCHAIN *oc);
static void odb_checkdate (long ldate, char msg[]);
static long odb_findstring (char strarr[], long m, long n, char str[]);
static long odb_findlong (long larr[], long n, long lg);
static void* odb_bmalloc (size_t nbytes);
static void odb_ftlerr (char msg[]);

static float odb_strikeinc[6] = {	/* strike increment factors */
        10.0, 5.0, 2.5, 1.0,
        .5, .01
};

static float odb_priceinc[4] = {	/* price increment factors */
        0.10, 0.0625, 0.05,
        0.01
};

/*---------------------------------------------------------------------------
c  Functions to read an options database file using an associated index.
c  These functions are accessible to client programs.
*/

ODBFILE* odb_open (char fn[], long lbufsize)
{
        /* Opens the specified options database and associated index
        .  returning a pointer to an ODBFILE structure through which
        .  the database may be accessed.
        .
        .  Arguments:
        .  fn       - file path and name, without extension (input)
        .  lbufsize - file buffer size, 0 for default buffer (input)
        .  return   - pointer to an ODBFILE database structure (output)
        .
        .  Notes:
        .  Some error and consistency checking is performed.
        */

        ODBFILE *odb;
        ODBFILEHDR *hdr;
        long rc, k;
        char *buf;

        /* allocate data structures */
        odb=(ODBFILE*)odb_bmalloc(sizeof(ODBFILE));
        hdr=(ODBFILEHDR*)odb_bmalloc(sizeof(ODBFILEHDR));
	buf=(char*)odb_bmalloc(sizeof(char)*256);

        /* verify data size and byte ordering assumptions */
        rc=(sizeof(long)!=4 || sizeof(float)!=4 || sizeof(int)!=4 ||
                sizeof(short)!=2 || sizeof(char)!=1 || sizeof(time_t)!=4);
        if(rc) odb_ftlerr("odb_open: invalid compiler assumptions");
        rc=87+256*(95+256*256*54);
        memcpy(buf,&rc,4);
        if(buf[0]!=87 || buf[1]!=95 || buf[2]!=0 || buf[3]!=54)
                odb_ftlerr("odb_open: non-Intel byte ordering");

        /* open index file and verify its identity */
        sprintf(odb->ndxfn,"%s.ndx",fn);
        if((odb->ndxfp=fopen(odb->ndxfn,"rb"))==NULL)
                odb_ftlerr("odb_open: cannot find index file");
        rc=fread(&odb->ndxfileid,4,1,odb->ndxfp);
        if(rc!=1) odb_ftlerr("odb_open: index fileid read error");
        if(odb->ndxfileid!=939338) odb_ftlerr("odb_open: bad index fileid");

        /* read index file header into ODBFILE structure */
        rc=fread(&odb->nstk,4,1,odb->ndxfp);
        rc+=fread(&odb->nday,4,1,odb->ndxfp);
        rc+=fread(&odb->firstdate,4,1,odb->ndxfp);
        rc+=fread(&odb->lastdate,4,1,odb->ndxfp);
        rc+=fread(&odb->updatetime,4,1,odb->ndxfp);
        rc+=fread(&odb->blockindex,4,1,odb->ndxfp);
        if(rc!=6 || ferror(odb->ndxfp))
                odb_ftlerr("odb_open: index header read error");

        /* read index file array data into ODBFILE structure */
        rc=fseek(odb->ndxfp,200,SEEK_SET);
        if(rc!=0 || ferror(odb->ndxfp))
                odb_ftlerr("odb_open: index file seek error");
        odb->symbol=(char*)odb_bmalloc(8*odb->nstk);
        odb->date=(long*)odb_bmalloc(4*odb->nday);
        odb->fpos=(long*)odb_bmalloc(4*odb->nstk*odb->nday);
	rc=fread(odb->symbol,8,odb->nstk,odb->ndxfp);
	rc+=fread(odb->date,4,odb->nday,odb->ndxfp);
	rc+=fread(odb->fpos,4,odb->nday*odb->nstk,odb->ndxfp);
	rc+=fread(&k,4,1,odb->ndxfp);
        if(rc!=1+odb->nstk+odb->nday*(1+odb->nstk) || ferror(odb->ndxfp))
                odb_ftlerr("odb_open: index array read error");
        if(k!=939338) odb_ftlerr("odb_open: invalid index terminator");

        /* close index file */
        fclose(odb->ndxfp);
        odb->ndxfp=NULL;

        /* open and buffer data file and verify its identity */
        sprintf(odb->dbfn,"%s.dat",fn);
        if((odb->dbfp=fopen(odb->dbfn,"rb"))==NULL)
                odb_ftlerr("odb_open: cannot find data file");
        if(lbufsize>0) {
                odb->fbuf=(char*)odb_bmalloc(lbufsize);
                rc=setvbuf(odb->dbfp,odb->fbuf,_IOFBF,lbufsize);
                if(rc!=0) odb_ftlerr("odb_open: cannot buffer data file");
        }
        else odb->fbuf=NULL;
        rc=fread(&hdr->fileid,4,1,odb->dbfp);
        if(rc!=1) odb_ftlerr("odb_open: data header read error");
        if(hdr->fileid!=939337) odb_ftlerr("odb_open: bad data fileid");

        /* read database file header information */
        rc=fread(&hdr->firstdate,4,1,odb->dbfp);
        rc+=fread(&hdr->lastdate,4,1,odb->dbfp);
        rc+=fread(&hdr->blockindex,4,1,odb->dbfp);
        rc+=fread(&hdr->updatetime,4,1,odb->dbfp);
        if(rc!=4 || ferror(odb->dbfp))
                odb_ftlerr("odb_open: data header read error");

        /* verify match between index and data files */
	if( odb->firstdate != hdr->firstdate ||
	    odb->lastdate != hdr->lastdate ||
	    odb->blockindex != hdr->blockindex ||
	    odb->updatetime != hdr->updatetime )
		odb_ftlerr("odb_open: mismatched database and index");

        /* free buffer and database header structure */
        free(hdr);
        free(buf);

        /* return pointer to ODBFILE database file structure */
        return(odb);
}

void odb_close (ODBFILE *odb)
{
        /* Closes an options database previously opened with odb_open */
        fclose(odb->dbfp);
        if(odb->fbuf) free(odb->fbuf);
        free(odb->symbol);
        free(odb->date);
        free(odb->fpos);
        free(odb);
}

long odb_nday (ODBFILE *odb)
{
        /* Returns the total number of indexed days */
        return(odb->nday);
}

long odb_nstk (ODBFILE *odb)
{
        /* Returns the total number of indexed underlying stocks */
        return(odb->nstk);
}

long odb_stkno (ODBFILE *odb, char symbol[])
{
        /* Returns the symbol index given the underlying symbol */
        long k;
        k=odb_findstring(odb->symbol,8,odb->nstk,symbol);
        if(strcmp(odb->symbol+8*k,symbol)==0) return(k);
        return(-1);     /* symbol not found in database index */
}

long odb_dayno (ODBFILE *odb, long idate)
{
        /* Returns the day index given the YYYYMMDD date */
        long k;
        k=odb_findlong(odb->date,odb->nday,idate);
        if(odb->date[k]==idate) return(k);
        return(-1);     /* date not found in database index */
}

char* odb_usym (ODBFILE *odb, long istk)
{
        /* Returns the symbol given the symbol index */
        if(istk<0 || istk>=odb->nstk)
                odb_ftlerr("odb_usym: istk out-of-bounds");
        return(odb->symbol+8*istk);
}

long odb_date (ODBFILE *odb, long iday)
{
	/* Returns the YYYYMMDD date given the day index */
        if(iday<0 || iday>=odb->nday)
                odb_ftlerr("odb_date: iday out-of-bounds");
        return(odb->date[iday]);
}

void odb_read (ODBFILE *odb, long istk, long iday, ODBCHAIN *oc)
{
        /* Reads the specified option chain.
        .
        .  Arguments:
        .  odb   - pointer to a valid options database (input)
        .  istk  - index number of underlying stock (input)
        .  iday  - index number of bar or date (input)
        .  oc    - returned option chain (output)
        */

        if(istk<0 || istk>=odb->nstk)
                odb_ftlerr("odb_read: istk out-of-bounds");
        if(iday<0 || iday>=odb->nday)
                odb_ftlerr("odb_read: iday out-of-bounds");
	oc->valid=odb->fpos[iday+(odb->nday)*istk];
        if(oc->valid<=0) return; /* no data for given stock and day */
        if(fseek(odb->dbfp,oc->valid,SEEK_SET) || ferror(odb->dbfp))
                odb_ftlerr("odb_read: datafile seek error");
        odb_readchn(odb->dbfp,oc);
        if(strcmp(odb->symbol+8*istk,oc->usymbol)!=0)
                odb_ftlerr("odb_read: symbol mismatch");
        if(odb->date[iday]!=oc->date)
                odb_ftlerr("odb_read: date mismatch");                             
}

long odb_find (ODBCHAIN *oc, long itype, long iexpdt, float strike) {
        /* Finds in the given chain (oc) the option having the 
        .  specified type (itype, 0=Call 1=Put), expiration date
        .  (iexpdt, as YYYYMMDD), and strike (strike).  Returns 
        .  the index into the chain for the option (if found) 
        .  or -1 (if not found or if the chain is invalid).
        */
        int k, m;
        float d;
        if(oc->valid<=0) return(-1);	/* chain invalid */
        d= 1.E-5 * strike;
        for(k=0; k<oc->nopt; k++) {
                if(oc->otype[k]!=itype) continue;
                if(fabs(oc->strike[k]-strike)>d) continue;
                m=10000L*oc->expyr[k]+100L*oc->expmo[k]+oc->expdy[k];
                if(m!=iexpdt) continue;
                return(k);	/* desired option found */
        }
        return(-1);		/* option not found */
}

void odb_typechain (FILE *fp, ODBCHAIN *oc)
{
        /* Writes a complete option chain to a text file */
	int k;
	fprintf(fp,"FILEPOSITION=%ld  MODE=%ld\n",
		(long)oc->valid, (long)oc->mode );
        fprintf(fp,"\nSTOCK %8s: %8ld%8.2f%8.2f%8.2f%8.2f%8.2f%12.1f\n",
		(char*)oc->usymbol, (long)oc->date, (float)oc->stkopn,
		(float)oc->stkhi, (float)oc->stklo, (float)oc->stkcls,
		(float)oc->stkacls, (float)oc->stkvol );
	fprintf(fp,"OPTIONS ( NOPT = %ld )\n",(long)oc->nopt);
        for(k=0; k<oc->nopt; k++) {
		fprintf(fp,"%8.2f%8.2f%8.2f%8.2f%9.1f%9.1f%10ld%2ld\n",
                        (float)oc->strike[k], (float)oc->bid[k],
			(float)oc->ask[k], (float)oc->vx[k],
			(float)oc->vol[k], (float)oc->oi[k],
			(long)(10000*oc->expyr[k] + 100*oc->expmo[k] +
			oc->expdy[k]), (long)oc->otype[k] );
        }
        fflush(fp);
}

/*---------------------------------------------------------------------------
c  The functions that follow are strictly internal to the library.
*/

static void odb_readchn (FILE *fp, ODBCHAIN *oc) {

        /* Reads and decompresses a single option chain record, which
        .  includes stock data, from a type 939337 compressed option
        .  database into an ODBCHAIN structure.
        .
        .  Arguments:
	.  fp   - option database file (input)
        .  oc   - option chain data structure (output, via pointer)
        .
        .  Notes:
	.  Some basic error checking is performed.  Updated for
	.  new format on 2006.11.26.  Expiration date is now for
	.  the Saturday that follows the 3rd Friday of the 
	.  expiration month.
        */

	long kstrike, kbid, kask, kvol, koi, kyrs, kmon, kday, kvx;
	long ktype, nzstrike, nzbidask, nzvol, nzoi, nzvx;
	long kopt, rc, kctl, kcwd, m, n, kdate, kincrcode;
	float fmstrike, fmprice;

        /* determine file position at which chain record begins */
	if((oc->valid= ftell(fp)) < 200)
		odb_ftlerr("odb_readchn: bad file position");

        /* read chain record date */
	kdate= 0;
	rc= fread(&kdate, 2, 1, fp);
	oc->date= 10000* (1950+ kdate/ 372) + 100*(1+ ((kdate/ 31)% 12))
		  + (1+ (kdate% 31));

	/* read underlying symbol, number of options, and data mode */
	kctl= 0;
	rc += fread(&kctl, 1, 1, fp);
	if((m= kctl & 7) < 1 || m > 6)
		odb_ftlerr("odb_readchn: bad symbol size");
	if((n= (kctl >> 3) & 7) > 2)
		odb_ftlerr("odb_readchn: bad nopt size");
	oc->mode= (kctl >> 6) & 1;
	memset(oc->usymbol, 0, 8);
	rc+= fread(oc->usymbol, m, 1, fp);
	oc->nopt= 0;
	if(n > 0) rc+= fread(&oc->nopt, n, 1, fp);

        /* check for data errors */
	if(rc != ((n > 0) ? 4 : 3) || ferror(fp))
		odb_ftlerr("odb_readchn: date, symbol, nopt read error");
	odb_checkdate(oc->date, "odb_readchn: bad chain date");
	if(oc->nopt > ODBMCH) odb_ftlerr("odb_readchn: ODBMCH exceeded");
	if(oc->nopt < 0) odb_ftlerr("odb_readchn: bad");

	/* read stock data */
	rc= fread(&oc->stkcls, 4, 1, fp);
	rc+= fread(&oc->stkacls, 4, 1, fp);
	if(oc->mode & 1) {	/* additional stock data are available */
		rc+= fread(&oc->stkopn, 4, 1, fp);
		rc+= fread(&oc->stkhi, 4, 1, fp);
		rc+= fread(&oc->stklo, 4, 1, fp);
		rc+= fread(&oc->stkvol, 4, 1, fp);
	}
	else {			/* only closing prices are available */
		oc->stkopn= 0.0;
		oc->stkhi= 0.0;
		oc->stklo= 0.0;
		oc->stkvol= 0.0;
	}
	if(rc != ((oc->mode & 1) ? 6 : 2) || ferror(fp))
		odb_ftlerr("odb_readchn: error reading stock data");

	/* read and extract price increment codes */
	kincrcode= 0;
	if(fread(&kincrcode, 1, 1, fp) != 1 || ferror(fp))
		odb_ftlerr("odb_readchn: error reading increment codes");
	if((kincrcode & 7) > 5 || ((kincrcode >> 3) & 7) > 3)
		odb_ftlerr("odb_readchn: bad price increment codes");
	fmstrike= odb_strikeinc[kincrcode & 7];
	fmprice= odb_priceinc[(kincrcode >> 3) & 7];

        /* read and decompress data for each option in chain */
	for(kopt= 0; kopt < oc->nopt; kopt++) {

                /* read and parse the control word */
		kcwd= 0;
		if(fread(&kcwd, 3, 1, fp) != 1 || ferror(fp))
			odb_ftlerr("odb_readchn: error reading kcwd");
		nzstrike= kcwd % 4;
		nzbidask= (kcwd / 4) % 4;
		nzvol= (kcwd / 16) % 5;
		nzoi= (kcwd / 80) % 5;
		nzvx= (kcwd / 400) % 3;
		ktype= (kcwd / 1200) % 2;
		kyrs= (kcwd / 2400) % 4;
		kmon= 1 + (kcwd / 9600) % 12;
		kday= 1 + (kcwd / 115200) % 31;

		/* read integer representations of option data */
		kstrike= 0; kbid= 0; kask= 0; kvol= 0; koi= 0; kvx= 0;
		rc= 0;
		if(nzstrike) rc+= fread(&kstrike, 1, nzstrike, fp);
                if(nzbidask) {
			rc+= fread(&kbid, 1, nzbidask, fp);
			rc+= fread(&kask, 1, nzbidask, fp);
                }
		if(nzvol) rc+= fread(&kvol, 1, nzvol, fp);
		if(nzoi) rc+= fread(&koi, 1, nzoi, fp);
		if(nzvx) rc+= fread(&kvx, 1, nzvx, fp);
		if(rc!=nzstrike+2*nzbidask+nzvol+nzoi+nzvx || ferror(fp))
			odb_ftlerr("odbread_chn: chain data read error");

                /* extract data to option chain structure */
		oc->strike[kopt]= (float)(fmstrike * kstrike);
		oc->bid[kopt]= (float)(fmprice * kbid);
		oc->ask[kopt]= (float)(fmprice * kask);
		oc->vol[kopt]= (float)kvol;
		oc->oi[kopt]= (float)koi;
		oc->vx[kopt]= (float)(0.01 * kvx);  /* implied volatility */
		oc->expyr[kopt]= (long)(kyrs + oc->date / 10000);
		oc->expmo[kopt]= (long)kmon;
		oc->expdy[kopt]= (long)kday;
		oc->otype[kopt]= (long)ktype;	    /* 0=call, 1=put */
        }

        /* read and verify block terminator */
	rc= 0;
	if(fread(&rc, 1, 1, fp) != 1 || ferror(fp))
		odb_ftlerr("odb_readchn: error reading block terminator");
	if(rc != 37) odb_ftlerr("odb_readchn: invalid block terminator");
}

static void odb_checkdate (long ldate, char msg[]) {
        /* verifies a date */
        int k;
        if((k=(ldate/10000))<1951 || k>2049) goto L01;
        if((k=((ldate/100)%100))<1 || k>12) goto L01;
        if((k=(ldate%100))<1 || k>31) goto L01;
        return;
   L01: fprintf(stdout,"\n odb_checkdate: bad date %ld\n",(long)ldate);
        odb_ftlerr(msg);
}

static long odb_findstring (char strarr[], long m, long n, char str[])
{
        /* locates string in array sorted in ascending order */
        long ia, ib, k;
        if(strcmp(str,strarr)<0) return(0);
        if(strcmp(str,strarr+m*(ib=n-1))>=0) return(ib);
        ia=0;
        while(ib-ia>1) {
                if(strcmp(strarr+m*(k=(ia+ib)>>1),str)>0) ib=k;
                else ia=k;
        }
        if(strcmp(strarr+m*ib,str)==0) return(ib);
        return(ia);
}

static long odb_findlong (long larr[], long n, long lg)
{
        /* locates long integer in array sorted in ascending order */
        long ia, ib, k;
        if(lg<larr[ia=0]) return(0);
        if(lg>=larr[ib=n-1]) return(ib);
        while(ib-ia>1) {
                if(larr[k=(ia+ib)>>1]>lg) ib=k;
                else ia=k;
        }
        if(lg==larr[ib]) return(ib);
        return(ia);
}

static void* odb_bmalloc (size_t nbytes)
{
        /* checked memory allocation */
        void *ptr;
        if((ptr=(void*)malloc(nbytes))==NULL)
                odb_ftlerr("odb_bmalloc: insufficient memory");
        return(memset(ptr,0,nbytes));
}

static void odb_ftlerr (char msg[])
{
        /* handles fatal errors */
	fprintf(stderr,"\nERROR: %s\n",(char*)msg);
        exit(EXIT_FAILURE);
}

/*---------------------------------------------------------------------------
c  Code used only for debugging
*/

#if 1==0
    main () {
        static ODBCHAIN oc;
        static ODBFILE *odb;
        static long istk, iday, m;
	odb=odb_open("../mktdata/dbases/indexopts", 0);
        fprintf(stdout,
                "NDAY=%ld  NSTK=%ld  STKNO(OEX)=%ld  DAYNO(20030211)=%ld\n",
                (long)odb_nday(odb), (long)odb_nstk(odb),
                (long)(m=odb_stkno(odb, "OEX")),
                (long)odb_dayno(odb, 20030211)  );
	fprintf(stdout, "SYMBOL(2)=%s  DATE(1)=%ld\n",
		(char*)odb_usym(odb, 2), (long)odb_date(odb, 1)  );
        fflush(stdout);
        for(istk=0; istk<odb_nstk(odb); istk+=1) {
                fprintf(stdout,"%10s\n",(char*)odb_usym(odb, istk));
        }
        fflush(stdout);
	for(istk=odb_stkno(odb, "QQQQ"); istk<odb_nstk(odb); istk+=100) {
		for(iday=0; iday<odb_nday(odb); iday+=20) {
                        odb_read(odb, istk, iday, &oc);
                        if(oc.valid) odb_typechain(stdout, &oc);
                        fflush(stdout);
                }
        }
        odb_close(odb);
        return(0);
    }
#endif


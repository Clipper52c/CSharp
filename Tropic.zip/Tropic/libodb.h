#ifndef LIBODB_H
#define LIBODB_H

/*
c  libodb.h
c
c  Equity and index options database library header file.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2006.  All Rights Reserved.
*/

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ODBMCH	(1355)		/* maximum options in any chain */

typedef struct {            /* database file header information */
	long	fileid;			/* database file type: 939337 */
	long	firstdate;		/* first data date: YYYYMMDD */
	long	lastdate;		/* last data date: YYYYMMDD */
	long	blockindex;		/* byte position for next write */
	long	updatetime;		/* time of last update: time_t */
} ODBFILEHDR;

typedef struct {			/* complete option chain record */
	long    valid;          /* byte pointer to record, 0=no data */
	long	mode;			/* data mode: 1=has stock O,H,L,V */
	long    date;           /* quote date, YYYYMMDD */
	char	usymbol[8];     /* stock (underlying) symbol */
	float   stkacls;        /* stock close, adjusted */
    float   stkcls;         /* stock close, unadjusted */
    float   stkopn;         /* stock open, unadjusted */
    float   stkhi;          /* stock high, unadjusted */
    float   stklo;          /* stock low, unadjusted */
	float   stkvol;         /* stock volume, unadjusted */
	long    nopt;           /* options in chain: 0 .. MAXCHN */
	float   strike[ODBMCH]; /* option strike price */
    float   bid[ODBMCH];    /* option last bid */
    float   ask[ODBMCH];    /* option last offer */
    float   vol[ODBMCH];    /* option volume */
    float   oi[ODBMCH];     /* option open interest */
	float	vx[ODBMCH];		/* implied volatility, daily percent */
	long    expyr[ODBMCH];  /* expir. year: 2000, 2001, .. */
    long    expmo[ODBMCH];  /* expir. month: 1, 2, .. 12 */
    long	expdy[ODBMCH];	/* expir. day: 1, 2, .. 31 (Saturday) */
    long    otype[ODBMCH];  /* option type: 0=call, 1=put */
} ODBCHAIN;

typedef struct {		/* main database and index structure */
	char    dbfn[256];	/* database file specification */
	char    ndxfn[256];	/* index file specification */
	FILE*	dbfp;		/* database file pointer */
	FILE*	ndxfp;		/* index file pointer */
	long    ndxfileid;	/* index file type: 939338 */
	long    nstk;	    /* total number of underlying stocks */
	long    nday;       /* total number of bars or days */
	long    firstdate;	/* first date in database */
	long    lastdate;	/* last date in database */
	long    updatetime; /* last database update time */
	long    blockindex;	/* next block position in database */
	char*	symbol;     /* underlying symbols [8*nstk] */
	long*	date;       /* dates [nday] */
	long*	fpos;       /* database file positions [nday*nstk] */
	char*	fbuf;		/* database file buffer */
} ODBFILE;

ODBFILE* odb_open (char fn[], long lbufsize);
void odb_close (ODBFILE *odb);
long odb_nday (ODBFILE *odb);
long odb_nstk (ODBFILE *odb);
long odb_stkno (ODBFILE *odb, char symbol[]);
long odb_dayno (ODBFILE *odb, long idate);
char* odb_usym (ODBFILE *odb, long istk);
long odb_date (ODBFILE *odb, long iday);
void odb_read (ODBFILE *odb, long istk, long iday, ODBCHAIN *oc);
long odb_find (ODBCHAIN *oc, long itype, long iexpdt, float strike);
void odb_typechain (FILE *fp, ODBCHAIN *oc);

#ifndef max
	#define max(a,b) (((a)>(b))?(a):(b))
	#define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifdef __cplusplus
};
#endif

#endif /* LIBODB_H */


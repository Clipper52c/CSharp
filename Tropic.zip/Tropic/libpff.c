/*
c  libpff.c
c
c  Revised 2007.08.13
c
c  Record-oriented functions for reading several types (939308, 939309,
c  939310, 939311) of database files containing stock or futures data,
c  and type 939329 supplemental files containing option implied
c  volatility, earnings, and/or other kinds of data that are bar-aligned
c  with the primary database.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2007.  All rights reserved.
*/

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "libpff.h"

/*
c   Description of functions
c
c   PORTFOLIODATA* pff_open (char fn[], long mode, long nbuf);
c
c	Opens a database file of type 939308 through 939311, containing
c       stock or futures data, and an optional supplemental database
c       file of type 939329, containing implied volatilities, earnings,
c       and/or other data.  Function pff_open also allocates memory for
c	the PORTFOLIODATA structure and many of its members.
c       Arguments
c	      fn	 - File name and path, without extension (input)
c         mode	 - Specifies database type and mode (input)
c		       1s bit on - O,H,L,C,V,SF stock data
c		       2s bit on - total buffering of all data
c		       4s bit on - has supplemental data
c		       8s bit on - O,H,L,C,V,OI,SF futures data
c		      16s bit on - intraday data (has time series)
c         nbuf   - Size of file buffer for supplemental data (input)
c       Returns
c         Pointer to a PORTFOLIODATA database structure with the
c         following members initialized
c            pff->nbar  - number of bars in data series
c            pff->nmkt  - number of markets (securities) in database
c            pff->nser  - number of primary series per market (6 or 7)
c            pff->mode  - mode passed as argument to pff_open()
c	         pff->mfid  - file type identifier (939308 through 939311)
c	         pff->ncmn  - number of common series (1 or 2)
c            pff->ldt[] - array [0..pff->nbar-1] of common YYYYMMDD dates
c	         pff->ltm[] - array [0..pff->nbar-1] of common HHMMSS times
c       Notes
c         1) Dates in pff->ldt[] and times in pff->ltm[] are common
c	       across all securities in the database.  For end-of-day
c          data, times are all set to 16:00:00 (4 P.M.) and pff->ncmn
c	       is set to 1; for intraday data, times are valid data and
c	       and pff->ncmn is set to 2.  Dates are always valid.
c         2) Longs and floats are assumed to occupy four bytes.
c	  3) Total buffering enables faster access to data, but requires
c	       substantially more memory.  The argument nbuf controls
c	       supplemental file buffering which is independent of total
c	       buffering (set nbuf to zero when using total buffering).
c       Subroutines required
c         pff_malloc, pff_ftlerr, pff_strtrim
c
c    void pff_close (PORTFOLIODATA *pff);
c
c       Closes portfolio and supplemental database files previously
c       opened with pff_open and frees all memory allocated to the
c       PORTFOLIODATA structure and its members.
c       Arguments
c         pff    - Pointer to a valid PORTFOLIODATA structure (input)
c       Returns
c         None
c       Subroutines required
c         None
c
c   void pff_seeksymbol (PORTFOLIODATA *pff, long imkt);
c
c       Loads symbol and name for security indexed by imkt into
c       PORTFOLIODATA structure members.
c       Arguments
c         pff    - Pointer to a valid PORTFOLIODATA structure (input)
c         imkt   - Index of security, 0 to pff->nmkt-1 (input)
c       Returns
c         Via PORTFOLIODATA structure members
c            pff->symbol  - ticker symbol for specified security
c            pff->name    - descriptive name for specified security
c       Subroutines required
c         pff_strtrim, pff_ftlerr
c
c   void pff_seekquotes (PORTFOLIODATA *pff, long imkt);
c
c       Loads primary data series (prices, volumes, split factors,
c       and open interests) for the security indexed by imkt
c       into PORTFOLIODATA structure members.
c       Arguments
c         pff    - Pointer to a valid PORTFOLIODATA structure (input)
c         imkt   - Index of security, 0 to pff->nmkt-1 (input)
c       Returns
c         Via PORTFOLIODATA structure members
c            pff->opn[]   - opening prices
c            pff->hi[]    - high prices
c            pff->lo[]    - low prices
c            pff->cls[]   - closing prices
c            pff->vol[]   - volumes
c	         pff->oi[]	  - open interests (futures data)
c            pff->sf[]    - split or adjustment factors
c         Each of these structure members may be treated as a vector
c         of length pff->nbar, the number of bars in each data series,
c         with the index beginning at 0 and ending at pff->nbar-1
c       Notes
c         1) In the case of stocks, the split factor may be multiplied
c	       by the price to obtain the raw price (original price, not 
c	       adjusted for splits), and divided into the volume to 
c	       obtain the raw volume.  With futures, the split factor
c	       can be used to obtain unadjusted prices for continuous,
c	       back-adjusted contracts.  See documentation on the
c	       particular database to determine the data to be found
c	       in the pff->sf[] array.
c         2) In the case of stocks, the first few elements of the split
c	       factor series (that is, pff->sf[]) may not contain
c	       split factors; instead, they may contain a variety of 
c	       useful information about the stock.  For example, 
c	       pff->sf[0] may contain, encoded as a four digit number,
c	       the following:
c                 1s digit    - Type: 0=group, 1=stock or spyder, 2=index
c                 10s digit   - Active: 0=no, 1=yes
c                 100s digit  - Optionable: 0=no, 1=yes
c                 1000s digit - Exchange: 1=NYSE, 2=AMEX, 3=NASD, 0=N/A
c         3) On bars where a security is inactive (gone for good or not
c	       yet issued) or has missing data, our convention is to set 
c	       volume to true or "hard" zero; on bars where the security
c              is active (alive), but has not traded, we set like to set
c	       volume to a miniscule positive number.
c         4) A null pointer is returned when a given data series is not
c              present in the database; e.g., pff->oi is returned as a
c              null pointer when reading a type 939308 stock database
c              since open interest is specific to futures.
c       Subroutines required
c         pff_ftlerr
c
c   void pff_seeksupp (PORTFOLIODATA *pff, long imkt);
c
c       Loads supplemental data series for security indexed by imkt
c	into PORTFOLIODATA structure members.
c       Arguments
c         pff    - Pointer to a valid PORTFOLIODATA structure (input)
c         imkt   - Index of security, 0 to pff->nmkt-1 (input)
c       Returns
c         Via PORTFOLIODATA structure members
c            pff->suppa[]    - supplemental series a
c            pff->suppb[]    - supplemental series b
c            pff->suppc[]    - supplemental series c
c            pff->suppd[]    - supplemental series d
c         Each of these structure members may be treated as a vector
c         of length pff->nbar, the number of bars in each data series,
c         with the index beginning at 0 and ending at pff->nbar-1
c       Notes
c         On bars for which data are unavailable, implied volatility
c         figures, option volumes, and other variables may be set to
c	  zero.  Other conventions may be used for other kinds of data.
c       Subroutines required
c         pff_ftlerr
*/

PORTFOLIODATA* pff_open (char fn[], long mode, long nbuf) {

    PORTFOLIODATA *pff;
    long k, n, m, fileid, rc, nmkt_supp, nbar_supp, nind_supp;
    float zdate_supp;
    double currdttm, prevdttm;
    char *buf;

    /* check variable size assumptions */
    rc=((sizeof(long)!=4)||(sizeof(float)!=4)||(sizeof(char)!=1));
    if(rc) pff_ftlerr("pff_open: invalid variable size assumptions");

    /* verify mode argument */
    m=((mode & PFF_STDDATA_BIT) != 0);
    n=((mode & PFF_FUTDATA_BIT) != 0);
    if((mode>>PFF_MODE_MAXBITS)!=0 || (m && n) || ((!m) && (!n)))
        pff_ftlerr("pff_open: invalid mode");

    /* allocate database data structure */
    pff=(PORTFOLIODATA*)pff_malloc(sizeof(PORTFOLIODATA));

    /* open quote, supplemental, and symbol files for reading */
    buf=(char*)pff_malloc(256);
    sprintf(buf,"%s.dat",fn);
    if((pff->dfil=fopen(buf,"rb"))==NULL)
        pff_ftlerr("pff_open: quote file not found");
    sprintf(buf,"%s.txt",fn);
    if((pff->sfil=fopen(buf,"rb"))==NULL)
        pff_ftlerr("pff_open: symbol file not found");
    pff->mode=mode;
    pff->fbuf=NULL;
    pff->qfil=NULL;
    if((mode & PFF_SUPPDATA_BIT) != 0) {
        sprintf(buf,"%s.ind",fn);
        if((pff->qfil=fopen(buf,"rb"))==NULL)
            pff_ftlerr("pff_open: supplemental file not found");
        if(nbuf>0) {
            pff->fbuf=(char*)pff_malloc(nbuf);
            if(setvbuf(pff->qfil,pff->fbuf,_IOFBF,nbuf)!=0)
                pff_ftlerr("pff_open: supplemental file buffer error");
        }
    }
    free(buf);
    buf=NULL;

    /* determine series count and file type identifier */
    if((mode & PFF_STDDATA_BIT) != 0) {
        pff->nser=6;  /* six data series (stocks): O,H,L,C,V,SF */
        if((mode & PFF_INTRADAY_BIT) != 0)
            pff->mfid=939309;		/* intraday stock data */
        else pff->mfid=939308;		/* end-of-day stock data */
    }
    else if((mode & PFF_FUTDATA_BIT) != 0) {
        pff->nser=7;  /* seven data series (futures): O,H,L,C,V,OI,SF */
        if((mode & PFF_INTRADAY_BIT) != 0)
            pff->mfid=939311;		/* intraday futures data */
        else pff->mfid=939310;		/* end-of-day futures data */
    }

    /* read and verify header of primary quote data file */
    rc=fread(&fileid,4,1,pff->dfil);        /* Read the first line of the data base, corresponds to tsapnd.c void write_database(APPLICATION* app) line 728 bwrite(&k, sizeof(long), 1, fp);*/
    if(rc!=1 || fileid!=pff->mfid)
        pff_ftlerr("pff_open: incorrect quote file header");
    rc=fread(&pff->nbar,4,1,pff->dfil);		/* number of bars */
    rc+=fread(&pff->nmkt,4,1,pff->dfil);	/* number of securities */
    if(rc!=2 || ferror(pff->dfil))
        pff_ftlerr("pff_open: error reading quote file header");

    /* allocate storage and read common (across securities) dates */
    pff->ldt=(long*)pff_malloc(4*pff->nbar);
    rc=fread(pff->ldt,4,pff->nbar,pff->dfil);
    if(rc!=pff->nbar || ferror(pff->dfil))
        pff_ftlerr("pff_open: error reading dates");
    for(k=0; k<pff->nbar; k++) {
        /* convert dates to long YYYYMMDD integer form */
        pff->ldt[k]=19000000+(long)(0.4+(*((float*)&pff->ldt[k])));
    }

    /* allocate storage and read (or set) common times */
    pff->ltm=(long*)pff_malloc(4*pff->nbar);
    if((mode & PFF_INTRADAY_BIT) != 0) {  
        /* real intraday data, so read times */
        rc=fread(pff->ltm,4,pff->nbar,pff->dfil);
        if(rc!=pff->nbar || ferror(pff->dfil))
            pff_ftlerr("pff_open: error reading times");
        for(k=0; k<pff->nbar; k++) {
            /* convert times to long HHMMSS integer form */
            pff->ltm[k]=(long)(0.4+(*((float*)&pff->ltm[k])));
        }
        pff->ncmn=2;	/* two valid common series: date and time */
    }
    else {  
        /* end-of-day data (set fixed times) */
        for(k=0; k<pff->nbar; k++) pff->ltm[k]=160000;
        pff->ncmn=1;	/* one valid common series: date */
    }
    
    /* verify dates and times */
    prevdttm= -1.0;
    for(k=0; k<pff->nbar; k++) {
        /* examine dates */
        n=pff->ldt[k];
        if( (rc=n/10000)<1850 || rc>2050 ||
            (rc=(n/100)%100)<1 || rc>12 ||
            (rc=n%100)<1 || rc>31 )
                pff_ftlerr("pff_open: invalid date");
        /* examine times */
        m=pff->ltm[k];
        if( (rc=m/10000)<0 || rc>23 ||
            (rc=(m/100)%100)<0 || rc>59 ||
            (rc=m%100)<0 || rc>59 )
                pff_ftlerr("pff_open: invalid time");
        /* examine date-time sequence */
        currdttm=1000000.0*(double)n + (double)m;
        if(currdttm<=prevdttm)
            pff_ftlerr("pff_open: invalid date-time sequence");
        prevdttm=currdttm;                
    }
    
    /* read and verify header of supplemental data file */
    if((mode & PFF_SUPPDATA_BIT) != 0) {
        rc=fread(&fileid,4,1,pff->qfil);
        if(rc!=1 || fileid!=939329)
            pff_ftlerr("pff_open: invalid supplemental file header");
        rc=fread(&nmkt_supp,4,1,pff->qfil);
        rc+=fread(&nind_supp,4,1,pff->qfil);
        rc+=fread(&nbar_supp,4,1,pff->qfil);
        rc+=fread(&zdate_supp,4,1,pff->qfil);
        if(rc!=4 || ferror(pff->qfil))
            pff_ftlerr("pff_open: error reading supplemental header");
        /* verify match between primary and supplemental data files */
        if(nmkt_supp!=pff->nmkt || nbar_supp!=pff->nbar ||
            (19000000+(long)(0.4+zdate_supp))!=pff->ldt[pff->nbar-1])
                pff_ftlerr("pff_open: mismatched supplemental file");
        if(nind_supp!=4) pff_ftlerr("pff_open: supplemental nind invalid");
    }
    
    /* allocate memory for additional database structure members */
    if((mode & PFF_TOTALBUF_BIT) == 0) {  
        /* data maintained in database files (series buffering only) */
        pff->symbol=(char*)pff_malloc(16);
        pff->name=(char*)pff_malloc(48);
        pff->opn=(float*)pff_malloc(n= sizeof(float)*pff->nbar);
        pff->hi=(float*)pff_malloc(n);
        pff->lo=(float*)pff_malloc(n);
        pff->cls=(float*)pff_malloc(n);
        pff->vol=(float*)pff_malloc(n);
        if((mode & PFF_FUTDATA_BIT) != 0) {
            pff->oi=(float*)pff_malloc(n);
        }
        else {
            pff->oi=NULL;
        }
        pff->sf=(float*)pff_malloc(n);
        if((mode & PFF_SUPPDATA_BIT) != 0) {
            pff->suppa=(float*)pff_malloc(n);
            pff->suppb=(float*)pff_malloc(n);
            pff->suppc=(float*)pff_malloc(n);
            pff->suppd=(float*)pff_malloc(n);
        }
        else {
            pff->suppa=NULL;
            pff->suppb=NULL;
            pff->suppc=NULL;
            pff->suppd=NULL;
        }
        pff->baseptr=NULL;
        pff->suppptr=NULL;
        pff->symptr=NULL;
        pff->nameptr=NULL;
    }
    else {  
        /* all accessed data saved in memory (total buffering) */
        pff->symbol=NULL;
        pff->name=NULL;
        pff->opn=NULL;
        pff->hi=NULL;
        pff->lo=NULL;
        pff->cls=NULL;
        pff->vol=NULL;
        pff->oi=NULL;
        pff->sf=NULL;
        pff->suppa=NULL;
        pff->suppb=NULL;
        pff->suppc=NULL;
        pff->suppd=NULL;
        pff->baseptr=(float**)pff_malloc(sizeof(float*)*pff->nmkt);
        pff->symptr=(char**)pff_malloc(sizeof(char*)*pff->nmkt);
        pff->nameptr=(char**)pff_malloc(sizeof(char*)*pff->nmkt);
        for(k=0; k<pff->nmkt; k++) {
            pff->baseptr[k]=NULL;
            pff->nameptr[k]=NULL;
            pff->symptr[k]=NULL;
        }
        if((mode & PFF_SUPPDATA_BIT) != 0) {
            pff->suppptr=(float**)pff_malloc(sizeof(float*)*pff->nmkt);
            for(k=0; k<pff->nmkt; k++) pff->suppptr[k]=NULL;
        } 
        else pff->suppptr=NULL;
    }

    /* return pointer to database structure */
    return(pff);
}

void pff_close (PORTFOLIODATA *pff) {

    long k;
    
    /* deallocate date and time series */
    free(pff->ldt);
    free(pff->ltm);
    
    /* close symbol and quote files */
    fclose(pff->sfil);
    fclose(pff->dfil);
    
    /* close supplemental file and free any file buffer */
    if((pff->mode & PFF_SUPPDATA_BIT) != 0) {
        fclose(pff->qfil);
        if(pff->fbuf) free(pff->fbuf);
    }
    
    /* deallocate memory used in unbuffered mode */
    if((pff->mode & PFF_TOTALBUF_BIT) == 0) {
        free(pff->symbol);
        free(pff->name);
        free(pff->opn);
        free(pff->hi);
        free(pff->lo);
        free(pff->cls);
        free(pff->vol);
        if(pff->oi) free(pff->oi);
        free(pff->sf);
        if((pff->mode & PFF_SUPPDATA_BIT) != 0) {
            free(pff->suppa);
            free(pff->suppb);
            free(pff->suppc);
            free(pff->suppd);
        }
    }
    
    /* deallocate memory used in totally buffered mode */
    else {
        for(k=0; k<pff->nmkt; k++) {
            if(pff->baseptr[k]) free(pff->baseptr[k]);
            if(pff->nameptr[k]) free(pff->nameptr[k]);
            if(pff->symptr[k]) free(pff->symptr[k]);
        }
        free(pff->baseptr);
        free(pff->nameptr);
        free(pff->symptr);
        if((pff->mode & PFF_SUPPDATA_BIT) != 0) {
            for(k=0; k<pff->nmkt; k++)
                if(pff->suppptr[k]) free(pff->suppptr[k]);
            free(pff->suppptr);
        }        
    }
    
    /* deallocate the database data structure */
    free(pff);
}

void pff_seeksymbol (PORTFOLIODATA *pff, long imkt) {

    long rc, i;
    char symbol[12], name[46];
    
    /* verify arguments */
    if(imkt<0 || imkt>=pff->nmkt)
        pff_ftlerr("pff_seeksymbol: invalid imkt");

    /* read symbol and name in totally buffered mode */
    if((pff->mode & PFF_TOTALBUF_BIT) != 0) {
        if(pff->symptr[imkt]==NULL) {
            /* read data into local storage */
            rc=fseek(pff->sfil,52*imkt,SEEK_SET);
            if(rc!=0 || ferror(pff->sfil))
                pff_ftlerr("pff_seeksymbol: seek error");
            rc=fread(symbol,10,1,pff->sfil);
            symbol[9]=0;
            pff_strtrim(symbol);
            rc+=fread(name,40,1,pff->sfil);
            name[40]=0;
            pff_strtrim(name);
            if(rc!=2 || ferror(pff->sfil))
                pff_ftlerr("pff_seeksymbol: read error");
            for(i=0; symbol[i]; i++)
                symbol[i]=toupper(symbol[i]);
            /* allocate buffer memory with copy of data */
            pff->symptr[imkt]= strdup(symbol);
            pff->nameptr[imkt]= strdup(name);
        }
        /* direct name and symbol pointers to relevant buffers */
        pff->symbol= pff->symptr[imkt];
        pff->name= pff->nameptr[imkt];
    }
    
    /* read symbol and name in unbuffered mode */
    else {
        /* read data into local storage */
        rc=fseek(pff->sfil,52*imkt,SEEK_SET);
        if(rc!=0 || ferror(pff->sfil))
            pff_ftlerr("pff_seeksymbol: seek error");
        rc=fread(symbol,10,1,pff->sfil);
        symbol[9]=0;
        pff_strtrim(symbol);
        rc+=fread(name,40,1,pff->sfil);
        name[40]=0;
        pff_strtrim(name);
        if(rc!=2 || ferror(pff->sfil))
            pff_ftlerr("pff_seeksymbol: read error");
        for(i=0; symbol[i]; i++)
            symbol[i]=toupper(symbol[i]);
        /* copy data into pre-allocated, user-accessible arrays */
        strcpy(pff->symbol, symbol);
        strcpy(pff->name, name);
    }
}

void pff_seekquotes (PORTFOLIODATA *pff, long imkt) {

    long fileid, byteptr, rc, nbar, nser;
    
    /* verify arguments and copy some data to local variables */
    if(imkt<0 || imkt>=pff->nmkt)
        pff_ftlerr("pff_seekquotes: invalid imkt");
    nser=pff->nser;
    nbar=pff->nbar;

    /* read quote data in buffered mode */    
    if((pff->mode & PFF_TOTALBUF_BIT) != 0) {
        if(pff->baseptr[imkt]==NULL) {
            /* allocate buffer storage and read specified data */
            byteptr=12+4*(pff->ncmn*nbar+(nser*nbar+1)*imkt);
            rc=fseek(pff->dfil,byteptr,SEEK_SET);
            if(rc!=0 || ferror(pff->dfil))
                pff_ftlerr("pff_seekquotes: seek error");
            pff->baseptr[imkt]=(float*)pff_malloc(4*nbar*nser);
            rc=fread(pff->baseptr[imkt],4,nbar*nser,pff->dfil);
            rc+=fread(&fileid,4,1,pff->dfil);
            if(rc!=1+nbar*nser || ferror(pff->dfil))
                pff_ftlerr("pff_seekquotes: read error");
            if(fileid!=pff->mfid)
                pff_ftlerr("pff_seekquotes: block error");
        }
        /* direct user-accessible pointers to the data */
        pff->opn= pff->baseptr[imkt];
        pff->hi= pff->opn + nbar;
        pff->lo= pff->hi + nbar;
        pff->cls= pff->lo + nbar;
        pff->vol= pff->cls + nbar;
        if((pff->mode & PFF_STDDATA_BIT) != 0) {
            pff->sf= pff->vol + nbar;        
        }
        else if((pff->mode & PFF_FUTDATA_BIT) != 0) {
            pff->oi= pff->vol + nbar;
            pff->sf= pff->oi + nbar;
        }
    }
    
    /* read quote data in unbuffered mode */
    else {
        /* read data into user-accessible, pre-allocated arrays */
        byteptr=12+4*(pff->ncmn*nbar+(nser*nbar+1)*imkt);
        rc=fseek(pff->dfil,byteptr,SEEK_SET);
        if(rc!=0 || ferror(pff->dfil))
            pff_ftlerr("pff_seekquotes: seek error");
        rc=fread(pff->opn,4,nbar,pff->dfil);	    /* open prices */
        rc+=fread(pff->hi,4,nbar,pff->dfil);	    /* high prices */
        rc+=fread(pff->lo,4,nbar,pff->dfil);	    /* low prices */
        rc+=fread(pff->cls,4,nbar,pff->dfil);	    /* last prices */
        if((pff->mode & PFF_STDDATA_BIT) != 0) {
            rc+=fread(pff->vol,4,nbar,pff->dfil);   /* volumes */
        }
        else if((pff->mode & PFF_FUTDATA_BIT) != 0) {
            rc+=fread(pff->vol,4,nbar,pff->dfil);   /* volumes */
            rc+=fread(pff->oi,4,nbar,pff->dfil);    /* open interests */
        }        
        rc+=fread(pff->sf,4,nbar,pff->dfil);	    /* split factors */
        rc+=fread(&fileid,4,1,pff->dfil);
        if(rc!=1+nser*nbar || ferror(pff->dfil))
            pff_ftlerr("pff_seekquotes: read error");
        if(fileid!=pff->mfid) 
            pff_ftlerr("pff_seekquotes: block error");
    }
}

void pff_seeksupp (PORTFOLIODATA *pff, long imkt) {

    long fileid, byteptr, rc, nbar;
    
    /* verify arguments and copy data to local variable */
    if((pff->mode && PFF_SUPPDATA_BIT) == 0)
        pff_ftlerr("pff_seeksupp: wrong mode, no suppdata");
    if(imkt<0 || imkt>=pff->nmkt)
        pff_ftlerr("pff_seeksupp: invalid imkt");    
    nbar=pff->nbar;
    
    /* read supplemental data in buffered mode */
    if((pff->mode & PFF_TOTALBUF_BIT) != 0) {
        if(pff->suppptr[imkt]==NULL) {
            /* allocate buffer storage and read specified data */
            byteptr=20+(16*nbar+4)*imkt;
            rc=fseek(pff->qfil,byteptr,SEEK_SET);
            if(rc!=0 || ferror(pff->qfil))
                pff_ftlerr("pff_seeksupp: seek error");
            pff->suppptr[imkt]=(float*)pff_malloc(16*nbar);
            rc=fread(pff->suppptr[imkt],4,nbar*4,pff->qfil);
            rc+=fread(&fileid,4,1,pff->qfil);
            if(rc!=1+4*nbar || ferror(pff->qfil))
                pff_ftlerr("pff_seeksupp: read error");
            if(fileid!=939329) 
                pff_ftlerr("pff_seeksupp: block error");            
        }
        /* direct user-accessible pointers to relevant data series */
        pff->suppa= pff->suppptr[imkt];
        pff->suppb= pff->suppa + nbar;
        pff->suppc= pff->suppb + nbar;
        pff->suppd= pff->suppc + nbar;
    }
    
    /* read supplemental data in unbuffered mode */    
    else {
        /* read data into user-accessible, pre-allocated arrays */
        byteptr=20+(16*nbar+4)*imkt;
        rc=fseek(pff->qfil,byteptr,SEEK_SET);
        if(rc!=0 || ferror(pff->qfil))
            pff_ftlerr("pff_seeksupp: seek error");
        rc=fread(pff->suppa,4,nbar,pff->qfil);
        rc+=fread(pff->suppb,4,nbar,pff->qfil);
        rc+=fread(pff->suppc,4,nbar,pff->qfil);
        rc+=fread(pff->suppd,4,nbar,pff->qfil);
        rc+=fread(&fileid,4,1,pff->qfil);
        if(rc!=1+4*nbar || ferror(pff->qfil))
            pff_ftlerr("pff_seeksupp: read error");
        if(fileid!=939329) 
            pff_ftlerr("pff_seeksupp: block error");
    }
}

/*---------------------------------------------------------------------------
c  Helper functions for module libpff.c
*/

char* pff_strtrim (char str[]) {
    /* trims whitespace characters from end of string */
    char *p=str;
    while(*p) p++;
    while(p>str) {
        p--;
        if(isspace(*p)) *p='\0';
        else break;
    }
    return(str);
}

void* pff_malloc (size_t n) {
    /* safely allocates memory */
    void *ptr;
    if((ptr=(void*)malloc(n))==NULL)
        pff_ftlerr("pff_malloc: insufficient memory");
    return(ptr);
}

void pff_ftlerr (char msg[]) {
    /* handles fatal errors */
    fprintf(stderr,"\nERROR: %s\n",(char*)msg);
    exit(EXIT_FAILURE);
}


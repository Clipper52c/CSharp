#ifndef LIBPFF_H
#define LIBPFF_H

/*
c  libpff.h
c
c  Header file for libpff.c (portfolio database library).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2007.  All rights reserved.
c
c  Revised 2009.06.02
*/

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/* database data structure */
typedef struct {
    /* these members are read-only for user */
    long   nbar, nmkt, nser, ncmn, mode, mfid, *ldt, *ltm;
    float  *opn, *hi, *lo, *cls, *vol, *sf, *oi;
    float  *suppa, *suppb, *suppc, *suppd;
    char   *name, *symbol;
    /* these members are off-limits for user */
    char   *fbuf, **symptr, **nameptr;
    float  **baseptr, **suppptr;
    FILE   *dfil, *sfil, *qfil;    
} PORTFOLIODATA;

/* bit flags used in mode specification */
#define PFF_STDDATA_BIT		1	/* standard O,H,L,C,V,SF data */
#define PFF_TOTALBUF_BIT	2	/* total buffering */
#define PFF_SUPPDATA_BIT	4	/* supplemental data */
#define PFF_FUTDATA_BIT		8	/* futures O,H,L,C,V,OI,SF data */
#define PFF_INTRADAY_BIT	16	/* intraday data (has time field) */
#define PFF_MODE_MAXBITS	5	/* total bits used in mode */

/* function prototypes */
PORTFOLIODATA* pff_open (char fn[], long mode, long nbuf);
void pff_close (PORTFOLIODATA *pff);
void pff_seeksymbol (PORTFOLIODATA *pff, long imkt);
void pff_seekquotes (PORTFOLIODATA *pff, long imkt);
void pff_seeksupp (PORTFOLIODATA *pff, long imkt);
char* pff_strtrim (char str[]);
void* pff_malloc (size_t n);
void pff_ftlerr (char msg[]);

/* macro functions */
#ifndef max
    #define max(a,b) (((a)>(b))?(a):(b))
    #define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifdef __cplusplus
};
#endif

#endif /* LIBPFF_H */

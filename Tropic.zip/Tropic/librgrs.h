#ifndef LIBRGRS_H
#define LIBRGRS_H

/*
c  librgrs.h
c
c  Header file for librgrs.c (regression function library).
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2005.  All rights reserved.
*/

#include "stdio.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    long    nvar, ncas;
    double  *rxx, *rxy, *ux, *sx, uy, sy, *bw, *bwtval, *bwtprb, ridge;
    double  rsq, adjrsq, mse, sse, msr, ssr, fnull, fprob, df1, df2;
} REGRESSION;

REGRESSION* rgrs_init (long nvar);
void rgrs_free (REGRESSION *rgrs);
void rgrs_accum (REGRESSION *rgrs, float vind[], float vdep);
void rgrs_calc (REGRESSION *rgrs);
void rgrs_print (REGRESSION *rgrs, FILE *fil);
float rgrs_yhat (REGRESSION *rgrs, float vin[]);
void rgrs_weights (REGRESSION *rgrs, float wgts[]);

long rgrs_dblmxinv (long n, double a[]);
double rgrs_dbetai (double a, double b, double x);
double rgrs_dgammln (double xx);

void rgrs_ftlerr (char msg[]);
void* rgrs_bmalloc (size_t n);

#ifndef max
    #define max(a,b) (((a)>(b))?(a):(b))
    #define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifdef __cplusplus
};
#endif

#endif /* LIBRGRS_H */

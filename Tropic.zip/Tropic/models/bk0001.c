/*
booka.c

Testing module based on those used for the Options book.  The code here
is intended to serve as a template for various tests.

Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
Copyright (C) 2005.  All rights reserved.
Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libpff.c"     	/* stockmarket database component */
#include "librgrs.c"    	/* regression component */
#include "libbspm.c"   	 	/* Black-Scholes pricing model */
#include "libmisc.c"    	/* utility library */

/*---------------------------------------------------------------------------
c  Analyzes average returns as a function of any two factors.
*/

void Test3 (float p1, float p2, float p3) {

    PORTFOLIODATA *pff;  REGRESSION *rgrs;
    int ibar,imkt, mperh,mperf, nlvl1,nlvl2,nsts, k1,k2,i;
    float *rfi,*hvx, bmn1,bmx1,bmn2,bmx2, x1,x2,y, vin[6];
    double *bdqq, an;

    /* open stockmarket database */
    pff=pff_open("../mktdata/dbases/nasdbig",1,0);
    printf("NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);

    /* create regression object */
    rgrs=rgrs_init(5);

    /* initialize parameters */
    mperh=30;     /* period in bars for historical volatility */
    mperf=18;     /* period in bars for calculating returns */
    nlvl1=14;     /* number of x1 levels or bins */
    nlvl2=10;     /* number of x2 levels or bins */
    nsts=2;       /* number of statistics per bin (always 2) */
    bmn1=0.05;    /* center value for lowest x1 bin */
    bmx1=0.60;    /* center value for highest x1 bin */
    bmn2=0.70;    /* center value for lowest x2 bin */
    bmx2=1.50;    /* center value for highest x2 bin */

    /* allocate and initialize vectors and matrices */
    rfi=(float*)misc_malloc(sizeof(*rfi)*pff->nbar);
    hvx=(float*)misc_malloc(sizeof(*hvx)*pff->nbar);
    bdqq=(double*)misc_malloc(sizeof(*bdqq)*nlvl1*nlvl2*nsts);
    memset(bdqq,0,sizeof(*bdqq)*nlvl1*nlvl2*nsts);
    #define bd(i,j,k) bdqq[(i)+nlvl1*((j)+nlvl2*(k))]

    /* read risk free interest rates */
    bsrdrfi("~/mktdata/optdbmp/wgs3mo.txt",pff->nbar,pff->ldt,rfi);

    /* loop over all stocks in database */
    for(imkt=0; imkt<pff->nmkt; imkt++) {

        /* read current stock and display progress */
	if(imkt%10==0) printf("PROC IMKT=%d\r",(int)imkt);
	pff_seekquotes(pff,imkt);

        /* skip all except active optionable NASD stocks */
	i=(int)pff->sf[0];
	if((i%10)!=1) goto L1;           /* not a stock */
	if(((i/10)%10)!=1) goto L1;      /* not active */
	if(((i/100)%10)!=0) goto L1;     /* not optionable */
	if(((i/1000)%10)!=3) goto L1;    /* not NASD */

        /* skip bad or deleted stocks */
        for(ibar=0; ibar<pff->nbar; ibar++)
	    if(pff->cls[ibar]<0.001) goto L1;

        /* calculate historical volatility */
	if(p1==1) i=1;			        /* standard deviation */
	else if(p1==2) i=6;             /* average hi-lo range */
	else misc_ftlerr("invalid mode 1s digit");
	bsvltyser(pff->hi,pff->lo,pff->cls,pff->nbar,hvx,mperh,i);

        /* loop over bars leaving room at both ends */
	for(ibar=mperh+3; ibar<pff->nbar-mperf-3; ibar++) {

        /* analyze active stocks that have no original */
	    /* (not split-corrected) price < $2 in recent past */
	    if( misc_dayofweek(pff->ldt[ibar+1]) != (int)p2 ) goto L2;
	    /* if( dayofmonth(pff->dt[ibar+1]) < 21 ) goto L2; */
	    if( pff->vol[ibar+mperf] < 0.001 ) goto L2;
	    if( pff->vol[ibar-mperh] < 0.001 ) goto L2;
            for(i=ibar-mperh; i<=ibar; i++)
		if( pff->cls[i] * pff->sf[i] < 1.0 ) goto L2;
	    if( pff->cls[ibar] * pff->sf[ibar] > 15.0 ) goto L2;

	    /* determine independent variables */
	    /* x2=Highest(pff->cls,5,ibar)/Average(pff->cls,20,ibar-5); */
	    x2 = pff->cls[ibar] / Average(pff->cls,20,ibar-1);
	    x1 = hvx[ibar];

	    /* determine dependent variable, here mperf-bar return */
	    /* y=log(pff->cls[ibar+mperf]/pff->cls[ibar+1]); */
	    /* y=log(Average(pff->cls,5,ibar+5)/pff->cls[ibar+1]); */
	    if(!( pff->lo[ibar+1] < Lowest(pff->cls,20,ibar) )) goto L2;
	    y = Average(pff->cls,5,ibar+mperf) /
			Lowest(pff->cls,20,ibar) - 1.0;

	    /* restrict range of independent variables */
	    if(x1<bmn1 || x1>bmx1) goto L2;
	    if(x2<bmn2 || x2>bmx2) goto L2;

	    /* accumulate binned statistics */
	    k1=(int)(0.5+(nlvl1-1)*(x1-bmn1)/(bmx1-bmn1));
	    k2=(int)(0.5+(nlvl2-1)*(x2-bmn2)/(bmx2-bmn2));
	    bd(k1,k2,0)+=((double)y);   /* for bin mean */
	    bd(k1,k2,1)+=1.0;           /* for bin case count */

            /* accumulate regression statistics */
	    vin[0]=1.0;         	/* intercept variable */
	    vin[1]=x1;           	/* independent variable 1 */
	    vin[2]=x1*x1;
	    vin[3]=x2;  	       	/* independent variable 2 */
	    vin[4]=x2*x2;
	    vin[5]=x1*x2;		    /* interaction term */
	    rgrs_accum(rgrs,vin,y);

            /* next bar (ibar) */
            L2:;
	}

        /* next stock (imkt) */
        L1:;
	if(imkt>29999) break;     /* debug use only */
    }
    printf("\n");

    /* finish calculating statistics */
    for(k1=0; k1<nlvl1; k1++) {
	for(k2=0; k2<nlvl2; k2++) {
	    an=bd(k1,k2,1);     	        /* bin case count */
	    if(an<10.0) bd(k1,k2,0)=0.0;    /* bin mean */
	    else bd(k1,k2,0)/=an;
	}
    }
    rgrs_calc(rgrs);

    /* print bin and regression statistics to file */
    {
	FILE *fp;  float x,s,n,w;  int id1,id2;
	fp=fopen("book.txt","at");
        if(!fp) misc_ftlerr("Cannot open output file");
	fprintf(fp,"TEST3 p1=%.3f p2=%.3f p3=%.3f\nBIN_STATISTICS\n",
	    (float)p1,(float)p2,(float)p3);
	fprintf(fp,"MEANS\n%6s%6s\n%6s","X1","X2"," ");
	for(k2=1; k2<nlvl2-1; k2++)
	    fprintf(fp,"%6.2f",(float)(bmn2+(k2*(bmx2-bmn2))/(nlvl2-1)));
	fprintf(fp,"\n");
	for(k1=1; k1<nlvl1-1; k1++) {
	    fprintf(fp,"%6.2f",(float)(bmn1+(k1*(bmx1-bmn1))/(nlvl1-1)));
	    for(k2=1; k2<nlvl2-1; k2++) {
		/* apply kernel smoothing */
		s=n=0.0;
		for(id1= -1;id1<=1;id1++)
		    for(id2= -1;id2<=1;id2++) {
			w=1.0/(1+id1*id1+id2*id2);
			if((x=bd(k1+id1,k2+id2,0))!=0.0) {
			    s+=w*x; n+=w;  } }
		if(n>0.0) fprintf(fp,"%6.2f",(float)(s/n));
		else fprintf(fp,"      ");
	    }
	    fprintf(fp,"\n");
	}
	fprintf(fp,"CASES\n%6s%6s\n%6s","X1","X2"," ");
	for(k2=1; k2<nlvl2-1; k2++)
	    fprintf(fp,"%6.2f",(float)(bmn2+(k2*(bmx2-bmn2))/(nlvl2-1)));
	fprintf(fp,"\n");
	for(k1=1; k1<nlvl1-1; k1++) {
	    fprintf(fp,"%6.2f",(float)(bmn1+(k1*(bmx1-bmn1))/(nlvl1-1)));
	    for(k2=1; k2<nlvl2-1; k2++) {
		/* apply kernel smoothing */
		s=n=0.0;
		for(id1= -1;id1<=1;id1++) for(id2= -1;id2<=1;id2++) {
		    w=1.0/(1+id1*id1+id2*id2);
		    if((x=bd(k1+id1,k2+id2,0))!=0.0) {
			s+=w*bd(k1+id1,k2+id2,1); n+=w;  } }
		if(n>0.0) fprintf(fp,"%6d",(int)(s/n));
		else fprintf(fp,"      ");
	    }
	    fprintf(fp,"\n");
	}
	fprintf(fp,"\nREGRESSION_STATISTICS\n");
	rgrs_print(rgrs,fp); fprintf(fp,"\n\n");
	fclose(fp);
    }

    /* free memory and close database */
    #undef bd
    free(bdqq);
    free(hvx);
    free(rfi);
    rgrs_free(rgrs);
    pff_close(pff);
}

/*---------------------------------------------------------------------------
c  Analyzes average returns as a function of any single factor.
*/

void Test2 (int mode) {

    PORTFOLIODATA *pff;  REGRESSION *rgrs;
    int ibar,imkt, mperh,mperf, nlvl,nsts, i,k,mm;
    float *rfi, *hvx, bmn,bmx, x,y, vin[3];
    double *bdqq, an;

    /* open stock database file */
    pff=pff_open("../mktdata/dbases/nasdbig",1,0);
    printf("NBAR=%d NMKT=%d\n",(int)pff->nbar,(int)pff->nmkt);

    /* create regression object */
    rgrs=rgrs_init(3);

    /* initialize parameters */
    mperh=30;   /* period in bars for historical volatility */
    mperf=10;   /* period in bars for calculating returns */
    nlvl=20;    /* number of levels or bins */
    nsts=4;     /* number of variables per bin (always 4) */
    bmn=0.10;   /* center value for lowest bin */
    bmx=2.00;   /* center value for highest bin */

    /* allocate and initialize vectors and matrices */
    rfi=(float*)misc_malloc(sizeof(*rfi)*pff->nbar);
    hvx=(float*)misc_malloc(sizeof(*hvx)*pff->nbar);
    bdqq=(double*)misc_malloc(sizeof(*bdqq)*nlvl*nsts);
    #define bd(i,j) bdqq[(i)+nlvl*(j)]
    memset(bdqq,0,sizeof(*bdqq)*nlvl*nsts);

    /* read risk free interest rates */
    bsrdrfi("wgs3mp.txt",pff->nbar,pff->ldt,rfi);

    /* loop over all stocks in database */
    for(imkt=0; imkt<pff->nmkt; imkt++) {

        /* read current stock and display progress */
        if(imkt%10==0) printf("PROCESSING IMKT=%d\r",(int)imkt);
	pff_seekquotes(pff,imkt);

        /* skip all except active optionable NASD stocks */
        k=(int)pff->sf[0];
        if((k%10)!=1) goto L1;           /* not a stock */
        if(((k/10)%10)!=1) goto L1;      /* not active */
        if(((k/100)%10)!=1) goto L1;     /* not optionable */
	if(((k/1000)%10)!=3) goto L1;       /* not NASD */

        /* skip bad or deleted stocks */
        for(ibar=0; ibar<pff->nbar; ibar++)
	    if(pff->cls[ibar]<0.001) goto L1;   /* bad or deleted */

        /* calculate historical volatility */
        if((mm=mode%10)==0) k=1;            /* standard deviation */
	else if(mm==1) k=6;                     /* average hi-lo range */
	else misc_ftlerr("invalid mode 1s digit");
	bsvltyser(pff->hi,pff->lo,pff->cls,pff->nbar,hvx,mperh,k);

        /* loop over bars leaving room at both ends */
	for(ibar=mperh+3; ibar<pff->nbar-mperf-3; ibar++) {

            /* analyze active stocks that have no original */
            /* (not split-corrected) price < $2 in recent past */
	    if(pff->vol[ibar+mperf]<0.0001) goto L2;
	    if(pff->vol[ibar-mperh]<0.0001) goto L2;
            for(i=ibar-mperh; i<=ibar; i++)
                if(pff->cls[i]*pff->sf[i]<2.0) goto L2;
	    if(pff->cls[ibar]*pff->sf[ibar]>35.0) goto L2;
	    if(hvx[ibar]<bmn || hvx[ibar]>bmx) goto L2;

	    if(Highest(pff->cls, 5, ibar) >
		0.95 * Average(pff->cls, 20, ibar-5)) goto L2;
            /* extract independent and dependent variables */
            x=hvx[ibar];                /* historical mperh-bar volatility */
	    y=log(pff->cls[ibar+mperf]/pff->cls[ibar+1]);  /* avg return */

	    /* accumulate binned statistics */
            k=(int)(0.5+(nlvl-1)*(x-bmn)/(bmx-bmn));
            k=(k<0)?(0):(k>nlvl-1)?(nlvl-1):k;
            bd(k,0)+=((double)x);       /* for bin mean of x */
            bd(k,1)+=((double)y);       /* for bin mean of y */
            bd(k,2)+=((double)y*y);     /* for bin stdev of y */
            bd(k,3)+=1.0;               /* for bin case count */

	    /* accumulate regression statistics */
	    vin[0]=1.0;         	/* intercept variable */
	    vin[1]=x;           	/* independent variable 1 */
	    vin[2]=x*x;         	/* independent variable 2 */
	    rgrs_accum(rgrs,vin,y);

            /* next bar (ibar) */
            L2:;
	}

        /* next stock (imkt) */
        L1:;
        if(imkt>29999) break;           /* debug use only */
    }
    printf("\n");

    /* finish calculating statistics */
    for(k=0; k<nlvl; k++) {
        an=bd(k,3);             /* case count */
        if(an<4.0) {            /* insufficient bin data */
	    bd(k,0)=0.0; bd(k,1)=0.0; bd(k,2)=0.0;
            continue;
        }
        bd(k,0)/=an;            /* x-variable bin mean */
        bd(k,1)/=an;            /* y-variable bin mean */
        bd(k,2)=(an/(an-1.0))*(bd(k,2)/an-bd(k,1)*bd(k,1));
        bd(k,2)=sqrt(bd(k,2));  /* y-variable bin stddev */
    }
    rgrs_calc(rgrs);

    /* print and plot statistics to file */
    {
	static char *clbl[]={"BIN","BCTR","XMEAN","YMEAN",
	    "SMOOTH","YSDEV","NCAS"};
	FILE *fp;  float *x, *y, smd;
	fp=fopen("book.txt","at");
	if(!fp) misc_ftlerr("Cannot open output file");
        x=(float*)misc_malloc(sizeof(float)*nlvl);
        y=(float*)misc_malloc(sizeof(float)*nlvl);
	fprintf(fp,"TEST2_MODE=%d\nBIN_STATISTICS\n",(int)mode);
	for(k=0; k<7; k++) fprintf(fp,"%10s",(char*)clbl[k]);
        fprintf(fp,"\n");
	for(k=0; k<nlvl; k++) {
	    if(k==0) smd=(bd(k,1)+0.5*bd(k+1,1))/1.5;
	    else if(k==nlvl-1) smd=(bd(k,1)+0.5*bd(k-1,1))/1.5;
	    else smd=(bd(k,1)+0.5*(bd(k+1,1)+bd(k-1,1)))/2.0;
	    fprintf(fp,"%10d%10.2f%10.2f%10.2f%10.2f%10.2f%10.1f\n",
                (int)k, (float)(bmn+(k*(bmx-bmn))/(nlvl-1)),
		(float)bd(k,0), (float)bd(k,1), smd,
		(float)bd(k,2), (float)bd(k,3)
	    );
	    x[k]=bd(k,0);
	    y[k]=smd;
	}
        fprintf(fp,"\nREGRESSION_STATISTICS\n");
	rgrs_print(rgrs,fp); fprintf(fp,"\n");
        misc_textplot(fp,x,y,nlvl);
	free(y);
	free(x);
	fclose(fp);
    }
    /* free memory and close database file */
    #undef bd
    free(bdqq);
    free(hvx);
    free(rfi);
    rgrs_free(rgrs);
    pff_close(pff);
}

/*---------------------------------------------------------------------------
c  Main program entry.
*/

int main (void) {
    float p1;
    for(p1=1; p1<=5; p1++) Test3(1,p1,0);
    return(0);
}



/*
c  tropsctl.c  (saved in /tropic/models as ctl002.c)
c
c  This version (saved as ctl002.c) searches for options with very
c  high levels of implied volatility and time value.  It writes out
c  a variety of data for the selected options.  This model is useful 
c  when examining the behaviour of options with very high levels of 
c  implied volatility as well as for checking options data for errors.
c
c  Revised 2006.12.26
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2006.  All Rights Reserved.
*/

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "libmisc.h"    /* utility library header */
#include "libbspm.h"    /* option pricing model header */
#include "libpff.h"     /* stock database header */
#include "libodb.h"     /* options database header */
#include "trops.h"      /* project header */

/*---------------------------------------------------------------------------
c  Analyze chain and generate output data.
*/

#define USES_STOCKDATA  (0)
#define TINYNUM         (1.E-32)

void analyze_chain(FILE *fp, ODBCHAIN &oc, long istk, long iday,
                    PORTFOLIO& pf) {

    #if USES_STOCKDATA == 1
        /* select corresponding data in stock database */
	long ibar, imkt, nops;
        ibar=pf.istkb[iday];
        imkt=pf.istkm[istk];
        if(ibar<0 || imkt<0) return;
        select_market(pf, imkt);

        /* calculate historical volatility from stock data */
        float hv;
        hv=bsvltybar(pf.hi, pf.lo, pf.cls, ibar, 30, 1);
    #endif

    /* declare local variables */
    static ODBCHAIN ocl;
    static long ncount= 0;
    long i, k, kkexp, kexpct, kktype, nops, nbad, igtv, isig;
    float timevalue, gtv;
    typedef struct {
	long	itype, iexpdt;
	float	strike, bid, ask, vol, oi;
    } SELOP;
    static SELOP sop[1200];
    
    /* initialize */
    ncount= ncount + 1;	/* count of calls to this function */
    kkexp= 1;			/* 1=nearest, 2=next-out */
    kktype= 1;			/* 0=call, 1=put */

    /* skip certain symbols */
    if( strcmp(oc.usymbol,"OEX") == 0 ||
        strcmp(oc.usymbol,"XAU") == 0 ||
        strcmp(oc.usymbol,"SPY") == 0
    ) return;
    if( strcmp(oc.usymbol,"RMBS") != 0 ) return;

    /* copy selected option data into local option subchain */
    nops= 0;
    kexpct= 0;
    for(i= 0; i < oc.nopt; i++) {
        /* determine option series: 1=nearest, 2=next nearest */
        if(i==0 || ( oc.expdy[i] != oc.expdy[i-1] ||
                     oc.expmo[i] != oc.expmo[i-1] ||
	             oc.expyr[i] != oc.expyr[i-1])  ) kexpct++;
        /* ignore options not of type kktype and series kkexp */
	if(oc.otype[i] != kktype || kexpct != kkexp) continue;
	/* copy the data */
	sop[nops].itype= oc.otype[i];
	sop[nops].iexpdt= 10000L*oc.expyr[i] +
	                    100L*oc.expmo[i] +
                                 oc.expdy[i]  ;
	sop[nops].bid= oc.bid[i];
	sop[nops].ask= oc.ask[i];
	sop[nops].vol= oc.vol[i];
	sop[nops].oi= oc.oi[i];
	sop[nops++].strike= oc.strike[i];
    }

    /* check for simple data errors */
    for(nbad= 0, i= 1; i < nops && nbad == 0; i++) {
	if(sop[i].strike == sop[i-1].strike) nbad++;
	if(sop[i].itype == 0) {
	    if(sop[i-1].bid > 0.0 && sop[i].bid > sop[i-1].bid) nbad++;
	}
	else {
	    if(sop[i].bid > 0.0 && sop[i].bid < sop[i-1].bid) nbad++;
	}
    }
    if(nops == 0) return;
    if(nbad > 0) {
        /* write error info */
        fprintf(fp, "*** ERROR *** ITEM= %d %s\n",
              (int)oc.date, (char*)oc.usymbol );    
    }

    /* for each option in local subchain ... */
    igtv= -1;
    gtv= 0.0;
    isig= 0;
    for(i= 0; i < nops; i++) {

	/* calculate option time value */
	if(sop[i].itype == 1) {
	    timevalue= sop[i].bid - max(0.0, sop[i].strike - oc.stkcls);
	}
	else {
	    timevalue= sop[i].bid - max(0.0, oc.stkcls - sop[i].strike);
	}
	
	/* determine option with greatest time value */
	if(timevalue > gtv) {
	    gtv= timevalue;	/* greatest time value */
	    igtv= i;		/* option with greatest time value */
        }

	/* if criteria met then show option data and generate signal */
	if(timevalue > .00005 * oc.stkcls && sop[i].vol > 8) {
	    #if 1==0
	        fprintf(fp, "%10ld %8s %8.2f %8.2f %8.2f %8.2f\n", 
                    (long)oc.date, (char*)oc.usymbol, 
                    (float)oc.stkcls, (float)sop[i].strike, 
                    (float)sop[i].bid, (float)timevalue );
            #endif
            isig= 1;            /* trade signal */
	}		
    }
    
    /* we are done if there is no signal or time value */
    if(isig < 1 || igtv < 2 || gtv < 0.10) return;
    fprintf(fp, "%ld %7s %8.2f %ld %ld\n", 
        (long)oc.date, (char*)oc.usymbol, (float)gtv,
        (long)sop[igtv].iexpdt, (long)oc.nopt );
    
    /* otherwise examine action that follows signal */
    for(k= iday; k < odb_nday(pf.odb) - 1; k++) {

        /* read option chain */
        odb_read(pf.odb, istk, k, &ocl);
        if(ocl.valid < 200) continue;		     /* no valid data */
        if(ocl.date >= sop[igtv-0].iexpdt - 0) break;  /* past exp date */

        /* find selected option and write relevant data */
        for(i= 0; i < ocl.nopt; i++) {
            /* ignore all but correct option */
            
#if 1==0            
fprintf(stdout, "%9.2f %9.2f\n", (float)ocl.strike[i], (float)sop[igtv].strike);
fprintf(stdout, "%9.2f %9.2f\n", (float)ocl.otype[i], (float)sop[igtv].itype);
fprintf(stdout, "%9ld %9ld\n", (long)ocl.expyr[i], (long)sop[igtv].iexpdt);
fprintf(stdout, "%9ld %9ld\n", (long)ocl.expmo[i], (long)sop[igtv].iexpdt);
fprintf(stdout, "%9ld %9ld\n", (long)ocl.expdy[i], (long)sop[igtv].iexpdt);
#endif            
            if(ocl.strike[i] != sop[igtv-0].strike) continue;
            if(ocl.otype[i] != sop[igtv-0].itype) continue;
            if(ocl.expmo[i] != misc_month(sop[igtv-0].iexpdt)) continue;
            if(ocl.expyr[i] != misc_year(sop[igtv-0].iexpdt)) continue;            
            if(ocl.expdy[i] != misc_dayofmonth(sop[igtv-0].iexpdt)) continue;
            /* print data series for trade */
            fprintf(fp, "%7s %8ld %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f\n",
                (char*)ocl.usymbol, (long)ocl.date,
                (float)ocl.stkcls, (float)ocl.strike[i],
                (float)ocl.bid[i], (float)ocl.ask[i],
                (float)ocl.vol[i], (float)ocl.oi[i] );                
        }
        
// ftlerr("TESTS");
    }
}

/*---------------------------------------------------------------------------
c  Entry function called from trops.c (main module).
*/

void run_system (PORTFOLIO &pf) {

    static ODBCHAIN oc;
    static long iday, istk, kt;
    static FILE *fp;

    /* clear simulated trade record */
    clear_trades(pf);

    /* open output file */
    fp= fopen("junk", "wt");

    /* for each stock in option database ... */
    for(istk= 0; istk < odb_nstk(pf.odb); istk++) {

        /* for each day ... */
        for(iday= 0; iday < odb_nday(pf.odb); iday++) {        

	    /* ignore all days other than Mondays */
            /* and all early-in-file dates */
	    if(iday < odb_nday(pf.odb) - 470) continue;
	    if(misc_dayofweek(odb_date(pf.odb, iday)) != 1) continue;

            /* read option chain */
            odb_read(pf.odb, istk, iday, &oc);

            /* ignore missing data */
            if(oc.valid <= 0) continue;

            /* analyze chain for options with desired features */
            analyze_chain(fp, oc, istk, iday, pf);

        }  /* next stock */

    }  /* next iday */

    /* close output file */
    fclose(fp);

    /* calculate trading statistics */
    calc_stats(pf);
}


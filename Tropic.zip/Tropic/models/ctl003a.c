/*
c  tropsctl.c  (saved in $HOME/tropic/models as ctl003a.c)
c
c  This version (saved as ctl003.c) trades options on a 1-day
c  timeframe, using actual option prices and option chains.
c  It also includes code designed to test newer routines 
c  in trops.c and libodb.c for handling options data.
c
c  Revised 2007.01.28
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2007.  All Rights Reserved.
*/

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "libmisc.h"    /* utility library header */
#include "libbspm.h"    /* option pricing model header */
#include "libpff.h"     /* stock database header */
#include "libodb.h"     /* options database header */
#include "trops.h"      /* project header */

/*--------------------------------------------------------------------------*/

void run_system (PORTFOLIO &pf) {

    static TRADE trd;
    static float xxclsval[MAXHLD];
    static long ibar, imkt, iday, istk, iexpdt, k, m;
    static long itimeleft, ibestopt, itype, ncont;
    static float ff, optprice, timevalue, realvalue;
    static float bestprice, beststrike;
    static FILE *fp;
    
    trd.clsvalue= xxclsval;

    /* clear simulated trade record */
    clear_trades(pf);
    
    /* debugging code */
    #if 1==0
        select_market(pf, (long)pf.parms[1]);
        ibar= (long)pf.parms[2];
        fprintf(stdout,"STOCK: SYMBOL=%6s DATE=%8ld CLOSE=%.2f\n", 
            (char*)pf.sym, (long)pf.dt[ibar], (float)pf.cls[ibar]);
        m= load_chain(pf, ibar);
        fprintf(stdout,"LOAD_CHAIN=%ld\n", (long)m);
        if(m == 0) {
            for(k= 0; k< pf.oc.nopt; k++) {
                m=  10000L*pf.oc.expyr[k] + 
                      100L*pf.oc.expmo[k] + pf.oc.expdy[k];
                itimeleft= datetoser(m) - datetoser(pf.dt[ibar]);
                if(pf.oc.otype[k] == 0)
                    ff= bscall(pf.oc.stkcls, pf.oc.strike[k], itimeleft,
                        pf.rfi[ibar], sqrt(365.25)*pf.oc.vx[k]/100.0);
                else
                    ff= bsput(pf.oc.stkcls, pf.oc.strike[k], itimeleft,
                        pf.rfi[ibar], sqrt(365.25)*pf.oc.vx[k]/100.0);
                fprintf(stdout,"%8ld %8ld %2ld "
                        " %8.2f  %8.2f %8.2f  %8.2f %8.2f\n",
                    (long)pf.oc.date, (long)m, 
                    (long)pf.oc.otype[k], (float)pf.oc.strike[k],
                    (float)pf.oc.bid[k], (float)pf.oc.ask[k],
                    (float)ff, (float)pf.oc.vx[k] );
                fflush(stdout);                                        
            }
            /* odb_typechain(stdout, &pf.oc); */
        }
        return;
    #endif

    /* for each stock in stockmarket database ... */
    for(imkt= 0; imkt < pf.nmkt; imkt++) {
    
        /* skip all but desired stocks (we can have up to 4 of them) */
        if( ! (	imkt+1 == (long)(.5 + pf.parms[11])	||
                imkt+1 == (long)(.5 + pf.parms[12])	||
                imkt+1 == (long)(.5 + pf.parms[13])	||
                imkt+1 == (long)(.5 + pf.parms[14])        
        ) ) continue;
        
        /* select (load) primary market data */
        select_market(pf, imkt);

        /* for each bar in stock quote series ... */
        for(ibar= 20; ibar < pf.nbar-5; ibar++) {

            /* avoid trades around 2001.9.11 terrorist attacks */
            if(pf.ldt[ibar]>20010810 && pf.ldt[ibar]<20010925) continue;

            /* check for a trading signal (simple MA trend-following).
            .  We want to be long into the next day if the close is
            .  above the MA, and flat if it is below
            */
            if( ! (
                pf.cls[ibar] > 
                    Average(pf.cls, (long)(.5 + pf.parms[1]), ibar-1)
                    
            ) ) continue;
            
            /* load option chain and verify data validity */
            if(load_chain(pf, ibar) != 0) continue;
            
            /* select from chain a specific option to trade */
            itype= 0;		/* option type, 1=put, 0=call */
            ncont= 100;		/* shares controlled, long 100 here */
            iexpdt= misc_nthned(pf.ldt[ibar], 1) + 1;  /* expiration date */
            itimeleft= misc_datetoser(iexpdt) -
                        misc_datetoser(pf.ldt[ibar]);  /* time left */
            if(pf.ldt[ibar+3] > iexpdt) continue;  /* not enough time */

            #if 1==0
                /* debugging code */
                fprintf(stdout,"IEXPDT=%d ITIMELEFT=%d NOPT=%d VALID=%d\n",
                    (int)iexpdt,(int)itimeleft,(int)oc.nopt
                    (int)oc.valid);
                fflush(stdout);
            #endif

            ibestopt= -1;
            ff= -1.E32;
            /* loop over all options in the chain */
            for(k= 0; k < pf.oc.nopt; k++) {
                /* option must have desired expiration date,
                .  type, and strike
                */
                m=10000*pf.oc.expyr[k]+100*pf.oc.expmo[k]+pf.oc.expdy[k];
                #if 1==0
                    /* debugging code */
                    fprintf(stdout,"M=%d IEXPDT=%d OTYPE=%d\n",
                        (int)m, (int)iexpdt, (int)pf.oc.otype[k]);
                    fflush(stdout);
                #endif
                if(m != iexpdt) continue;
                if(pf.oc.otype[k] != itype) continue;

                /* option must have no intrinsic value but highest
                .  time value-- this gets an OOM option with a
                .  strike closest to the stock price, i.e., the
                .  nearest OOM option.
                */
                optprice= .5 * (pf.oc.bid[k] + pf.oc.ask[k]);
                if(pf.oc.otype[k] == 0)
                    realvalue= max(0.0, pf.oc.stkcls - pf.oc.strike[k]);
                else
                    realvalue= max(0.0, pf.oc.strike[k] - pf.oc.stkcls);
                timevalue= optprice - realvalue;
                if(realvalue < 0.001 && timevalue > ff) {
                    ff= timevalue;
                    beststrike= pf.oc.strike[k];
                    bestprice= optprice;
                }                
            }
            if(ff < pf.parms[3]) continue;	/* not enough time value */


            #if 1==0
                /* debugging code */
                fprintf(stdout,"A: %8ld %7.2f %8ld  %7.2f %6.2f\n", 
                    (long)pf.dt[ibar], (float)pf.cls[ibar], (long)iexpdt,
                    (float)beststrike, (float)bestprice);
                fflush(stdout);
            #endif
            
            /* build trade starting with entry bar and price */
            trd.imkt= imkt;
            trd.ientrybar= ibar;
            trd.nshr= ncont;
            trd.entryvalue= ncont * bestprice;  /* for short position */
            trd.clsvalue[0]= trd.entryvalue;            
 
            /* close trade on next bar (exit bar) */
            if(load_chain(pf, ibar+1) != 0) continue;
            k= odb_find(&pf.oc, itype, iexpdt, beststrike);
            if(k < 0) continue;		/* option not found, no trade */
            trd.iexitbar= ibar + 1;
            trd.clsvalue[1]= ncont * 0.5 * (pf.oc.ask[k] + pf.oc.bid[k]);
            
            #if 1==0
                /* debugging code */
                fprintf(stdout,"B: %8ld %6.2f %6.2f %6.2f %8.2f %8.2f %8.2f\n", 
                    (long)pf.dt[ibar+1], (float)pf.oc.ask[k], 
                    (float)pf.oc.bid[k], (float)(trd.clsvalue[1]/ncont),
                    (float)beststrike, (float)pf.oc.strike[k] );
                fflush(stdout);
            #endif

            /* post trade to simulated account */
            add_trade(pf, trd);

        }  /* next bar (ibar) */

    }  /* next stock (imkt) */

    /* calculate trading statistics */
    calc_stats(pf);
}


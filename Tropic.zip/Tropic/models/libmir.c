
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "libmir.h"	/* miscellaneous indicator routines header */

/*-------------------------------------------------------------------------*/

void mir_ftlerr(char msg[]) {
    /* Handles fatal errors */
    fprintf(stderr,"\nERROR: %s!\n",(char*)msg);
    exit(EXIT_FAILURE);
}

void* mir_malloc(size_t n) {
    /* Safely allocates memory */
    void *ptr;
    if((ptr=(void*)malloc(n))==NULL)
        mir_ftlerr("mir_malloc: insufficient memory");
    return(ptr);
}

/*-------------------------------------------------------------------------*/

void mir_movavg (float a[], float d[], int mtype, int m, int n) {

    /* Calculates a variety of moving averages.  Procedure operates on
    .  entire time series.  Averages may be calculated in-place (that
    .  is, with a == d).
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of moving average values
    .  d     - in:  series [0..n-1] of original data points
    .  mtype - in:  type of moving average to calculate
    . 			1 = Simple
    . 			2 = Exponential
    . 			3 = Front-weighted triangular
    . 			4 = Triangular
    . 			5 = Centered simple
    . 			6 = Centered (symetric) exponential
    . 			7 = Centered triangular
    .  m     - in:  period (length) of moving average
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_ftlerr, mir_malloc
    */

    int i, j, k, mc;
    float sum, sumw, w, coeff;
    float *v;

    /* use temporary results vector for in-place calculations */
    if(a==d) v=(float*)mir_malloc(sizeof(float)*n);
    else v=a;

    /* calculate the specified moving average */
    switch(mtype) {
      case 1:  /* simple moving average */
          for(i=0, sum=0.0; i<m; i++) v[i]=(sum=sum+d[i])/(i+1);
          for(i=m; i<n; i++) v[i]=(sum=sum-d[i-m]+d[i])/m;
          break;
      case 2:  /* exponential moving average */
	  for(i=0, sum=0.0, sumw=0.0, coeff=2.0/(1.0+m); i<n; i++)
	      v[i]=(sum=sum+coeff*(d[i]-sum))/(sumw=sumw+coeff*(1.0-sumw));
	  break;
      case 3:  /* front-weighted triangular moving average */
	  for(i=1; i<=n; i++) {
	      for(j=0, sum=0.0, sumw=0.0; j<m; j++) {
		  if((k=i-j)<1) break;
		  w=m-j; sum+=w*d[k-1]; sumw+=w; }
	      v[i-1]=sum/sumw; }
	  break;
      case 4:  /* triangular moving average */
	  for(i=1, coeff=0.5*(m-1); i<=n; i++) {
	      for(j=0, sum=0.0, sumw=0.0; j<m; j++) {
		  if((k=i-j)<1) break;
		  w=(1.0+coeff)-fabs(j-coeff);
		  sum+=w*d[k-1]; sumw+=w; }
	      v[i-1]=sum/sumw; }
	  break;
      case 5:  /* centered simple moving average */
	  for(i=1, mc=(m-1)/2; i<=n; i++) {
	      for(j=0, sum=0.0, sumw=0.0; j<m; j++) {
		  k=i-j+mc;
		  if(k<1 || k>n) continue;
		  sum+=d[k-1]; sumw+=1.0; }
	      v[i-1]=sum/sumw; }
	  break;
      case 6:  /* centered symetric exponential moving average */
	  coeff=2.0/(1.0+m);
	  for(i=0, sum=d[0]; i<n; i++) v[i]=(sum=sum+coeff*(d[i]-sum));
	  for(i=n-1, sum=v[n-1]; i>=0; i--) v[i]=(sum=sum+coeff*(v[i]-sum));
	  break;
      case 7:  /* centered triangular moving average */
	  for(i=1, mc=(m-1)/2, coeff=0.5*(m-1); i<=n; i++) {
	      for(j=0, sum=0.0, sumw=0.0; j<m; j++) {
		  k=i-j+mc;
		  if(k<1 || k>n) continue;
		  w=(1.0+coeff)-fabs(j-coeff);
		  sum+=w*d[k-1]; sumw+=w; }
	      v[i-1]=sum/sumw; }
	  break;
      default:
	  mir_ftlerr("mir_movavg: invalid mtype");
    }

    /* copy results and free scratch vector if necessary */
    if(a==d) {
	memcpy(a,v,sizeof(float)*n);
	free(v);
    }
}

void mir_stochosc (float a[], float hi[], float lo[], float cls[],
int mtype, int m, int n) {

    /* Calculates any of several variations on Lane's Stochastic
    .  oscillator.  Procedure operates on entire data series.
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of oscillator values
    .  hi    - in:  series [0..n-1] of highs
    .  lo    - in:  series [0..n-1] of lows
    .  cls   - in:  series [0..n-1] of closes
    .  mtype - in:  variation of Stochastic oscillator to compute
    . 			1 = Classical Fast %K
    . 			2 = Classical Slow %K = Fast %D
    . 			3 = Classical Slow %D
    .  m     - in:  period (length) of Stochastic oscillator
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_ftlerr, mir_malloc, mir_movavg
    */

    int i, j, k;
    float *hihi, *lolo, hh, ll, rg;
    
    /* allocate scratch vectors */
    hihi=(float*)mir_malloc(sizeof(float)*n);
    lolo=(float*)mir_malloc(sizeof(float)*n);
    
    /* at each bar find highest high and lowest low in past m bars */
    for(i=0; i<n; i++) {
	for(j=0, hh=hi[i], ll=lo[i]; j<m; j++) {
	    if((k=i-j)<0) break;
	    if(hi[k]>hh) hh=hi[k];
	    if(lo[k]<ll) ll=lo[k]; }
	hihi[i]=hh;  lolo[i]=ll; }
	
    /* calculate the stochastic oscillator */	
    if(mtype==1) {  
        /* calculate Lane's Fast %K stochastic */
	for(i=0, a[0]=50.0; i<n; i++) {
	    rg=hihi[i]-lolo[i];
	    if(rg>0.0) a[i]=100.0*(cls[i]-lolo[i])/rg;
	    else if(i>0) a[i]=a[i-1]; }  }
    else if(mtype==2 || mtype==3) {
        /* calculate Slow %K (= Fast %D) or Slow %D */
	for(i=0; i<n; i++) {
	    rg=hihi[i]-lolo[i];
	    lolo[i]=cls[i]-lolo[i];
	    hihi[i]=rg; }
	mir_movavg(hihi,hihi,1,3,n);  /* 3-period simple ma */
	mir_movavg(lolo,lolo,1,3,n);  /* 3-period simple ma */
	for(i=0, a[0]=50.0; i<n; i++) {
	    if((rg=hihi[i])>0.0) a[i]=100.0*lolo[i]/rg;
	    else if(i>0) a[i]=a[i-1]; }
	if(mtype==3)  /* Slow %D requires additional smoothing */
	    mir_movavg(a,a,1,3,n); }  /* 3-period simple ma */
    else mir_ftlerr("mir_stochosc: invalid mtype");
    
    /* free scratch vectors */
    free(lolo);
    free(hihi);
}

void mir_rsiosc (float a[], float d[], int mtype, int m, int n) {

    /* Calculates any of several variations on William's RSI
    .  oscillator.  Procedure operates on whole data series.
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of oscillator values
    .  d     - in:  series [0..n-1] of data points
    .  mtype - in:  variation of RSI oscillator to compute
    . 			1 = Classical RSI
    . 			2 = RSI using simple moving average
    .  m     - in:  period (length) of RSI oscillator
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_ftlerr, mir_malloc, mir_movavg
    */

    int i;
    float tmp, coeff, sum, up, dn, aup, adn;
    float *vaup, *vadn, *scratch;

    switch(mtype) {
      case 1:	/* classical RSI */
	  for(i=1, coeff=1.0/m, a[0]=50.0, aup=adn=0.0; i<n; i++) {
	      up=0.0; dn=0.0;
	      if((tmp=d[i]-d[i-1])>0.0) up=tmp;
	      else if(tmp<0.0) dn=(-tmp);
	      aup=coeff*((m-1)*aup+up);
	      adn=coeff*((m-1)*adn+dn);
	      a[i]=((sum=aup+adn)>0.0)?(100.0*aup/sum):(a[i-1]); }
	  break;
      case 2:	/* simple MA RSI */
	  vaup=(float*)mir_malloc(sizeof(float)*n);
	  vadn=(float*)mir_malloc(sizeof(float)*n); 
	  scratch=(float*)mir_malloc(sizeof(float)*n);
	  for(i=1, vaup[0]=0.0, vadn[0]=0.0; i<n; i++) {
	      vaup[i]=0.0; vadn[i]=0.0;
	      if((tmp=d[i]-d[i-1])>0.0) vaup[i]=tmp;
	      else if(tmp<0.0) vadn[i]=(-tmp); }
	  mir_movavg(vaup,vaup,1,m,n);
	  mir_movavg(vadn,vadn,1,m,n);
	  for(i=1, a[0]=50.0; i<n; i++)
	      a[i]=((sum=vaup[i]+vadn[i])>0.0)?(100.0*vaup[i]/sum):(a[i-1]);
	  free(scratch); 
	  free(vadn);
	  free(vaup);
	  break;
      default:
	  mir_ftlerr("mir_rsiosc: invalid mtype");
    }
}

void mir_macdosc (float a[], float d[], int mtype, int m1, int m2, int n) {

    /* Calculates any of several variations on Appel's MACD
    .  oscillator.  Procedure operates on whole data series.
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of oscillator values
    .  d     - in:  series [0..n-1] of data points
    .  mtype - in:  variation of MACD oscillator to compute
    . 			1 = Classical MACD
    . 			2 = Front-weighted triangular MACD
    . 			3 = Triangular MACD
    .  m1    - in:  period (length) of shorter moving average
    .  m2    - in:  period (length) of longer moving average
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_ftlerr, mir_malloc, mir_movavg
    */

    float *ma1, *ma2;
    int i;

    ma1=(float*)mir_malloc(sizeof(float)*n);
    ma2=(float*)mir_malloc(sizeof(float)*n);
    switch(mtype) {
      case 1:  /* classic MACD */
	  mir_movavg(ma1,d,2,m1,n);
	  mir_movavg(ma2,d,2,m2,n);
	  break;
      case 2:  /* front-weighted triangular MACD */
	  mir_movavg(ma1,d,3,m1,n);
	  mir_movavg(ma2,d,3,m2,n);
	  break;
      case 3:  /* triangular MACD */
	  mir_movavg(ma1,d,4,m1,n);
	  mir_movavg(ma2,d,4,m2,n);
	  break;
      default:
	  mir_ftlerr("mir_macdosc: invalid mtype");
    }
    for(i=0; i<n; i++) a[i]=ma1[i]-ma2[i];    
    free(ma2);
    free(ma1);
}

void mir_cciosc (float a[], float d[], int mtype, int m, int n) {

    /* Calculates any of several variations on Lambert's CCI
    .  oscillator.  Procedure operates on whole data series.
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of oscillator values
    .  d     - in:  series [0..n-1] of data points
    .  mtype - in:  variation of CCI oscillator to compute
    . 			1 = Classical (mean deviation) CCI
    . 			2 = Standard deviation CCI
    .  m     - in:  period (length) of CCI oscillator
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_ftlerr
    */

    int i, j, k, nu;
    float ui, si;

    switch(mtype) {
      case 1:  /* classical version using mean deviations */
	  for(i=2, a[0]=0.0; i<=n; i++) {
	      for(j=0, ui=0.0, nu=0; j<m; j++) {
		  if((k=i-j) < 1) break;
		  nu+=1;  ui+=d[k-1]; }
	      ui=ui/nu;
	      for(j=0, si=0.0; j<m; j++) {
		  if((k=i-j) < 1) break;
		  si+=fabs(d[k-1]-ui); }
	      si=si/nu;
	      a[i-1]=(si>0.0)?((d[i-1]-ui)/(0.015*si)):(a[i-2]); }
	  break;
      case 2:  /* alternative version using standard deviations */
	  for(i=2, a[0]=0.0; i<=n; i++) {
	      for(j=0, ui=0.0, nu=0; j<m; j++) {
		  if((k=i-j) < 1) break;
		  nu+=1;  ui+=d[k-1]; }
	      ui=ui/nu;
	      for(j=0, si=0.0; j<m; j++) {
		  if((k=i-j) < 1) break;
		  si+=(d[k-1]-ui)*(d[k-1]-ui); }
	      si=sqrt(si/nu);
	      a[i-1]=(si>0.0)?((d[i-1]-ui)/(0.01*si)):(a[i-2]); }
	  break;
      default:
	  mir_ftlerr("mir_csiosc: invalid mtype");
    }
}

void mir_revstoch (float a[], float hi[], float lo[], float cls[],
int mtype, int m, int n) {

    /* Calculates any of several variations on Lane's Stochastic
    .  oscillator, running time in reverse.  Typically used as a
    .  target for neural networks and other prediction models.
    .  Procedure operates on whole data series.
    .
    .  Arguments:
    .  a     - out: series [0..n-1] of oscillator values
    .  hi    - in:  series [0..n-1] of highs
    .  lo    - in:  series [0..n-1] of lows
    .  cls   - in:  series [0..n-1] of closes
    .  type  - in:  variation of time-reversed Stochastic to compute
    . 			1 = Classical Fast %K
    . 			2 = Classical Slow %K = Fast %D
    . 			3 = Classical Slow %D
    .  m     - in:  period (length) of Stochastic oscillator
    .  n     - in:  number of data points in input series
    .
    .  Routines called: mir_malloc, mir_stochosc
    */

    float *ra, *rhi, *rlo, *rcls;
    int i, k;

    ra=(float*)mir_malloc(sizeof(float)*n);
    rhi=(float*)mir_malloc(sizeof(float)*n);
    rlo=(float*)mir_malloc(sizeof(float)*n);
    rcls=(float*)mir_malloc(sizeof(float)*n);
    for(i=0; i<n; i++) {
        k=n-i-1; 
        rhi[i]=hi[k];
        rlo[i]=lo[k];
        rcls[i]=cls[k]; }
    mir_stochosc(ra,rhi,rlo,rcls,mtype,m,n);
    for(i=0; i<n; i++) {
        k=n-i-1;
        a[i]=ra[k]; }
    free(ra);
    free(rhi);
    free(rlo);
    free(rcls);
}

/*---------------------------------------------------------------------------
c  Testing and debugging code for routines above.
*/

#if 1==0	/* begin debugging code */
int main (int nargs, char **args) {

    #define N 1000
    #define M 820
    static FILE *fil;
    static int i;
    static float hi[N], lo[N], cls[N], sma[N], ema[N], fwtma[N], tma[N];
    static float csma[N], cema[N], ctma[N], fastk[N], slowk[N], slowd[N];
    static float rfastk[N], rslowk[N], rslowd[N], rsi_classic[N];
    static float rsi_sma[N], macd_classic[N], macd_tma[N];

    /* generate test data */
    for(i=0; i<N; i++) {
        cls[i]= 50.0 + 20.0 * sin(.05 * i);
        hi[i]=	cls[i] + (1.5 * rand()) / RAND_MAX;
        lo[i]=  cls[i] - (1.5 * rand()) / RAND_MAX;
    }
    
    /* open output file */    
    fil=fopen("msctests.txt","wt");
        
    /* tests of moving averages */
    mir_movavg(sma,cls,1,13,N);		/* 13-bar SMA */
    mir_movavg(ema,cls,2,13,N);		/* 13-bar EMA */
    mir_movavg(fwtma,cls,3,13,N);	/* 13-bar WMA */
    mir_movavg(tma,cls,4,13,N);		/* 13-bar TMA*/
    mir_movavg(csma,cls,5,13,N);	/* 13-bar CSMA */
    mir_movavg(cema,cls,6,13,N);	/* 13-bar CEMA */
    mir_movavg(ctma,cls,7,13,N);	/* 13-bar CTMA */
    fprintf(fil,"MOVING AVERAGES\n%6s%10s%10s%10s%10s%10s%10s%10s%10s\n",
        "I","CLS","SMA","EMA","FWTMA","TMA","CSMA","CEMA","CTMA");
    for (i = M; i < N; i++) {
        fprintf(fil,"%6d%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f\n",
          i,cls[i],sma[i],ema[i],fwtma[i],tma[i],csma[i],cema[i],ctma[i]);
    }

    /* tests of Lane's Stochastic variations */
    mir_stochosc(fastk,hi,lo,cls,1,9,N);	/* 9-bar FastK */
    mir_stochosc(slowk,hi,lo,cls,2,9,N);	/* 9-bar SlowK */
    mir_stochosc(slowd,hi,lo,cls,3,9,N);	/* 9-bar SlowD */
    mir_revstoch(rfastk,hi,lo,cls,1,9,N);	/* 9-bar rev-FastK */
    mir_revstoch(rslowk,hi,lo,cls,2,9,N);	/* 9-bar rev-SlowK */
    mir_revstoch(rslowd,hi,lo,cls,3,9,N);	/* 9-bar rev-SlowD */
    fprintf(fil,"\nSTOCHASTICS\n%6s%10s%10s%10s%10s%10s%10s%10s\n",
        "I","CLS","FASTK","SLOWK","SLOWD","RFASTK","RSLOWK","RSLOWD");
    for (i = M; i < N; i++) {
        fprintf(fil,"%6d%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f%10.2f\n",
          i,cls[i],fastk[i],slowk[i],slowd[i],rfastk[i],rslowk[i],rslowd[i]);
    }

    /* tests of rsi indicators */
    mir_rsiosc(rsi_classic,cls,1,14,N);		    /* 14-bar classic RSI */
    mir_rsiosc(rsi_sma,cls,2,14,N);		        /* 14-bar SMA RSI */
    fprintf(fil,"\nRSI\n%6s%10s%10s%10s\n","I","CLS","RSI_C","RSI_X");
    for (i = M; i < N; i++) {
        fprintf(fil,"%6d%10.2f%10.2f%10.2f\n",
	    i,cls[i],rsi_classic[i],rsi_sma[i] );
    }

    /* tests of macd variations */
    mir_macdosc(macd_classic,cls,1,12,26,N);    /* 12-26 classic MACD */
    mir_macdosc(macd_tma,cls,2,12,26,N);	    /* 12-26 TMA MACD */
    fprintf(fil,"\nRSI\n%6s%10s%10s%10s\n","I","CLS","MACD_C","MACD_T");    
    for (i = M; i < N; i++) {
        fprintf(fil,"%6d%10.2f%10.2f%10.2f\n",
	    i,cls[i],macd_classic[i],macd_tma[i]);
    }

    exit(0);
}
#endif		/* end debugging code */

/*---------------------------------------------------------------------------
c  More indicator and indicator-like routines.
*/

void mir_nmzs (float ans[], float v[], int np, int nb)
{
    /* Normalizes a data series to z-score form using a moving average
    .  and moving standard deviation.  Must be checked for accuracy
    .  with long data series!
    .  ans  - out: normalized data series, ans[0..nb-1]
    .  v    - in:  original data series, v[0..nb-1]
    .  np   - in:  period of moving average
    .  nb   - in:  total number of bars in data series
    */
    double u, s, x1, x2, vbase;
    int i;
    vbase=0.5*(v[0]+v[nb-1]);		/* for accuracy improvement */
    u=0.0; s=0.0;
    for(i=0; i<np; i++) {
	x1=v[i]-vbase;
	u+=x1; s+=x1*x1;
	if(i<3) ans[i]=0.0;
	else ans[i]=((i+1)*x1-u)/sqrt((i+1)*s-u*u+1.0E-64);
    }
    for(i=np; i<nb; i++) {
	x1=v[i-np]-vbase; x2=v[i]-vbase;
	u+=(x2-x1); s+=(x2*x2-x1*x1);
	ans[i]=(np*x2-u)/sqrt(np*s-u*u+1.0E-64);
    }
}

void mir_rtxs (float ans[], float v[], float p, int nb)
{
    /* Time-reversed exponential moving average. 
    .  ans  - out: smoothed data series, ans[0..nb-1]
    .  v    - in:  raw data series, v[0..nb-1]
    .  p    - in:  smoothing coefficient
    .  nb   - in:  number of bars
    */
    int i;
    double sum1, sum2, fac;
    sum1=sum2=0.0;
    fac=2.0/(1.0+p);
    for(i=nb-1; i>=0; i--) {
	sum1+=fac*((double)v[i]-sum1);
	sum2+=fac*(1.0-sum2);
	ans[i]=(float)(sum1/sum2);
    }
}

void DollarVolS (float *dv, float *cls, float tsz, float tv,
int np, int nb, int mode) {
    /* Computes dollar volatility levels.
    .  dv    - out: series dv[0..nb-1] of dollar volatility levels
    .  cls   - in:  series cls[0..nb-1] of closing prices
    .  tsz   - in:  tick size (was 0.25 for the ES)
    .  tv    - in:  tick value (was 12.50 for the ES)
    .  np    - in:  period of measurement in bars
    .  nb    - in:  total number of bars
    .  mode  - in:  computational method (must currently be 1)
    */
    void AverageS(float a[], float d[], long np, long nb);
    float fac, *ser;
    int i;
    switch(mode) {
      case 1:                           /*  bar-to-bar mode */
        fac=tv/tsz;                     /* dollars per decimal unit */
        ser=(float*)malloc(sizeof(float)*nb);
        for(i=1; i<nb; i++)             /* absolute change in dollars */
            ser[i]=fac*fabs(cls[i]-cls[i-1]);
        ser[0]=ser[1];
        AverageS(dv,ser,np,nb);         // average the changes
        free(ser);
        break;
      default:
        mir_ftlerr("DollarVolS: invalid mode");
        break;
    };
}

void VIAverageS (float *a, float *v, int m1, int m2, int nb) {
    /* Variable index adaptive moving average based loosely
    .  on VIDYA.  This routine uses unit-based vectors.
    .  a   - resultant moving average [1..nb]
    .  v   - input data series [1..nb]
    .  m1  - short parameter
    .  m2  - long parameter
    .  nb  - number of bars in data series
    */
    int i;
    double sum, b, cs, cl, cx, d, tiny=(1.0E-32), sdlong, sdshort;
    if(m1<=1) {
        memcpy(a+1,v+1,sizeof(float)*nb);
        return;
    }
    sdlong=sdshort=fabs(v[2]-v[1]);
    sum=v[1];
    cs=2.0/(1+m2);
    cl=2.0/(1+4*m2);
    cx=2.0/(m1-1);
    a[1]=sum;
    for(i=2; i<=nb; i++) {
        d=(v[i]-v[i-1]);
        d=d*d;
        sdlong=sdlong+cl*(d-sdlong);
        sdshort=sdshort+cs*(d-sdshort);
        b=cx*sdshort/(sdlong+tiny);
        b=b/(1.0+b);
        sum=sum+b*(v[i]-sum);
        a[i]=sum;
    }
}


void mir_rcor (float ans[], float a[], float b[], int np, int nb)
{
    /* Rolling correlation between two data series.
    .  ans  - out: correlation series, ans[0..nb-1]
    .  a    - in:  first data series, a[0..nb-1]
    .  b    - in:  second data series, b[0..nb-1]
    .  np   - in:  lookback in bars in computing correlations
    .  nb   - in:  total number of bars in data series
    */
    double x, xo, y, yo, ux, uy, sx, sy, sxy, tsx, tsy, anp;
    int i;
    anp=np;
    ux=uy=sx=sy=sxy=0.0;
    for(i=0; i<np; i++) {
	x=a[i]; y=b[i]; ux+=x; uy+=y;
	sx+=x*x; sy+=y*y; sxy+=x*y; ans[i]=0.0;
    }
    for(i=np; i<nb; i++) {
	x=a[i]; y=b[i]; xo=a[i-np]; yo=b[i-np];
	ux+=(x-xo); uy+=(y-yo);
	sx+=(x*x-xo*xo); sy+=(y*y-yo*yo); sxy+=(x*y-xo*yo);
	tsx=(anp*sx-ux*ux); tsy=(anp*sy-uy*uy);
	if(tsx>0.0 && tsy>0.0) ans[i]=(anp*sxy-ux*uy)/sqrt(tsx*tsy);
	else ans[i]=0.0;
    }
}

void mir_rlrs (float vout[], float vin[], int mper, int nb)
{
    /* Rolling linear regression slope of best-fit line to past mper bars.
    .  vout  - out: series [0..nb-1] of slopes
    .  vin   - in:  data series [0..nb-1]
    .  mper  - in:  bars over which to fit line
    .  nb    - in:  total number of bars in series
    */
    double ux, uy, sx, sy, sxy, ya, yb;
    int i;
    ux=mper-0.5*(mper-1);  sx=0.0;
    for(i=1; i<=mper; i++) { ya=i-ux; sx+=ya*ya; }
    sx=1.0/(mper*sx); uy=sy=sxy=0.0;
    for(i=1; i<=mper; i++) {
	ya=vin[i-1]; uy+=(ya); sy+=(ya*ya);
	sxy+=(ya*i); vout[i-1]=0.0;
    }
    for(i=mper+1; i<=nb; i++) {
	ya=vin[i-mper-1]; yb=vin[i-1]; 
	ux=i-0.5*(mper-1); uy+=(yb-ya);
	sy+=(yb*yb-ya*ya); sxy+=(yb*i-ya*(i-mper));
	vout[i-1]=sx*(sxy*mper-ux*uy);
    }
}

void mir_lsrg (float *regval, float *regerr, float v1[], float v2[],
int m, int n, int l, int k)
{
    /* Performs a linear regression using two time series (single
    .  reference bar).
    .  regval  - out: predicted value of series 2 (at bar k+l)
    .  regerr  - out: standard error of prediction
    .  v1      - in:  data [0..] series 1 (predictor)
    .  v2      - in:  data [0..] series 2 (predictee)
    .  m       - in:  starting bar (ref. series 1)
    .  n       - in:  ending bar (ref. series 1)
    .  l       - in:  lead/lag (ref. series 2)
    .  k       - in:  bar of series 1 to use in prediction of
    . 				series 2 at bar k+l
    */
    int i;
    float ux, uy, sx, sy, rxy, x, y, an, b1, b2;
    ux=uy=sx=sy=rxy=0.0;
    an=n-m+1;
    b1=0.5*(v1[m]+v1[n]);
    b2=0.5*(v2[m+l]+v2[n+l]);
    for(i=m; i<=n; i++) {
	x=v1[i]-b1; y=v2[i+l]-b2;
	ux+=x; uy+=y; sx+=(x*x); sy+=(y*y); rxy+=(x*y);
    }
    ux=ux/an; uy=uy/an; sx=sx/an-ux*ux; sy=sy/an-uy*uy;
    if(sx>0.0 && sy>0.0) {
	sx=sqrt(sx); sy=sqrt(sy); rxy=(rxy/an-ux*uy)/(sx*sy);
	x=v1[k];
	*regval=(uy+b2)+sy*(rxy*(x-(ux+b1))/sx);
	*regerr=sy*sqrt(1.0-rxy*rxy);
    }
    else {
	rxy=0.0; *regval=uy; *regerr=0.0;
    }
}

void mir_lrlex (float vout[], float vin[], int mper, int mfut, int nb)
{
    /* Linear regression series prediction via line extrapolation.
    .  Predicted value of vin[k+mfut] is placed in vout[k] with
    .  prediction based on data in vin[k-mper+1..k].
    .  vout  - out: series [0..nb-1] of predictions generated
    .  vin   - in:  series [0..nb-1] on which to base predictions
    .  mper  - in:  number of bars to use in prediction model
    .  mfut  - in:  number of bars ahead to predict
    .  nb    - in:  number of bars in series
    */
    double xa,ya,xb,yb, ux,uy,sx,sy,sxy, slope,am, tiny=1.E-25;
    int i;
    ux=sx=uy=sy=sxy=0.0;
    for(i=1; i<=mper; i++) {
        xb=am=i; yb=vin[i-1];
	ux+=xb; sx+=xb*xb; uy+=yb; sy+=yb*yb; sxy+=xb*yb;
	if(i>2) {
	    slope=(am*sxy-ux*uy)/(am*sx-ux*ux+tiny);
	    vout[i-1]=slope*((i+mfut)-ux/am)+uy/am;
	}
	else vout[i-1]=vin[i-1];
    }
    am=mper;
    for(i=mper+1; i<=nb; i++) {
	xa=i-mper; ya=vin[i-mper-1]; xb=i; yb=vin[i-1];
	ux+=(xb-xa); uy+=(yb-ya); sx+=(xb*xb-xa*xa);
	sy+=(yb*yb-ya*ya); sxy+=(xb*yb-xa*ya);
	slope=(am*sxy-ux*uy)/(am*sx-ux*ux+tiny);
	vout[i-1]=slope*((i+mfut)-ux/am)+uy/am;
    }
}


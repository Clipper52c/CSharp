#ifndef LIBMIR_H
#define LIBMIR_H

#ifndef FALSE
    #define FALSE 0
    #define TRUE 1
#endif

/* error handling and memory allocation routines */
void	mir_ftlerr(char msg[]);
void*	mir_malloc(size_t n);

/* indicator and moving average routines */
void	mir_movavg (float a[], float d[], int mtype, int m, int n);
void	mir_stochosc (float a[], float hi[], float lo[], float cls[],
            int mtype, int m, int n);
void	mir_rsiosc (float a[], float d[], int mtype, int m, int n);
void	mir_macdosc (float a[], float d[], int mtype, int m1, int m2, int n);
void	mir_cciosc (float a[], float d[], int mtype, int m, int n);
void	mir_revstoch (float a[], float hi[], float lo[], float cls[],
            int mtype, int m, int n);
void	mir_nmzs (float ans[], float v[], int np, int nb);
void	mir_rtxs (float ans[], float v[], float p, int nb);
void	DollarVolS (float *dv, float *cls, float tsz, float tv,
            int np, int nb, int mode);
void	VIAverageS (float *a, float *v, int m1, int m2, int nb);
void	mir_rcor (float ans[], float a[], float b[], int np, int nb);
void	mir_rlrs (float vout[], float vin[], int mper, int nb);
void	mir_lsrg (float *regval, float *regerr, float v1[], float v2[],
            int m, int n, int l, int k);
void	mir_lrlex (float vout[], float vin[], int mper, int mfut, int nb);

#define RoundToInteger(x) ((int)(0.5+(x)))
#define CrossesAbove(a,b,i) (a[i]>=b[i] && a[(i)-1]<b[(i)-1])
#define CrossesBelow(a,b,i) (a[i]<b[i] && a[(i)-1]>=b[(i)-1])
#define TurnsUp(a,i) (a[i]>=a[(i)-1] && a[(i)-1]<a[(i)-2])
#define TurnsDn(a,i) (a[i]<a[(i)-1] && a[(i)-1]>=a[(i)-2])
#define Clip(a,b,c) (((a)<(b))?(b):(((a)>(c))?(c):(a)))

#endif /* LIBMIR_H */


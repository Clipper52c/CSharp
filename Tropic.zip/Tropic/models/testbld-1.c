/*
c  mod_smavg.c (filename is testbld-1.c in the distribution)
c
c  Copy this file to ~/tropic and rename it to tropsmod.c to
c  compile and run the example.  Note: this example model works
c  with the latest upgrade of C-Trader Professional; it will
c  not work with earlier versions.
c
c  Trades a simple intraday moving average system that is long when
c  prices are above the moving average, flat when they are below,
c  and that never holds positions overnight or outside a specified
c  range of times.
c
c  This model uses the atsm_ series of functions that implement a
c  simple series-oriented simulation by translating transactions on
c  the data series into trades posted using TRADE structures and
c  the add_trade function.  The add_trade function is implemented in
c  trops.c, and is part of the C-Trader Professional platform; the
c  atsm_ functions are implemented in tropsctl.c, and are treated
c  more as user or model code, like all the other code in that file.
c
c  p1		= moving average length
c  p11..p17	= index of security to trade, 1..nmkt
*/

void trs_runsys (void) {
    /* Called from function run_system in tropsctl.c for each bar
    .  in each market.
    */
    long kpos, ktime, ktfirst, ktlast, nsize;
    
    ktfirst= 140000;	/* trading starts at 2:00 PM */
    ktlast= 155900;	    /* trading ends at 4:59 PM */    
    nsize= 1000;	    /* trading size is 1000 shares or contracts */
    
    /* we only want to trade at certain times of the day */
    if(ibar<nbar-5 && (ktime=tm[ibar])>=ktfirst && ktime<=ktlast &&
            dt[ibar-1]==dt[ibar+1]) {
        /* get position */
        kpos=atsm_position();
        /* if we are flat ... */
        if(kpos==0) {
            /* and if close of current bar > moving average ... */
            if(cls[ibar] > Average(cls, (long)prm[1], ibar)) {
                /* then buy nsize at close of current bar */
                atsm_transact(nsize, cls[ibar]);
            }
        }
        /* if we are long ... */
        else if(kpos!=0) {
            /* and if close of current bar is < moving average ... */
            if(cls[ibar] < Average(cls, (long)prm[1], ibar)) {
                /* then go flat at close of current bar */
                atsm_transact(-kpos, cls[ibar]);
            }
        }
    }
    
    /* and to be flat at all other times, including overnight */
    else {
        /* offset any existing position at the close */
        if((kpos=atsm_position())!=0) {
            atsm_transact(-kpos, cls[ibar]);
        }
    }
    
    /* update account simulation for current bar (ibar) */
    atsm_update();
}


long trs_runsys_mkt (void) {
    /* Called from function run_system in tropsctl.c after market
    .  loop but before bar loop.  Return a non-zero value from
    .  this function to bypass bar loop processing run_system.
    */
    atsm_reset();   /* reset account for trading current market */
    return(0);
}

long trs_runsys_raw (void) {
    /* Called from function run_system in tropsctl.c before market
    .  and bar loops.  Return a non-zero value from this function
    .  to bypass both the market and bar loops in run_system.
    */
    return(0);
}

/*
PARMSET=1
    1        6.00000
    11       1.00000
**
Use above parameters with ~/mktdata/dbases/m5data as a test of the
software's overall function and intraday data handling capabilities.
*/

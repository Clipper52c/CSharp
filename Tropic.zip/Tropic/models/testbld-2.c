/* Example saved in ~/tropic/models as testbld-2.c
c
c  This model is used to verify that the software is working correctly
c  and to illustrate how trading systems are implemented and tested
c  using C-Trader Professional.  Note: this code is for the pre-update
c  version and will need modification to work with the current upgraded
c  CTPro version.
c
c  Be sure that you set edit the init.scr file so that the correct
c  data is loaded by the loadportfolio command!  For this model, we
c  need Yahoo end-of-day data for dividend-bearing stocks.
c
c  The trading model attempts to exploit stocks going ex-dividend.
c  It buys selected stocks at the close prm[2] days before they
c  go ex-dividend, and sells them at the close prm[3] days after
c  they have gone ex-dividend.  Yahoo data is required since these
c  data are corrected for dividends as well as splits, and the
c  dividend events can therefore be determined from analysis of
c  the split factors.
*/

void trs_noname_sub (void) {

    /* Declare the local TRADE structure that will be used to return
    c  trades from the trading model to the backtesting platform.
    */
    TRADE gtrd;
    
    /* Allocate some memory for an array that is declared as a pointer
    c  in the TRADE structure.  In the previous version of C-Trader Pro,
    c  this array was pre-allocated in the structure itself; the change
    c  was made to enable us to dynamically allocate memory, as needed,
    c  in the many instances of the TRADE structure that are created
    c  and used internally by the backtesting engine.  Note that MAXHLD,
    c  which is declare in trops.h, defines the maximum number of bars
    c  for which trades may be held; MAXHLD may be set to a large
    c  number, e.g., 30000, if desired--although one might want to use
    c  a smaller number so as to help catch errors in your trading
    c  models.
    */
    float xxclsval[MAXHLD];
    gtrd.clsvalue= xxclsval;
    
    /* Declare additional local variables as required
    c  by the trading model
    */
    int ib1, ib2, ib3, ib4, k;  
    float ans[2], cc, cmsn, r, dividend;

    /* Calculate indices for important bars */
    ib1= ibar - (long)(.5 + prm[2]);	// entry bar
    ib2= ibar;				// cum-dividend bar
    ib3= ibar + 1;			// ex-dividend bar
    ib4= ib3 + (long)(.5 + prm[3]);	// exit bar

    /* Perform initial rough volume and price screen */
    if(vol[ib1]<=0.0) return;
    if((cc=sf[ib1]*cls[ib1])<0.15 || cc>2700.0) return;

    /* Basic trading rules */
    // 1) we must have an appropriate dividend to exploit
    if(!(
        (r= sf[ib2] / sf[ib3] - 1.0) > 0.0014  &&  r < 0.095 
        && (cc= (sf[ib2] - sf[ib3]) * cls[ib2]) < 12.50  &&  cc > prm[5]
    )) return;
    
    // 2) there must be some liquidity and volume to get a reasonable fill
    if(Average(vol, 20, ib1) / sf[ib1] < prm[0]) return;
  
    // 3) there must be an active lookback with a range of prices
    pd_liquidity (ans, hi, lo, cls, vol, ib1);
    if(ans[0]>0.25 || ans[1]<0.5) return;  
    
    // 4) there must not be too much of a run-up in the stock's price
    if(cls[ib1] > prm[1] * cls[ib1-1]) return;
    dividend= r;
    
    cmsn= 0.02;		// factor in commission and slippage

    /* Fill in a TRADE structure and post the trade directly to the
    c  simulated account.  We do this here without the use of
    c  the additional structures and functions (notably trsig,
    c  trdstock(), and trdoption()) that are available in tropsctl.c
    c  to make things easier.  We want to show how things work at the
    c  lowest level.
    */
    gtrd.imkt=		imkt;
    gtrd.ientrybar=	ib1;
    gtrd.iexitbar=	ib4;
    gtrd.nshr=		100;
    gtrd.entryvalue=	gtrd.nshr * (sf[ib1] * cls[ib1] + cmsn);
    gtrd.clsvalue[0]= 	gtrd.nshr * (sf[ib1] * cls[ib1]);
    for(k= ib1 + 1; k <= ib4; k++) {
        // determine the position's closing value at each bar
        gtrd.clsvalue[k-ib1]= gtrd.nshr * (sf[ib1] * cls[k]);
        // implement a profit target
        if(hi[k] > (cc= prm[4] * cls[ib1])) {
            gtrd.clsvalue[k-ib1]= gtrd.nshr * (sf[ib1] * cc);
            gtrd.iexitbar= k;
            break;
        }
    }
    // post the trade to the simulated account
    add_trade(*gpf, gtrd);
    
    // Note: since trsig.lensize is left at 0 in the above code,
    // run_system() in tropsctl.c will not call trdstock() or trdoption(),
    // and hence will not post any trades; the trades directly posted
    // above with add_trade() will thus be the only trades entered
    // into the simulated account.
}

/*-------------------------------------------------------------------------*/

void trs_runsys (void) {
    /* Called from run_system() in tropsctl.c, this routine calls 
    .  trading model trs_noname_sub(), above, and performs some 
    .  filtering.  Static module-global variables declared in 
    .  tropsctl.c are employed for speed and convenience.
    */
    trsig.lensize=0;	/* 0 => take no position, i.e., no signal */
    #if 1==0
        /* restrict trading signals to specified day of week */
        /* prm[9] settings: 0=AllDays, 1=Mon, 2=Tues, .. , 5=Fri */
        if(prm[9]>0.0 && idow[ibar]!=(char)prm[9]) return;
    #endif
    #if 1==1
        /* avoid trades during 2001.09.11 terrorist attacks */
        if(dt[ibar]>20010810 && dt[ibar]<20010925) return;
    #endif
    /* generate trading signal in trsig */
    trs_noname_sub();
    #if 1==0
    {   /* block repeat signals within period TRS_LOOKBACK */
        #define TRS_LOOKBACK 6
        static long ibarbase;
        if(trsig.lensize==0) return;
        ibarbase=ibar;
        for(ibar=ibarbase-TRS_LOOKBACK; ibar<ibarbase; ibar++) {
            trsig.lensize=0;
            trs_noname_sub();
            if(trsig.lensize!=0) {trsig.lensize=0; ibar=ibarbase; return;}
        }
        ibar=ibarbase;
        trsig.lensize=0;
        trs_noname_sub();
        #undef TRS_LOOKBACK
    }
    #endif
}

int trs_runsys_mkt (void) {
    /* This function is where one may performe whole-series calculations
    .  and other initializations for each security.  It is called
    .  from run_system() in tropsctl.c inside the security (market)
    .  loop, but just before the bar loop; hence, all globals are
    .  valid except for ibar.  The return value should be non-zero
    .  if one wishes to bypass the bar loop in tropsctl.c for any
    .  reason.
    */
    
    return(0);
}

int trs_runsys_raw (void) {
    /* This function is called from run_system() in tropsctl.c and 
    .  allows an entire model to be implmented locally, here in 
    .  trs_runsys(), if desired.  To bypass normal model support 
    .  in tropsctl.c, and calls to trs_noname() above, return an 
    .  integer greater than 0; otherwise, return 0.  All globals 
    .  except those specific to the selected market are valid here; 
    .  when implementing models in this function, one must directly 
    .  handle looping over and selection (loading) of markets (securities),
    .  copying market-specific variables to globals, looping over bars, 
    .  and posting trades using add_trade().
    */
    
    /* use normal model support (return a 0) */
    return(0);
}

/*
The parameters below can be loaded using the loadparms command by typing
"loadparms 1" at the trops-> prompt.  The loadparms command without any
arguments loads parameters from the file parms.txt in the current working
directory.  The command may also be given the name of a file containing the
desired parameters--just use a filename that does not begin with a number!
To save parameters, use the saveparms command.  It can save parameters to
the specified file or, when issued without a filename argument, to the file
parms.txt in the current working directory.  PARMSET blocks within trading
model code must be created with a text editor-- you can copy in your
parms.txt so that you can have copies of your parameters saved with your
trading models.

PARMSET=1
    1        1.00200
    4       22.00000
   11        6.00000
   12        9.00000
   13       12.00000
**

*/


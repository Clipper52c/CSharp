// bndfilt.c (c++)
//
// Bandpass filter class and associated functions.  The filter implemented
// is a variation on a standard 2-pole analogue bandpass filter, such as
// might be found in electronics gear, with adjustments made to remove
// unwanted components such as response to dc offset and signal drift.
//
// Include this code in tropsmod.c or tropsctl.c to use bandpass filters.
//
// Copyright 2005. All Rights Reserved.
// Jeffrey Owen Katz, Ph.D.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

//---------------------------------------------------------------------------

class BNDFILT {		// bandpass filter class structure
private:
    int nkern;		// number of elements in kernels
    double *ipkern;	// in-phase kernel
    double *iqkern;	// in-quadrature kernel
    double per;		// center periodicity
    double wid;		// band width (0.05..0.20)
public:
    ~BNDFILT (void);
    BNDFILT (void);
    void build_kernel (float period, float width);
    void apply (float *ds, float *inphase, float *inquad, int n);
    int kernel_length (void) { return (nkern); };
    float period(void) { return ((float)per); };
    float width(void) { return ((float)wid); };
};

//---------------------------------------------------------------------------

BNDFILT::BNDFILT(void) {
    // Constructor
    // Initializes kernel size to zero and pointers to NULL
    nkern = 0;
    iqkern = NULL;
    ipkern = NULL;
}

BNDFILT::~BNDFILT(void) {
    // Destructor
    // Frees kernel array memory
    if (iqkern) free (iqkern);
    if (ipkern) free (ipkern);
}

static double bnd_wsin (int k, double per, double wid) {
    // Returns value of in-quadrature filter kernel, with period
    // per and bandwidth wid, k bars into past.  This function is
    // internal only.
    double w, t;
    w = 6.28318 * (k - 1) / per;
    t = wid * w;
    t = exp (-t*t);
    if (t > 0.01) return (t * sin (w));
    return (0.0);
}

static double bnd_wcos (int k, double per, double wid) {
    // Returns value of in-phase filter kernel, with period per
    // and bandwidth wid, k bars into past.  This function is
    // internal only.
    double w, t;
    w = 6.28318 * (k - 1) / per;
    t = wid * w;
    t = exp (-t*t);
    if (t > 0.01) return (t * cos (w));
    return (0.0);
}

static double bnd_wgt (int k, double per, double wid) {
    // Returns filter kernel decay at k bars into past for
    // filter with period per and bandwidth wid.  This function
    // is internal only.
    double w, t;
    w = 6.28318 * (k - 1) / per;
    t = wid * w;
    t = exp (-t*t);
    if (t > 0.01) return (t);
    return (0.0);
}

static double bnd_sprod (double *a, double *b, int n) {
    // Calculates scalar product of two vectors (unit offset)
    double sum;
    sum = 0.0;
    while (n--) sum += *(++a) * *(++b);
    return (sum);
}

static void bnd_remove (double *a, double *b, double *bp,
double *c, double *cp, int m) {
    // Removes unwanted components (vectors b and c) from vector a.
    // This function is internal only.
    double bb, bc, cb, cc, ab, ac, num, den, bmul, cmul;
    int i;
    ab = bnd_sprod (a, bp, m);
    ac = bnd_sprod (a, cp, m);
    bb = bnd_sprod (b, bp, m);
    bc = bnd_sprod (b, cp, m);
    cb = bnd_sprod (c, bp, m);
    cc = bnd_sprod (c, cp, m);
    num = cc * ab - cb * ac;
    den = cb * bc - bb * cc;
    bmul = num / den;
    num = bb * ac - ab * bc;
    cmul = num / den;
    for (i = 1; i <= m; i++)
	a[i] = a[i] + bmul * b[i] + cmul * c[i];
}

static void bnd_orthonormalize (double *a, double *b, int m) {
    // Normalizes vector a to unit length, adjusts b so that it is
    // orthogonal to a, and then normalizes b to unit length.
    // This function is internal only.
    double sum;
    int i;
    sum = 1.0 / sqrt (bnd_sprod (a, a, m));
    for (i = 1; i <= m; i++)
	a[i] = sum * a[i];
    sum = bnd_sprod (a, b, m);
    for (i = 1; i <= m; i++)
	b[i] = b[i] - sum * a[i];
    sum = 1.0 / sqrt (bnd_sprod (b, b, m));
    for (i = 1; i <= m; i++)
	b[i] = sum * b[i];
}

static float bnd_convolve (float *a, double *b, int k, int m) {
    // Convolves vector a (of length > m) with vector b (of length m)
    // with convolution ending at element (bar) k of vector a.
    // This function is internal only.
    double sum;
    int i;
    sum = 0.0;
    for (i = 1; i <= m; i++)
	sum += a[k-i+1] * b[i];
    return (sum);
}

static double * bnd_dblmalloc (int nelts) {
    // Checked memory allocator
    double *ptr;
    ptr = (double *) malloc (sizeof(double) * (nelts + 1));
    if (ptr == NULL) {
	fprintf (stderr, "\nERROR: bndfilt: out of memory\n");
	exit (EXIT_FAILURE);
    }
    return (ptr);
}

void BNDFILT::build_kernel (float period, float width) {
    // Member function.  Builds the kernel for a bandpass filter
    // instance with given period (measured in bars) and
    // bandwidth (also measured in bars).  This member function
    // is called by the user to initialize a filter instance.
    int i, m;
    double *imprespiq, *imprespip, *offset, *trend;
    double *rawoffset, *rawtrend;
    // copy into instance the bandwidth and period of the filter
    wid = width;	// bandwidth (0.1 is good, lower is narrower)
    per = period;	// center period of filter
    // allocate local scratch memory
    m = (int) (80.0 / wid);
    imprespiq = bnd_dblmalloc (m);
    imprespip = bnd_dblmalloc (m);
    offset = bnd_dblmalloc (m);
    trend = bnd_dblmalloc (m);
    rawoffset = bnd_dblmalloc (m);
    rawtrend = bnd_dblmalloc (m);
    // determine vector components for constructing filter kernels
    for (i = 1; i <= m; i++) {
	imprespip[i] = bnd_wcos(i, per, wid);
	imprespiq[i] = bnd_wsin(i, per, wid);
	offset[i] = bnd_wgt(i, per, 2.0 * wid);
	trend[i] = bnd_wgt(i, per, 2.0 * wid) * i;
	rawoffset[i] = 1.0;
	rawtrend[i] = i;
    }
    // remove unwanted components and orthonormalize filter kernels
    bnd_remove (imprespip, offset, rawoffset, trend, rawtrend, m);
    bnd_remove (imprespiq, offset, rawoffset, trend, rawtrend, m);
    bnd_orthonormalize (imprespip, imprespiq, m);
    // free any existing member kernel arrays (e.g., when same filter
    // instance is re-tuned for a new period and bandwidth)
    if (ipkern) free (ipkern);
    if (iqkern) free (iqkern);
    // determine required kernel array length
    for (i = m; i >= 1; i--) {
	nkern = i;
	if (imprespip[i] != 0.0 || imprespiq[i] != 0.0) break;
    }
    // allocate new kernel arrays (these are class instance members)
    ipkern = bnd_dblmalloc (nkern);
    iqkern = bnd_dblmalloc (nkern);
    // copy local filter kernels to instance kernels
    memcpy (ipkern, imprespip, sizeof(double)*(nkern+1));
    memcpy (iqkern, imprespiq, sizeof(double)*(nkern+1));
    // free local scratch memory
    free (imprespiq);
    free (imprespip);
    free (offset);
    free (trend);
    free (rawoffset);
    free (rawtrend);
}

void BNDFILT::apply (float *ds, float *inphase, float *inquad, int n) {
    // Member function.  Applies a filter instance to the input
    // series ds[0..n-1] producing filtered in-phase and in-quadrature
    // output series.  Series ds[0..n-1], inphase[0..n-1], and
    // inquad[0..n-1] are vectors of length n.  This member function
    // is called by the user to apply a filter instance to a data
    // series so as to obtain the filtered output series.
    int k;
    for (k = 1; k <= nkern+2; k++) {
	inphase[k-1] = 0.0;
	inquad[k-1] = 0.0;
    }
    ds--;
    for (k = nkern+2; k <= n; k++) {
	inphase[k-1] = bnd_convolve (ds, ipkern, k, nkern);
	inquad[k-1] = bnd_convolve (ds, iqkern, k, nkern);
    }
}

//---------------------------------------------------------------------------
// Testing code used only for debugging
#if 1==1
int main () {
    static float signal[2000], inphase[2000], inquad[2000], sper[2000];
    static int n = 1000, i;
    static double w, per, pm;
    static BNDFILT filter;
    static FILE *fil;

    // initialize a single bandpass filter instance
    filter.build_kernel (20.0, 0.1);
    printf ("Kernel length = %d\n", filter.kernel_length());

    // create a signal with a slowly sweeping period
    w = 0.0;
    per = 15.0;
    pm = exp (log (20.0 / 15.0) / 500.0);
    for (i = 0; i < n; i++) {
	per *= pm;
	w += 6.28318 * (1.0 / per);
	sper[i] = per;
	signal[i] = cos(w);
    }

    // apply the filter to the signal to obtain the in-phase and
    // in-quadrature filter outputs
    filter.apply (signal, inphase, inquad, n);

    // write the results to a file
    fil = fopen ("junk", "wt");
    for (i = 0; i < n; i++)
	fprintf (fil, "%6d %8.2f %8.2f %10.2f %10.2f %12.2f\n",
	    i, sper[i], signal[i], inphase[i], inquad[i],
	    (float)(inphase[i]*inphase[i] + inquad[i]*inquad[i]) );
    fclose (fil);

    exit (0);
    return (0);
}
#endif /* end of testing code */

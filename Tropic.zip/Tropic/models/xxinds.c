#include <math.h>
#include <stdio.h>
#include <stdlib.h>

void RegBandS (float u[], float s[], float r[], float y[], float x[],
int m, int n) {
    /* Generates rolling regression bands for y[0..n-1], the dependendent
    .  variable, given x[0..n-1], the independent variable.  The predicted
    .  mean of y[k] is returned in u[k], the standard error of prediction
    .  in s[k], and the correlation coefficient in r[k].  The figures in
    .  u[k], s[k], and r[k] are obtained from regressing y[k-m+1..k]
    .  on x[k-m+1..k].  The parameter m controls the rolling period of
    .  the regression, while n specifies the total number of data points
    .  in the series.  NULL may be passed for u[], s[], or r[], if
    .  the specific series is not required.  An efficient vectorized
    .  algorithm is used for the calculations.
    */
    double tx, txo, ty, tyo, sumx, sumy, sumxx, sumyy, sumxy;
    double basex, basey, sx, sy, ux, uy, sxy, rxy, am;
    int k;
    basex=0.5*(x[0]+x[n-1]);
    basey=0.5*(y[0]+y[n-1]);
    sumx=sumy=sumxx=sumyy=sumxy=0.0;
    am=m;
    for(k=0; k<m; k++) {
	sumx+=(tx=x[k]-basex);
	sumxx+=tx*tx;
	sumy+=(ty=y[k]-basey);
	sumyy+=ty*ty;
	sumxy+=tx*ty;
	if(u) u[k]=0.0;
	if(s) s[k]=0.0;
	if(r) r[k]=0.0;
    }
    for(k=m; k<n; k++) {
	sumx+=((tx=x[k]-basex)-(txo=x[k-m]-basex));
	sumy+=((ty=y[k]-basey)-(tyo=y[k-m]-basey));
	sumxx+=(tx*tx-txo*txo);
	sumyy+=(ty*ty-tyo*tyo);
	sumxy+=(tx*ty-txo*tyo);
	ux=sumx/am;
	uy=sumy/am;
	sx=sumxx/am-ux*ux;
	sy=sumyy/am-uy*uy;
	sxy=sumxy/am-ux*uy;
	if((sx>0.0)&&(sy>0.0)) {
	    rxy=sxy/((sx=sqrt(sx))*(sy=sqrt(sy)));
	    if(u) u[k]=(float)(basey+uy+sy*rxy*(tx-ux)/sx);
	    if(s) s[k]=(float)(sy*(1.0-rxy*rxy));
	    if(r) r[k]=(float)rxy;
	} else {
	    if(u) u[k]=(float)(basey+uy);
	    if(s) s[k]=s[k-1];
	    if(r) r[k]=0.0;
	}
    }
}

void prfvltys (float vhat[], long ldt[], float hi[], float lo[],
float cls[], int nbar) {
    /* Generates regression-based predictions of future volatility
    .  over the next 10 bars using two measures of historical
    .  volatility together with three seasonal harmonics.  This is
    .  the prediction model described on page 182 in "Advanced
    .  Option Pricing Models" by Jeffrey Owen Katz, Ph.D. & Donna
    .  L. McCormick (McGraw Hill, 2005).
    .  Arguments:
    .    vhat         - returned predicted volatilities [0..nbar-1]
    .    ldt          - dates [0..nbar-1] in YYYYMMDD form
    .    hi, lo, cls  - stock prices [0..nb-1]
    .    nbar         - number of data points (bars) in series
    .  Routines called:
    .    bmalloc, vltyser
    */
    void* bmalloc(int nbytes);
    void vltyser(float hi[], float lo[], float cls[], int nb,
	float hvx[], int mper, int mode);
    float *hvx1, *hvx2, sum, x1, x2, *x, angle;
    int mperh1, mperh2, k, ibar;
    static float w[12] = {
         0.0774, 0.6673, 0.1806, -0.1014, 0.0224, 0.0430,
        -0.0150, 0.0791, 0.0508,  0.0263, 0.0121, 0.0151  };
    /* allocate array memory */
    hvx1=(float*)bmalloc(sizeof(*hvx1)*nbar);
    hvx2=(float*)bmalloc(sizeof(*hvx2)*nbar);
    x=(float*)bmalloc(sizeof(*x)*12);
    /* set historical volatility averaging periods */
    mperh1=30;
    mperh2=70;
    /* calculate simple average range historical volatility */
    vltyser(hi,lo,cls,nbar,hvx1,mperh1,6);  /* short term */
    vltyser(hi,lo,cls,nbar,hvx2,mperh2,6);  /* long term */
    /* for each bar with a valid historical volatility ... */
    for(ibar=mperh2+mperh1+5; ibar<nbar; ibar++) {
        /* extract independent variables */
        x1=hvx1[ibar];          /* historical short-term volatility */
        x2=hvx2[ibar-mperh1];   /* historical long-term volatility */
        k=ldt[ibar]%10000;
        angle=6.283185*(31*(k/100)-31+(k%100))/372.0;
        x[0]=1.0;
        x[1]=x1;
        x[2]=x2;
        x[3]=x1*x2;
        x[4]=x1*x1;
        x[5]=x2*x2;
        x[6]=x1*sin(4.0*angle); /* seasonal harmonics */
        x[7]=x1*cos(4.0*angle);
        x[8]=x1*sin(8.0*angle);
        x[9]=x1*cos(8.0*angle);
        x[10]=x1*sin(12.0*angle);
        x[11]=x1*cos(12.0*angle);
        /* apply regression weights to independent variables */
        for(sum=0.0, k=0; k<12; k++) sum+=w[k]*x[k];
        vhat[ibar]=sum;         /* predicted future volatility */
    }
    for(ibar=0; ibar<mperh1+mperh2+5; ibar++) vhat[ibar]=0.0;
    /* free memory and return */
    free(x);
    free(hvx2);
    free(hvx1);
}



/*
xxmesa.c

Maximum entropy cycle analysis and forecasting package.  Note that all
routines in this module have been modified to use double precision
arithmetic (for greater numerical stability) and zero-based arrays
(for compatility with our software); the original routines supplied
in Numerical Recipies in C used single precision arithmetic and unit-
based arrays.  This module requires bmalloc() and ftlerr() within scope.

Jeffrey Owen Katz, Ph.D.
Copyright (C) 2002, 2005.  All Rights Reserved.
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#define bmalloc misc_malloc
#define ftlerr misc_ftlerr

void xcyclea (float a[], float b[], int nb) {

	/* Calculates a cycle-based predictive indicator using the maximum
	.  entropy method.  This version employs averaging of nahead
	.  multiple raw predictions to generate an indicator that leads
	.  the data by nlead bars (see code).
	.  a    - out: vector [0..nb-1] of indicator values
	.  b    - in:  vector [0..nb-1] of prices or other data
	.  nb   - in:  number of bars (data points) in a and b
	*/

	void* bmalloc(int nbytes);
	void memcoeff(float *data, int n, int m, float *xms, float *d);
	void mempredict (float *data, int ndata, float *d, int m,
		float *future, int nfut);
	int npoles=15, npoints=50, nahead=10, nlead=4, i, imin, cb;
	float *wdata, *wcoeff, *wahead, xms;
	wdata=(float*)bmalloc(4*npoints);
	wcoeff=(float*)bmalloc(4*npoles);
	wahead=(float*)bmalloc(4*nahead);
	memset(a,0,sizeof(*a)*nb);
	/* ***** check code ***** */
	for(cb=npoints+20; cb<nb; cb++) {
		/* calculate oscillator to analyze for cycles */
		imin=cb-npoints+1;
		for(i=imin; i<=cb; i++)
			wdata[i-imin]=b[i]-b[i-1];
		/* determine autoregressive coefficients */
		memcoeff(wdata,npoints,npoles,&xms,wcoeff);
		/* extrapolate time series into future */
		mempredict(wdata,npoints,wcoeff,npoles,wahead,nahead);
		/* actually compute the data series */
		/* ****** check this code ***** */
		for(i=nlead; i<nahead-nlead && cb+i<nb; i++)
			a[cb+i]+=wahead[i+nlead];

	}
	free(wahead);
	free(wcoeff);
	free(wdata);
}

void xcycleb (float a[], float b[], int nb)
{
	/* Calculates a cycle-based predictive indicator using the maximum
	.  entropy method.  This version involves fitting cosines to the
	.  dominant cycle and using these to extrapolate the signal.
	.  a    - out: vector [0..nb-1] of indicator values
	.  b    - in:  vector [0..nb-1] of prices or other data
	.  nb   - in:  number of bars (data points) in a and b
	*/

	void* bmalloc(int nbytes);
	void ftlerr(char msg[]);
	void memcoeff(float *data, int n, int m, float *xms, float *d);
	float memeval (float fdt, float *d, int m, float xms);
	int npoles=14, npoints=40, i, imin, cb, m;
	float *wdata, *wcoeff, xms, fdt, peakfdt, pwr, peakpwr;
	float fdtmin, fdtmax, sum, ftmp;
	wdata=(float*)bmalloc(4*npoints);
	wcoeff=(float*)bmalloc(npoles);
	memset(a,0,4*nb);
	for(cb=2*npoints+40; cb<nb; cb++) {
		/* calculate oscillator to analyze for cycles */
		imin=cb-npoints+1;
		for(i=imin; i<=cb; i++)
			wdata[i-imin]=b[i]-b[i-1];
		/* determine autoregressive coefficients */
		memcoeff(wdata,npoints,npoles,&xms,wcoeff);
		/* find cycle period of strongest energy */
		peakpwr=0.0;
		fdtmin=1.0/25.0;
		fdtmax=0.25;
		for(fdt=fdtmin; fdt<=fdtmax; fdt*=1.1) {
			pwr=memeval(fdt,wcoeff,npoles,xms);
			if(pwr>peakpwr) {
				peakpwr=pwr;
				peakfdt=fdt;
			}
		}
		/* prediction using three-cycle cosine smoothing */
		m=(int)(1.0+1.0/peakfdt);
		if(m>=npoints) m=npoints;
		if(m<2) m=2;
		if(m>=npoints) ftlerr("xcyclea: ERR1");
		ftmp=2.0*M_PI*peakfdt;
		sum=0.0;
		for(i=0; i<m+m+m && cb-1-i>=0; i++) {
			sum+=cos(ftmp*(i+2))*(b[cb-i]-b[cb-1-i]);
		}
		a[cb]=sum;
	}
	free(wcoeff);
	free(wdata);
}

void mempredict (float *data, int ndata, float *d, int m,
float *future, int nfut) {

	/* Extrapolates a signal using the maximum entropy
	.  (linear prediction) coefficients.
	.  data	   - input, historical data series [0..ndata-1]
	.  ndata   - input, number of historical data points
	.  d	   - input, mem coefficients [0..m-1] from memcoeff
	.  m	   - input, number of coefficients or poles
	.  future  - output, extrapolated future series [0..nfut-1]
	.  nfut	   - input, number of points to extrapolate
	*/

	static float reg[151];
	float sum, discrp;
	int k, j;
	--data; --d; --future;
	for (j=1; j<=m; j++) reg[j]=data[ndata+1-j];
	for (j=1; j<=nfut; j++) {
		discrp=0.0;
		sum=discrp;
		for (k=1; k<=m; k++) sum += d[k]*reg[k];
		for (k=m; k>=2; k--) reg[k]=reg[k-1];
		future[j]=reg[1]=sum;
	}
}

float memeval (float fdt, float *d, int m, float xms) {

	/* Evaluates spectral density (power) at a specified frequency.
	.  fdt	- input, frequency in cycles per bar or data point
	.  d	- input, mesa coefficients from memcoeff
	.  m	- input, number of coefficients or poles
	.  xms	- input, total power from memcoeff
	.  Function returns total power at specified wavelength.
	*/

	int i;
	float sumr=1.0, sumi=0.0;
	double wr=1.0, wi=0.0, wpr, wpi, wtemp, theta;
	--d;
	theta=6.28318530717959*fdt;
	wpr=cos(theta);
	wpi=sin(theta);
	for (i=1; i<=m; i++) {
		wr=(wtemp=wr)*wpr-wi*wpi;
		wi=wi*wpr+wtemp*wpi;
		sumr -= d[i]*wr;
		sumi -= d[i]*wi;
	}
	return(xms/(sumr*sumr+sumi*sumi));
}

void memcoeff (float *data, int n, int m, float *xms, float *d) {

	/* Calculates the maximum entropy coefficients for a given
	.  data series.  These are also the coefficients used for
	.  linear predictive modelling.
	.  data		- input, data series [0..n-1]
	.  n		- input, number of data points
	.  m		- input, number of poles
	.  xms		- output, total power
	.  d		- output, mem coefficients [0..m-1]
	*/

	int k, j, i;
	float p;
	static float wk1[1200], wk2[1200], wkm[151];
	void ftlerr(char msg[]);
	--data; --d;
	for (p=0.0, j=1; j<=n; j++) p += data[j]*data[j];
	*xms=p/n;
	wk1[1]=data[1];
	wk2[n-1]=data[n];
	for (j=2; j<=n-1; j++) {
		wk1[j]=data[j];
		wk2[j-1]=data[j];
	}
	for (k=1; k<=m; k++) {
		float num=0.0, denom=0.0;
		for (j=1; j<=(n-k); j++) {
			num += wk1[j]*wk2[j];
			denom += wk1[j]*wk1[j] + wk2[j]*wk2[j];
		}
		d[k]=2.0*num/denom;
		*xms *= (1.0-d[k]*d[k]);
		for (i=1; i<=(k-1); i++)
			d[i]=wkm[i]-d[k]*wkm[k-i];
		if (k == m) return;
		for (i=1; i<=k; i++) wkm[i]=d[i];
		for (j=1; j<=(n-k-1); j++) {
			wk1[j] -= wkm[k]*wk2[j];
			wk2[j]=wk2[j+1]-wkm[k]*wk1[j+1];
		}
	}
	ftlerr("memcoeff: should never get here");
}


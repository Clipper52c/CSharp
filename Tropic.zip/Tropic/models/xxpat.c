/*-----------xxpat1.c------------------------------------------------------*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

void pd_hstop (float tls[], float hi[], float lo[], int m, int cb) {

    /* Function detects a head and shoulders top using a pivot point
    .  technique.  Aim is not to detect all valid head and shoulder
    .  tops, but to have those that are detected be valid, high
    .  quality formations.  Function returns a trendline connecting
    .  the valleys if a formation is detected, otherwise a null
    .  trendline is returned.  Trendlines are returned with
    .  tls[0]=bar1, tls[1]=price1, tls[2]=bar2, and tls[3]=price2
    .  tls  - output, trendline connecting valleys
    .  hi   - input, high prices [0..cb..]
    .  lo   - input, low prices [0..cb..]
    .  m    - input, lookback period
    .  cb   - input, current or reference bar
    */

    void pivtpts(float pivs[],float hi[],float lo[],int mp,int m,int cb);
    static float pivs[19];
    #define pivt(k) ((int)(pivs[3*(k)+1]))
    #define pivx(k) ((int)(pivs[3*(k)+2]))
    #define pivy(k) (pivs[3*(k)+3])
    pivtpts(pivs, hi, lo, 6, m, cb);
    memset(tls, 0, 16);
    if(pivs[0]<5) return;
    if(pivt(0)>0 && pivt(1)<0 && pivt(2)>0 && pivt(3)<0 && pivt(4)>0) {
        if(pivy(2)>1.002*pivy(4) && pivy(2)>1.002*pivy(0)) {
            if(pivy(4)>1.002*pivy(3) && pivy(4)>1.002*pivy(1)) {
                if(pivy(0)>1.002*pivy(1) && pivy(0)>1.002*pivy(3)) {
                    tls[0]=pivx(3);
                    tls[1]=pivy(3);
                    tls[2]=pivx(1);
                    tls[3]=pivy(1);
                }
            }
        }
    }
    #undef pivt
    #undef pivx
    #undef pivy
}

void pivccw (float pivxy[], float ancxy[], float v[], int m, int cb) {

    /* Function rotates a line passing through an anchor point in a
    .  counter-clockwise direction until it contacts a high pivot in
    .  the data series.  Note that any x coordinate is here assumed
    .  to be a bar index, and that the anchor point is assumed to lie
    .  to the right of the data series which, for this routine, ends
    .  at the reference bar.
    .  pivxy  - output, pivot point coordinates (pivxy[0], pivxy[1])
    .  ancxy  - input, anchor point coordinates (ancxy[0], ancxy[1])
    .  v      - input, data series [0..cb..]
    .  m      - input, lookback period
    .  cb     - input, current or reference bar
    */

    int k;
    float delta, deltamax;
    deltamax= -1.0E32;
    for(k=max(0,cb-m+1); k<=cb; k++) {
        delta=(v[k]-ancxy[1])/(ancxy[0]-k);
        if(delta>deltamax) {
            deltamax=delta;
            pivxy[0]=k;
            pivxy[1]=v[k];
        }
    }
}

void pivcw (float pivxy[], float ancxy[], float v[], int m, int cb) {

    /* Function rotates a line passing through an anchor point in a
    .  clockwise direction until it contacts a low pivot in the data
    .  series.  Note that any x coordinate is here assumed to be a bar
    .  index, and that the anchor point is assumed to lie to the right
    .  of the data series, which, for this routine, ends at the
    .  reference bar.
    .  pivxy  - output, pivot point coordinates (pivxy[0], pivxy[1])
    .  ancxy  - input, anchor point coordinates (ancxy[0], ancxy[1])
    .  v      - input, data series [0..cb..]
    .  m      - input, lookback period
    .  cb     - input, current or reference bar
    */

    int k;
    float delta, deltamax;
    deltamax= -1.0E32;
    for(k=max(0,cb-m+1); k<=cb; k++) {
        delta=(ancxy[1]-v[k])/(ancxy[0]-k);
        if(delta>deltamax) {
            deltamax=delta;
            pivxy[0]=k;
            pivxy[1]=v[k];
        }
    }
}

void pivtpts (float pivs[], float hi[], float lo[], int n, int m, int icb) {

    /* Function determines pivot points using simple algorithm.
    .  Note that any x coordinate is here assumed to be a bar index.
    .  pivs - output, array [0..3*mp] containing the following:
    .             pivs[0]      - number of pivot points
    .             pivs[3*k+1]  - pivot is high (1) or low (-1)
    .             pivs[3*k+2]  - pivot x value (k=0..pivs[0]-1)
    .             pivs[3*k+3]  - pivot y value (k=0..pivs[0]-1)
    .  hi   - input, array [0..cb..] of high prices
    .  lo   - input, array [0..cb..] of low prices
    .  n    - input, maximum number of pivots to detect
    .  m    - input, lookback period in which to find pivots
    .  icb  - input, current or reference bar
    */

    int k, npivs;
    npivs=0;
    m=max(2,icb-m);
    for(k=icb-2; k>=m; k--) {     /* work backwards through data */
        if( hi[k] >= hi[k-1] && hi[k] >= hi[k-2] &&
            hi[k] >  hi[k+1] && hi[k] >  hi[k+2] ) {
                pivs[3*npivs+1]=1.0;    /* high pivot */
                pivs[3*npivs+2]=k;      /* pivot bar */
                pivs[3*npivs+3]=hi[k];  /* pivot price */
		if(++npivs>=n) break;
        }
        if( lo[k] <= lo[k-1] && lo[k] <= lo[k-2] &&
            lo[k] <  lo[k+1] && lo[k] <  lo[k+2] ) {
                pivs[3*npivs+1]= -1.0;  /* low pivot */
                pivs[3*npivs+2]=k;      /* pivot bar */
                pivs[3*npivs+3]=lo[k];  /* pivot price */
		if(++npivs>=n) break;
        }
    }
    pivs[0]=npivs;
}

void tldxa (float tls[], float hi[], int m, int cb) {

        /* Function determines a descending trendline that is just
        .  above the high of the last bar.  A null trendline is
        .  returned in no valid descending trendline can be found.
        .  tls  - output, trendline as standard 4-tuple
        .  hi   - input, high prices
        .  m    - input, lookback
        .  cb   - input, current (most recent) bar
        */

        int k;  float delta, maxdelta;

        /* find most recent high pivot point */
        maxdelta = -1.0E50;
        tls[2] = 0.0;
        for (k = cb - m + 2; k < cb; k++) {
                delta = (hi[k] - hi[cb]) / (cb - k);
                if (delta > maxdelta) {
                        maxdelta = delta;
                        tls[2] = k;
                        tls[3] = hi[k];
                }
        }

        /* find previous pivot to establish a trendline */
        maxdelta = -1.0E50;
        tls[0] = 0.0;
        for (k = cb - m + 1; k < tls[2]; k++) {
                delta = (hi[k] - tls[3]) / (tls[2] - k);
                if (delta > maxdelta) {
                        maxdelta = delta;
                        tls[0] = k;
                        tls[1] = hi[k];
                }
        }

        if (tls[1] < tls[3]) memset (tls, 0, 16);
}

void flmoon(int n, int nph, long *jd, float *frac) {
	/* find Julian date of specific phase of the moon */
	/* nph: 0=new, 1=first qtr, 2=full, 3=last qtr */
	void ftlerr(char msg[]);
	int i;
	float am,as,c,t,t2,xtra;
	#define RAD (3.14159265/180.0)
	c=n+nph/4.0;
	t=c/1236.85;
	t2=t*t;
	as=359.2242+29.105356*c;
	am=306.0253+385.816918*c+0.010730*t2;
	*jd=2415020+28L*n+7L*nph;
	xtra=0.75933+1.53058868*c+((1.178e-4)-(1.55e-7)*t)*t2;
	if (nph == 0 || nph == 2)
		xtra += (0.1734-3.93e-4*t)*sin(RAD*as)-0.4068*sin(RAD*am);
	else if (nph == 1 || nph == 3)
		xtra += (0.1721-4.0e-4*t)*sin(RAD*as)-0.6280*sin(RAD*am);
	else ftlerr("nph is unknown in flmoon");
	i=(int)(xtra >= 0.0 ? floor(xtra) : ceil(xtra-1.0));
	*jd += i;
	*frac=xtra-i;
	#undef RAD
}

long MoonPhaseDate (long ymd, int phase) {
    /* returns YYYMMDD date of next instance of specified lunar phase */
    /* phase: 0=new, 1=frstqtr, 2=full, 3=lstqtr */
    long julday(int mm, int idd, int iyyyy);
    void caldat(long jd, long *mm, long *idd, long *iyyyy);
    static long jd, yyyy, mm, dd, ins=600, insjd;  float frac;
    jd=julday((ymd/100)%100,ymd%100,1900+ymd/10000);
    do{ flmoon(--ins,phase,&insjd,&frac);
	frac=24.0*(frac-5.0/24.0); if(frac<0.0){insjd--; frac+=24.0;}
        if(frac>12.0){insjd++; frac-=12.0;} else{frac+=12.0;} }
    while(insjd>=jd);
    do{ flmoon(++ins,phase,&insjd,&frac);
	frac=24.0*(frac-5.0/24.0); if(frac<0.0){insjd--; frac+=24.0;}
        if(frac>12.0){insjd++; frac-=12.0;} else{frac+=12.0;} }
    while(insjd<jd);
    caldat(insjd,&mm,&dd,&yyyy);
    return(10000*(yyyy-1900)+100*mm+dd);
}

long DaysSinceMoonPhase (long ymd, int phase) {
    /* returns number of days since specified lunar phase */
    /* phase: 0=new, 1=frstqtr, 2=full, 3=lstqtr */
    static long jd, ins=600, insjd;  float frac;
    jd=julday((ymd/100)%100,ymd%100,1900+ymd/10000);
    do{ flmoon(++ins,phase,&insjd,&frac);
	frac=24.0*(frac-5.0/24.0); if(frac<0.0){insjd--; frac+=24.0;}
        if(frac>12.0){insjd++; frac-=12.0;} else{frac+=12.0;} }
    while(insjd<=jd);
    do{ flmoon(--ins,phase,&insjd,&frac);
	frac=24.0*(frac-5.0/24.0); if(frac<0.0){insjd--; frac+=24.0;}
        if(frac>12.0){insjd++; frac-=12.0;} else{frac+=12.0;} }
    while(insjd>jd);
    return jd-insjd;  /* 0 to about 28 days */
}

void RollerA (float ans[], float hi[], float lo[], float cls[],
float sfac, int m, int cb) {

    /* Detects and analyzes "rolling stocks" for tradability on the long
    .  side.  Trades can be taken when profit looks good, count is
    .  sufficient for statistical stability, and position on current
    .  bar is zero.
    .  ans	    - results:
    .		        ans[1] = trade count in test period
    .		        ans[2] = profit in test period
    .		        ans[3] = support (buy) price
    .		        ans[4] = resistance (sell) price
    .			ans[5] = position at current bar
    .  hi, lo, cls  - price series [0..cb..]
    .  sfac	    - split factor at current bar
    .  m	    - analysis lookback period
    .  cb	    - current or reference bar
    */

    int position, count, i;
    float highesthigh, lowestlow, bestprofit, profit, sup, res, cmsn;
    float midpoint, tiny=0.001, delta;

    memset(ans, 0, sizeof(*ans) * 6);
    highesthigh = Highest(hi, m, cb) * sfac;
    lowestlow = Lowest(lo, m, cb) * sfac;
    if(highesthigh > lowestlow + 0.70) return;
    midpoint = 0.5 * (highesthigh + lowestlow);
    delta = 0.01 * cls[cb] * sfac;
    cmsn = 0.02;
    bestprofit = 0.0;
    for(sup = lowestlow; sup < midpoint; sup += 0.01) {
	for(res = sup + 0.03; res <= highesthigh; res += 0.01) {
	    position = 0;
	    count = 0;
	    for(i = cb - m + 1; i <= cb; i++) {
		if(position == 0) {
		    if(lo[i] * sfac < sup + tiny) position = 1;
		}
		else {
		    if(hi[i] * sfac > res - tiny) {
			position = 0;
			count += 1;
		    }
		}
	    }
	    profit = count * ((res - cmsn) / (sup + cmsn) - 1.0);
	    if(profit > bestprofit) {
		bestprofit = profit;
		ans[1] = count;
		ans[2] = profit;
		ans[3] = sup;
		ans[4] = res;
		ans[5] = position;
	    }
	}
    }
}

void RollerB (float ans[], float hi[], float lo[], float cls[],
float ser1[], float ser2[], int m, int cb) {

    /* Detects stocks that trade well on the long side using Stochastics
    .  or other two-series indicator.  Trades can be taken when profit
    .  looks good, count is sufficient for statistical stability, and
    .  position on current bar is one and, on previous bar, zero.
    .  ans	    - results:
    .		         ans[1] = trade count in test period
    .		         ans[2] = profit in test period
    .		         ans[3] = buy limit price
    .		         ans[4] = position at previous bar
    .			 ans[5] = position at current bar
    .  hi, lo, cls  - price series [0..cb..]
    .  ser1, ser2   - indicator pair series [0..cb..]
    .  m	    - analysis (simulated trades) lookback period
    .  cb	    - current or reference bar
    */

    int position, count, i;
    float profit, cmsn, entryprice, exitprice, tiny=0.001;

    memset(ans, 0, sizeof(*ans) * 6);
    cmsn = 2.0;
    profit = 0.0;
    position = 0;
    count = 0;
    for(i = cb - m + 1; i <= cb; i++) {
	ans[4] = position;
	if(position == 0) {
	    if(ser1[i] > ser2[i] && ser1[i-1] < ser2[i-1]
	     && ser1[i]<0.25) {
		position = 1;
		entryprice = cls[i];
	    }
	}
	else {
	    if(ser1[i] < ser2[i] && ser1[i-1] > ser2[i-1]) {
		position = 0;
		count += 1;
		exitprice = cls[i];
		profit += exitprice / (entryprice + tiny) - 1.0;
	    }
	}
	ans[5] = position;
    }
    ans[1] = count;
    ans[2] = profit / count;
    ans[3] = cls[cb];
}

void pd_pivnhi (int ipiv[], float v[], int mp, int mf, int n, int ibar) {

    /* Function locates upper pivot points (tops) in n bars preceding
    .  the current or reference bar using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..npiv] of pivot point indices
    .              ipiv[0] = npiv, number of upper pivots detected
    .              ipiv[1] = index or bar of oldest pivot
    .              ipiv[2] = index or bar of next to oldest pivot
    .              ...
    .              ipiv[npiv] = index of most recent pivot
    .     v    - input, array [0..ibar..] of prices or other data
    .     mp   - input, points to test preceeding each candidate pivot
    .     mf   - input, points to test following each candidate pivot
    .     n    - input, number of past bars to examine
    .     ibar - input, current or reference bar
    */

    int i, k, npiv;
    for(npiv=0, k=ibar-n+1+mp; k<=ibar-mf; k++) {
	for(i=k-mp; i<k; i++) if(v[i] > v[k]) goto L01;
	for(i=k+1; i<=k+mf; i++) if(v[i] >= v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void pd_pivnlo (int ipiv[], float v[], int mp, int mf, int n, int ibar) {

    /* Function locates lower pivot points (bottoms) in n bars preceding
    .  the current or reference bar using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..npiv] of pivot point indices
    .              ipiv[0] = npiv, number of upper pivots detected
    .              ipiv[1] = index or bar of oldest pivot
    .              ipiv[2] = index or bar of next to oldest pivot
    .              ...
    .              ipiv[npiv] = index of most recent pivot
    .     v    - input, array [0..ibar..] of prices or other data
    .     mp   - input, points to test preceeding each candidate pivot
    .     mf   - input, points to test following each candidate pivot
    .     n    - input, number of past bars to examine
    .     ibar - input, current or reference bar
    */

    int i, k, npiv;
    for(npiv=0, k=ibar-n+1+mp; k<=ibar-mf; k++) {
	for(i=k-mp; i<k; i++) if(v[i] < v[k]) goto L01;
	for(i=k+1; i<=k+mf; i++) if(v[i] <= v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void pd_doubletop (float ans[], float hi[], float lo[], float cls[],
float vol[], int ibar) {

    /* Detects a confirmed double-top in the period preceeding the
    .  reference bar, which is also the breakout bar.  Returns various
    .  data on the detected double-top.  Seems to signal shorts for
    .  breakouts below the valley, but longs for breakouts below
    .  the midway point between the valley and the tops.
    */

    int mB, m0, m1, m2, m3, m4, k, kk;
    float x, ha, hb, ala;
    static float bigneg= -1.0E32, bigpos=1.0E32;

    /* initialize */
    ans[0]=0;
    m0=(m4=ibar)-60;

    /* find valid highest pivot */
    for(ha=bigneg, k=m0; k<=m4; k++)
	if(hi[k]>=ha) { ha=hi[k]; m1=k; }
    if(m1-m0<3 || m4-m1<2) return;

    /* find valid next highest pivot */
    for(hb=bigneg, k=m0; k<=m4; k++)
	if(abs(k-m1)>3 && hi[k]>=hb) { hb=hi[k]; m3=k; }
    if(m3-m0<3 || m4-m3<2) return;
    if(m3<m1) { k=m1; m1=m3; m3=k; }

    /* test for valid tops */
    if((kk=m3-m1)<16 || kk>35) return;
    if(hb<0.985*ha) return;

    /* find valley between tops */
    for(ala=bigpos, k=m1; k<=m3; k++)
	if(lo[k]<ala) { ala=lo[k]; m2=k; }
    if(0.5*(ha+hb)-ala<0.05*ha) return;
    if(m3-m2<3 || m2-m1<7) return;

    /* test for breakout or confirmation */
    /* using midpoint gives signals for longs, using valley for shorts */
    if(cls[m4]>=(x=0.5*(ala+hb))) return;
    for(k=m3+1; k<m4; k++) if(cls[k]<=x) return;

    ans[0]=1;
    ans[1]=m1;
    ans[2]=m2;
    ans[3]=m3;
}

/*------xxpat2.c-----------------------------------------------------------*/

/*
xxpat2.c

Detection routines for the Bulkowski and other related patterns.
A list of the routines appears below:

pd_hstop        	head & shoulders top
pd_hsbottom			head & shoulders bottom
pd_pivtlow			pivot low points
pd_pivthigh			pivot high points
pd_doublebottom		double bottom
pd_pipebottom		pipe bottom
pd_bkoutdn			downside breakout from congestion
pd_liquidity		measure of liquidity
pd_correlate		Pearson product-moment correlation
pd_vxest			best Book 3 volatility estimator

Copyright (C) 2005.  All Rights Reserved.
Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
*/

#include <stdlib.h>
#include <math.h>
#include <string.h>

float Highest (float v[], int m, int icb);
float Lowest (float v[], int m, int icb);
void* bmalloc(int nbytes);
void vltyser(float hi[], float lo[], float cls[], int nbar,
		float hvx[], int mper, int mode);

/*-------------------------------------------------------------------------*/

void pd_hstop (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a confirmed head and sholders top in the period
	.  preceding the reference bar (which is also the breakout bar).
	.  Returns measures of the detected head & shoulders top.
	.  Arguments:
	.     ans         - output, pattern detection results:
	.                   ans[0]    - detected: 1.0=Yes 0.0=No
	.	              	ans[1]    - head high
	.		      		ans[2]    - breakout threshold
	.                   ans[3]    - target price
	.                   ans[10..] - trendline data
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Seems to work, but needs some tweaking!  One problem
	.     is that only a few pattern instances are detected.
	.     Currently this routine is tuned to detect short-term
	.     formations.
	*/

	void pd_pivthigh(int ipiv[],float v[],int mp,int mf,int n,int icb);
	int ipiv[5], k, m1, m2, m3, m4, m5, mx;
	float d, bt1, bt2;

	/* locate valid upper pivots (m1, m3, m5) */
	ans[0]=0.0;
	pd_pivthigh(ipiv, hi, 3, 3, 4, icb);
	if(ipiv[0] < 4) return;
	m5=ipiv[1]; m3=ipiv[2]; m1=ipiv[3]; mx=ipiv[4];
	if(icb-m5 > 12 || m5-m1 > 45) return;
	if(m5-m3 < 5 || m3-m1 < 5) return;
	if(abs((m5-m3)-(m3-m1)) > 6) return;
	if(hi[m1] > 0.99*hi[m3]) return;
	if(hi[m5] > 0.99*hi[m3]) return;
	if(fabs(hi[m1]-hi[m5]) > 0.02 * hi[m3]) return;
	for(k=m5+1; k<=icb; k++) if(hi[k] > hi[m5]) return;
	if(hi[mx] > lo[m1]) return;

	/* locate valid lower pivots (m2, m4) */
	for(m2=m1, d=lo[m1], k=m1+1; k<=m3; k++)
		if(lo[k]<d) { d=lo[k]; m2=k; }
	if(m2==m1 || m2==m3) return;
	if(lo[m2] > 0.99*hi[m1]) return;
	for(m4=m3, d=lo[m3], k=m3+1; k<=m5; k++)
		if(lo[k]<d) { d=lo[k]; m4=k; }
	if(m4==m3 || m4==m5) return;
	if(lo[m4] > 0.99*hi[m5]) return;
	/* if(hi[mx] > min(lo[m2],lo[m4])) return; */

	/* check for breakout and copy out results */
	bt1=min(lo[m2],lo[m4]);
	bt2=lo[m2]+(lo[m4]-lo[m2])*(icb-m2)/((float)(m4-m2));
	ans[1]=hi[m3];
	ans[2]=max(bt1,bt2);
	ans[3]=2.0*ans[2]-ans[1];
	if(cls[icb] >= ans[2]) return;
	if(cls[icb] < 1.03*ans[3]) return;

	/* copy out additional results */
	ans[0]=1.0;
	ans[10]=m2;  ans[11]=lo[m2];
	ans[12]=m4;  ans[13]=lo[m4];  ans[14]=13;
	ans[15]=m1;  ans[16]=hi[m1];
	ans[17]=m3;  ans[18]=hi[m3];  ans[19]=13;
}

void pd_hsbottom (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a confirmed head and sholders bottom in the period
	.  preceding the reference bar (which is also the breakout bar).
	.  Returns measures of the detected head & shoulders bottom.
	.     ans         - output, pattern detection results:
	.                   ans[0]    - detected: 1.0=Yes 0.0=No
	.	              	ans[1]    - head low
	.		      		ans[2]    - breakout threshold
	.                   ans[3]    - target price
	.                   ans[10..] - trendline data
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Seems to work well, but needs some tweaking!  One problem
	.     is that only a few pattern instances are detected.
	.     Currently this routine is tuned to detect short-term
	.     formations.
	*/

	void pd_pivtlow(int ipiv[],float v[],int mp,int mf,int n,int icb);
	int ipiv[5], k, m1, m2, m3, m4, m5, mx;
	float d, bt1, bt2;

	/* locate valid lower pivots (m1, m3, m5) */
	ans[0]=0.0;
	pd_pivtlow(ipiv, lo, 3, 3, 4, icb);
	if(ipiv[0] < 4) return;
	m5=ipiv[1]; m3=ipiv[2]; m1=ipiv[3]; mx=ipiv[4];
	if(icb-m5 > 12 || m5-m1 > 45) return;
	if(m5-m3 < 5 || m3-m1 < 5) return;
	if(abs((m5-m3)-(m3-m1)) > 6) return;
	if(lo[m1] < 1.01*lo[m3]) return;
	if(lo[m5] < 1.01*lo[m3]) return;
	if(fabs(lo[m1]-lo[m5]) > 0.02 * lo[m3]) return;
	for(k=m5+1; k<=icb; k++) if(lo[k] < lo[m5]) return;
	if(lo[mx] < hi[m1]) return;

	/* locate valid upper pivots (m2, m4) */
	for(m2=m1, d=hi[m1], k=m1+1; k<=m3; k++)
		if(hi[k]>d) { d=hi[k]; m2=k; }
	if(m2==m1 || m2==m3) return;
	if(hi[m2] < 1.01*max(lo[m1],lo[m3])) return;
	for(m4=m3, d=hi[m3], k=m3+1; k<=m5; k++)
		if(hi[k]>d) { d=hi[k]; m4=k; }
	if(m4==m3 || m4==m5) return;
	if(hi[m4] < 1.01*max(lo[m3],lo[m5])) return;

	/* check for breakout and copy out results */
	bt1=max(hi[m2],hi[m4]);
	bt2=hi[m2]+(hi[m4]-hi[m2])*(icb-m2)/((float)(m4-m2));
	if(cls[icb] <= min(bt1,bt2)) return;
	ans[1]=lo[m3];
	ans[2]=min(bt1,bt2);
	ans[3]=2.0*ans[2]-ans[1];
	if(cls[icb] > 0.97*ans[3]) return;

	/* copy out additional results */
	ans[0]=1.0;
	ans[10]=m2;  ans[11]=hi[m2];
	ans[12]=m4;  ans[13]=hi[m4];  ans[14]=13;
	ans[15]=m1;  ans[16]=lo[m1];
	ans[17]=m3;  ans[18]=lo[m3];  ans[19]=13;
}

void pd_pivtlow (int ipiv[], float v[], int mp, int mf, int n, int icb)
{
    /* Function locates a user-specified number of lower pivot
    .  points (bottoms) preceding the current or reference bar
    .  using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..n] of pivot point indices
    .              ipiv[0] = n, number of lower pivots actually found
    .              ipiv[1] = index or bar of most recent pivot
    .              ipiv[2] = index or bar of next most recent pivot
    .              ...
    .              ipiv[n] = index of oldest pivot
    .     v    - input, array [0..icb..] of prices or other data
    .     mp   - input, points preceeding each candidate pivot to test
    .     mf   - input, points following each candidate pivot to test
    .     n    - input, maximum number of pivots to detect
    .     icb  - input, current or reference bar
    .  Notes:
    .     If there are fewer than n pivots found, then ipiv[] will
    .     contain trailing zeros.
    */

    int i, k, npiv;
    for(npiv=0, k=icb-mf; k>=mp && npiv<n; k--) {
	for(i=k+1; i<=k+mf; i++)
		if(v[i] <= v[k]) goto L01;
	for(i=k-mp; i<k; i++)
		if(v[i] <= v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void pd_pivthigh (int ipiv[], float v[], int mp, int mf, int n, int icb)
{
    /* Function locates a user-specified number of upper pivot
    .  points (tops) preceding the current or reference bar
    .  using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..n] of pivot point indices
    .              ipiv[0] = n, number of upper pivots actually found
    .              ipiv[1] = index or bar of most recent pivot
    .              ipiv[2] = index or bar of next most recent pivot
    .              ...
    .              ipiv[n] = index of oldest pivot
    .     v    - input, array [0..icb..] of prices or other data
    .     mp   - input, points preceeding each candidate pivot to test
    .     mf   - input, points following each candidate pivot to test
    .     n    - input, maximum number of pivots to detect
    .     icb  - input, current or reference bar
    .  Notes:
    .     If there are fewer than n pivots found, then ipiv[] will
    .     contain trailing zeros.
    */

    int i, k, npiv;
    for(npiv=0, k=icb-mf; k>=mp && npiv<n; k--) {
	for(i=k+1; i<=k+mf; i++)
		if(v[i] >= v[k]) goto L01;
	for(i=k-mp; i<k; i++)
		if(v[i] >= v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void pd_doublebottom (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a confirmed double bottom in the period preceding
	.  the reference bar, which is also the breakout bar.  Also
	.  returns various measures of the detected double bottom.
	.  ans         	  - output, pattern detection results:
	.               	ans[0] - detected: 1.0=Yes 0.0=No
	.	            	ans[1] - pattern size
	.		     		ans[2] - breakout threshold
	.       	    	ans[3] - bars seperating bottoms
	.  hi, lo, cls - input, price series [0..icb..]
	.  vol         - input, volume series [0..icb..]
	.  icb         - input, index of current or reference bar
	*/

	int m0, m1, m2, m3, m12, k;
	float d;

	/* initialize */
	memset(ans,0,sizeof(*ans)*4);
	m0=(m3=icb)-110;
	if(m0<0) return;

	/* find and verify two valid bottoms (bars m1 and m2) */
	for(m1=m0, d=lo[m0], k=m0+1; k<=m3; k++)
		if(lo[k] < d) { m1=k; d=lo[k]; }
	if(m1-m0 < (m3-m0)/2 || m3-m1 < 4) return;
	for(m2= -1, d=1.0E32, k=m0; k<=m3; k++)
		if(abs(k-m1) > 4)
			if(lo[k] < d) { m2=k; d=lo[k]; }
	if(m2-m0 < (m3-m0)/2 || m3-m2 < 4) return;
	if(m2<m1) { k=m1; m1=m2; m2=k; }
	if(m2-m1 > 30 || m2-m1 < 8) return;
	if(fabs(lo[m2]-lo[m1]) > 0.02*(lo[m2]+lo[m1])) return;
	if(vol[m1] < vol[m2]) return;
	if(lo[m1] > lo[m2]) return;

	/* find and verify high between bottoms (bar m12) */
	for(m12=m1, d=hi[m1], k=m1+1; k<=m2; k++)
		if(hi[k] > d) { m12=k; d=hi[k]; }
	if(m12 <= m1 || m12 >= m2) return;
	if(hi[m12] < 0.54*(lo[m1]+lo[m2])) return;

	/* verify breakout following the second (m2) bottom */
	for(k=m2+1; k<m3; k++)
		if(cls[k] > hi[m12]) return;
	if(cls[k] < hi[m12]) return;

	/* double bottom has been detected */
	ans[0]=1.0;							/* confirmed double bottom detected */
	ans[1]=hi[m12]-0.5*(lo[m1]+lo[m2]); /* pattern size */
	ans[2]=hi[m12];						/* pattern breakout threshold */
	ans[3]=(float)(m2-m1);				/* bars between bottoms */
}

void pd_pipebottom (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a confirmed pipe bottom in the period preceding
	.  the reference bar, which is also the breakout bar.  Also
	.  returns various measures of any detected pipe bottom.
	.  Arguments:
	.     ans         - output, pattern detection results:
	.                   ans[0] - detected: 1.0=Yes 0.0=No
	.	               	ans[1] - pattern size
	.		       		ans[2] - breakout threshold
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Works fairly well with NI between 1 to 5.  We may want
	.     to do some parameter tweaking, and we need a good exit
	.     model that can get out on any upward thrust before
	.     the gains are lost.
	*/

	#define NW 21	/* total longbars lookback */
	#define NI 3	/* daily bars in a longbar (may be 1..5) */
	float whi[NW], wlo[NW], wcls[NW], wvol[NW];
	float wur, wsr, d, v;
	int kb1, kb2, k, i, m1, m2, m3, m4;

	/* initialize */
	memset(ans,0,sizeof(*ans)*3);
	if(icb<=NI*NW) return;

	/* create longbars and determine range statistics */
	for(wur=0.0, wsr=0.0, k=0; k<NW; k++) {
		kb1=(kb2=icb-NI*(NW-k-1))-NI+1;
		whi[k]=0.0; wlo[k]=1.0E32; wvol[k]=0.0;
		for(i=kb1; i<=kb2; i++) {
			if(hi[i]>whi[k]) whi[k]=hi[i];
			if(lo[i]<wlo[k]) wlo[k]=lo[i];
			wvol[k]+=vol[i];
		}
		wcls[k]=cls[kb2];
		wur+=(d=(whi[k]-wlo[k]));
		wsr+=d*d;
	}
	wur=wur/NW;
	wsr=sqrt(max(0.0,wsr/NW-wur*wur));

	/* detect a confirmed pipe bottom */
	m1=NW-14;	/* first pattern-space bar */
	m4=NW-1;	/* last pattern-space bar */
	for(d=wlo[m1], m2=m1, k=m1+1; k<=m4; k++)
		if(wlo[k]<d) { d=wlo[k]; m2=k; }
	if(m2==m1 || m2==m4) return;
	if(whi[m2]-wlo[m2] < wur+0.8*wsr) return;
	for(d=wlo[m1], m3=m1, k=m1+1; k<=m4; k++)
		if(k!=m2 && wlo[k]<d) { d=wlo[k]; m3=k; }
	if(m3==m1 || m3==m4 || abs(m3-m2)!=1) return;
	if(whi[m3]-wlo[m3] < wur+0.8*wsr) return;
	if(m3<m2) {k=m2; m2=m3; m3=k; }
	d=min(whi[m2],whi[m3])-max(wlo[m2],wlo[m3]);
	if(d<0.40*(whi[m2]-wlo[m2])) return;
	if(d<0.40*(whi[m3]-wlo[m3])) return;
	d=min(wvol[m2],wvol[m3]);
	v=0.2*min(whi[m2],whi[m3])+0.8*max(wlo[m2],wlo[m3]);
	for(k=m1-8; k<=m4; k++)
	    if(k>=0 && k!=m2 && k!=m3) {
		if(k>=m2-2 && k<=m3+2 && wvol[k]>0.98*d) return;
		if(k>=m2-4 && k<=m3+2 && wlo[k]<v) return;
		if(k>m3+2 && lo[k]<min(wlo[m2],wlo[m3])) return;
		if(k>m3 && k<m4 && wcls[k]>=max(whi[m2],whi[m3])) return;
	    }
	if(wcls[m4]<=max(whi[m2],whi[m3])) return;

	/* store results and return */
	ans[0]=1.0;
	ans[1]=max(whi[m2],whi[m3])-min(wlo[m2],wlo[m3]);
	ans[2]=max(whi[m2],whi[m3]);
	return;
	#undef NI
	#undef NW
}

void pd_bkoutdn (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a close-only breakout from congestion to
	.  the downside.
	.  ans        - output, pattern detection results:
	.               ans[0] - detected: 1.0=Yes 0.0=No
	.	            ans[1] - congestion height
	.		     	ans[2] - breakout threshold
	.  hi, lo, cls - input, price series [0..icb..]
	.  vol         - input, volume series [0..icb..]
	.  icb         - input, index of current or reference bar
	*/

	memset(ans,0,sizeof(*ans)*3);
	if(icb<12) return;

	/* detection downside close-only breakout */
	if(cls[icb] > 0.99*Lowest(cls,10,icb-1)) return;
	if(Highest(cls,10,icb)-Lowest(cls,10,icb) > 0.04*cls[icb]) return;

	ans[0]=1;
	ans[1]=Highest(cls,10,icb)-Lowest(cls,10,icb);
	ans[2]=0.99*Lowest(cls,10,icb-1);
	return;
}

void pd_liquidity (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects poor liquidity and spotty trading in the period
	.  preceding the reference bar.  For stocks with good
	.  liquidity and differentiated bars, ans[0] usually falls
	.  below 0.10 and almost always below 0.30; for stocks with
	.  poor liquidity ans[0] usually falls above 0.50 and almost
	.  always above 0.30.
	.  ans         - output, pattern detection results:
	.               ans[0] - liquidity: 0.0=High ... 1.0=Low
	.		     	ans[1] - result valid: 1.0=Yes, 0.0=No
	.  hi, lo, cls - input, price series [0..icb..]
	.  vol         - input, volume series [0..icb..]
	.  icb         - input, index of current or reference bar
	*/

	int i, m0, m1, ncnt;

	/* initialize */
	memset(ans,0,sizeof(*ans)*2);
	m0=min((m1=icb)-50,1);		/* 50-bar lookback */
	if(m1-m0<25) return;

	/* calculate percentage of illiquid features */
	for(ncnt=0, i=m0; i<=m1; i++) {
		if(vol[i]<=0.0 || hi[i]==lo[i]) ncnt+=2;
		if(cls[i]==lo[i] || cls[i]==hi[i]) ncnt++;
		if(hi[i]==hi[i-1] || lo[i]==lo[i-1]) ncnt++;
	}
	ans[0]=0.25*((float)ncnt)/((float)(m1-m0+1));
	ans[1]=1.0;
}

float pd_correlate (float x[], float y[], int n)
{
	/* Calculates the Pearson product-moment correlation
	.  between x[] and y[].
	.  x    - input vector [0..n-1] containing the x variate
	.  y    - input vector [0..n-1] containing the y variate
	.  n    - input parameter containing the length of x and y
	.  ret  - function return containing the correlation
	*/

	int k;
	float xk, yk, ux, uy, sx, sy, rxy;
	ux=sx=uy=sy=rxy=0.0;
	for(k=0; k<n; k++) {
		ux+=(xk=x[k]); sx+=xk*xk;
		uy+=(yk=y[k]); sy+=yk*yk;
		rxy+=xk*yk;
	}
	ux=ux/n;  uy=uy/n;  sx=sx/n-ux*ux;  sy=sy/n-uy*uy;
	if(sx>0.0 && sy>0.0) rxy=(rxy/n-ux*uy)/(sqrt(sx)*sqrt(sy));
	else rxy=0.0;
	return(rxy);
}

void pd_vxest (float vhat[], float dt[], float hi[], float lo[],
float cls[], int nbar)
{
    /* Generates regression-based predictions of future volatility
    .  over the next 10 bars using two measures of historical
    .  volatility together with three seasonal harmonics.  This is
    .  the prediction model described on page 182 in "Advanced
    .  Option Pricing Models" by Jeffrey Owen Katz, Ph.D. & Donna
    .  L. McCormick (McGraw Hill, 2005).
    .  Arguments:
    .    vhat         - returned predicted volatilities [0..nbar-1]
    .    dt           - dates [0..nbar-1] in YYYMMDD.0 form
    .    hi, lo, cls  - stock prices [0..nb-1]
    .    nbar         - number of data points (bars) in series
    .  Routines called:
    .    bmalloc, vltyser
    */

    float *hvx1, *hvx2, sum, x1, x2, *x, angle;
    int mperh1, mperh2, k, ibar;
    static float w[12] = {
         0.0774, 0.6673, 0.1806, -0.1014, 0.0224, 0.0430,
        -0.0150, 0.0791, 0.0508,  0.0263, 0.0121, 0.0151  };
    /* allocate array memory */
    hvx1=(float*)bmalloc(sizeof(*hvx1)*nbar);
    hvx2=(float*)bmalloc(sizeof(*hvx2)*nbar);
    x=(float*)bmalloc(sizeof(*x)*12);
    /* set historical volatility averaging periods */
    mperh1=30;
    mperh2=70;
    /* calculate simple average range historical volatility */
    vltyser(hi,lo,cls,nbar,hvx1,mperh1,6);  /* short term */
    vltyser(hi,lo,cls,nbar,hvx2,mperh2,6);  /* long term */
    /* for each bar with a valid historical volatility ... */
    for(ibar=mperh2+mperh1+5; ibar<nbar; ibar++) {
        /* extract independent variables */
        x1=hvx1[ibar];          /* historical short-term volatility */
        x2=hvx2[ibar-mperh1];   /* historical long-term volatility */
        k=((int)dt[ibar])%10000;
        angle=6.283185*(31*(k/100)-31+(k%100))/372.0;
        x[0]=1.0;
        x[1]=x1;
        x[2]=x2;
        x[3]=x1*x2;
        x[4]=x1*x1;
        x[5]=x2*x2;
        x[6]=x1*sin(4.0*angle); /* seasonal harmonics */
        x[7]=x1*cos(4.0*angle);
        x[8]=x1*sin(8.0*angle);
        x[9]=x1*cos(8.0*angle);
        x[10]=x1*sin(12.0*angle);
        x[11]=x1*cos(12.0*angle);
        /* apply regression weights to independent variables */
        for(sum=0.0, k=0; k<12; k++) sum+=w[k]*x[k];
        vhat[ibar]=sum;         /* predicted future volatility */
    }
    for(ibar=0; ibar<mperh1+mperh2+5; ibar++) vhat[ibar]=0.0;
    /* free memory and return */
    free(x);
    free(hvx2);
    free(hvx1);
}

float pd_XCorrelation (float x[], float y[], int n)
{
	int k;
	float ux, uy, sx, sy, rxy;
	ux=sx=uy=sy=rxy=0.0;
	for(k=0; k<n; k++) {
		ux+=x[k]; sx+=x[k]*x[k];
		uy+=y[k]; sy+=y[k]*y[k];
		rxy+=x[k]*y[k];
	}
	ux=ux/n;  uy=uy/n;
	sx=sx/n-ux*ux;  sy=sy/n-uy*uy;
	if(sx>0.0 && sy>0.0) rxy=(rxy/n-ux*uy)/(sqrt(sx)*sqrt(sy));
	else rxy=0.0;
	return(rxy);
}

void pd_Xpipebottom (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb)
{
	/* Detects a confirmed pipe bottom in the period preceding
	.  the reference bar (which is also the breakout bar).  Also
	.  returns various measures of any detected pipe bottom.
	.  Arguments:
	.     ans         - output, pattern detection results:
	.                   ans[0] - detected: 1.0=Yes 0.0=No
	.	               	ans[1] - pattern size
	.		       		ans[2] - breakout threshold
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Works fairly well with NI between 1 to 5.  We may want
	.     to do some parameter tweaking, and we need a good exit
	.     model that should be able to get out on any upward
	.     thrust before the gains are lost.
	*/

	#define NW 21	/* total longbars lookback */
	#define NI 3	/* bars in a longbar (may be 1..5) */
	float whi[NW], wlo[NW], wcls[NW], wvol[NW];
	float wur, wsr, d, v;
	int kb1, kb2, k, i, m1, m2, m3, m4;

	/* initialize */
	memset(ans,0,sizeof(*ans)*3);
	if(icb<=NI*NW) return;

	/* create longbars and determine range statistics */
	for(wur=0.0, wsr=0.0, k=0; k<NW; k++) {
		kb1=(kb2=icb-NI*(NW-k-1))-NI+1;
		whi[k]=0.0; wlo[k]=1.0E32; wvol[k]=0.0;
		for(i=kb1; i<=kb2; i++) {
			if(hi[i]>whi[k]) whi[k]=hi[i];
			if(lo[i]<wlo[k]) wlo[k]=lo[i];
			wvol[k]+=vol[i];
		}
		wcls[k]=cls[kb2];
		wur+=(d=(whi[k]-wlo[k]));
		wsr+=d*d;
	}
	wur=wur/NW;
	wsr=sqrt(max(0.0,wsr/NW-wur*wur));

	/* detect a confirmed pipe bottom */
	m1=NW-14;	/* first pattern-space bar */
	m4=NW-1;	/* last pattern-space bar */
	for(d=wlo[m1], m2=m1, k=m1+1; k<=m4; k++)
		if(wlo[k]<d) { d=wlo[k]; m2=k; }
	if(m2==m1 || m2==m4) return;
	if(whi[m2]-wlo[m2] < wur+0.8*wsr) return;
	for(d=wlo[m1], m3=m1, k=m1+1; k<=m4; k++)
		if(k!=m2 && wlo[k]<d) { d=wlo[k]; m3=k; }
	if(m3==m1 || m3==m4 || abs(m3-m2)!=1) return;
	if(whi[m3]-wlo[m3] < wur+0.8*wsr) return;
	if(m3<m2) {k=m2; m2=m3; m3=k; }
	d=min(whi[m2],whi[m3])-max(wlo[m2],wlo[m3]);
	if(d<0.40*(whi[m2]-wlo[m2])) return;
	if(d<0.40*(whi[m3]-wlo[m3])) return;
	d=min(wvol[m2],wvol[m3]);
	v=0.2*min(whi[m2],whi[m3])+0.8*max(wlo[m2],wlo[m3]);
	for(k=m1-8; k<=m4; k++)
	    if(k>=0 && k!=m2 && k!=m3) {
		if(k>=m2-2 && k<=m3+2 && wvol[k]>0.98*d) return;
		if(k>=m2-4 && k<=m3+2 && wlo[k]<v) return;
		if(k>m3+2 && lo[k]<min(wlo[m2],wlo[m3])) return;
		if(k>m3 && k<m4 && wcls[k]>=max(whi[m2],whi[m3])) return;
	    }
	if(wcls[m4]<=max(whi[m2],whi[m3])) return;

	/* store results and return */
	ans[0]=1.0;
	ans[1]=max(whi[m2],whi[m3])-min(wlo[m2],wlo[m3]);
	ans[2]=max(whi[m2],whi[m3]);
	return;
	#undef NI
	#undef NW
}

void pd_hstop (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb) {

	/* Detects a confirmed head and sholders top in the period
	.  preceding the reference bar (which is also the breakout bar).
	.  Returns measures of the detected head & shoulders top.
	.  Arguments:
	.     ans         - output, pattern detection results:
	.                   ans[0]    - detected: 1.0=Yes 0.0=No
	.	              	ans[1]    - head high
	.		      		ans[2]    - breakout threshold
	.                   ans[3]    - target price
	.                   ans[10..] - trendline data
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Seems to work, but needs some tweaking!  One problem
	.     is that only a few pattern instances are detected.
	.     Currently this routine is tuned to detect short-term
	.     formations.
	*/

	void pd_pivthigh(int ipiv[],float v[],int mp,int mf,int n,int icb);
	int ipiv[5], k, m0, m1, m2, m3, m4, m5, mx;
	float d, bt1, bt2;

	/* locate valid upper pivots (m1, m3, m5) */
	ans[0]=0.0;
	pd_pivthigh(ipiv, hi, 3, 3, 4, icb);
	if(ipiv[0] < 4) return;
	m5=ipiv[1]; m3=ipiv[2]; m1=ipiv[3]; mx=ipiv[4];
	if(icb-m5 > 12 || m5-m1 > 45) return;
	if(m5-m3 < 5 || m3-m1 < 5) return;
	if(abs((m5-m3)-(m3-m1)) > 6) return;
	if(hi[m1] > 0.99*hi[m3]) return;
	if(hi[m5] > 0.99*hi[m3]) return;
	if(fabs(hi[m1]-hi[m5]) > 0.02 * hi[m3]) return;
	for(k=m5+1; k<=icb; k++) if(hi[k] > hi[m5]) return;
	if(hi[mx] > lo[m1]) return;

	/* locate valid lower pivots (m2, m4) */
	for(m2=m1, d=lo[m1], k=m1+1; k<=m3; k++)
		if(lo[k]<d) { d=lo[k]; m2=k; }
	if(m2==m1 || m2==m3) return;
	if(lo[m2] > 0.99*hi[m1]) return;
	for(m4=m3, d=lo[m3], k=m3+1; k<=m5; k++)
		if(lo[k]<d) { d=lo[k]; m4=k; }
	if(m4==m3 || m4==m5) return;
	if(lo[m4] > 0.99*hi[m5]) return;
	/* if(hi[mx] > min(lo[m2],lo[m4])) return; */

	/* check for breakout and copy out results */
	bt1=min(lo[m2],lo[m4]);
	bt2=lo[m2]+(lo[m4]-lo[m2])*(icb-m2)/((float)(m4-m2));
	ans[1]=hi[m3];
	ans[2]=max(bt1,bt2);
	ans[3]=2.0*ans[2]-ans[1];
	if(cls[icb] >= ans[2]) return;
	if(cls[icb] < 1.05*ans[3]) return;

	/* copy out additional results */
	ans[0]=1.0;
	ans[10]=m2;  ans[11]=lo[m2];
	ans[12]=m4;  ans[13]=lo[m4];  ans[14]=13;
	ans[15]=m1;  ans[16]=hi[m1];
	ans[17]=m3;  ans[18]=hi[m3];  ans[19]=13;
}

void pd_hsbottom (float ans[], float hi[], float lo[], float cls[],
float vol[], int icb) {

	/* Detects a confirmed head and sholders bottom in the period
	.  preceding the reference bar (which is also the breakout bar).
	.  Returns measures of the detected head & shoulders bottom.
	.     ans         - output, pattern detection results:
	.                   ans[0]    - detected: 1.0=Yes 0.0=No
	.	              	ans[1]    - head low
	.		      		ans[2]    - breakout threshold
	.                   ans[3]    - target price
	.                   ans[10..] - trendline data
	.     hi, lo, cls - input, price series [0..icb..]
	.     vol         - input, volume series [0..icb..]
	.     icb         - input, index of current or reference bar
	.  Notes:
	.     Seems to work well, but needs some tweaking!  One problem
	.     is that only a few pattern instances are detected.
	.     Currently this routine is tuned to detect short-term
	.     formations.
	*/

	void pd_pivtlow(int ipiv[],float v[],int mp,int mf,int n,int icb);
	int ipiv[5], k, m0, m1, m2, m3, m4, m5, mx;
	float d, bt1, bt2;

	/* locate valid lower pivots (m1, m3, m5) */
	ans[0]=0.0;
	pd_pivtlow(ipiv, lo, 3, 3, 4, icb);
	if(ipiv[0] < 4) return;
	m5=ipiv[1]; m3=ipiv[2]; m1=ipiv[3]; mx=ipiv[4];
	if(icb-m5 > 12 || m5-m1 > 45) return;
	if(m5-m3 < 5 || m3-m1 < 5) return;
	if(abs((m5-m3)-(m3-m1)) > 6) return;
	if(lo[m1] < 1.01*lo[m3]) return;
	if(lo[m5] < 1.01*lo[m3]) return;
	if(fabs(lo[m1]-lo[m5]) > 0.02 * lo[m3]) return;
	for(k=m5+1; k<=icb; k++) if(lo[k] < lo[m5]) return;
	if(lo[mx] < hi[m1]) return;

	/* locate valid upper pivots (m2, m4) */
	for(m2=m1, d=hi[m1], k=m1+1; k<=m3; k++)
		if(hi[k]>d) { d=hi[k]; m2=k; }
	if(m2==m1 || m2==m3) return;
	if(hi[m2] < 1.01*max(lo[m1],lo[m3])) return;
	for(m4=m3, d=hi[m3], k=m3+1; k<=m5; k++)
		if(hi[k]>d) { d=hi[k]; m4=k; }
	if(m4==m3 || m4==m5) return;
	if(hi[m4] < 1.01*max(lo[m3],lo[m5])) return;

	/* check for breakout and copy out results */
	bt1=max(hi[m2],hi[m4]);
	bt2=hi[m2]+(hi[m4]-hi[m2])*(icb-m2)/((float)(m4-m2));
	if(cls[icb] <= min(bt1,bt2)) return;
	ans[1]=lo[m3];
	ans[2]=min(bt1,bt2);
	ans[3]=2.0*ans[2]-ans[1];
	if(cls[icb] > 0.97*ans[3]) return;

	/* copy out additional results */
	ans[0]=1.0;
	ans[10]=m2;  ans[11]=hi[m2];
	ans[12]=m4;  ans[13]=hi[m4];  ans[14]=13;
	ans[15]=m1;  ans[16]=lo[m1];
	ans[17]=m3;  ans[18]=lo[m3];  ans[19]=13;
}

void pd_pivtlow (int ipiv[], float v[], int mp, int mf, int n, int icb) {

    /* Function locates a user-specified number of lower pivot
    .  points (bottoms) preceding the current or reference bar
    .  using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..n] of pivot point indices
    .            ipiv[0] = n, number of lower pivots actually found
    .            ipiv[1] = index or bar of most recent pivot
    .            ipiv[2] = index or bar of next most recent pivot
    .            ...
    .            ipiv[n] = index of oldest pivot
    .     v    - input, array [0..icb..] of prices or other data
    .     mp   - input, points preceeding each candidate pivot to test
    .     mf   - input, points following each candidate pivot to test
    .     n    - input, maximum number of pivots to detect
    .     icb  - input, current or reference bar
    .  Notes:
    .     If there are fewer than n pivots found, then ipiv[] will
    .     contain trailing zeros.
    */

    int m, i, k, npiv;
    for(npiv=0, k=icb-mf; k>=mp && npiv<n; k--) {
	for(i=k+1; i<=k+mf; i++) if(v[i] <= v[k]) goto L01;
	for(i=k-mp; i<k; i++) if(v[i] < v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void pd_pivthigh (int ipiv[], float v[], int mp, int mf, int n, int icb) {

    /* Function locates a user-specified number of upper pivot
    .  points (tops) preceding the current or reference bar
    .  using a simple algorithm.
    .  Arguments:
    .     ipiv - output, array [0..n] of pivot point indices
    .            ipiv[0] = n, number of upper pivots actually found
    .            ipiv[1] = index or bar of most recent pivot
    .            ipiv[2] = index or bar of next most recent pivot
    .            ...
    .            ipiv[n] = index of oldest pivot
    .     v    - input, array [0..icb..] of prices or other data
    .     mp   - input, points preceeding each candidate pivot to test
    .     mf   - input, points following each candidate pivot to test
    .     n    - input, maximum number of pivots to detect
    .     icb  - input, current or reference bar
    .  Notes:
    .     If there are fewer than n pivots found, then ipiv[] will
    .     contain trailing zeros.
    */

    int m, i, k, npiv;
    for(npiv=0, k=icb-mf; k>=mp && npiv<n; k--) {
	for(i=k+1; i<=k+mf; i++) if(v[i] >= v[k]) goto L01;
	for(i=k-mp; i<k; i++) if(v[i] > v[k]) goto L01;
	ipiv[++npiv]=k;
	L01: ;
    }
    ipiv[0]=npiv;
}

void RegBandS (float u[], float s[], float r[], float y[], float x[],
int m, int n) {

    /* Generates rolling regression bands for y[0..n-1], the dependendent
    .  variable, given x[0..n-1], the independent variable.  The predicted
    .  mean of y[k] is returned in u[k], the standard error of prediction
    .  in s[k], and the correlation coefficient in r[k].  The figures in
    .  u[k], s[k], and r[k] are obtained from regressing y[k-m+1..k]
    .  on x[k-m+1..k].  The parameter m controls the rolling period of
    .  the regression, while n specifies the total number of data points
    .  in the series.  NULL may be passed for u[], s[], or r[], if
    .  the specific series is not required.  An efficient updating
    .  algorithm is used for the calculations.
    */

    double tx, txo, ty, tyo, sumx, sumy, sumxx, sumyy, sumxy;
    double basex, basey, sx, sy, ux, uy, sxy, rxy, am;
    int k;
    basex=0.5*(x[0]+x[n-1]);
    basey=0.5*(y[0]+y[n-1]);
    sumx=sumy=sumxx=sumyy=sumxy=0.0;
    am=m;
    for(k=0; k<m; k++) {
	sumx+=(tx=x[k]-basex);
	sumxx+=tx*tx;
	sumy+=(ty=y[k]-basey);
	sumyy+=ty*ty;
	sumxy+=tx*ty;
	if(u) u[k]=0.0;
	if(s) s[k]=0.0;
	if(r) r[k]=0.0;
    }
    for(k=m; k<n; k++) {
	sumx+=((tx=x[k]-basex)-(txo=x[k-m]-basex));
	sumy+=((ty=y[k]-basey)-(tyo=y[k-m]-basey));
	sumxx+=(tx*tx-txo*txo);
	sumyy+=(ty*ty-tyo*tyo);
	sumxy+=(tx*ty-txo*tyo);
	sx=sumxx/am-(ux=sumx/am)*ux;
	sy=sumyy/am-(uy=sumy/am)*uy;
	sxy=sumxy/am-ux*uy;
	if((sx>0.0)&&(sy>0.0)) {
	    rxy=sxy/((sx=sqrt(sx))*(sy=sqrt(sy)));
	    if(u) u[k]=(float)(basey+uy+sy*rxy*(tx-ux)/sx);
	    if(s) s[k]=(float)(sy*(1.0-rxy*rxy));
	    if(r) r[k]=(float)rxy;
	} else {
	    if(u) u[k]=(float)(basey+uy);
	    if(s) s[k]=s[k-1];
	    if(r) r[k]=0.0;
	}
    }
}


// trops.c
//
// Revised: 2008.07.15
//
// Main simulation, optimization, and reporting module.
//
// Copyright (C) 2008.  All Rights Reserved.
// Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include "libpff.h"	// primary database library header
#include "libodb.h"	// options database library header
#include "libmisc.h"	// utility (misc. functions) library header
#include "libbspm.h"	// options pricing library header
#include "libkbd.h"	// header for kb_hit() and kb_getch_w()
#include "libga.h"	// genetic optimizer class header
#include "trops.h"	// main application header

//----- Defines for abbreviated access to commonly used functions -----------

#define  ftlerr(x)	misc_ftlerr((char*)(x))
#define  month		misc_month
#define  year		misc_year
#define  dayofweek	misc_dayofweek
#define  dayofmonth	misc_dayofmonth
#define  datetoser	misc_datetoser
#define  sertodate	misc_sertodate
#define  hmstosec	misc_hmstosec
#define  randtest	misc_randtest
#define  nthned		misc_nthned
#define  kfindlng	misc_kfindlng
#define  strtrim	misc_strtrim
#define  strlwrcas	misc_strlwr
#define  struprcas	misc_strupr
#define  cumnrml	misc_cumnrml

//------------ Globally Visible Simulation Related Functions ----------------

void select_market (PORTFOLIO &pf, long imkt) {
    // Selects (loads data for) the specified primary market (security) 
    // and sets up some or all of the following data pointers:
    //   pf.opn   - series [0..pf.nbar-1] of opening prices
    //   pf.hi    - series [0..pf.nbar-1] of high prices
    //   pf.lo    - series [0..pf.nbar-1] of low prices    
    //   pf.cls   - series [0..pf.nbar-1] of closing prices
    //   pf.vol   - series [0..pf.nbar-1] of volumes
    //   pf.oi    - series [0..pf.nbar-1] of open interests
    //   pf.sf    - series [0..pf.nbar-1] of split or adjustment factors
    //   pf.suppa - series [0..pf.nbar-1] of supplemental data (1 of 4)
    //   pf.suppb - series [0..pf.nbar-1] of supplemental data (2 of 4)
    //   pf.suppc - series [0..pf.nbar-1] of supplemental data (3 of 4)    
    //   pf.suppd - series [0..pf.nbar-1] of supplemental data (4 of 4)
    //   pf.sym   - security ticker symbol (always upper case)
    //   pf.nam   - security name
    // Note 1: Data are loaded from the database file specified in the
    //   most recently issued loadportfolio command.  Supplemental data
    //   are loaded only if they are available and have been requested.
    //   Data series that are not available are marked by null pointers.
    // Note 2: Prices and volumes for stocks are usually split-corrected
    //   and may be dividend-corrected as well (e.g., with Yahoo data).
    //   Multiply prices by the split factors to obtain the original,
    //   uncorrected prices; divide volumes by the split factors to
    //   obtain the original, uncorrected volumes.  With back-adjusted
    //   continuous futures contracts, the array pf.sf[] will contain
    //   the adjustment factors; these may be added to or subtracted
    //   from (see database documentation) the adjusted prices to
    //   recover the original contract prices.
    if(pf.pfloaded==FALSE) ftlerr("select_market: no open database");
    if(imkt<0) ftlerr("select_market: imkt<0");
    if(imkt>=pf.nmkt) ftlerr("select_market: imkt>=pf.nmkt");
    if(imkt==pf.mktselected) return;  // specified market already selected
    if((pf.pftype & (PFF_STDDATA_BIT | PFF_FUTDATA_BIT)) != 0) {
        // primary stock or futures market data
        PORTFOLIODATA* pfp = pf.pff;
        pff_seekquotes(pfp, imkt);
        pf.opn=pfp->opn;
        pf.hi=pfp->hi;
        pf.lo=pfp->lo;
        pf.cls=pfp->cls;
        pf.vol=pfp->vol;
        pf.oi=pfp->oi;
        pf.sf=pfp->sf;
        pff_seeksymbol(pfp, imkt);
        pf.sym=pfp->symbol;
        pf.nam=pfp->name;
        if((pf.pftype & PFF_SUPPDATA_BIT) != 0) {
            // primary supplemental market data
            pff_seeksupp(pfp, imkt);
            pf.suppa=pfp->suppa;
            pf.suppb=pfp->suppb;
            pf.suppc=pfp->suppc;
            pf.suppd=pfp->suppd;
        }
    }
    else ftlerr("select_market: invalid pf.pftype");
    pf.mktselected=imkt;	// set the current market selection
}

long load_chain (PORTFOLIO &pf, long ibar) {
    // Loads from an options database (opened with the loadoptions
    // command) the option chain corresponding to the specified bar
    // (ibar) and currently selected market in the portfolio database.  
    // Returns 0 on success (chain loaded), -1 on failure (chain not 
    // found).  May be called only if there are open stock and option 
    // databases, and if a market (stock) has been selected via a 
    // previous call to select_market().  The trading model may access 
    // the loaded chain in pf.oc (an option chain structure as defined 
    // in libodb.h) after a successful call to load_chain().
    long kstk, kday;
    if(pf.odb==NULL) ftlerr("load_chain: no open options database");
    if(pf.pff==NULL) ftlerr("load_chain: no open primary database");
    if(pf.mktselected<0) ftlerr("load_chain: no market selected");
    if(ibar<0) ftlerr("load_chain: ibar<0");
    if(ibar>=pf.nbar) ftlerr("load_chain: ibar>=pf.nbar");
    if((kstk=pf.ioptm[pf.mktselected])<0) return(-1);
    if((kday=pf.ioptb[ibar])<0) return(-1);
    odb_read(pf.odb, kstk, kday, &pf.oc);
    if(pf.oc.valid<=0) return(-1);
    return(0);
}

void clear_trades (PORTFOLIO &pf) {
    // Clears all trades from the simulated trade record
    pf.ntrd=0;
    pf.ktrdpool=0;
}

void add_trade (PORTFOLIO &pf, TRADE &trd) {
    // Adds a trade to the record of trades taken for the portfolio.
    // On entry, structure trd must contain:
    //   trd.imkt        - index of market (security) traded, 0..pf.nmkt-1
    //   trd.ientrybar   - bar trade entered, 0..pf.nbar-1
    //   trd.iexitbar    - bar trade exited, 0..pf.nbar-1
    //   trd.nshr        - shares or contracts long (+) or short (-)
    //   trd.entryvalue  - trade entry value, credit (-) or debit (+)
    //   trd.clsvalue[]  - trade value as of close for each
    //                       bar in trade, [0..MAXHLD-1]
    //   trd.exdat[]     - extra data associated with trade, [0..MAXEXD-1]
    // Note 1:
    //   When allocating a TRADE structure within a trading model (to
    //   pass to add_trade), be sure to also allocate the structure
    //   member trd.clsvalue (a float pointer).
    // Note 2:
    //   When a trade involves options, trd.imkt should contain the
    //   market index of the underlying security, not of the option.
    long nhld, k;
    if(trd.ientrybar<0) ftlerr("add_trade: trd.ientrybar<0");
    if(trd.iexitbar>=pf.nbar) ftlerr("add_trade: trd.iexitbar>=pf.nbar");
    if((nhld=trd.iexitbar-trd.ientrybar+1)<1) ftlerr("add_trade: nhld<1");
    if(nhld>MAXHLD) ftlerr("add_trade: nhld>MAXHLD");
    if(pf.ntrd>=MAXTRD) ftlerr("add_trade: pf.ntrd>=MAXTRD");
    {
        TRADE& pftrd = pf.trd[pf.ntrd];
        pftrd.imkt=trd.imkt;
        pftrd.nshr=trd.nshr;
        pftrd.ientrybar=trd.ientrybar;
        pftrd.iexitbar=trd.iexitbar;
        pftrd.entryvalue=trd.entryvalue;
        memcpy(pftrd.exdat, trd.exdat, sizeof(float)*MAXEXD);
        if((k=pf.ktrdpool+nhld)>MAXTRP)
            ftlerr("add_trade: MAXTRP exceeded");
        pftrd.clsvalue=&pf.trdpool[pf.ktrdpool];
        pf.ktrdpool=k;
        memcpy(pftrd.clsvalue, trd.clsvalue, sizeof(float)*nhld);
    }
    pf.ntrd++;
}

void calc_stats (PORTFOLIO &pf) {
    // Calculates portfolio equity curves and performance statistics
    // for in-sample and out-of-sample trades.  Notes: (1) This routine
    // assumes a constant portfolio size (that is, no compounding)
    // when determining annual return relative to drawdown and other
    // related statistics; and (2), some statistics based on the equity
    // curve (but not the equity curve itself) are in terms of end-of-day
    // bars, even when the actual bars are of a shorter duration, to
    // aid in comparisons between trading models operating on different
    // timeframes.
    long i, k, n, kstart, kstop, kisbeg, kisend, kosbeg, kosend, ientdt;
    long isbegeod, isendeod, osbegeod, osendeod, nbareod, na, nb, *ldteod;
    float eqmax, eq, eqprev, draw, x, s, u, au, as, bu, bs, a, b, r;
    float tinynum=1.0E-32, *eqclseod, *poscnteod;
    // clear closing equity curve and position count arrays
    for(k=0; k<pf.nbar; k++) pf.eqcls[k]=0.0;
    for(k=0; k<pf.nbar; k++) pf.poscnt[k]=0.0;
    // accumulate equity changes and position counts
    for(k=0; k<pf.ntrd; k++) {		// loop over all trades
        TRADE &trk = pf.trd[k];
        kstart=trk.ientrybar;		// entry bar
        kstop=trk.iexitbar;		// exit bar
        x=trk.clsvalue[0]-trk.entryvalue;
        pf.eqcls[kstart]+=x;		// accumulate equity changes
        pf.poscnt[kstart]+=1.0;		// accumulate position counts
        for(i=kstart+1; i<=kstop; i++) {
            x=trk.clsvalue[i-kstart]-trk.clsvalue[i-kstart-1];
            pf.eqcls[i]+=x;		// accumulate equity changes
            pf.poscnt[i]+=1.0;		// accumulate position counts
        }
    }
    // integrate bar-to-bar equity changes to obtain equity curve
    for(k=1; k<pf.nbar; k++) pf.eqcls[k]+=pf.eqcls[k-1];
    // determine and verify bar ranges for each sample
    kisbeg= -1;  kisend= -1;  kosbeg= -1;  kosend= -1;
    for(k=0; k<pf.nbar; k++) {
        if((i=pf.ldt[k])>=pf.isdate && i<=pf.osdate) {
            if(kisbeg<0) kisbeg=k;	// in-sample begin bar
            kisend=k;			// in-sample end bar
        }
        if(i>=pf.osdate && i<=pf.enddate) {
            if(kosbeg<0) kosbeg=k;	// out-sample begin bar
            kosend=k;			// out-sample end bar
        }
    }
    if(kisbeg<0 || kosbeg<0) ftlerr("calc_stats: bad sampling dates");
    // compute correlation of in-sample equity with best-fit line
    au=0.0; as=0.0; bu=0.0; bs=0.0; r=0.0;
    x=0.5*(kisbeg+kisend);
    u=0.5*(pf.eqcls[kisbeg]+pf.eqcls[kisend]);
    for(k=kisbeg; k<=kisend; k++) {
        au+=(a=k-x); as+=a*a; bu+=(b=pf.eqcls[k]-u); bs+=b*b; r+=a*b;
    }
    if((n=kisend-kisbeg+1)>2) {
        au=au/n; bu=bu/n; as=as/n-au*au; bs=bs/n-bu*bu;
        r= (as>0.0 && bs>0.0) ? (r/n-au*bu)/(sqrt(as)*sqrt(bs)) : 0.0;
    }
    else r=0.0;
    pf.psi.rvalue=r;
    // compute correlation of out-of-sample equity with best-fit line
    au=0.0; as=0.0; bu=0.0; bs=0.0; r=0.0;
    x=0.5*(kosbeg+kosend);
    u=0.5*(pf.eqcls[kosbeg]+pf.eqcls[kosend]);
    for(k=kosbeg; k<=kosend; k++) {
        au+=(a=k-x); as+=a*a; bu+=(b=pf.eqcls[k]-u); bs+=b*b; r+=a*b;
    }
    if((n=kosend-kosbeg+1)>2) {
        au=au/n; bu=bu/n; as=as/n-au*au; bs=bs/n-bu*bu;
        r= (as>0.0 && bs>0.0) ? (r/n-au*bu)/(sqrt(as)*sqrt(bs)) : 0.0;
    }
    else r=0.0;
    pf.pso.rvalue=r;
    // compute statistics from in-sample equity data
    eqprev=pf.eqcls[kisbeg];
    eqmax=eqprev;
    draw=0.0; na=0; au=0.0; as=0.0; nb=0; bu=0.0; bs=0.0;
    for(k=kisbeg+1; k<=kisend; k++) {
        x=(eq=pf.eqcls[k])-eqprev; eqprev=eq;
        na++; au+=x; as+=x*x;
        if(fabs(x)>tinynum) { nb++; bu+=x; bs+=x*x; }
        if(eq>eqmax) eqmax=eq;
        if(eqmax-eq>draw) draw=eqmax-eq;        
    }
    au=au/(x=na+tinynum); as=as/x-au*au;
    as= (as>0.0) ? sqrt(as) : 0.0;
    bu=bu/(x=nb+tinynum); bs=bs/x-bu*bu;
    bs= (bs>0.0) ? sqrt(bs) : 0.0;
    pf.psi.rbrdraw=draw;
    pf.psi.rbrnet=na*au;
    pf.psi.rbrbars=na;
    pf.psi.rbrbarsm=nb;
    r=datetoser(pf.ldt[kisend])-datetoser(pf.ldt[kisbeg]);
    r=r+(hmstosec(pf.ltm[kisend])-hmstosec(pf.ltm[kisbeg]))/86400.0;
    r= (r>0.0) ? 365.25/(r+0.5) : 0.0;
    pf.psi.rbrsharp=sqrt(na*r)*au/(as+tinynum);
    pf.psi.rbrsharpm=sqrt(nb*r)*bu/(bs+tinynum);
    pf.psi.rbraroa=100.0*r*pf.psi.rbrnet/(pf.psi.rbrdraw+tinynum);
    // compute statistics from out-of-sample equity data
    eqprev=pf.eqcls[kosbeg];
    eqmax=eqprev;
    draw=0.0; na=0; au=0.0; as=0.0; nb=0; bu=0.0; bs=0.0;
    for(k=kosbeg+1; k<=kosend; k++) {
        x=(eq=pf.eqcls[k])-eqprev; eqprev=eq;
        na++; au+=x; as+=x*x;
        if(fabs(x)>tinynum) { nb++; bu+=x; bs+=x*x; }
        if(eq>eqmax) eqmax=eq;
        if(eqmax-eq>draw) draw=eqmax-eq;        
    }
    au=au/(x=na+tinynum); as=as/x-au*au;
    as= (as>0.0) ? sqrt(as) : 0.0;
    bu=bu/(x=nb+tinynum); bs=bs/x-bu*bu;
    bs= (bs>0.0) ? sqrt(bs) : 0.0;
    pf.pso.rbrdraw=draw;
    pf.pso.rbrnet=na*au;
    pf.pso.rbrbars=na;
    pf.pso.rbrbarsm=nb;
    r=datetoser(pf.ldt[kosend])-datetoser(pf.ldt[kosbeg]);
    r=r+(hmstosec(pf.ltm[kosend])-hmstosec(pf.ltm[kosbeg]))/86400.0;
    r= (r>0.0) ? 365.25/(r+0.5) : 0.0;
    pf.pso.rbrsharp=sqrt(na*r)*au/(as+tinynum);
    pf.pso.rbrsharpm=sqrt(nb*r)*bu/(bs+tinynum);
    pf.pso.rbraroa=100.0*r*pf.pso.rbrnet/(pf.pso.rbrdraw+tinynum);
    // prepare end-of-day date, equity, and position count series
    if((pf.pftype & PFF_INTRADAY_BIT) != 0) {  // data is intraday
        // determine required number of end-of-day bars
        for(nbareod=1, i=1; i<pf.nbar; i++) 
            if(pf.ldt[i]!=pf.ldt[i-1]) nbareod++;
        // allocate memory for decimated end-of-day series
        ldteod=(long*)pff_malloc(sizeof(long)*nbareod);
        eqclseod=(float*)pff_malloc(sizeof(float)*nbareod);
        poscnteod=(float*)pff_malloc(sizeof(float)*nbareod);        
        // decimate intraday data to obtain end-of-day series
        for(k=0, x=0.0, i=0; i<pf.nbar; i++) {
            if(pf.poscnt[i]>x) x=pf.poscnt[i];
            if(i==pf.nbar-1 || pf.ldt[i]!=pf.ldt[i+1]) {
                ldteod[k]=pf.ldt[i];
                eqclseod[k]=pf.eqcls[i];
                poscnteod[k++]=x;  
                x=0.0;
            } 
        }
        // test for correct calculations
        if(k!=nbareod) ftlerr("calc_stats: k!=nbar_eod");
    }
    else {  // data is end-of-day
        // set up pointers to already existing end-of-day data
        nbareod=pf.nbar;
        ldteod=pf.ldt;
        eqclseod=pf.eqcls;
        poscnteod=pf.poscnt;
    }        
    // determine end-of-day bars corresponding to relevant sampling dates
    isbegeod=kfindlng(ldteod,nbareod,pf.isdate);  // first in-sample bar
    if(ldteod[isbegeod]<pf.isdate) isbegeod++;
    isendeod=kfindlng(ldteod,nbareod,pf.osdate);  // last in-sample bar
    osbegeod=isendeod;				  // first out-sample bar
    osendeod=kfindlng(ldteod,nbareod,pf.enddate); // last out-sample bar    
    // calculate in-sample statistics from end-of-day equity data
    n=0; u=0.0; s=0.0; na=0; au=0.0; as=0.0; nb=0; bu=0.0; bs=0.0;
    draw=0.0; k=0; eqmax=eqclseod[isbegeod];
    pf.psi.asim= 0.0; pf.psi.maxsim= 0.0;
    for(i=isbegeod+1; i<=isendeod; i++) {
        x=(eq=eqclseod[i])-eqclseod[i-1];
        n++; u+=x; s+=x*x;
        if(fabs(x)>tinynum) { na++; au+=x; as+=x*x; }
        if(eq>eqmax) eqmax=eq;
        if(eqmax-eq>draw) draw=eqmax-eq;
        pf.psi.asim+=poscnteod[i];
        if(poscnteod[i]>pf.psi.maxsim) pf.psi.maxsim=poscnteod[i];
        x= (i<5) ? eq : eq-eqclseod[i-5];
        if(x>0.0) k++;
        nb++; bu+=x; bs+=x*x;
    }
    pf.psi.barcnt=n;
    pf.psi.draw=draw;
    r=datetoser(ldteod[isendeod])-datetoser(ldteod[isbegeod]);
    r= (r>0.0) ? 365.25/(r+0.5) : 0.0;
    u=u/(x=n+tinynum); s=s/x-u*u;
    s= (s>0.0) ? sqrt(s) : tinynum;
    pf.psi.sharpe=sqrt(x*r)*u/s;
    au=au/(x=na+tinynum); as=as/x-au*au;
    as= (as>0.0) ? sqrt(as) : tinynum;
    pf.psi.sharpm=sqrt(x*r)*au/as;
    bu=bu/(x=nb+tinynum); bs=bs/x-bu*bu;
    bs= (bs>0.0) ? sqrt(bs) : tinynum;
    pf.psi.sharpw=sqrt(0.2*x*r)*bu/bs;
    pf.psi.prob=cumnrml(sqrt(x=n+tinynum)*(-u/s));
    pf.psi.aroa=100.0*r*x*u/(draw+tinynum);
    pf.psi.asim=pf.psi.asim/x;
    pf.psi.neteq=x*u;
    pf.psi.winpct=100.0*k/x;
    // calculate out-of-sample statistics from end-of-day equity data
    n=0; u=0.0; s=0.0; na=0; au=0.0; as=0.0; nb=0; bu=0.0; bs=0.0;
    draw=0.0; k=0; eqmax=eqclseod[osbegeod];
    pf.pso.maxsim= 0.0; pf.pso.asim= 0.0;
    for(i=osbegeod+1; i<=osendeod; i++) {
        x=(eq=eqclseod[i])-eqclseod[i-1];
        n++; u+=x; s+=x*x;
        if(fabs(x)>tinynum) { na++; au+=x; as+=x*x; }
        if(eq>eqmax) eqmax=eq;
        if(eqmax-eq>draw) draw=eqmax-eq;
        pf.pso.asim+=poscnteod[i];
        if(poscnteod[i]>pf.pso.maxsim) pf.pso.maxsim=poscnteod[i];
        x= (i<5) ? eq : eq-eqclseod[i-5];
        if(x>0.0) k++;
        nb++; bu+=x; bs+=x*x;
    }
    pf.pso.barcnt=n;
    pf.pso.draw=draw;
    r=datetoser(ldteod[osendeod])-datetoser(ldteod[osbegeod]);
    r= (r>0.0) ? 365.25/(r+0.5) : 0.0;
    u=u/(x=n+tinynum); s=s/x-u*u;
    s= (s>0.0) ? sqrt(s) : tinynum;
    pf.pso.sharpe=sqrt(x*r)*u/s;
    au=au/(x=na+tinynum); as=as/x-au*au;
    as= (as>0.0) ? sqrt(as) : tinynum;
    pf.pso.sharpm=sqrt(x*r)*au/as;
    bu=bu/(x=nb+tinynum); bs=bs/x-bu*bu;
    bs= (bs>0.0) ? sqrt(bs) : tinynum;
    pf.pso.sharpw=sqrt(0.2*x*r)*bu/bs;
    pf.pso.prob=cumnrml(sqrt(x=n+tinynum)*(-u/s));
    pf.pso.aroa=100.0*r*x*u/(draw+tinynum);
    pf.pso.asim=pf.pso.asim/x;
    pf.pso.neteq=x*u;
    pf.pso.winpct=100.0*k/x;
    // free memory allocated for decimation-derived end-of-day data
    if((pf.pftype & PFF_INTRADAY_BIT) != 0) {
        free(ldteod);
        free(eqclseod);
        free(poscnteod);
    }
    nbareod=0;
    // calculate statistics from trade-by-trade data
    pf.psi.wins=     pf.pso.wins=     0.0;
    pf.psi.losses=   pf.pso.losses=   0.0;
    pf.psi.avgwin=   pf.pso.avgwin=   0.0;
    pf.psi.avgloss=  pf.pso.avgloss=  0.0;
    pf.psi.stdtrd=   pf.pso.stdtrd=   0.0;    
    pf.psi.bigwin=   pf.pso.bigwin=   0.0;
    pf.psi.bigloss=  pf.pso.bigloss=  0.0;
    pf.psi.ahld=     pf.pso.ahld=     0.0;
    pf.psi.maxhld=   pf.pso.maxhld=   0.0;
    for(i=0; i<pf.ntrd; i++) {
        ientdt=pf.ldt[pf.trd[i].ientrybar];		// trade entry date
        k=pf.trd[i].iexitbar-pf.trd[i].ientrybar+1;     // bars held
        x=pf.trd[i].clsvalue[k-1]-pf.trd[i].entryvalue; // profit or loss
        if(ientdt>=pf.isdate && ientdt<=pf.osdate) {	// in-sample trade
            if(x>0.0) {		// winner
                pf.psi.wins+=1.0;
                pf.psi.avgwin+=x;
                if(x>pf.psi.bigwin) pf.psi.bigwin=x;          }
            else {		// loser
                pf.psi.losses+=1.0;
                pf.psi.avgloss+=x;
                if(x<pf.psi.bigloss) pf.psi.bigloss=x;        }
            pf.psi.stdtrd+=x*x;
            pf.psi.ahld+=((float)k);
            pf.psi.maxhld=max(pf.psi.maxhld,((float)k));      
        }
        if(ientdt>=pf.osdate && ientdt<=pf.enddate) {	// out-sample trade
            if(x>0.0) {		// winner
                pf.pso.wins+=1.0;
                pf.pso.avgwin+=x;
                if(x>pf.pso.bigwin) pf.pso.bigwin=x;          }
            else {		// loser
                pf.pso.losses+=1.0;
                pf.pso.avgloss+=x;
                if(x<pf.pso.bigloss) pf.pso.bigloss=x;        }
            pf.pso.stdtrd+=x*x;
            pf.pso.ahld+=((float)k);
            pf.pso.maxhld=max(pf.pso.maxhld,((float)k));      
        }
    }
    pf.psi.trds=pf.psi.wins+pf.psi.losses;
    pf.psi.net=pf.psi.avgwin+pf.psi.avgloss;
    pf.psi.avgtrd=pf.psi.net/(a= pf.psi.trds+tinynum);
    pf.psi.avgwin=pf.psi.avgwin/(pf.psi.wins+tinynum);
    pf.psi.avgloss=pf.psi.avgloss/(pf.psi.losses+tinynum);
    x=pf.psi.stdtrd/a-pf.psi.avgtrd*pf.psi.avgtrd;
    pf.psi.stdtrd= (x>0.0) ? (sqrt(x)) : (0.0);
    pf.psi.ahld=pf.psi.ahld/a;
    pf.pso.trds=pf.pso.wins+pf.pso.losses;
    pf.pso.net=pf.pso.avgwin+pf.pso.avgloss;
    pf.pso.avgtrd=pf.pso.net/(a= pf.pso.trds+tinynum);
    pf.pso.avgwin=pf.pso.avgwin/(pf.pso.wins+tinynum);
    pf.pso.avgloss=pf.pso.avgloss/(pf.pso.losses+tinynum);
    x=pf.pso.stdtrd/a-pf.pso.avgtrd*pf.pso.avgtrd;
    pf.pso.stdtrd= (x>0.0) ? (sqrt(x)) : (0.0);    
    pf.pso.ahld=pf.pso.ahld/a;
    // determine fitness measure to be used in optimizations
    //    ****** modify this to suit one's taste ******
    pf.psi.fitness= min(1.3 * pf.psi.sharpw, pf.pso.sharpw);
    if(pf.psi.fitness > 8.0) pf.psi.fitness= 0.0;
    pf.pso.fitness= pf.pso.sharpw;
}

long symbol_to_index (PORTFOLIO &pf, char *symbol) {
    // Returns k such that select_market(pf, k) will load data
    // for the security identified by the specified ticker symbol.  
    // Either 0 <= k < pf.nmkt, if the symbol can be found in 
    // the primary market database, or k == -1, if the symbol
    // cannot be located.
    long k;
    pf.mktselected= -1;		// clear (invalidate) market selection
    for(k=0; k<pf.nmkt; k++) {
        pff_seeksymbol(pf.pff, k);
        if(strcmp(pf.pff->symbol, symbol)==0) return(k);
    }
    return(-1);			// symbol not found
}

//----------------- Function to Read Primary Market Data --------------------

static void read_portfolio (PORTFOLIO &pf, long mode, char *fn) {
    // Opens and closes primary (and related supplementary) market
    // database files.
    //   pf    - Master application data structure
    //   mode  - Database type(s) and buffering mode
    //              1s bit on -  O,H,L,C,V,SF stock data
    //              2s bit on -  total buffering (fast, RAM-intensive)
    //              4s bit on -  supplemental data present
    //              8s bit on -  O,H,L,C,V,SF,OI futures data
    //             16s bit on -  intraday data (has a time field)
    //   fn    - Database file specification (path + name, no extension)
    // Note 1: If the filespec (fn) is either an empty string or a null
    //   pointer, all currently open databases are closed and no new
    //   databases are opened.
    // Note 2: The bit flags used for mode are defined in libpff.h
    long k;
    // close all open databases and free memory for invalidated data
    if(pf.pff) { pff_close(pf.pff); pf.pff=NULL; }
    if(pf.odb) { odb_close(pf.odb); pf.odb=NULL; }
    if(pf.ioptb) { free(pf.ioptb); pf.ioptb=NULL; }
    if(pf.ioptm) { free(pf.ioptm); pf.ioptm=NULL; }
    if(pf.rfi) { free(pf.rfi); pf.rfi=NULL; }
    if(pf.eqcls) { free(pf.eqcls); pf.eqcls=NULL; }
    if(pf.poscnt) { free(pf.poscnt); pf.poscnt=NULL; }
    // set all copies of database-related data pointers to NULL
    pf.ldt=NULL; pf.ltm=NULL;
    pf.opn=NULL; pf.hi=NULL; pf.lo=NULL; pf.cls=NULL; pf.vol=NULL;
    pf.oi=NULL; pf.sf=NULL; pf.sym=NULL; pf.nam=NULL;
    pf.suppa=NULL; pf.suppb=NULL; pf.suppc=NULL; pf.suppd=NULL;
    // clear and/or free all market-data-dependent variables and structures
    clear_trades(pf);
    free_system(pf);
    pf.nbar=0; pf.nmkt=0; pf.nser=0;
    pf.pftype=0; pf.pfloaded=FALSE;
    pf.idpfffile=0; pf.idodbfile=0;
    pf.mktselected= -1;
    strcpy(pf.pfffn,"");
    strcpy(pf.odbfn,"");
    // return if no new database is to be opened
    if(fn==NULL || strlen(fn)<1) return;
    // open new primary (and possibly supplemental) market database
    pf.pff=pff_open(fn, mode, PFFBUFSZ);
    // copy some database info to application structure members
    pf.nbar=pf.pff->nbar;		// bar count
    pf.nmkt=pf.pff->nmkt;		// ticker count
    pf.nser=pf.pff->nser;		// quote series count
    pf.ldt=pf.pff->ldt;			// date series pointer
    pf.ltm=pf.pff->ltm;			// time series pointer
    pf.pftype=mode;			// database mode argument
    strcpy(pf.pfffn, fn);		// database filespec
    // allocate memory for equity and position count series
    pf.eqcls=(float*)pff_malloc(sizeof(float)*pf.nbar);
    pf.poscnt=(float*)pff_malloc(sizeof(float)*pf.nbar);
    // clear the newly allocated series
    for(k=0; k<pf.nbar; k++) pf.eqcls[k]=0.0;
    for(k=0; k<pf.nbar; k++) pf.poscnt[k]=0.0;
    // generate unique file instance identifier
    if((pf.idpfffile=rand())==0) pf.idpfffile=123987;
    // flag portfolio as loaded and clear any market selection
    pf.pfloaded=TRUE;
    pf.mktselected= -1;
}

//------------------- Reporting and Display Functions -----------------------

static long limx (float x) {
    // Converts x to an integer between -99999 and +99999
    if (x > 99999.0) return 99999;
    if (x < -99999.0) return -99999;
    return ( (long) x );
}

static void wroptln (FILE *fil, PORTFOLIO &pf, long mode) {
    // Writes an optimization header line or a optimization data line
    // to the console or to a specified file.
    // Set mode as follows:
    //   0 = write header lines with first 25 parameter values
    //   1 = write in-sample optimization data line
    //   2 = write out-of-sample optimization data line
    // Data fields written to each optimization data line:
    //   S        I=InSample, O=OutOfSample (other than OST$ and OSTN)
    //   P##      First parameter of pf.nprmopt parameters
    //   P##      Second parameter of pf.nprmopt parameters
    //   AROA     Average return (as percent per year) on account
    //              relative to maximum drawdown
    //   PROB     Probability of Sharpe ratio based on a t-test
    //   TRD$     Average dollars per trade
    //   TRDS     Number of trades
    //   WINP     Percentage of winning trades
    //   OST$     OutOfSample dollars per trade
    //   OSTN     OutOfSample trade count
    //   RVALUES  Correlations of equity (IS and OS) with straight line
    // Note: The first field of every line written is a code that enables
    //   the Unix sort utility to easily create the desired sort order
    //   when sorting the optimization data file.
    long i, j;
    switch(mode) {
      case 0:	// write parameters and the results header line
        // write first 25 parameters
        fprintf(fil,"A# FIRST 25 PARAMETERS (BEFORE OPTIMIZATION)\n");
        for(i=0; i<5; i++) {
            fprintf(fil,"B%d ",(int)i);
            for(j=i; j<25; j+=5)
                fprintf(fil,"%2d %8.3f    ",(int)j,(float)pf.parms[j]);
            fprintf(fil,"\n");        
        }
        fprintf(fil,"C# OPTIMIZATION DATA TABLE\n");
        // write results header line
        fprintf(fil,"%2s%6s%02d%6s%02d %5s%6s%6s%6s%6s%6s%6s   %7s\n",
            "D#",
            "P", (int)((pf.nprmopt>0)?(pf.prmlst[0].n):(0)),
            "P", (int)((pf.nprmopt>1)?(pf.prmlst[1].n):(1)),
            "AROA", "PROB", "TRD$",
            "TRDS", "WINP", "OST$", "OSTN", "RVALUES"   );
        break;
      case 1:	// write in-sample results data line
        fprintf(fil,"%1s %8.3f%8.3f%6d .%04d%6d%6d%6d%6d%6d %c.%03d %c.%03d",
            "I",
            (float)pf.parms[((pf.nprmopt>0)?(pf.prmlst[0].n):(0))],
            (float)pf.parms[((pf.nprmopt>1)?(pf.prmlst[1].n):(1))],
            (int)limx(pf.psi.aroa),
            (int)limx(9999.9*pf.psi.prob),
            (int)limx(pf.psi.avgtrd),
            (int)limx(pf.psi.trds),
            (int)limx(100.0*pf.psi.wins/(pf.psi.trds+1.E-3)),
            (int)limx(pf.pso.avgtrd),
            (int)limx(pf.pso.trds),
            (char)((pf.psi.rvalue>=0.0)?(' '):('-')),
            (int)fabs(999.9*pf.psi.rvalue),
            (char)((pf.pso.rvalue>=0.0)?(' '):('-')),
            (int)fabs(999.9*pf.pso.rvalue) );
        #define OPTLINE_EXTRA 0
        #if OPTLINE_EXTRA == 1
            if(fil!=stdout) {
                fprintf(fil,"  %8.2f", (float)pf.psi.fitness);
            }
        #endif
        fprintf(fil,"\n");
        break;
      case 2:	// write out-of-sample results data line
        fprintf(fil,"%1s %8.3f%8.3f%6d .%04d%6d%6d%6d%6d%6d %c.%03d",
            "O",
            (float)pf.parms[((pf.nprmopt>0)?(pf.prmlst[0].n):(0))],
            (float)pf.parms[((pf.nprmopt>1)?(pf.prmlst[1].n):(1))],
            (int)limx(pf.pso.aroa),
            (int)limx(9999.9*pf.pso.prob),
            (int)limx(pf.pso.avgtrd),
            (int)limx(pf.pso.trds),
            (int)limx(100.0*pf.pso.wins/(pf.pso.trds+1.E-3)),
            (int)limx(pf.pso.avgtrd),
            (int)limx(pf.pso.trds),
            (char)((pf.pso.rvalue>=0.0)?(' '):('-')),
            (int)fabs(999.9*pf.pso.rvalue) );
        #if OPTLINE_EXTRA == 1            
            if(fil!=stdout) {
                fprintf(fil,"  %8.2f", (float)pf.pso.fitness);
            }
        #endif
        #undef OPTLINE_EXTRA
        fprintf(fil,"\n");
        break;
      default:	// handle argument error
        ftlerr("wroptln: invalid mode");
    }
    if(fil==stdout) fflush(fil);
}

static void write_respcrv (FILE *fil, PORTFOLIO &pf) {
    // Writes response curve data (as a table) to the console, a file,
    // or a pipe.  A response curve allows one to examine the typical
    // behaviour of prices just before and after trade entries.
    long nr, me, mh, k, i, nw, nl;
    float *rdq, up, uv, pl;
    #define na (-8)	/* relative bar, initial */
    #define nb (10)	/* relative bar, final */
    #define nc (4)	/* data columns for each relative bar */
    // allocate array and set up Fortran-like indexing
    rdq=(float*)pff_malloc(sizeof(float)*(nr=nb-na+1)*nc);
    #define rd(i,j) rdq[(i)-na+(j)*nr]
    // clear response array and trade counters
    for(k=0; k<nr*nc; k++) rdq[k]=0.0;
    nw=0; nl=0;
    // accumulate response data over trades
    for(k=0; k<pf.ntrd; k++) {
        TRADE& trk = pf.trd[k];
        me=trk.ientrybar;			// trade entry bar
        if(me+na<0 || me+nb>=pf.nbar) continue;
        mh=trk.iexitbar-me+1;			// bars trade held
        pl=trk.clsvalue[mh-1]-trk.entryvalue;	// trade profit or loss
        select_market(pf, trk.imkt);		// load market data
        up=pf.cls[me] + 1.E-22;			// entry bar close price
        uv=Average(pf.vol, 10, me) + 1.E-3;	// average volume
        if(pl > 0.0) {
            for(i=na; i<=nb; i++) {		// accumulate win data
                rd(i,0)+=pf.cls[i+me]/up;
                rd(i,1)+=pf.vol[i+me]/uv; }
            nw++;				// win count
        }
        else {
            for(i=na; i<=nb; i++) {		// accumulate loss data
                rd(i,2)+=pf.cls[i+me]/up;
                rd(i,3)+=pf.vol[i+me]/uv; }
            nl++;				// loss count
        }
    }
    // finish computing response statistics
    for(i=na; i<=nb; i++) {
        rd(i,0)=(nw>0)?(rd(i,0)/nw):(0.0);	// normalized win price
        rd(i,1)=(nw>0)?(rd(i,1)/nw):(0.0);	// normalized win volume
        rd(i,2)=(nl>0)?(rd(i,2)/nl):(0.0);	// normalized loss price
        rd(i,3)=(nl>0)?(rd(i,3)/nl):(0.0);	// normalized loss volume
    }
    // write response curve table
    fprintf(fil,"\n-- NORMALIZED RESPONSE DATA ----------------------"
        "---------\n");
    fprintf(fil,"WINS: %ld  LOSSES: %ld\n",(long)nw,(long)nl);
    fprintf(fil,"%5s%9s%9s%9s%9s%9s%9s\n",
        "BAR","PWIN","PLOSS","VWIN","VLOSS","PTOT","VTOT");
    for(i=na; i<=nb; i++) {
        if(i==0) fprintf(fil,"\n");
        fprintf(fil, "%5ld", (long)i);
        fprintf(fil, "%9.3f%9.3f%9.2f%9.2f%9.3f%9.2f\n",
            (float)rd(i,0), (float)rd(i,2),
            (float)rd(i,1), (float)rd(i,3),
            (float)((nw*rd(i,0)+nl*rd(i,2))/(nw+nl)),
            (float)((nw*rd(i,1)+nl*rd(i,3))/(nw+nl))  );
    }
    fflush(fil);
    #undef rd
    free(rdq);
    #undef na
    #undef nb
    #undef nc
}

static void draw_equity (FILE *fil, PORTFOLIO &pf) {
    // Draws a simple text-based (ASCII characters only) equity chart
    // sending it to the console, the pager, or a file
    #define nr	(24)	/* number of rows in plot */
    #define nc	(78)	/* number of columns in plot */
    char *row[nr];
    float eqmin, eqmax;
    long ibar, ir, ic, ibarfirst, ibarlast;
    // determine range of bars to examine
    ibarfirst= -1;  ibarlast= -1;
    for(ibar=0; ibar<pf.nbar; ibar++) {
        if(ibarfirst<0 && pf.ldt[ibar]>=pf.isdate) ibarfirst=ibar;    
        if(pf.ldt[ibar]<=pf.enddate) ibarlast=ibar;
    }
    if(ibarfirst<0 || ibarlast<0)
        ftlerr("draw_equity: bad sampling dates");    
    // determine range of equity over specified bars
    eqmax=eqmin=pf.eqcls[ibarfirst];
    for(ibar=ibarfirst+1; ibar<=ibarlast; ibar++) {
        eqmax=max(eqmax, pf.eqcls[ibar]);
        eqmin=min(eqmin, pf.eqcls[ibar]);
    }
    // check range of equity before plotting
    if(eqmax<1.00001*eqmin) {
        fprintf(stdout,"EQMAX: %f  EQMIN: %f (ZERO RANGE, NO PLOT)\n",
            (float)eqmax, (float)eqmin);
        return;
    }
    // create blank text drawing array
    for(ir=0; ir<nr; ir++) {
        row[ir]=(char*)pff_malloc(sizeof(char)*nc);
        for(ic=0; ic<=nc-2; ic++) row[ir][ic]=' ';
        row[ir][nc-1]=0;
    }
    // draw header row or line
    sprintf(row[nr-1],"EQUITY FROM %d TO %d   MIN=%.2f  MAX=%.2f",
        (int)pf.ldt[ibarfirst], (int)pf.ldt[ibarlast],
        (float)eqmin, (float)eqmax);
    // draw bottom axis with tickmarks
    for(ic=0; ic<nc-1; ic++) {
        if((ic%5)==0) row[0][ic]='+';
        else row[0][ic]='-';
    }
    // draw left axis with tickmarks
    for(ir=0; ir<nr-1; ir++) {
        if((ir%5)==0) row[ir][0]='+';
        else row[ir][0]='|';
    }
    // draw data points
    for(ibar=ibarfirst; ibar<=ibarlast; ibar++) {
        ic=(long)(1.0+(nc-2)*
            (float)(ibar-ibarfirst)/(float)(ibarlast-ibarfirst));
        if(ic>nc-2) ic=nc-2;  if(ic<1) ic=1;
        ir=(long)(1.0+(nr-2)*(pf.eqcls[ibar]-eqmin)/(eqmax-eqmin));
        if(ir>nr-2) ir=nr-2;  if(ir<1) ir=1;
        row[ir][ic]='*'; // data point
        if(ibar>0 && pf.ldt[ibar-1]<=pf.osdate && pf.ldt[ibar]>pf.osdate)
            row[0][ic]='X'; // in-sample -vs- out-of-sample marker
    }
    // write drawing to file, pipe, or console
    for(ir=nr-1; ir>=0; ir--)
        fprintf(fil,"%s\n",(char*)strtrim(row[ir]));
    // free text drawing array
    for(ir=0; ir<nr; ir++) free(row[ir]);
    #undef nr
    #undef nc
}

static void write_summary (FILE *fil, PORTFOLIO &pf, long mode) {
    // Writes a basic summary (mode==0) or an extended summary
    // (mode==1) of trading model performance to console, pager,
    // or file.
    float tinynum=1.E-32, bignum=1.E32;
    // test for absence of simulated trades on which to base summary
    if(pf.ntrd==0) {
        fprintf(fil,"*** NO TRADES TAKEN OR SYSTEM NOT RUN ***\n");
        return;
    }
    // write basic performance statistics
    fprintf(fil,"-- BASIC PERFORMANCE STATISTICS ----------------"
        "---------------------------\n");
    fprintf(fil,"%-10s%12s%12s","DESC","IN-SAMPLE","OUT-SAMPLE");    
    fprintf(fil,"       %-10s%12s%12s\n\n","DESC","IN-SAMPLE","OUT-SAMPLE");
    fprintf(fil,"%-10s%12.2f%12.2f","NET PROFIT",
        (float)pf.psi.neteq, (float)pf.pso.neteq);
    fprintf(fil,"       %-10s%12.1f%12.1f\n","RETURN",
        (float)misc_trim(-99999.99, pf.psi.aroa, 99999.99),
        (float)misc_trim(-99999.99, pf.pso.aroa, 99999.99) );
    fprintf(fil,"%-10s%12.2f%12.2f","DRAWDOWN",
        (float)pf.psi.draw, (float)pf.pso.draw);
    fprintf(fil,"       %-10s%12.5f%12.5f\n","PROB",
        (float)pf.psi.prob, (float)pf.pso.prob);
    fprintf(fil,"%-10s%12.2f%12.2f","DLY PROFIT",
        (float)(pf.psi.net/pf.psi.barcnt),
        (float)(pf.pso.net/pf.pso.barcnt) );
    fprintf(fil,"       %-10s%12.2f%12.2f\n","AVG WIN",
        (float)pf.psi.avgwin, (float)pf.pso.avgwin);
    fprintf(fil,"%-10s%12.2f%12.2f","AVG TRADE",
        (float)pf.psi.avgtrd, (float)pf.pso.avgtrd );
    fprintf(fil,"       %-10s%12.2f%12.2f\n","BIG WIN",
        (float)pf.psi.bigwin, (float)pf.pso.bigwin);
    fprintf(fil,"%-10s%12d%12d","NO. TRADES",
        (int)pf.psi.trds, (int)pf.pso.trds);
    fprintf(fil,"       %-10s%12.2f%12.2f\n","AVG LOSS",
        (float)pf.psi.avgloss, (float)pf.pso.avgloss);
    fprintf(fil,"%-10s%12d%12d","NO. WINS",
        (int)pf.psi.wins, (int)pf.pso.wins);
    fprintf(fil,"       %-10s%12.2f%12.2f\n","BIG LOSS",
        (float)pf.psi.bigloss, (float)pf.pso.bigloss);
    fprintf(fil,"%-10s%12d%12d","NO. LOSSES",
        (int)pf.psi.losses, (int)pf.pso.losses);
    fprintf(fil,"       %-10s%12.2f%12.2f\n","TRD STDEV",
        (float)pf.psi.stdtrd, (float)pf.pso.stdtrd);
    fprintf(fil,"%-10s%12.1f%12.1f","PCT WINS",
        (float)(100.0*pf.psi.wins/(pf.psi.trds+tinynum)),
        (float)(100.0*pf.pso.wins/(pf.pso.trds+tinynum)) );
    fprintf(fil,"       %-10s%12.1f%12.1f\n","AVG HOLD",
        (float)pf.psi.ahld, (float)pf.pso.ahld);
    fprintf(fil,"%-10s%12.1f%12.1f","PCT WKS UP",
        (float)pf.psi.winpct, (float)pf.pso.winpct );
    fprintf(fil,"       %-10s%12.1f%12.1f\n","MAX HOLD",
        (float)pf.psi.maxhld, (float)pf.pso.maxhld);
    fprintf(fil,"%-10s%12.2f%12.2f","SHARPE",
        (float)pf.psi.sharpe, (float)pf.pso.sharpe);
    fprintf(fil,"       %-10s%12.1f%12.1f\n","AVG SIM P",
        (float)pf.psi.asim, (float)pf.pso.asim);
    fprintf(fil,"%-10s%12.2f%12.2f","SHARPE-W",
        (float)pf.psi.sharpw, (float)pf.pso.sharpw);
    fprintf(fil,"       %-10s%12.1f%12.1f\n","MAX SIM P",
        (float)pf.psi.maxsim, (float)pf.pso.maxsim);
    fprintf(fil,"%-10s%12.2f%12.2f","SHARPE-M",
        (float)pf.psi.sharpm, (float)pf.pso.sharpm);        
    fprintf(fil,"       %-10s%12.3f%12.3f\n","R-VALUE",
        (float)pf.psi.rvalue, (float)pf.pso.rvalue);
    fprintf(fil,"%-10s%12.2f%12.2f","NB-SHARP",
        (float)pf.psi.rbrsharp, (float)pf.pso.rbrsharp);
    fprintf(fil,"       %-10s%12.1f%12.1f\n","NB-AROA",
        (float)misc_trim(-99999.99, pf.psi.rbraroa, 99999.99),
        (float)misc_trim(-99999.99, pf.pso.rbraroa, 99999.99) );
    fprintf(fil,"%-10s%12.2f%12.2f","NB-SHARPM",
        (float)pf.psi.rbrsharpm, (float)pf.pso.rbrsharpm);
    fprintf(fil,"       %-10s%12d%12d\n","NB-BARS",
        (int)pf.psi.rbrbars, (int)pf.pso.rbrbars);
    fprintf(fil,"%-10s%12.2f%12.2f","NB-NETPFT",
        (float)pf.psi.rbrnet, (float)pf.pso.rbrnet);
    fprintf(fil,"       %-10s%12d%12d\n","NB-BARSM",
        (int)pf.psi.rbrbarsm, (int)pf.pso.rbrbarsm);
    fprintf(fil,"%-10s%12.2f%12.2f","NB-DRAWDN",
        (float)pf.psi.rbrdraw, (float)pf.pso.rbrdraw);
    fprintf(fil,"       %-10s%12.1f%12.1f\n","NB-PCTME",
        (float)(100.0*pf.psi.rbrbarsm/(pf.psi.rbrbars+tinynum)),
        (float)(100.0*pf.pso.rbrbarsm/(pf.pso.rbrbars+tinynum)) );
    fflush(fil);
    // return when only basic summary is desired
    if(mode<1) return;
    // write sampling dates
    fprintf(fil, "\n-- SPECIFIED SAMPLING DATES ----\n");
    fprintf(fil, "IN-SAMPLE: %8d TO %8d\n",
        (int)pf.isdate, (int)pf.osdate);
    fprintf(fil, "OUT-SAMPLE: %8d TO %8d\n\n",
        (int)pf.osdate, (int)pf.enddate);
    // write response curve table and draw equity chart
    write_respcrv(fil, pf);
    fprintf(fil, "\n\n");
    draw_equity(fil, pf);
    // write year-by-month profit-loss table
    {
        float *pltabqq, chgmax, sclcoeff, eqprev, pl, avg;
        long myra, myrz, imon, iyr, nr, nc, i, navg;
        // initialize variables and allocate year-by-month table
        myra=year(pf.ldt[0]);		// first year in data series
        myrz=year(pf.ldt[pf.nbar-1]);	// last year in data series
        nr=(myrz-myra+1) + 2;		// two extra rows for col stats
        nc=(12) + 2;			// two extra cols for row stats
        pltabqq=(float*)pff_malloc(sizeof(float)*nr*nc);
        for(i=0; i<nr*nc; i++) pltabqq[i]=0.0;
        #define pltab(kyr,kmn) pltabqq[((kyr)-myra)+nr*((kmn)-1)]
        // accumulate p/l data in year-by-month table
        eqprev=pf.eqcls[0];
        for(i=0; i<pf.nbar; i++) {
            imon=month(pf.ldt[i]);
            if(i==pf.nbar-1 || imon!=month(pf.ldt[i+1])) {
                iyr=year(pf.ldt[i]);
                pltab(iyr,imon)=pf.eqcls[i]-eqprev;
                eqprev=pf.eqcls[i];
            }
        }
        // determine largest profit or loss in table
        chgmax=0.0;
        for(iyr=myra; iyr<=myrz; iyr++)
            for(imon=1; imon<=12; imon++)
                if((pl=fabs(pltab(iyr,imon)))>chgmax) chgmax=pl;
        // determine a good scale coefficient
        sclcoeff=1.0;
        while(chgmax/sclcoeff > 999.99) sclcoeff*=10.0;
        while(chgmax/sclcoeff < 99.99) sclcoeff*=0.1;
        // calculate sums and counts by years, months, and all
        avg=0.0; navg=0;
        for(iyr=myra; iyr<=myrz; iyr++) {
            for(imon=1; imon<=12; imon++) {
                if(fabs(pl=pltab(iyr,imon))<tinynum) continue;
                pltab(iyr,13)+=pl;
                pltab(iyr,14)+=1.0;
                pltab(myrz+1,imon)+=pl;
                pltab(myrz+2,imon)+=1.0;
                avg+=pl;
                navg+=1;
            }
        }
        // write out table to file, pager, or pipe
        fprintf(fil,"\n\nMONTH-BY-YEAR P/L TABLE (SCALE %.3f)\n"
            "YEAR --- MONTH --------------------------------"
            "------------------------\n     ",(float)sclcoeff);
        for(imon=1; imon<=12; imon++)
            fprintf(fil,"%5d",(int)imon);
        fprintf(fil,"\n\n");
        for(iyr=myra; iyr<=myrz; iyr++) {
            fprintf(fil,"%4d ",(int)iyr);
            for(imon=1; imon<=12; imon++)
                fprintf(fil,"%5d",(int)(pltab(iyr,imon)/sclcoeff));
            pl=pltab(iyr,13)/(pltab(iyr,14)+tinynum);
            fprintf(fil," %5d\n",(int)(pl/sclcoeff));
        }
        fprintf(fil,"\nAVGPL");
        for(imon=1; imon<=12; imon++) {
            pl=pltab(myrz+1,imon)/(pltab(myrz+2,imon)+tinynum);
            fprintf(fil,"%5d",(int)(pl/sclcoeff));
        }
        fprintf(fil,"%6d\n",(int)((avg/(navg+tinynum))/sclcoeff));
        // undefine table array and free memory
        #undef pltab
        free(pltabqq);
    }
    // write p/l by day-of-week, day-of-month, days-to-expiration,
    // and days-since-expiration
    {
        float *upl, *spl, eqprev, x;
        long *npl, i, k;
        // allocate memory
        upl=(float*)pff_malloc(sizeof(float)*60);
        spl=(float*)pff_malloc(sizeof(float)*60);
        npl=(long*)pff_malloc(sizeof(long)*60);
        // determine average returns by day-of-week
        for(k=1; k<=5; k++) { upl[k]=0.0; spl[k]=0.0; npl[k]=0; }
        eqprev=pf.eqcls[0];
        for(i=0; i<pf.nbar; i++) {
            if(i==pf.nbar-1 || pf.ldt[i]!=pf.ldt[i+1]) {
                x=pf.eqcls[i]-eqprev;
                if(fabs(x) > tinynum) {
                    upl[k=dayofweek(pf.ldt[i])]+=x;
                    spl[k]+=x*x;
                    npl[k]+=1;
                }
                eqprev=pf.eqcls[i];
            }
        }
        for(k=1; k<=5; k++) {
            upl[k]=upl[k]/(x=npl[k]+tinynum);
            spl[k]=(x<2.5)?(0.0):(sqrt(spl[k]/x-upl[k]*upl[k])+tinynum);
        }
        // display or write results
        fprintf(fil,"\n\n-- P/L BY DAY-OF-WEEK ---------------------\n");
        fprintf(fil,"%7s%12s%12s%12s\n","DAYNO","AVGPL","STERR","N");
        for(k=1; k<=5; k++)
            fprintf(fil,"%7d%12.2f%12.2f%12d\n",
                (int)k,(float)upl[k],
                (float)(spl[k]/sqrt(npl[k]+tinynum)),(int)npl[k]);
        // determine average returns by day-of-month
        for(k=1; k<=31; k++) { upl[k]=0.0; spl[k]=0.0; npl[k]=0; }
        eqprev=pf.eqcls[0];
        for(i=0; i<pf.nbar; i++) {
            if(i==pf.nbar-1 || pf.ldt[i]!=pf.ldt[i+1]) {
                x=pf.eqcls[i]-eqprev;
                if(fabs(x) > tinynum) {
                    upl[k=dayofmonth(pf.ldt[i])]+=x;
                    spl[k]+=x*x;
                    npl[k]+=1;
                }
                eqprev=pf.eqcls[i];
            }
        }
        for(k=1; k<=31; k++) {
            upl[k]=upl[k]/(x=npl[k]+tinynum);
            spl[k]=(x<1.5)?(0.0):(sqrt(spl[k]/x-upl[k]*upl[k])+tinynum);
        }
        // display or write results
        fprintf(fil,"\n\n-- P/L BY DAY-OF-MONTH --------------------\n");
        fprintf(fil,"%7s%12s%12s%12s\n","DAYNO","AVGPL","STERR","N");
        for(k=1; k<=31; k++)
            fprintf(fil,"%7d%12.2f%12.2f%12d\n",
                (int)k,(float)upl[k],
                (float)(spl[k]/sqrt(npl[k]+tinynum)),(int)npl[k]);
        // determine average returns by days-to-expiration
        for(k=0; k<=59; k++) { upl[k]=0.0; spl[k]=0.0; npl[k]=0; }
        eqprev=pf.eqcls[0];
        for(i=0; i<pf.nbar; i++) {
            if(i==pf.nbar-1 || pf.ldt[i]!=pf.ldt[i+1]) {
                x=pf.eqcls[i]-eqprev;
                if(fabs(x) > tinynum) {
                    k=datetoser(nthned(pf.ldt[i],1))-datetoser(pf.ldt[i]);
                    upl[k]+=x;
                    spl[k]+=x*x;
                    npl[k]+=1;
                }
                eqprev=pf.eqcls[i];
            }
        }
        for(k=0; k<=35; k++) {
            upl[k]=upl[k]/(x=npl[k]+tinynum);
            spl[k]=(x<1.5)?(0.0):(sqrt(spl[k]/x-upl[k]*upl[k])+tinynum);
        }
        // display or write results
        fprintf(fil,"\n\n-- P/L BY DAYS-TO-EXPIRATION --------------\n");
        fprintf(fil,"%7s%12s%12s%12s\n","DAYNO","AVGPL","STERR","N");
        for(k=0; k<=35; k++)
            fprintf(fil,"%7d%12.2f%12.2f%12d\n",
                (int)k,(float)upl[k],
                (float)(spl[k]/sqrt(npl[k]+tinynum)),(int)npl[k]);
        // determine average returns by days-since-expiration
        for(k=0; k<=59; k++) { upl[k]=0.0; spl[k]=0.0; npl[k]=0; }
        eqprev=pf.eqcls[0];
        for(i=0; i<pf.nbar; i++) {
            if(i==pf.nbar-1 || pf.ldt[i]!=pf.ldt[i+1]) {
                x=pf.eqcls[i]-eqprev;
                if(fabs(x) > tinynum) {
                    k=datetoser(pf.ldt[i])-datetoser(nthned(pf.ldt[i],0));
                    upl[k]+=x;
                    spl[k]+=x*x;
                    npl[k]+=1;
                }
                eqprev=pf.eqcls[i];
            }
        }
        for(k=1; k<=35; k++) {
            upl[k]=upl[k]/(x=npl[k]+tinynum);
            spl[k]=(x<1.5)?(0.0):(sqrt(spl[k]/x-upl[k]*upl[k])+tinynum);
        }
        // display or write results
        fprintf(fil,"\n\n-- P/L BY DAYS-SINCE-EXPIRATION -----------\n");
        fprintf(fil,"%7s%12s%12s%12s\n","DAYNO","AVGPL","STERR","N");
        for(k=1; k<=35; k++)
            fprintf(fil,"%7d%12.2f%12.2f%12d\n",
                (int)k,(float)upl[k],
                (float)(spl[k]/sqrt(npl[k]+tinynum)),(int)npl[k]);
        // free memory
        free(npl);
        free(spl);
        free(upl);
    }
    // write profit-loss histogram
    {
        // declare local variables
        long nhist, ihist, *khisto, i, nhld;
        float pl, plhi, pllo;
        // allocate and clear histogram array
        khisto=(long*)pff_malloc(sizeof(long)*(nhist=30));
        for(i=0; i<nhist; i++) khisto[i]=0;
        // determine range of trade p/l values
        pllo=bignum;
        plhi= -bignum;
        for(i=0; i<pf.ntrd; i++) {
            nhld=pf.trd[i].iexitbar-pf.trd[i].ientrybar+1;
            pl=pf.trd[i].clsvalue[nhld-1]-pf.trd[i].entryvalue;
            if(pl>plhi) plhi=pl;
            if(pl<pllo) pllo=pl;
        }
        plhi=1.00001*plhi;
        pllo=0.99999*pllo;
        // accumulate histogram data
        for(i=0; i<pf.ntrd; i++) {
            nhld=pf.trd[i].iexitbar-pf.trd[i].ientrybar+1;
            pl=pf.trd[i].clsvalue[nhld-1]-pf.trd[i].entryvalue;
            ihist=(long)(nhist*(pl-pllo)/(plhi-pllo));
            ihist=(ihist<0)?(0):(ihist>nhist-1)?(nhist-1):ihist;
            khisto[ihist]+=1;
        }
        // write results to file, pager, or screen
        fprintf(fil,"\n\n-- TRADE P/L HISTOGRAM -------\n");
        fprintf(fil,"NUMBER OF TRADES = %ld\n",(long)pf.ntrd);
        fprintf(fil,"%10s%10s%10s\n","LOPL","HIPL","COUNT");
        for(i=0; i<nhist; i++) {
            fprintf(fil,"%10.1f%10.1f%10ld\n",
                (float)(pllo+i*(plhi-pllo)/nhist),
                (float)(pllo+(i+1)*(plhi-pllo)/nhist),
                (long)khisto[i]);
        }
        // free memory
        free(khisto);
    }
    // write table of weekly trade and equity data
    {
        // declare local variables and structure
        long nw, kw, lsda, k, nh;
        float pl;
        struct WTS {
            long ldate, ldatel, ltrds, lwins;
            float eqty, trdpl;
        } *wts;
        // allocate structure and initialize variables
        lsda=datetoser(pf.ldt[0])-dayofweek(pf.ldt[0])-1;
        nw=(datetoser(pf.ldt[pf.nbar-1])-lsda+15)/7;
        wts=(struct WTS *)pff_malloc(sizeof(struct WTS)*nw);
        for(kw=0; kw<nw; kw++) {
            wts[kw].ldate=sertodate(7*kw+lsda-1);
            wts[kw].ldatel=0;
            wts[kw].ltrds=0;
            wts[kw].lwins=0;
            wts[kw].trdpl=0.0;
            wts[kw].eqty=0.0;
        }
        // extract equity and last date values for each table row
        for(k=0; k<pf.nbar; k++) {
            if(k==pf.nbar-1 || pf.ldt[k]!=pf.ldt[k+1]) {
                kw=(datetoser(pf.ldt[k])-lsda+6)/7;
                kw=(kw<0)?(0):(kw>nw-1)?(nw-1):(kw);
                wts[kw].ldatel=pf.ldt[k];
                wts[kw].eqty=pf.eqcls[k];
            }
        }
        // determine trade count, win count, and trade p/l data
        for(k=0; k<pf.ntrd; k++) {
            nh=pf.trd[k].iexitbar-pf.trd[k].ientrybar+1;
            pl=pf.trd[k].clsvalue[nh-1]-pf.trd[k].entryvalue;
            kw=(datetoser(pf.ldt[pf.trd[k].ientrybar])-lsda+6)/7;
            kw=(kw<0)?(0):(kw>nw-1)?(nw-1):(kw);
            wts[kw].ltrds+=1;
            if(pl>0.0) wts[kw].lwins+=1;
            wts[kw].trdpl+=pl;
        }
        // write out results
        fprintf(fil,"\n\n-- WEEKLY TRADES AND EQUITY REPORT -----"
            "----------------------\n");
        fprintf(fil,"%6s %6s S %6s %6s %8s %12s %10s\n", "W-DATE",
            "A-DATE","NTRDS","NWINS","AVTRD","EQTY","DEQTY");            
        for(kw=0; kw<nw; kw++) {
            if(kw>0 && wts[kw].ldatel==0) wts[kw].eqty=wts[kw-1].eqty;
            fprintf(fil,"%06ld %06ld %1d %6ld %6ld %8.2f %12.2f %10.2f\n",
                (long)(wts[kw].ldate % 1000000),
                (long)(wts[kw].ldatel % 1000000),
                (int)(((k=wts[kw].ldate)<pf.isdate)?(0):
                    (k<=pf.osdate)?(1):(k<=pf.enddate)?(2):(3)),
                (long)(wts[kw].ltrds),
                (long)(wts[kw].lwins),
                (float)(wts[kw].trdpl/(wts[kw].ltrds+tinynum)),
                (float)(wts[kw].eqty),
                (float)((kw>0)?(wts[kw].eqty-wts[kw-1].eqty):(0.0)) );
        }
        // free memory
        free(wts);
    }
    // flush output and return
    fflush(fil);
}

//---------------- Functions to Optimize Model Parameters -------------------

static long optimize_manual (FILE *fil, PORTFOLIO &pf, long np) {

    // Performs portfolio-wide optimization using brute force
    // or user-guided methodology.
    // fil     - output file for optimization data
    // pf      - portfolio (application) data structure
    // np      - number of parameters to optimize (0 is ok)
    // return  - 0=CompleteRun, 1=KilledByUser

    static float f0, f1, f2, f3, bfit;
    static float bprm[MAXPRM];
    static long rc, mkb;

    // define local macro code block
    #define OptBlock                                    \
        if(((mkb++ % 10) == 0) && kb_hit()) {		\
            if(kb_getch_w()=='Q') {			\
                rc= 1;					\
                goto MOPT_END;				\
            }						\
        }						\
        run_system(pf);                                 \
        if(pf.psi.trds > 0) {                           \
            if(pf.psi.fitness > bfit) {                 \
                bfit=pf.psi.fitness;                    \
                memcpy(bprm, pf.parms, sizeof(bprm));   \
            }                                           \
            wroptln(fil, pf, 1);                        \
        }                                               \
        if(pf.noptlnflag) wroptln(stdout, pf, 1)        \
        
    // initialize return code
    rc= 0;  

    // do in-sample optimization
    wroptln(fil, pf, 0);                       // write header line to file
    if(pf.noptlnflag) wroptln(stdout, pf, 0);  // display it on screen
    bfit= -1.0E32;
    mkb=0;
    memcpy(bprm, pf.parms, sizeof(bprm));
    switch(np) {
      case 0:	// run & evaluate system with existing parms
        OptBlock;  
        break;
      case 1:	// optimize a single parameter
        for(f0=pf.prmlst[0].f1; f0<=pf.prmlst[0].f2; f0+=pf.prmlst[0].f3) {
            pf.parms[pf.prmlst[0].n]=f0;
            OptBlock;
        }
        break;
      case 2:	// optimize two parameters
        for(f0=pf.prmlst[0].f1; f0<=pf.prmlst[0].f2; f0+=pf.prmlst[0].f3) {
        for(f1=pf.prmlst[1].f1; f1<=pf.prmlst[1].f2; f1+=pf.prmlst[1].f3) {
            pf.parms[pf.prmlst[0].n]=f0;
            pf.parms[pf.prmlst[1].n]=f1;
            OptBlock;
        }}
        break;
      case 3:	// optimize three parameters
        for(f0=pf.prmlst[0].f1; f0<=pf.prmlst[0].f2; f0+=pf.prmlst[0].f3) {
        for(f1=pf.prmlst[1].f1; f1<=pf.prmlst[1].f2; f1+=pf.prmlst[1].f3) {
        for(f2=pf.prmlst[2].f1; f2<=pf.prmlst[2].f2; f2+=pf.prmlst[2].f3) {
            pf.parms[pf.prmlst[0].n]=f0;
            pf.parms[pf.prmlst[1].n]=f1;
            pf.parms[pf.prmlst[2].n]=f2;
            OptBlock;
        }}}
        break;
      case 4:	// optimize four parameters
        for(f0=pf.prmlst[0].f1; f0<=pf.prmlst[0].f2; f0+=pf.prmlst[0].f3) {
        for(f1=pf.prmlst[1].f1; f1<=pf.prmlst[1].f2; f1+=pf.prmlst[1].f3) {
        for(f2=pf.prmlst[2].f1; f2<=pf.prmlst[2].f2; f2+=pf.prmlst[2].f3) {
        for(f3=pf.prmlst[3].f1; f3<=pf.prmlst[3].f2; f3+=pf.prmlst[3].f3) {
            pf.parms[pf.prmlst[0].n]=f0;
            pf.parms[pf.prmlst[1].n]=f1;
            pf.parms[pf.prmlst[2].n]=f2;
            pf.parms[pf.prmlst[3].n]=f3;
            OptBlock;
        }}}}
        break;
      default:	// handle error condition
        ftlerr("optimize_manual: invalid np");
    }
    MOPT_END:;
    memcpy(pf.parms, bprm, sizeof(bprm));    // save best parameters

    // undefine local code block macro
    #undef OptBlock

    // run out-of-sample verification using best parameters
    run_system(pf);
    wroptln(fil, pf, 2);             // save out-of-sample results
    wroptln(stdout, pf, 2);          // show out-of-sample results
    
    // return with completion code
    return(rc);
}

static long optimize_genetic (FILE *fil, PORTFOLIO &pf, long np) {

    // Performs portfolio-wide genetic optimization.
    // fil     - output file for optimization data
    // pf      - portfolio (application) data structure
    // np      - number of parameters to optimize
    // return  - 0=CompleteRun, 1=KilledByUser    

    static float bprm[MAXPRM], *pfit;
    static long gen, i, isdup, rc;
    static GENOPT go;
    #define MINFIT (-999999.0)

    // set up genetic optimizer
    rc= 0;
    fprintf(stdout,"Initializing genetic optimizer...\n");
    fflush(stdout);
    go.setup(np, 30*np);  // set population 30 times parameter count
    go.randomize(1234);
    go.mutation(0.2);
    go.algorithm(GONORMAL);
    go.differential(0.2);
    go.crossover(0.3);
    go.chunk(1);
    for(i=0; i<np; i++) go.scale(i, pf.prmlst[i].f1, pf.prmlst[i].f2);

    // do in-sample optimization
    fprintf(stdout,"Genetically optimizing portfolio...\n");
    fflush(stdout);
    wroptln(fil, pf, 0);                       // write header line to disk
    if(pf.noptlnflag) wroptln(stdout, pf, 0);  // display it on screen
    pfit=(float*)pff_malloc(sizeof(float)*pf.maxgen);
    for(i=0; i<pf.maxgen; i++) pfit[i]=MINFIT;
    gen=0;
    while(gen<pf.maxgen) {
        if(kb_hit()) { 			// allow user to interrupt
            if(kb_getch_w() == 'Q') {	// by typing uppercase Q
                rc= 1; 
                break; 
            }
        }
        go.receive_vector(bprm);
        for(i=0; i<np; i++)             // copy and round parameters
            pf.parms[pf.prmlst[i].n] =
                pf.prmlst[i].f3 * floor(0.5 + bprm[i] / pf.prmlst[i].f3);
        run_system(pf);
        if(pf.psi.trds<0.5) continue;
        pfit[gen]=pf.psi.fitness;
        for(isdup=FALSE, i=gen-1; i>=0 && i>=gen-500; i--) {
            if(pfit[i]==pf.psi.fitness) { isdup=TRUE; break; } }
        if(isdup==TRUE || pf.psi.trds<9.5) go.send_fitness(MINFIT);
        else go.send_fitness(pf.psi.fitness);
        if(isdup==FALSE && pf.psi.trds>3.5) wroptln(fil, pf, 1);
        if(pf.noptlnflag) wroptln(stdout, pf, 1);
        gen++;
    }
    free(pfit);
    go.mostfitvector(bprm);             // get best parameter set found
    for(i=0; i<np; i++)                 // copy and round parameters
        pf.parms[pf.prmlst[i].n] =
            pf.prmlst[i].f3 * floor(0.5 + bprm[i] / pf.prmlst[i].f3);

    // run out-of-sample verification using best parameters
    run_system(pf);
    wroptln(fil, pf, 2);                // save out-of-sample results
    wroptln(stdout, pf, 2);             // show out-of-sample results

    // close up and return
    go.clear();
    return(rc);
    #undef MINFIT
}

//---------------- Function to Parse and Execute Commands -------------------

static long execute_command (PORTFOLIO &pf, char *cmdln) {

    // Parses and executes trading model development commands.
    // pf       - portfolio (application) data structure
    // cmdln    - command line to parse and execute
    // return   - 0=Okay, 1=Error or User Kill, 2=Exit

    // local scratch variables
    static long rc, i, j, k, kk, mc;
    static float fv, f1;
    static char fn[256], tkrsym[256], buf[256];
    static FILE *fil;

    // define local macro functions
    #define error(a) {fprintf(stdout,(a)); fflush(stdout); return(1);}
    #define iscom(a) (1==sscanf(cmdln,"%s",buf) && strcmp(buf,a)==0)

    // process quit command (used to exit script or development shell)
    if(iscom("quit")) return(2);

    // process loadparms command (reads model parameters from file)
    else if(iscom("loadparms")) {
        rc=sscanf(cmdln+9,"%s",fn);
        if(rc==1 && strcmp(fn,"0")==0) {
            // clears all parameters when command argument is 0
            for(k=0; k<MAXPRM; k++) pf.parms[k]=0.0;
        }
        else if(rc==1 && (k=atol(fn))>=1 && k<=99 && strlen(fn)<=2) {
            // loads parameters from a PARMSET=NN block in the model
            // implementation file (tropsmod.c) when argument is NN
            for(kk=0; kk<MAXPRM; kk++) pf.parms[kk]=0.0;
            fil=fopen("tropsmod.c","rt");
            if(fil==NULL) error("File tropsmod.c not found!\n");
            kk=0; j=0;
            while(fgets(fn,256,fil)) {
                if(strncmp(fn,"PARMSET=",8)==0 && atol(fn+8)==k) j=1;
                else if (strncmp(fn,"**",2)==0) j=0;
                if(j==0 || strncmp(fn,"PARMSET=",8)==0) continue;
                if(sscanf(fn,"%ld %f",&i,&fv)!=2) {
                    fclose(fil);
                    error("Bad parameter data line!\n");
                }
                if(i<0 || i>=MAXPRM) {
                    fclose(fil);
                    error("Parameter index out-of-range!\n");
                }
                pf.parms[i]= fv;
                kk++;
            }
            fclose(fil);
            if(kk<1) error("No parameters found or read!\n");
        }
        else {
            // loads parameters from default or specified file
            fil=fopen((rc==1)?(fn):("parms.txt"),"rt");
            if(fil==NULL) error("Parameter file not found!\n");
            for(k=0; k<MAXPRM; k++) pf.parms[k]=0.0;
            for(k=0; k<MAXPRM; k++) {
                if(fgets(buf,sizeof(buf),fil)==NULL) break;
                rc=sscanf(buf,"%ld %f",&i,&fv);
                if(rc==0 || rc==EOF) break;
                else if(rc!=2 || i<0 || i>=MAXPRM) {
                    fclose(fil);
                    error("Parameter file bad or index out-of-range!\n");
                }
                pf.parms[i]=fv;
            }
            fclose(fil);
        }
        pf.prmloaded=TRUE;      // parameters loaded flag
        pf.nprmopt=0;           // parameter last set or optimized
    }

    // process saveparms command (saves model parameters to file)
    else if(iscom("saveparms")) {
        if(pf.prmloaded==FALSE) error("No parameters to save!\n");
        rc=sscanf(cmdln+9,"%s",fn);
        fil=fopen((rc==1)?(fn):("parms.txt"),"wt");
        if(fil==NULL) error("Cannot open file!\n");
        for(k=0; k<MAXPRM; k++) {
            if(pf.parms[k]==0.0) continue;
            fprintf(fil,"%5d %14.5f\n",(int)k,(float)pf.parms[k]);
        }
        fclose(fil);
    }

    // process loadportfolio command (opens primary market database)
    else if(iscom("loadportfolio")) {
        rc=sscanf(cmdln+13,"%ld %s",(long*)&k,(char*)fn);
        if(rc==EOF) {
            // clear all data, close all databases, and free memory
            // when command is issued without arguments
            pf.isdate=0; pf.osdate=0; pf.enddate=0;            
            read_portfolio(pf, 0, NULL);
            fprintf(stdout,"ALL OPEN DATABASES CLOSED\n");
        }
        else if(rc==2) {
            // open primary (and possibly supplemental) market database(s)
            // when command is given with mode (k) and database name (fn)
            // arguments
            read_portfolio(pf, k, fn);
            // display some database information
            fprintf(stdout, "NBAR: %d  NMKT: %d  NSER: %d  MODE: %d\n",
                (int)pf.nbar, (int)pf.nmkt, (int)pf.nser, (int)pf.pftype);
            fprintf(stdout, "FIRST BAR: %8d.%06d  LAST BAR: %8d.%06d\n",
                (int)pf.ldt[0], (int)pf.ltm[0], 
                (int)pf.ldt[pf.nbar-1], (int)pf.ltm[pf.nbar-1] );
            if(pf.nbar<50) ftlerr("Too few bars in primary database\n");
            // set and display default sampling dates
            pf.isdate=pf.ldt[MAXLBK];			// in-sample begin
            pf.osdate=pf.ldt[(MAXLBK+2*(pf.nbar-7))/3];	// out-sample begin
            pf.enddate=pf.ldt[pf.nbar-2];		// out-sample end
            fprintf(stdout,"ISDATE: %d  OSDATE: %d  ENDDATE: %d\n",
                (int)pf.isdate, (int)pf.osdate, (int)pf.enddate );
        }
        else { error("Invalid command syntax!\n"); }
    }

    // process loadrfi command (loads interest rate data)
    else if(iscom("loadrfi")) {
        if(pf.pfloaded==FALSE) error("Requires loaded primary database");
        rc=sscanf(cmdln+7,"%s",(char*)fn);
        if(pf.rfi) { free(pf.rfi); pf.rfi=NULL; }
        if(rc==1) {
            pf.rfi=(float*)pff_malloc(sizeof(float)*pf.nbar);
            for(k=0; k<pf.nbar; k++) pf.rfi[k]=0.0;
            bsrdrfi(fn, pf.nbar, pf.ldt, pf.rfi);
        }
    }

    // process loadoptions command (opens stock options database)
    else if(iscom("loadoptions")) {
        // If no command argument is given, any currently open options
        // database is closed; if a database name is given, then any
        // open database is closed and the specified database opened.    
        if(pf.pfloaded==FALSE) error("Requires loaded primary database");    
        rc=sscanf(cmdln+11,"%s",(char*)fn);
        // deallocate dependent data series and clear some variables
        if(pf.ioptb) { free(pf.ioptb); pf.ioptb=NULL; }
        if(pf.ioptm) { free(pf.ioptm); pf.ioptm=NULL; }
        pf.idodbfile=0;		// clear file instance identifier
        strcpy(pf.odbfn,"");	// clear file name string
        // close any open options database
        if(pf.odb) {
            odb_close(pf.odb); pf.odb=NULL;
            fprintf(stdout,"PREVIOUSLY OPENED OPTION DATABASE CLOSED\n");
        }
        // open a new options database
        if(rc==1) {
            // open options database
            pf.odb=odb_open(fn, 0);
            if(pf.odb==NULL) error("Cannot open options database!\n");
            strcpy(pf.odbfn, fn);  // copy database filename
            // create mapping arrays
            fprintf(stdout,"BUILDING MAPPING ARRAYS\n");
            fflush(stdout);
            #if 1 == 0
                // this code will not work well with intraday data;
                // anyhow, inverse maps are not generally used,
                // hence 1 == 0
                for(k=0; k<odb_nday(pf.odb); k++) {
                    j=odb_date(pf.odb,k);
                    for(i=0, mc= -1; i<pf.nbar; i++) {
                        if(pf.dt[i]==j) {
                            mc=i;
                            break;
                        }
                    }
                    // array maps option iday to stock ibar (or -1)
                    pf.istkb[k]=mc;
                }
                for(k=0; k<odb_nstk(pf.odb); k++) {
                    mc=symbol_to_index(pf, odb_usym(pf.odb, k));
                    // array maps option istk to stock imkt (or -1)
                    pf.istkm[k]=mc;
                }
            #endif
            pf.ioptb=(long*)pff_malloc(sizeof(long)*pf.nbar);
            pf.ioptm=(long*)pff_malloc(sizeof(long)*pf.nmkt);
            for(k=0; k<pf.nbar; k++) {
                mc=odb_dayno(pf.odb, pf.ldt[k]);
                // array maps stock ibar to option iday (or -1)
                pf.ioptb[k]=mc;
            }
            pf.mktselected= -1;
            for(k=0; k<pf.nmkt; k++) {
                pff_seeksymbol(pf.pff, k);
                mc=odb_stkno(pf.odb, pf.pff->symbol);
                // array maps stock imkt to option istk (or -1)
                pf.ioptm[k]=mc;
            }
            fprintf(stdout,"OPTION DATABASE OPENED: FIRST: %d  LAST: %d\n",
                (int)(odb_date(pf.odb,0)),
                (int)(odb_date(pf.odb,odb_nday(pf.odb)-1)) );
            // create unique file instance identifier
            if((pf.idodbfile=rand())==0) pf.idodbfile=123983;
        }
    }

    // process setdates command (sets in-sample and out-of-sample dates)
    else if(iscom("setdates")) {
        if(pf.pfloaded==FALSE) error("Requires open primary database!\n");
        rc=sscanf(cmdln+8,"%ld %ld %ld",(long*)&i,(long*)&j,(long*)&k);
        // no arguments given, so merely display currently set dates
        if(rc==0 || rc==EOF) goto LDTDISP;        
        if(rc!=3) error("Invalid command syntax!\n");
        // arguments given, so set dates and then display them
        if(i>=j || j>=k) {
            fprintf(stdout, "Invalid dates or date sequence given!\n");
            fprintf(stdout, "Current unchanged values shown below\n");
            goto LDTDISP;
        }
        pf.isdate=i;  pf.osdate=j;  pf.enddate=k;
        LDTDISP:
        fprintf(stdout,"ISDATE: %d  OSDATE: %d  ENDDATE: %d\n",
            (int)pf.isdate, (int)pf.osdate, (int)pf.enddate );
    }

    // process explicit set command (sets model parameters)
    else if(iscom("set")) {
        for(k=i=0; cmdln[i]; i++) if(cmdln[i]=='=') k++;
        rc=sscanf(cmdln+3," p%ld=%f p%ld=%f p%ld=%f p%ld=%f p%ld=%f p%ld=%f",
            &pf.prmlst[0].n, &pf.prmlst[0].f1,
            &pf.prmlst[1].n, &pf.prmlst[1].f1,
            &pf.prmlst[2].n, &pf.prmlst[2].f1,
            &pf.prmlst[3].n, &pf.prmlst[3].f1,
            &pf.prmlst[4].n, &pf.prmlst[4].f1,
            &pf.prmlst[5].n, &pf.prmlst[5].f1 );
        if(k==0 || rc!=2*k) error("Command syntax error!\n");
        for(i=0; i<k; i++) {
            if(pf.prmlst[i].n<0 || pf.prmlst[i].n>MAXPRM-1)
                error("Out-of-range parameter index!\n");
            pf.parms[pf.prmlst[i].n]=pf.prmlst[i].f1;
        }
        pf.nprmopt=k;           // count of parameters set
        pf.prmloaded=TRUE;      // parameters loaded flag
    }

    // process implicit set command (sets parameters with fewer keystrokes)
    else if(sscanf(cmdln," p%ld=%f",(long*)&k,(float*)&f1)==2) {
        for(k=i=0; cmdln[i]; i++) if(cmdln[i]=='=') k++;
        rc=sscanf(cmdln+0," p%ld=%f p%ld=%f p%ld=%f p%ld=%f p%ld=%f p%ld=%f",
            &pf.prmlst[0].n, &pf.prmlst[0].f1,
            &pf.prmlst[1].n, &pf.prmlst[1].f1,
            &pf.prmlst[2].n, &pf.prmlst[2].f1,
            &pf.prmlst[3].n, &pf.prmlst[3].f1,
            &pf.prmlst[4].n, &pf.prmlst[4].f1,
            &pf.prmlst[5].n, &pf.prmlst[5].f1 );
        if(k==0 || rc!=2*k) error("Command syntax error!\n");
        for(i=0; i<k; i++) {
            if(pf.prmlst[i].n<0 || pf.prmlst[i].n>MAXPRM-1)
                error("Out-of-range parameter index!\n");
            pf.parms[pf.prmlst[i].n]=pf.prmlst[i].f1;
        }
        pf.nprmopt=k;           // count of parameters set
        pf.prmloaded=TRUE;
    }

    // process setrange command (sets range of parameters to single value)
    else if(iscom("setrange")) {
        rc=sscanf(cmdln+8," p%ld-p%ld=%f",&i,&j,&fv);
        if(rc!=3) error("Command syntax error!\n");
        for(k=i; k<=j; k++) {
            if(k>=0 && k<MAXPRM) pf.parms[k]=fv;
        }    
    }

    // process show command (shows model parameters and other data)
    else if(iscom("show")) {
        rc=sscanf(cmdln+4,"%s",(char*)fn);
        if(rc==1) {
            fil=fopen(fn,"wt");
            if(fil==NULL) { error("Cannot open output file!\n"); }
        } else fil=stdout;
        fprintf(fil,"NBAR: %d  NMKT: %d  NSER: %d  TYPE: %d\n",
            (int)pf.nbar,(int)pf.nmkt,(int)pf.nser,(int)pf.pftype);
        fprintf(stdout, "FIRST BAR: %8d.%06d  LAST BAR: %8d.%06d\n",
            (int)pf.ldt[0], (int)pf.ltm[0], 
            (int)pf.ldt[pf.nbar-1], (int)pf.ltm[pf.nbar-1] );            
        fprintf(fil,"PFFFN: %s\nODBFN: %s\n",
            (char*)pf.pfffn,(char*)pf.odbfn);
        for(k=0; k<15; k++) {
            for(i=k; i<MAXPRM; i+=15)
                fprintf(fil,"%4d %10.3f   ",(int)i,(float)pf.parms[i]);
            fprintf(fil,"\n");
        }
        if(rc==1) fclose(fil);
        else fflush(fil);
    }

    // process dq command (draws equity curve using ASCII characters)
    else if(iscom("dq")) {
        rc=sscanf(cmdln+2,"%s",(char*)fn);
        if(rc==1) {
            fil=fopen(fn,"wt");
            if(fil==NULL) { error("Cannot open output file!\n"); }
        } else fil=stdout;
        draw_equity(fil,pf);
        if(rc==1) fclose(fil);
        else fflush(fil);
    }
    
    // process sum command (writes system performance summary)
    else if(iscom("sum")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        rc=sscanf(cmdln+3,"%s",(char*)fn);
        if(rc==1) {
            if(strcmp(fn,"-l")==0) {
                // write extended summary directly to screen
                write_summary(stdout, pf, 1);
            }
            else if(strcmp(fn,"-p")==0) {
                // pipe extended summary to pager (I like "less")
                #if 1==1
                    // Alternative access to pager without pipes that
                    // does not require disabling "broken pipe" signals
                    if((fil=fopen("pagersum.tmp","wt"))==NULL)
                        error("Cannot write output for pager!\n");
                    write_summary(fil, pf, 1);
                    fclose(fil);
                    if(system("less -c pagersum.tmp")) {
                        fprintf(stdout,"Pager or data not found!\n");
                        fflush(stdout);
                    }
                    remove("pagersum.tmp");
                #endif
                #if 1==0
                    // send data to pager through a pipe
                    // be sure to  #include <signal.h>
                    signal(SIGPIPE, SIG_IGN);
                    if((fil=popen("less -c","w"))==NULL)
                        error("Cannot pipe output to pager!\n");
                    write_summary(fil, pf, 1);
                    pclose(fil);
                    signal(SIGPIPE, SIG_DFL);
                #endif
            }
            else if(fn[0] != '-') {
                // write extended summary to file
                if((fil=fopen(fn,"wt"))==NULL)
                    error("Cannot open output file!\n");
                write_summary(fil, pf, 1);
                fclose(fil);
            }
            else { error("Invalid argument in command!\n"); }
        }
        // write basic (short) summary to screen
        else write_summary(stdout, pf, 0);        
    }

    // process maxgen command (sets maximum number of generations)
    else if(iscom("maxgen")) {
        rc=sscanf(cmdln+6,"%ld",(long*)&k);
        if(rc!=1) error("Invalid command syntax!\n");
        pf.maxgen=k;
    }

    // process mopt command (manual optimization)
    else if(iscom("mopt")) {
        if(pf.pfloaded==FALSE) error("Requires open primary database!\n");
        for(k=i=0; cmdln[i]; i++) if(cmdln[i]=='=') k++;
        rc=sscanf(cmdln+4,
            " p%ld=%f,%f,%f p%ld=%f,%f,%f p%ld=%f,%f,%f p%ld=%f,%f,%f",
            &pf.prmlst[0].n, &pf.prmlst[0].f1,
                &pf.prmlst[0].f2, &pf.prmlst[0].f3,
            &pf.prmlst[1].n, &pf.prmlst[1].f1,
                &pf.prmlst[1].f2, &pf.prmlst[1].f3,
            &pf.prmlst[2].n, &pf.prmlst[2].f1,
                &pf.prmlst[2].f2, &pf.prmlst[2].f3,
            &pf.prmlst[3].n, &pf.prmlst[3].f1,
                &pf.prmlst[3].f2, &pf.prmlst[3].f3 );
        if(rc!=4*k && rc>=0) error("Syntax error!\n");
        for(i=0; i<k; i++) {
            if(pf.prmlst[i].n<0 || pf.prmlst[i].n>MAXPRM-1)
                error("Out-of-range parameter index!\n"); }
        fil=fopen("mopt.txt", "wt");
        if(fil==NULL) error("Cannot open optimization output file!\n");
        pf.nprmopt=k;           // count of parameters optimized
        rc= optimize_manual(fil, pf, k);
        fclose(fil);
        pf.prmloaded=TRUE;
        if(rc != 0) error("Optimization killed by user!\n");
    }

    // process gopt command (performs genetic parameter optimization)
    else if(iscom("gopt")) {
        if(pf.pfloaded==FALSE) error("Requires open primary database!\n");
        for(k=i=0; cmdln[i]; i++) if(cmdln[i]=='=') k++;
        rc=sscanf(cmdln+4,
            " p%ld=%f,%f,%f p%ld=%f,%f,%f p%ld=%f,%f,%f p%ld=%f,%f,%f",
            &pf.prmlst[0].n, &pf.prmlst[0].f1,
                &pf.prmlst[0].f2, &pf.prmlst[0].f3,
            &pf.prmlst[1].n, &pf.prmlst[1].f1,
                &pf.prmlst[1].f2, &pf.prmlst[1].f3,
            &pf.prmlst[2].n, &pf.prmlst[2].f1,
                &pf.prmlst[2].f2, &pf.prmlst[2].f3,
            &pf.prmlst[3].n, &pf.prmlst[3].f1,
                &pf.prmlst[3].f2, &pf.prmlst[3].f3 );
        if(k==0 || rc!=4*k) error("Command syntax error!\n");
        for(i=0; i<k; i++) {
            if(pf.prmlst[i].n<0 || pf.prmlst[i].n>MAXPRM-1)
                error("Out-of-range parameter index!\n"); }
        fil=fopen("mopt.txt", "wt");
        if(fil==NULL) error("Cannot open optimization output file!\n");
        pf.nprmopt=k;           // count of parameters optimized
        rc=optimize_genetic(fil, pf, k);
        fclose(fil);
        pf.prmloaded=TRUE;
        if(rc!=0) error("Optimization killed by user!\n");
    }
    
    // process optline command (turns on or off line-by-line display)
    else if(iscom("optline")) {
        if(sscanf(cmdln+7,"%s",(char*)fn)==1) {
            if(strcmp(struprcas(fn),"ON")==0) pf.noptlnflag=TRUE;
            if(strcmp(fn,"OFF")==0) pf.noptlnflag=FALSE;
        }
        if(pf.noptlnflag==TRUE) fprintf(stdout,"OPTLINES ON\n");
        else fprintf(stdout,"OPTLINES OFF\n");
    }

    // process sop command (displays optimization results in pager)
    else if(iscom("sop")) {
        fil=fopen("mopt.txt","rt");
        if(fil==NULL) error("No optimization data to display!\n");
        fclose(fil);
        rc=sscanf(cmdln+3,"%s",(char*)fn);
        // display unsorted optimization data when no arguments are given
        if(rc!=1) system("less -S -#4 -c mopt.txt");
        else {
            // arguments to sop command specify sorting options
            if(strcmp(fn,"-ri")==0)		// sorted by in-samp r
                system("sort -k 1,1 -k 11,11nr mopt.txt | less -S -#4 -c");
            else if (strcmp(fn,"-ro")==0)	// sorted by out-samp r
                system("sort -k 1,1 -k 12,12nr mopt.txt | less -S -#4 -c");
            else if (strcmp(fn,"-pr")==0)	// sorted by in-samp prob
                system("sort -k 1,1 -k 5,5n mopt.txt | less -S -#4 -c");
            else { error("Invalid syntax!\n"); } 
        }
    }

    // process trades command (writes system trade-by-trade data)
    else if(iscom("trades")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        if(pf.ntrd==0) error("There are no trades to write!\n");
        rc=sscanf(cmdln+6,"%s",(char*)fn);
        // ***** add capability of viewing trades in pager
        fil=fopen((rc==1)?(fn):("trds.txt"),"wt");
        if(fil==NULL) error("Cannot open output file!\n");
        // ***** add some additional info to file, such as database
        //       file name and parameter values, with # in first field
        //       so utilities can treat the additional data as distinct
        //       from the trade data
        fprintf(fil,"# %5s %6s %6s %6s %12s %12s %6s %6s %6s %6s %9s\n",
            "INDX","SYMB","SHRS","HELD","ENPR","EXPR","ENDT",
            "ENTM","EXDT","EXTM","PL");
        for(i=0; i<pf.ntrd; i++) {
            TRADE &trdi = pf.trd[i];
            pf.mktselected= -1;
            pff_seeksymbol(pf.pff, trdi.imkt);
            strncpy(tkrsym, pf.pff->symbol, 6);
            tkrsym[6]=0;
            fprintf(fil,"D %5d %6s %6d %6d %12.5f %12.5f "
                    "%06d %06d %06d %06d %9d",
                (int)trdi.imkt,
                (char*)tkrsym,
                (int)trdi.nshr,
                (int)(trdi.iexitbar-trdi.ientrybar+1),
                (float)(trdi.entryvalue/trdi.nshr),
                (float)(trdi.clsvalue[trdi.iexitbar-trdi.ientrybar]
                        / trdi.nshr),
                (int)(pf.ldt[trdi.ientrybar] % 1000000),
                (int)pf.ltm[trdi.ientrybar],
                (int)(pf.ldt[trdi.iexitbar] % 1000000),
                (int)pf.ltm[trdi.iexitbar],
                (int)(trdi.clsvalue[trdi.iexitbar-trdi.ientrybar]
                        - trdi.entryvalue)
            );
            #define WRITETRADEBARS TRUE
            #if WRITETRADEBARS == TRUE
                fprintf(fil,"  I ");
                for(k=0; k<trdi.iexitbar-trdi.ientrybar+1; k++)
                    fprintf(fil,"%6d",(int)trdi.clsvalue[k]);
            #endif
            #undef WRITETRADEBARS
            fprintf(fil,"\n");
        }
        fclose(fil);
    }

    // process wreqty command (writes daily equity data)
    else if(iscom("wreqty")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        if(pf.ntrd==0) error("No trades, hence no equity curve!\n");
        rc=sscanf(cmdln+6,"%s",(char*)fn);
        // ***** add capability for display in pager
        fil=fopen((rc==1)?(fn):("eqty.txt"),"wt");
        if(fil==NULL) error("Cannot open equity output file!\n");
        fprintf(fil,"%8s %6s %5s %12s %10s\n",
            "DATE","TIME","SAMP","EQTY","NPOS");
        for(i=0; i<pf.nbar; i++) {
            if(pf.ldt[i]<pf.isdate) rc=0;	    // pre-in-sample
            else if(pf.ldt[i]<=pf.osdate) rc=1; // in-sample
            else if(pf.ldt[i]<=pf.enddate) rc=2;// out-of-sample
            else rc=3;				            // post-out-of-sample
            fprintf(fil,"%08d %06d %5d %12.2f %10d\n",
                (int)pf.ldt[i],			        // date
                (int)pf.ltm[i],			        // time
                (int)rc,			            // sample
                (float)pf.eqcls[i],		        // equity
                (int)pf.poscnt[i] );		    // position count
        }
        fclose(fil);
    }

    // process wrdata command (writes raw data for specific symbol)
    else if(iscom("wrdata")) {
        char *pricefmt[2]={ (char*)"%10.2f %10.2f %10.2f %10.2f ",
                            (char*)"%10.5f %10.5f %10.5f %10.5f " };
        if(pf.pfloaded==FALSE) error("Requires loaded portfolio!\n");
        kk=sscanf(cmdln+6,"%s %s",(char*)tkrsym,(char*)fn);
        if(kk<1 || kk>2) error("Syntax error!\n");
        if((k=symbol_to_index(pf,struprcas(tkrsym)))<0)
            error("Symbol not found!\n");
        select_market(pf, k);
        if((fil=fopen(((kk==1)?("wrdata.txt"):(strcmp(fn,"-p")==0)?
            ("pagerraw.tmp"):(fn)),"wt"))==NULL)
                error("Cannot open output file!\n");
        for(fv=0.0, k=0; k<pf.nbar; k++) {
            if(pf.cls[k]>fv) fv=pf.cls[k]; }
        j=((fv>9.99)?(0):(1));
        for(k=0; k<pf.nbar; k++) {
            fprintf(fil, "%8d %08d %06d ",
                (int)k, (int)pf.ldt[k], (int)pf.ltm[k] );
            fprintf(fil, pricefmt[j],
                (float)pf.opn[k], (float)pf.hi[k],
                (float)pf.lo[k], (float)pf.cls[k] );
            fprintf(fil, "%12.0f %10.0f %9.3f %1d %2d %2d ",
                (float)(pf.vol[k]), (float)((pf.oi)?(pf.oi[k]):(0.0)),
                (float)pf.sf[k],
                (int)dayofweek(pf.ldt[k]),
                (int)(datetoser(nthned(pf.ldt[k],1))-datetoser(pf.ldt[k])),
                (int)(datetoser(nthned(pf.ldt[k],2))-datetoser(pf.ldt[k])));
            if((pf.pftype & PFF_SUPPDATA_BIT) != 0) {
                fprintf(fil, "%10.2f %10.2f %10.2f %10.2f",
                    (float)pf.suppa[k], (float)pf.suppb[k],
                    (float)pf.suppc[k], (float)pf.suppd[k] );
            }
            fprintf(fil,"\n");
        }
        fclose(fil);
        if(kk==2 && strcmp(fn,"-p")==0) {
            if(system((char*)"less -S -#8 -c pagerraw.tmp")) {
                fprintf(stdout,(char*)"Pager or data not found!\n");
                fflush(stdout);
            }        
            remove("pagerraw.tmp");
        }
    }
    
    // process dsym command (displays symbols and names for markets)
    else if(iscom("dsym")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        rc=sscanf(cmdln+4,"%ld,%ld",&k,&kk);
        if(rc<1 || rc>2) error("Invalid command syntax!\n");
        if(rc==1) {
            // display a single symbol given the market index
            if(k<0 || k>=pf.nmkt) 
                error("Index specified is out-of-range!\n");
            select_market(pf, k);
            fprintf(stdout,"SYMBOL: %6ld %8s  %s\n",
                (long)k, (char*)pf.sym, (char*)pf.nam);
        }
        else {        
            // display and write all symbols (markets) selected by the
            // contents of a specifed range of parameter registers
            if(k<0 || kk>=MAXPRM || kk<k)
                error("Parameters specified are out-of-range!\n");
            fil=fopen("dsym.txt","at");
            if(fil==NULL) error("Cannot open symbol list file!\n");
            fprintf(fil,"\n");
            for(i=k; i<=kk; i++) {
                if((j=((long)(0.5+pf.parms[i]))-1)<0) continue;
                select_market(pf, j);
                fprintf(stdout,"SYMBOL: %6ld %8s  %s\n",
                    (long)j, (char*)pf.sym, (char*)pf.nam);
                fprintf(fil,"SYMBOL: %6ld %8s  %s\n",
                    (long)j, (char*)pf.sym, (char*)pf.nam);                    
            }
            fclose(fil);
        }
    }    

    // process run command (runs system on portfolio)
    else if(iscom("run")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        run_system(pf);
        wroptln(stdout, pf, 0);         // header line
        wroptln(stdout, pf, 1);         // in-sample performance
        wroptln(stdout, pf, 2);         // out-of-sample performance
    }

    // abbeviated (fewer keystrokes) run command (runs system on portfolio)
    else if(iscom("r")) {
        if(pf.pfloaded==FALSE || pf.prmloaded==FALSE)
            error("Requires loaded portfolio and parameters!\n");
        run_system(pf);
        wroptln(stdout, pf, 0);         // header line
        wroptln(stdout, pf, 1);         // in-sample performance
        wroptln(stdout, pf, 2);         // out-of-sample performance
    }

    // process index command (display market index for given symbol)
    else if(iscom("index")) {
        if(pf.pfloaded==FALSE) error("Requires loaded portfolio!\n");
        if(sscanf(cmdln+5,"%s",(char*)fn)!=1) error("Syntax error!\n");
        if((rc=symbol_to_index(pf, struprcas(fn)))<0) {
            sprintf(buf,"Symbol not found: %s\n",(char*)fn);
            error(buf);
        }
        else {
            select_market(pf, rc);
            fprintf(stdout,"MARKET SELECTED: SYMBOL= %s INDEX= %d\n",
                (char*)pf.sym, (int)pf.mktselected);
        }
    }
    
    // process all graphics commands (using code in tropsgx.c)
    else if(cmdln[0]=='x') {	// first command character is always 'x'
        // the xinit and xfree commands are for internal use only and
        // should never be issued by the user
        if(strcmp(cmdln,"xinit")==0 || strcmp(cmdln,"xfree")==0)
            error("Invalid graphics command!\n");
        // the user may issue the xclose command to close all graphics
        // windows and re-initialize the graphics subsystem
        if(strcmp(cmdln,"xclose")==0) { xgr_execute(pf,cmdln); }
        else {
            // all other graphics commands are just passed to xgr_execute
            // to be acted upon by the graphics module command interpreter
            if(pf.pfloaded==FALSE) error("Requires loaded portfolio!\n");
            if(xgr_execute(pf,cmdln)!=0) error("Graphics command error!\n");
        }
    }

    // process manual command (displays user manual in pager)
    else if(iscom("man")) {
        if(system("less readme.txt"))
            error("Pager (less) or readme.txt not found!\n");
    }

    // process shell command (starts a BASH command shell)
    else if(iscom("shell")) {
        if(system("bash"))
            error("BASH shell returned error code or is not in path!\n");
    }
    
    // process shcmd command (runs a single shell command)
    else if(iscom("shcmd")) {
        if(sscanf(cmdln+5,"%s",(char*)fn)!=1) error("Syntax error!\n");
        if(system(cmdln+5)) error("Shell command returned error code!\n");    
    }

    // process help command (lists basic commands)
    else if(iscom("help")) {
      fprintf(stdout,
      "  help                 - Displays basic commands\n"
      "  mhelp                - Displays additional commands\n"
      "  xhelp                - Displays graphics commands\n"
      "  man                  - Displays user documentation\n"
      "  loadportfolio [m fn] - Loads or unloads primary securities data\n"
      "  loadrfi [fn]         - Loads or unloads interest rate data\n"
      "  loadoptions [fn]     - Opens or closes stock options database\n"
      "  saveparms [fn]       - Saves current parameter set\n"
      "  loadparms [fn | N]   - Loads previously saved parameter set\n"
      "  setdates [d1 d2 d3]  - Sets or shows sampling dates\n"
      "  show [fn]            - Displays current settings and parameters\n"
      "  [set] pN=V ...       - Sets parameter values\n"
      "  setrange pM-pN=V     - Sets parameter range to single value\n"
      "  run (or r)           - Runs system with current parameters\n"
      "  sum [fn | -p | -l]   - Writes performance summary\n"
      "  dq [fn]              - Draws equity curve to screen or file\n"
      "  index sym            - Displays index for a given symbol\n"
      "  dsym m[,n]           - Displays symbols\n"
      "  quit                 - Exits the application\n" );
    }

    // process mhelp command (lists additional commands)
    else if(iscom("mhelp")) {
      fprintf(stdout,    
      "  trades [fn]          - Writes trade-by-trade data\n"
      "  wreqty [fn]          - Writes equity data\n"
      "  wrdata sym [fn | -p] - Writes or displays raw market data\n"
      "  maxgen n             - Sets maximum number of generations\n"
      "  optline [on | off]   - Sets or shows console optline display\n"
      "  mopt pN=a,b,c ...    - Performs brute-force optimization\n"
      "  gopt pN=a,b,c ...    - Performs genetic optimization\n"
      "  sop [-ri | -pr]      - Displays optimization data\n"
      "  shell                - Starts a BASH shell\n"
      "  shcmd                - Processes a single shell command\n"
      "  runscript fn         - Runs a C-Trader script file\n" );
    }

    else { error("No such command!\n"); }  // handle non-existent command

    fflush(stdout);                     // flush screen output
    return(0);                          // normal (no error) return
    #undef iscom                        // undefine local macro
    #undef error                        // undefine local macro
}

//-------------------------- Main Entry Function ----------------------------

int main (int argc, char **args) {

    static PORTFOLIO *pf;		// global application data
    static long rc, k;			// return code and index variable
    static char cmdln[256], *pch;	// command line buffer
    static char fn[256];		// script file name
    static FILE *fil;			// script input file
    static float x;			// for floating point tests

    // verify compiler variable size assumptions
    rc=(sizeof(double)!=8 || sizeof(float)!=4 || sizeof(long)!=4
        || sizeof(int)!=4 || sizeof(short)!=2 || sizeof(char)!=1);
    if(rc) ftlerr("main: variable size assumptions not met");
    
    // verify pointer and floating point assumptions
    memset(&x, 0, sizeof(float));
    memset(&fil, 0, sizeof(FILE*));
    if(x!=0.0 || (int)(x=1234567.0)!=1234567 || (int)(x= -4567.0)!= -4567)
        ftlerr("main: floating point assumptions not met");
    if(fil!=NULL) ftlerr("main: pointer assumptions not met");
    
    // verify big-endian assumption (Intel byte ordering)
    rc=87+256*(95+256*256*54);
    pch=(char*)(&rc);
    if(pch[0]!=87 || pch[1]!=95 || pch[2]!=0 || pch[3]!=54)
        ftlerr("main: Intel byte ordering assumptions not met");
    
    // verify proper operation of psuedorandom number generator
    randtest();
    
    // allocate application data structure
    pf=(PORTFOLIO*)pff_malloc(sizeof(PORTFOLIO));

    // initialize application data structure
    pf->nbar=0;				// clear bar count
    pf->nmkt=0;				// clear ticker count
    pf->nser=0;				// clear series count
    pf->ntrd=0;				// clear trade count
    pf->isdate=0;			// clear in-sample start date
    pf->osdate=0;			// clear out-sample start date
    pf->enddate=0;			// clear out-sample end date
    pf->pftype=0;			// clear portfolio data type
    pf->pfloaded=FALSE;                 // clear data loaded flag
    pf->prmloaded=FALSE;                // clear parameters loaded flag
    pf->maxgen=175000;                  // set default maximum generations
    pf->nprmopt=0;                      // clear param. optimization count
    pf->noptlnflag=TRUE;		// set default optimization display
    for(k=0; k<MAXPRM; k++) 
        pf->parms[k]=0.0;		// clear parameters vector    
    strcpy(pf->odbfn, "");		// clear options database filename
    strcpy(pf->pfffn, "");		// clear primary database filename
    pf->mktselected= -1;                // clear market selection
    pf->idpfffile=0;			// clear unique pff file id
    pf->idodbfile=0;			// clear unique odb file id
    pf->odb=NULL;                       // clear options database pointer
    pf->pff=NULL;                       // clear primary database pointer
    pf->ldt=NULL;  pf->ltm=NULL;	// clear date and time pointers
    pf->opn=NULL;  pf->hi=NULL;		// clear primary data pointers
    pf->lo=NULL;  pf->cls=NULL;		// .. ditto
    pf->vol=NULL;  pf->oi=NULL;  	// .. ditto
    pf->sf=NULL;    			// .. ditto
    pf->suppa=NULL;  pf->suppb=NULL;	// .. ditto
    pf->suppc=NULL;  pf->suppd=NULL;	// .. ditto
    pf->ioptb=NULL;  pf->ioptm=NULL;	// clear option to stock map pointers
    pf->rfi=NULL;			// clear interest rates pointer
    pf->eqcls=NULL;			// clear equity curve pointer
    pf->poscnt=NULL;			// clear position counts pointer
    
    // initialize graphics module (tropsgx.c)
    xgr_execute(*pf, (char*)"xinit");

    // run initialization script (if one exists)
    fil=fopen("init.scr","rt");
    if(fil) {
        while(fgets(cmdln,sizeof(cmdln),fil)) {
            if((pch=strchr(cmdln,'!'))!=NULL) *pch=0; // remove comment
            if(strlen(strtrim(cmdln))==0) continue;   // handle empty line
            fprintf(stdout,"Trops-> %s\n",cmdln);     // display command
            fflush(stdout);
            rc=execute_command(*pf, cmdln);           // execute command
            if(rc==1 || rc==2) break;                 // error or quit
        }
        fclose(fil);
    }

    // get user commands
L1: fprintf(stdout,"Trops-> ");
    fflush(stdout);
    fgets(cmdln,sizeof(cmdln),stdin);
    if((pch=strchr(cmdln,'!'))!=NULL) *pch=0;    // remove comment
    if(strlen(strtrim(cmdln))==0) goto L1;       // handle empty line

    // intercept and process the runscript command
    if(strncmp(cmdln,"runscript",9)==0) {
        rc=sscanf(cmdln+9,"%s",(char*)fn);
        if(rc!=1) { fprintf(stdout,"Invalid command syntax!\n"); goto L1; }
        fil=fopen(fn,"rt");
        if(fil==NULL) { fprintf(stdout,"Script not found!\n"); goto L1; }
        while(fgets(cmdln,sizeof(cmdln),fil)) {
            if((pch=strchr(cmdln,'!'))!=NULL) *pch=0; // remove comment
            if(strlen(strtrim(cmdln))==0) continue;   // handle empty line
            fprintf(stdout,"Trops-> %s\n",cmdln);
            fflush(stdout);
            rc= execute_command(*pf, cmdln);
            if(rc==1 || rc==2) break;	// error or "quit" command
        }
        fclose(fil);
        goto L1;                        // get next user command
    }

    // execute all other commands
    rc=execute_command(*pf, cmdln);
    if(rc==0 || rc==1) goto L1;         // get next user command
    if(rc==2) goto L2;                  // quit the program

    // close databases, free memory, and exit to shell
L2: xgr_execute(*pf, (char*)"xfree");	// close down graphics module
    read_portfolio(*pf, 0, NULL);  	// close databases and free memory
    free(pf);				// free application data structure
    return(EXIT_SUCCESS);
}


#ifndef TROPS_H
#define TROPS_H

/*
c  trops.h
c
c  Project header for trading optimization and simulation platform.
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2008.  All Rights Reserved.
c
c  Notes:
c    For access to primary and supplemental market data use the
c      pointers that are members of the PORTFOLIO structure along
c      with the function select_market().  Data series not present
c      in the database are marked by null pointers.
c    For access to options data use the option chain that is a member
c      of the PORTFOLIO structure together with the load_chain()
c      function, implemented in trops.c, or the odb_ family of functions
c      that are implemented in libodb.c.  Code in trops.c takes care of
c      opening and closing options databases, so no need exists to use
c      odb_open() or odb_close() in trading model code.
c    Prices and volumes for stocks are usually provided in split (and 
c      possibly dividend) corrected form.  To obtain the original,
c      uncorrected prices, multiply the corrected prices by the split
c      factors in pf.sf[]; to obtain the original volumes, divide the
c      corrected volumes by the same split factors.  For futures and
c      other securities, consult the database documentation.
c
c
c   CTraderPro datatypes:
c
c   939308		libpff.c	end-of-day stock data
c   939309		libpff.c	intraday stock data
c   939310		libpff.c	end-of-day futures data
c   939311		libpff.c	intraday futures data
c   939329		libpff.c	supplemental files containing option implied volatility, earnings, and/or other kinds of data that are bar-aligned with the primary database.
c   393337		libodb.h	compressed options
c   939338		libodb.h	compressed options index file type.
c
c
c   For a quick test of operation, Here are the steps:
c
c   Preps:
c   make sure you have the data in the c:/mktdata directory
c   make sure you build the project, using debug or release
c   make sure you copy the trops.exe file over to the main directory, the tropic root directory.
c
c   Goto the c:/tropic directory, and type in these commands (in CMake Powershell):
c   ./trops
c   run
c   sum
c   dq
c   (if using graphic mode):
c   xbars def  (to setup the bars)
c   xdq (to run the equity plot)
c   xscan (to display the chart)
c
c   Note: after you run xscan, if you go back to the command prompt, you will see that you are hang in the
c         command prompt, just key 'q' at the freeze screen
c
c   If you build in the debug mode, you can use vs code's debug facility to debug
c   All you have to do is setup a launch.json file
c
c   For debugging, do this:
c   Go to the run menu and select Add configuration ... pick any default (here you just want to launch the launch.json file)
c   When you see the launch.json file, click Add configuration again at the bottom
c   choose C:/C++: (Windows) Launch
c   edit the "program tag", just enter the correct path to the trops.exe file
c
  Revised 2008.07.15
*/

#include "libodb.h"							// options database header file
#define OPTDB ODBFILE						// alternative (shorter) database reference
#define OPTCH ODBCHAIN					// alternative (shorter) chain reference

#include "libpff.h"							// primary (stocks, futures) database header
#define PFFDB PORTFOLIODATA			// alternative (shorter) database reference
#define PFFBUFSZ     1200000		// database supplemental data buffer size

#define MAXLBK       52					// max. bars lookback (first tradable bar)
#define MAXPRM       48					// max. model parameters
#define MAXPCB       7					// max. parameter control blocks
#define MAXTRD       62500			// max. round turn trades
#define MAXHLD       2200				// max. in-trade bars (holding period)
#define MAXTRP       500000			// max. allocation pool for trade data
#define MAXEXD       2					// max. trade-specific extra data values

struct TRADE {									// basic data for each completed round turn
    long     imkt;							// index of market traded, 0..pf.nmkt-1
    long     ientrybar;					// bar trade entered, 0..pf.nbar-1
    long     iexitbar;					// bar trade exited, 0..pf.nbar-1
    long     nshr;							// shares or contracts, + or -
    float    entryvalue;				// position value at trade entry
    float    *clsvalue;					// position value as of each bar's close
    float    exdat[MAXEXD];			// extra data associated with trade
};

struct STATS {									// basic portfolio performance statistics
    // computed from equity data in its native timeframe
    float    rbrdraw;						// maximum drawdown
    float    rbrnet;						// net profit based on equity curve
    float    rbraroa;						// annualized return (vis-a-vis drawdown)
    float    rbrbars;						// sample bar count
    float    rbrbarsm;					// sample market-exposed bar count
    float    rbrsharp;					// native timeframe Sharpe ratio
    float    rbrsharpm;					// market-exposed Sharpe ratio
    float    rvalue;						// equity correlation with straight line
    // computed from end-of-day equity data, native or derived
    float    aroa;							// annualized return (vis-a-vis drawdown)
    float    sharpe;						// daily Sharpe ratio (zero interest rate)
    float    sharpw;						// weekly Sharpe ratio (zero interest rate)
    float    sharpm;						// market-exposed Sharpe ratio
    float    prob;							// risk-to-reward significance (t test)
    float    neteq;							// net profit based on equity curve
    float    barcnt;						// sample bar count
    float    draw;							// maximum drawdown
    float    winpct;						// percent winning weeks
    float    asim;							// average simultaneous positions
    float    maxsim;						// maximum simultaneous positions
    // computed directly from simulated trades
    float    trds;							// number of trades
    float    wins;							// number of winners
    float    losses;						// number of losers
    float    avgtrd;						// average trade in dollars
    float    stdtrd;						// standard deviation in dollars
    float    avgwin;						// average winner in dollars
    float    avgloss;						// average loser in dollars
    float    bigwin;						// biggest winner
    float    bigloss;						// biggest loser
    float    ahld;							// average holding period
    float    maxhld;						// maximum holding period
    float    net;								// net profit based on trades
    // computed from statistics chosen by the user
    float    fitness;						// measure of overall solution quality
};

struct PRMLIST {								// parameter optimization control data
    long     n;									// parameter number, 0..MAXPRM-1
    float    f1, f2, f3;				// parameter start, stop, step values
};

struct PORTFOLIO {							// master application data structure
    long     nmkt;							// number of markets or securities
    long     nbar;							// number of bars or data points
    long     nser;							// number of series in primary data
    long     ntrd;							// number of trades taken
    long     isdate;						// in-sample start date, YYYYMMDD
    long     osdate;						// out-of-sample start date, YYYYMMDD
    long     enddate;						// out-of-sample stop date, YYYYMMDD
    long     pftype;						// primary data series type (see libpff.h)
    long     pfloaded;					// primary data series loaded flag
    long     prmloaded;					// parameters loaded flag
    long     maxgen;						// maximum generation count
    long     nprmopt;						// number of parms in last optimization
    long     noptlnflag;				// console optimization display switch
    long     mktselected;				// market (security) currently selected
    long     idpfffile;					// unique primary dataset identifier
    long     idodbfile;					// unique option dataset identifier
    long     ktrdpool;					// index for trade data allocation pool
    long     *ldt;							// common (across markets) dates, YYYYMMDD
    long     *ltm;							// common (across markets) times, HHMMSS
    float    *rfi;							// risk free interest rates, 0.XXX
    float    *opn, *hi, *lo;		// pointers used to access data series
    float    *cls, *vol, *sf;		// ... ditto
    float    *oi;								// ... ditto
    char     *sym, *nam;				// pointers for security symbol and name
    float    *suppa, *suppb;		// pointers used for supplemental data
    float    *suppc, *suppd;		// ... ditto
    long     *ioptb;						// maps stock ibar to options iday (or -1)
    long     *ioptm;						// maps stock imkt to options istk (or -1)
    float    *eqcls;						// portfolio equity-at-close series
    float    *poscnt;						// number of open positions on each bar    
    PFFDB    *pff;							// portfolio database pointer
    OPTDB    *odb;							// options database pointer
    STATS    psi;								// in-sample performance statistics
    STATS    pso;								// out-of-sample performance statistics
    float    parms[MAXPRM];			// global model parameters
    PRMLIST  prmlst[MAXPCB];		// parameter optimization control blocks
    TRADE    trd[MAXTRD];				// data for each round turn trade
    float    trdpool[MAXTRP];		// allocation pool for trade data
    char     pfffn[256];				// primary market database file name
    char     odbfn[256];				// options database file name
    OPTCH    oc;								// options chain structure    
};

// globally visible functions implemented in trops.c that
// contain code necessary for trading model backtests
void    select_market (PORTFOLIO &pf, long imkt);
long	  load_chain (PORTFOLIO &pf, long ibar);
void    clear_trades (PORTFOLIO &pf);
void    add_trade (PORTFOLIO &pf, TRADE &trd);
void    calc_stats (PORTFOLIO &pf);
long    symbol_to_index (PORTFOLIO &pf, char *symbol);

// globally visible functions implemented in tropsctl.c that contain
// code for the trading model being studied (run_system) and to free
// any memory allocated within run_system (free_system)
void    run_system (PORTFOLIO &pf);
void	  free_system (PORTFOLIO &pf);

// globally visible function implemented in tropsgx.c that
// contains code for executing graphics-related commands
long	  xgr_execute (PORTFOLIO &pf, char cmdln[]);

// miscelaneous macro definitions
#ifndef TRUE
  #define TRUE 1
  #define FALSE 0
#endif
#ifndef max
  #define max(a,b) (((a)>(b))?(a):(b))
  #define min(a,b) (((a)<(b))?(a):(b))
#endif

#endif  /* TROPS_H */
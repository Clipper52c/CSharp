/*
c  tropsctl.c  (copy saved in models as ctl001a.c)
c
c  Contains code common to many trading models; code specific to the
c  model under study must be included from tropsmod.c, via an #include 
c  statement near the end of this module.  Trading model code is handled 
c  this way so that it can be easily maintained and take advantage of 
c  module-global static variables for speed and convenience.
c
c  Note 1: Some of the functions herein were written for end-of-day
c  data and may need to be modified for intraday analysis.
c
c  Note 2: The only external functions in this module (together with
c  the #included tropsmod.c) are run_system() and free_system().
c  These functions are called from trops.c, the application's main file.
c
c  Note 3: The code in this file should not be regarded as part of the
c  C-Trader platform, but as part of the trading model implementation.
c  All trading models to be studied using C-Trader are implemented in
c  functions run_system and free_system (included herein) and the
c  functions they, in turn, call.
c
c  Revised: 2008.08.15
c
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c  Copyright (C) 2008.  All Rights Reserved.
*/

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "libmisc.h"    /* utility (misc. functions) library header */
#include "libbspm.h"    /* option pricing library header */
#include "trops.h"      /* main application header */

#define USES_SDA 0      /* uses supplemental data: 0=no, 1=yes */
#define USES_WMS 0      /* uses whole-market statistics: 0=no, 1=yes */
#define USES_TRX 0	    /* uses standard trade routines: 0=no, 1=yes */

/*---------------------------------------------------------------------------
c  Defines intended to simplify access to commonly used functions
*/

#define	ftlerr		misc_ftlerr
#define nthned		misc_nthned
#define	datetoser	misc_datetoser
#define dayofweek	misc_dayofweek
#define dayofmonth	misc_dayofmonth

/*---------------------------------------------------------------------------
c  Functions implementing standard management of round-turn trades
*/

#if USES_TRX == 1	/* include these routines only if needed */

static long trdstock (PORTFOLIO &pf, long ienbr, float enpr, 
float ptrg, float slss, long ntmlm, long nsize)
{
    /* Takes a long or short trade in the currently selected stock,
    .  entering on the specified bar at the specified price, and exiting 
    .  on a profit target, stop loss, or time limit, whichever comes 
    .  first.  In other words, this routine combines an externally-
    .  specified entry with the "Standard Exit Strategy" used in 
    .  "The Encyclopedia of Trading Strategies" (McGraw Hill, 2000).
    .  Arguments:
    .    pf           - portfolio (application) data structure
    .    ienbr        - entry bar
    .    enpr         - entry price
    .    ptrg         - profit target price
    .    slss         - stop loss price
    .    ntmlm        - time limit in bars (counting entry bar)
    .    nsize        - number of shares (- or +)
    .    return value - bar on which trade completed (zero if no trade)
    .  Notes:
    .    Trades are only taken if data are valid and mostly complete.
    .    Size is in terms of original (uncorrected for splits) shares.
    .    Commission is assumed to be $.02 per round turn.  Slippage
    .    may be set using pf.parms[30].  Written for End-of-Day data.
    */

    long i, nbad, nhld, nbar, imkt;
    float sfx, *hi, *lo, *cls, *vol, *sf;
    TRADE trd;
    float trd_clsval[MAXHLD];

    /* allocate TRADE structure member trd.clsvalue */
    trd.clsvalue= trd_clsval;

    /* copy data to local variables for speed and convenience */
    nbar= pf.nbar;
    imkt= pf.mktselected;    
    hi= pf.hi;
    lo= pf.lo;
    cls= pf.cls;
    vol= pf.vol;
    sf= pf.sf;

    /* trade analysis for entry bar */
    if(ienbr>nbar-5) ftlerr("trdstock: ienbr>nbar-5");
    if(ienbr<25) ftlerr("trdstock: ienbr<25");
    if(hi[ienbr]<=lo[ienbr]) return(0); /* zero-range bar, no entry */
    if(hi[ienbr]==hi[ienbr-1] && lo[ienbr]==lo[ienbr-1] &&
        vol[ienbr]==vol[ienbr-1])
            return(0);                      /* duplicate bar, no entry */    
    sfx= sf[ienbr];			                /* split factor on entry bar */
    if(vol[ienbr]<2.5*sfx) return(0);	    /* insufficient volume, no entry */
    trd.imkt= imkt;			                /* market (stock) being traded */
    trd.ientrybar= ienbr;		            /* specified entry bar */
    trd.nshr= nsize;			            /* shares, long (+) or short (-) */
    trd.entryvalue= nsize*sfx*enpr + 	    /* entry value */
        abs(nsize)*0.02;		            /* .. plus round-turn commission */
    trd.clsvalue[0]= nsize*sfx*cls[ienbr];  /* closing value on entry bar */
    if((nhld=1)>=ntmlm) goto L0;	        /* take exit on entry bar close */

    /* long trade beyond entry bar */
    #define STK_PTTYPE 1  /* profit target: 1=intraday, 2=close only */
    if(nsize>0) {
        nbad= 0;
        for(i=ienbr+1;; i++) {
            if(vol[i]<=0.0 || hi[i]<=lo[i]) nbad++;
            else if(hi[i]==hi[i-1] && lo[i]==lo[i-1] &&
                        vol[i]==vol[i-1]) nbad++;
            if(nbad>3) return(0);  /* data questionable, no trade */
            nhld++;
            if(cls[i]<slss) {       /* close-only stop loss */
		trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                goto L0;
            }
            #if STK_PTTYPE == 1	    /* profit target intraday */
                if(hi[i]>ptrg) {
		    trd.clsvalue[i-ienbr]= nsize*sfx*ptrg;
                    goto L0;
                }
            #endif            
	    #if STK_PTTYPE == 2	        /* profit target on close */
                if(cls[i]>ptrg) {
		    trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                    goto L0;
                }
            #endif 
	    if(nhld>=ntmlm || i>=nbar-2) {  /* time limit */
		trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                goto L0;
            }
            trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];  /* hold trade */
        }
    }

    /* short trade beyond entry bar */
    else if(nsize<0) {
        nbad= 0;
        for(i=ienbr+1;; i++) {
            if(vol[i]<=0.0 || hi[i]<=lo[i]) nbad++;
            else if(hi[i]==hi[i-1] && lo[i]==lo[i-1] &&
                        vol[i]==vol[i-1]) nbad++;
            if(nbad>3) return(0);  /* data questionable, no trade */
            nhld++;
            if(cls[i]>slss) {       /* close-only stop loss */
                trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                goto L0;
            }
            #if STK_PTTYPE == 1	    /* profit target intraday */
                if(lo[i]<ptrg) {  
                    trd.clsvalue[i-ienbr]= nsize*sfx*ptrg;
                    goto L0;
                }
            #endif            
            #if STK_PTTYPE == 2	    /* profit target on close */
                if(cls[i]<ptrg) {  
                    trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                    goto L0;
                }
            #endif
            if(nhld>=ntmlm || i>nbar-2) {  /* time limit hit */
                trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];
                goto L0;
            }
            trd.clsvalue[i-ienbr]= nsize*sfx*cls[i];  /* hold trade */
        }
    }
    #undef STK_PTTYPE

    /* post trade to simulated account and return with exit bar */
L0: trd.iexitbar= ienbr+nhld-1;
    add_trade(pf, trd);
    return(trd.iexitbar);
}

static long trdoption (PORTFOLIO &pf, long ienbr, float enpr, 
float ptrg, long ntmlm, long nsize, long itype, float strk)
{
    /* Takes a long or short trade in an option of the specified type and 
    .  strike on the currently selected stock.  Entry is at the specifed
    .  stock price on the specified bar.  Exit is on a price limit on the 
    .  stock, or on a time limit, whichever comes first.  Note that nsize 
    .  must be specifed in shares controlled rather than in option 
    .  contracts (each contract normally controls 100 shares).
    .  Arguments:
    .    pf           - portfolio data structure
    .    ienbr        - entry bar
    .    enpr         - entry price (referred to stock, not option)
    .    ptrg         - profit target price (referred to stock, not option)
    .    ntmlm        - time limit in bars
    .    nsize        - number of option contracts times 100 (- or +)
    .    itype        - option type (1=call, 2=put)
    .    strk         - option strike
    .    return value - bar on which trade completed (zero if no trade)
    .  Notes:
    .    Trades are only taken if the data are valid and mostly complete.
    .    A profit target on short options may be set via pf.parm[18] as
    .    a multiple of the entry price; if pf.parms[18] is zero, then
    .    the default value of .25 is used.  A multiplier may be supplied
    .    in pf.parms[22] for volatility as a correction; leaving 
    .    pf.parms[22]==0.0 causes the default of 1.0 (no correction) to 
    .    be used as the multiplier.  Written only for end-of-day data.
    */

    long i, ixpdt, ixpdtser, icbdtser, itl, isgn, nbad, nhld;
    float opr, tmp, vx, vxmul, oeprc, rfi;
    long *dt, nbar, imkt, ixpir;
    float *hi, *lo, *cls, *vol, *prm, *vxest;    
    float cf= sqrt(365.25)/100.0;
    TRADE trd;
    float trd_clsval[MAXHLD];

    /* allocate TRADE structure member trd.clsvalue */
    trd.clsvalue= trd_clsval;

    /* copy some data to local variables for speed and convenience */
    nbar= pf.nbar;
    imkt= pf.mktselected;    
    dt= pf.ldt;
    hi= pf.hi;
    lo= pf.lo;
    cls= pf.cls;
    vol= pf.vol;
    prm= pf.parms;
    rfi= pf.rfi[ienbr];
    #if USES_SDA == 1
        /* use implied volatility (from supplemental data) */
        vxest= ((prm[20]<0.5) ? (NULL) : ((prm[20]<1.5)?(suppa):(suppb)));
    #else
        /* use historical volatility */
        vxest= NULL;
    #endif
    /* expiration to use: 1=closest, 2=next, ... */
    ixpir= ((prm[20]<1.5) ? (1) : (2));

    /* local macro used to calculate theoretical option price */
    #define OPT_STRATEGY 1
    #if OPT_STRATEGY == 1  /* use a single option */
        #define optprice(xsp) \
            ( (itype==1) ? (bscall((xsp),strk,itl,rfi,vx)) : \
                       (bsput((xsp),strk,itl,rfi,vx)) )
    #endif
    #if OPT_STRATEGY == 2  /* use a spread or hedged option */
        #define optprice(xsp) \
            ( (itype==1) ? (bscall((xsp),strk,itl,rfi,vx) \
                      - bscall((xsp),strk+2.0,itl,rfi,vx)) : \
                       (bsput((xsp),strk,itl,rfi,vx) \
                      - bsput((xsp),strk-2.0,itl,rfi,1.1*vx)) )
    #endif
    #undef OPT_STRATEGY

    /* trade data at entry bar */
    if(ienbr>nbar-5) ftlerr("trdoption: ienbr>nbar-5");
    if(vol[ienbr]<=1.0) return(0);	/* little activity, no trade */
    if(hi[ienbr]<=lo[ienbr]) return(0);	/* zero-range bar, no trade */
    if(hi[ienbr]==hi[ienbr-1] && lo[ienbr]==lo[ienbr-1] &&
        vol[ienbr]==vol[ienbr-1])
            return(0);			                /* duplicate bar, no trade */
    ixpdt= nthned(dt[ienbr],ixpir);	            /* option expiration date */
    ixpdtser= datetoser(ixpdt);		            /* serial date of expiration */
    icbdtser= datetoser(dt[ienbr]);	            /* serial date of entry bar */
    itl= ixpdtser-icbdtser;		                /* days left to expiration */
    if(itl<0) ftlerr("trdoption: itl<0");	    /* should never happen */
    if(itl<5+(long)prm[29]) return(0);	        /* not enough time, no trade */
    vxmul= (prm[22]<=0.001) ? 1.0 : prm[22];    /* volatility correction */
    if(vxest) vx= vxmul*cf*vxest[ienbr];	    /* use implied volatility */
    else {				/* or use historical estimate */
        for(nbad=0, i=ienbr-30; i<ienbr; i++) {
            if(hi[i]<=lo[i]) nbad++;
            else if(hi[i]==hi[i-1] && lo[i]==lo[i-1]) nbad++;
            if(nbad>3) return(0);	    /* no valid estimate, no trade */
        }
        vx= vxmul*bsvltybar(hi,lo,cls,ienbr,30,5);
    }
    if(vx<0.05) return(0);              /* no trade when no volatility */
    opr= optprice(enpr);		        /* option price on trade entry */
    #if 1==1
        if(nsize<0) {
            if(opr<0.10) return(0); }	/* no trade when price too low */
        else if(nsize>0) {
            if(opr<0.05) return(0); }
        else return(0);
    #endif
    trd.imkt= imkt;			            /* underlying stock */
    trd.ientrybar= ienbr;		        /* trade entry date */
    trd.nshr= nsize;			        /* number contracts * 100 */
    trd.entryvalue= nsize*(oeprc=opr);	/* position value on entry */
    opr= optprice(cls[ienbr]);		    /* option price on entry bar close */
    trd.clsvalue[0]= nsize*opr;		    /* position value entry bar close */
    nhld= 1;				            /* bars held so far */
    if(nhld>=ntmlm) goto L0;		    /* take exit on entry bar close */

    /* trade data beyond the entry bar */
    isgn= ((3-2*itype)*nsize>0)?(1):(-1);  /* sign of position delta */
    nbad= 0;
    for(i=ienbr+1;; i++) {
        if(vol[i]<=0.0 || hi[i]<=lo[i]) nbad++;
        else if(hi[i]==hi[i-1] && lo[i]==lo[i-1] &&
            vol[i]==vol[i-1]) nbad++;
        if(nbad>3) return(0);		/* missing data, no trade */
        nhld++;
        icbdtser= datetoser(dt[i]);
        itl= ixpdtser-icbdtser;		/* days left to expiration */
        if(itl<0) ftlerr("trdoption: itl<0");
        /* determine or estimate volatility */
        if(vxest) { if(vxest[i]>0.05) vx= vxmul*cf*vxest[i]; }
        else vx= vxmul*bsvltybar(hi,lo,cls,i,30,5);
        if(vx<0.05) return(0);		/* no volatility, no trade */
        if(nsize<0) {	            /* profit target on decay of short options */
            tmp= (itype==1) ? (lo[i]) : (hi[i]);
            opr= optprice(tmp);
            tmp= (prm[18]>0.001) ? (prm[18]) : (0.25);
            if(opr<tmp*oeprc) {
                /* close short if most option value is gone */
                trd.clsvalue[i-ienbr]= nsize*(tmp*oeprc);
                goto L0;
            }
        }
        #define OPT_PTTYPE 2
        #if OPT_PTTYPE == 1  /* use intraday profit targets */
            if(isgn>0 && hi[i]>ptrg) {
                /* profit target on stock rise when delta positive */
                tmp= ptrg;   /* spr=max(lo[i],ptrg); */
                opr= optprice(tmp);
                trd.clsvalue[i-ienbr]= nsize*opr;
                goto L0;
            }
            if(isgn<0 && lo[i]<ptrg) {
                /* profit target on stock fall when delta negative */
                tmp= ptrg;   /* spr=min(hi[i],ptrg); */
                opr= optprice(tmp);
                trd.clsvalue[i-ienbr]= nsize*opr;
                goto L0;
            }
        #endif
        #if OPT_PTTYPE == 2  /* use close-only profit targets */
            if(isgn>0 && cls[i]>ptrg) {
                /* profit target on stock rise when delta positive */
                opr= optprice(cls[i]);
                trd.clsvalue[i-ienbr]= nsize*opr;
                goto L0;
            }
            if(isgn<0 && cls[i]<ptrg) {
                /* profit target on stock fall when delta negative */
                opr= optprice(cls[i]);
                trd.clsvalue[i-ienbr]= nsize*opr;
                goto L0;
            }
        #endif
        #undef OPT_PTTYPE
        if(i>=nbar-1 || nhld>=ntmlm || dt[i+1]>=ixpdt) {
            /* time limit which includes exit before expiration */
            opr= optprice(cls[i]);
            trd.clsvalue[i-ienbr]= nsize*opr;
            goto L0;
        }
        opr= optprice(cls[i]);
        trd.clsvalue[i-ienbr]= nsize*opr;  /* continue to hold trade */
    }

    /* clear local option pricing macro */
    #undef optprice

    /* post trade to simulated account and return with exit bar */
L0: trd.iexitbar=ienbr+nhld-1;
    #if 1==0
        { /* debugging for trdoption */
        static FILE *fp;
        fp=fopen("junk2","at");
        fprintf(fp,"%5d %10d %10d %10.2f  %8.2f %8.2f %8.2f\n",
             (int)imkt, (int)itl, (int)nsize, (float)enpr,
             (float)vx, (float)trd.entryvalue,
             (floattrd.clsvalue[nhld-1]);
        fclose(fp); }
    #endif
    add_trade(pf, trd);
    return(trd.iexitbar);
}

#endif

/*---------------------------------------------------------------------------
c  Function to assess stock liquidity
*/

float pd_liquidity (float hi[], float lo[], float cls[],
float vol[], long icb) {

    /* Detects poor liquidity and spotty trading in the period
    .  preceding the reference bar.  For stocks with good liquidity 
    .  and differentiated bars, the return value usually falls
    .  below 0.10 and almost always below 0.30; for stocks with poor
    .  liquidity, the return value usually falls above 0.50 and almost
    .  always above 0.30.  Hard-zero volume is assumed to indicate
    .  missing data with prices that have been filled in from
    .  previous bars.  Written primarily for end-of-day stock data.
    .  Arguments:
    .    hi, lo, cls - input, price series [0..icb..]
    .    vol         - input, volume series [0..icb..]
    .    icb         - input, index of current or reference bar
    .  Returns:
    .    liquidity: -1.0=Invalid, 0.0..0.1=High, 0.5..1.0=Low
    */

    long i, m0, m1, ncnt;

    /* initialize */
    m0=max((m1=icb)-50,1);              /* 50-bar normal lookback */
    if(m1-m0<25) return(-1.0);          /* 25-bar minimum lookback */

    /* calculate percentage of illiquid features */
    for(ncnt=0, i=m0; i<=m1; i++) {
        if(vol[i]<=0.0 || hi[i]<=lo[i]) ncnt+=2;
        if(cls[i]<=lo[i] || cls[i]>=hi[i]) ncnt++;
        if(hi[i]==hi[i-1] || lo[i]==lo[i-1]) ncnt++;
    }
    return(0.25*((float)ncnt)/((float)(m1-m0+1)));
}

/*---------------------------------------------------------------------------
c  Function to calculate statistics based on the entire market
*/

#if USES_WMS == 1

  #define WMS_MAXRNK	25	/* maximum no. ranks */
  #define WMS_RANKTYPE	1	/* what to rank */
  typedef struct {
      long    n;		    /* no. data points */
      float   *u;		    /* average stock price [nbar] */
      float   *rankthr;		/* rank thresholds [nbar*WMS_MAXRNK] */
  } WMSTATS;
  static long wms_khasrun= FALSE;

  void wmstats (PORTFOLIO &pf, WMSTATS &wms) {

    /* Calculates a variety of whole-market statistics including
    .  thresholds corresponding to the rankings of a specified 
    .  variable in descending order.  This routine is set up so as
    .  to make it easy to calculate additional statistics.
    .  Arguments:
    .    pf   - PORTFOLIO structure as defined in trops.h (input)
    .    wms  - structure containing the computed statistics (output)
    .  Statistics currently returned in members of wms:
    .      n		- number of data points (stocks)
    .      u		- average stock price [ibar]
    .      rankthr	- ranking thresholds [ibar+pf.nbar*irnk]
    .  Notes:
    .	   Ranges for array indices used in members of wms:
    .		0 <= ibar < pf.nbar
    .		0 <= irnk < WMS_MAXRNK
    */

    long imkt, ibar, i, k;
    float x;
    
    /* allocate memory and clear data */
    if(wms_khasrun) {
        if(wms.u) free(wms.u);
        if(wms.rankthr) free(wms.rankthr);
    }
    wms_khasrun= TRUE;
    wms.u= (float*)misc_malloc(sizeof(float)*pf.nbar);
    wms.rankthr= (float*)misc_malloc(sizeof(float)*pf.nbar*WMS_MAXRNK);
    wms.n= 0;
    for(k=0; k<pf.nbar; k++) wms.u[k]= 0.0;
    for(k=0; k<pf.nbar*WMS_MAXRNK; k++) wms.rankthr[k]= 0.0;
    
    /* local macro functions */
    #define rthr(i,j)  ( wms.rankthr[(i)+pf.nbar*(j)] )
    #define swapf(a,b) { float ff; ff=(a); (a)=(b); (b)=ff; } 

    /* for each stock in market database ... */
    for(imkt= 0; imkt < pf.nmkt; imkt++) {
    
        /* restrict calculations to specific stocks */
        /*  ***** there are no current stock filters */

        /* select and load the stock's data */
        select_market(pf, imkt);
        wms.n += 1;			/* data point (stock) count */

        /* for each bar of selected stock ... */
        for(ibar= 0; ibar < pf.nbar; ibar++) {
        
            /* accumulate data for average price over all stocks */
            wms.u[ibar] += pf.cls[ibar];
            
            /* determine variable to rank */
            #if WMS_RANKTYPE == 1	/* rank upside opening gaps */
                if(ibar > 0) { x= max(pf.opn[ibar] - pf.cls[ibar-1], .0); }
                else { x= .0; }
            #endif
            #if WMS_RANKTYPE == 2	/* rank downside opening gaps */
                if(ibar > 0) { x= max(pf.cls[ibar-1] - pf.opn[ibar], .0); }
                else { x= .0; }
            #endif            
            #if WMS_RANKTYPE == 3	/* rank upside gains at close */
                if(ibar > 0) { x= max(pf.cls[ibar] - pf.cls[ibar-1], .0); }
                else { x= .0; }            
            #endif
            #if WMS_RANKTYPE == 4	/* rank downside gains at close */
                if(ibar > 0) { x= max(pf.cls[ibar-1] - pf.cls[ibar], .0); }
                else { x= .0; }                        
            #endif
            
            /* accumulate data for determination of rank thresholds */
            if(x > rthr(ibar,0)) {
                rthr(ibar,0)= x;
                for(k= 1; k < WMS_MAXRNK; k++) {
                    if(rthr(ibar,0) > rthr(ibar,k))
                        swapf(rthr(ibar,0), rthr(ibar,k));
                }
            }
            
        } /* next bar */

    } /* next stock */

    /* finish calculating statistics */
    for(ibar= 0; ibar < pf.nbar; ibar++) {
        wms.u[ibar] /= (float)wms.n;
        for(i= 0; i < WMS_MAXRNK-1; i++) {
            for(k= i+1; k < WMS_MAXRNK; k++)
                if(rthr(ibar,i) < rthr(ibar,k))
                    swapf(rthr(ibar,i), rthr(ibar,k));
        }
    }

    #if 1==0
        { /* debugging code for market statistics */
        FILE *fp=fopen("junk","wt");
        for(ibar= 0; ibar < pf.nbar; ibar++) {
            fprintf(fp, "%8ld %7.2f %8ld X ",
                (long)pf.dt[ibar], (float)wms.u[ibar], (long)wms.n);
            for(k= 0; k < WMS_MAXRNK; k++)
                fprintf(fp, "%7.2f", (float)rthr(ibar,k));                
            fprintf(fp, "\n");
        }
        fclose(fp);
        ftlerr("debug_wms"); }
    #endif

    /* undefine local macro functions */    
    #undef rthr
    #undef swapf
  }
  #undef WMS_RANKTYPE

#endif

/*---------------------------------------------------------------------------
c  Module-global static variables
*/

#if USES_TRX == 1
  typedef struct {	    /* trading entry signal data structure */
    long    lensize;	/* position size (shares controlled: 0, +-n) */
    float   enprce;	    /* entry price (referred to stock) */
    float   sloss;	    /* stop loss price (referred to stock) */
    float   ptarg;	    /* profit target price (referred to stock) */
    float   strike;	    /* strike price (for options) */
    long    lsectyp;	/* security type (0=Stock, 1=Call, 2=Put) */
    long    lmaxhld;	/* maximum holding period (in bars) */
    long    lentrybr;	/* entry bar (returned) */
    long    lexitbr;	/* exit bar (returned) */
  } TRADESIGNAL;
  static TRADESIGNAL trsig;	/* trading model signal structure */
#endif

#if USES_WMS == 1
  static WMSTATS wms;  	/* whole-market statistics structure */
#endif

static PORTFOLIO *gpf;
static long nbar, nmkt, nser, *dt, *tm, ibar, imkt;
static float *opn, *hi, *lo, *cls, *vol, *oi, *sf, *prm;
#if USES_SDA == 1
  static float *suppa, *suppb, *suppc, *suppd;
#endif

/*---------------------------------------------------------------------------
c  Alternative trading model simulation method (ATSM) implementation.
c  This simulator component allows a system to operate on a single series,
c  much like TradeStation or the original C-Trader, by translating and then
c  posting the trades to the native simulator.  Multiple series may be
c  handled, one complete series at a time, so portfolio simulation is still
c  feasible; however, jumping between tradeable derivative series midstream,
c  as is required when selecting strikes or expirations to trade, is not
c  supported by this approach.  The ability to perform on-the-fly selection
c  or manipulation of the series being traded is supported by the native
c  simulation model, which was specifically designed to handle such
c  situations, at the cost of greater difficulty writing systems.
*/

/* Structure used by the ATSM component */
typedef struct {
    long    npos;			    /* current position size */
    long    ntrns;			    /* transaction count */
    long    ntbar;			    /* last transaction bar */
    float   cash;			    /* current cash position */
    TRADE   trd;			    /* trade structure */
    float   trd_clsval[MAXHLD];	/* array for trade structure */
} ATSM_TYPE;

/* Define a module-global static instance of the ATSM structure */
static ATSM_TYPE atsm;

void atsm_reset (void) {
    /* Initializes everything for trading the next (or first) data
    .  series.  This routine should be called from within the market
    .  (security) loop just before the bar loop begins.
    */
    atsm.npos= 0;
    atsm.ntrns= 0;
    atsm.ntbar= 0;
    atsm.cash= 0.0;
    atsm.trd.clsvalue= atsm.trd_clsval;
}

void atsm_transact (long nsize, float price) {
    /* Executes a transaction on the current bar.  Assumes the
    .  module-global variable ibar is used as the bar index.
    */
    long k;
    /* Close out any existing position creating a round-turn trade */
    if(atsm.npos != 0) {
        atsm.trd.iexitbar= ibar;
        k= atsm.trd.iexitbar - atsm.trd.ientrybar;
        if(k<0 || k>=MAXHLD) ftlerr((char*)"atsm_transact: MAXHLD exceeded");
        atsm.trd.clsvalue[k]= atsm.npos * price + atsm.cash;
        add_trade(*gpf, atsm.trd);  /* post trade using native method */
    }
    /* Update local current position and cash assets data */
    atsm.ntrns += 1;
    atsm.ntbar = ibar;
    atsm.npos += nsize;
    atsm.cash -= nsize * price;
    /* Open a new position if necessary */
    if(atsm.npos != 0) {
        atsm.trd.nshr= atsm.npos;
        atsm.trd.imkt= imkt;
        atsm.trd.ientrybar= ibar;
        atsm.trd.entryvalue= atsm.npos * price + atsm.cash;
        /* An outrageously large value helps catch errors */
        for(k= 0; k< MAXHLD; k++) atsm.trd.clsvalue[k]= -1.E25;
    }
}

void atsm_update (void) {
    /* Updates the data in atsm.trd.clsvalue[] as of the close of
    .  each bar.  Assumes the module-global variable ibar is used
    .  as the bar index.
    */
    long k;
    if(atsm.npos != 0) {
        k= ibar - atsm.trd.ientrybar;
        if(k<0 || k>=MAXHLD) ftlerr((char*)"atsm_update: MAXHLD exceeded");
        atsm.trd.clsvalue[k]= atsm.npos * cls[ibar] + atsm.cash;
    }
}

long atsm_position (void) {
    /* Returns the current position size (0 = Flat) */
    return(atsm.npos);
}

float atsm_cash (void) {
    /* Returns the current cash assets */
    return(atsm.cash);
}

long atsm_barsheld (void) {
    /* Returns the number of bars since the most recent transaction
    .  (including the transaction bar) when a position exists,
    .  or zero when no position exists.
    */
    if(atsm.npos == 0) return(0);
    return(ibar - atsm.ntbar + 1);
}

/*---------------------------------------------------------------------------
c  Main trading model implementation.  This routine is normally called
c  from trops.c with all data passed via the PORTFOLIO data structure.
c  It calls into tropsmod.c (where more of the trading model to be
c  tested is implemented) passing data using static module-global
c  variables.
*/

/* Prototypes for functions implemented in tropsmod.c */
long trs_runsys_raw (void);
long trs_runsys_mkt (void);
void trs_runsys (void);

void run_system (PORTFOLIO &pf) {

    /* Clear simulated trade record */
    clear_trades(pf);

    /* Copy selected items to static module-global variables */
    gpf=  &pf; 		    // portfolio (application) data structure
    nbar= pf.nbar;  	// number of bars in primary database
    nmkt= pf.nmkt;  	// number of securities in primary database 
    nser= pf.nser;	    // number of quote data series per security
    prm=  pf.parms;  	// trading model parameters [0..MAXPRM-1]
    dt=   pf.ldt; 	    // dates [0..pf.nbar-1] as YYYYMMDD
    tm=   pf.ltm;	    // times [0..pf.nbar-1] as HHMMSS

    /* Precalculate whole-market statistics */
    #if USES_WMS == 1
        static long idu_wms= 0;
        if(idu_wms != pf.idpfffile) {
            /* recalculation occurs only when database changes */
            fprintf(stdout,"COMPUTING WMSTATS\n");
            fflush(stdout);
            wmstats(pf, wms);
            idu_wms=pf.idpfffile;
        }
    #endif
    
    /* Calls models fully implemented within tropsmod.c (return 1)
    .  and may also be used for initialization purposes (return 0).
    .  Only the following module-global variables are initialized
    .  and valid at this point: *gpf, nbar, nmkt, nser, prm[],
    .  dt[], tm[].
    */
    if(trs_runsys_raw() != 0) goto L30;

    /* Loop over individual securities (markets) in portfolio database */
    for(imkt=0; imkt<nmkt; imkt++) {

	/* Select a subset of up to 7 securities to trade as a portfolio:
	.    pf.parms[11] = first security to trade (1 .. pf.nmkt)
	.    pf.parms[12] = 0, or second security to trade (1 .. pf.nmkt)
	.    ...
	.    pf.parms[17] = 0, or last security to trade (1 .. pf.nmkt)
	.  To trade all securities (markets) in the database, possibly
	.  thousands, set pf.parms[11] to -1 (p11=-1 at the
	.  trops-> command line).
	*/
	if(pf.parms[11] > -.5) {
	    long m, kk;
	    m= imkt+1;
	    for(kk=11; kk<=17; kk++) {
	        if( m == (long)(prm[kk]+ .5) ) goto L55;
            }
            #if 1==0
                /* enable this code for an additional 7 securities */
	        for(kk=31; kk<=37; kk++) {
	            if( m == (long)(prm[kk]+ .5) ) goto L55;
                }
            #endif
            goto L20;	// go to end of security (imkt) loop
	    L55:;
	}

        /* Set up market-related static module-global variables */
        select_market(pf, imkt);	// load data for given security
        opn= pf.opn;  hi= pf.hi;  	// opening and high prices
        lo= pf.lo;  cls= pf.cls;  	// low and closing prices
        vol= pf.vol;  sf= pf.sf;	// volumes and split factors
        oi= pf.oi;			        // open interest figures
        #if USES_SDA == 1
            suppa= pf.suppa;  suppb= pf.suppb;	// supplemental series
            suppc= pf.suppc;  suppd= pf.suppd;	// ditto
        #endif
        
        /* Calls function in tropsmod.c that may be used for vectorized
        .  whole-series calculations on a per-security basis.  Normally,
        .  this function should return 0; if bar-by-bar computations
        .  in tropsctl.c (see below) are to be bypassed, return 1.
        .  All global variables except ibar are defined and valid
        .  at this point.
        */
        if(trs_runsys_mkt() != 0) goto L20;
        
        /* Loop over most bars in current security */
	for(ibar=MAXLBK; ibar<nbar-6; ibar++) {

            /* Run trading model sequentially on every bar with 
            .  data passed via static module-global variables, all
            .  of which are defined and valid at this point.
            */
            #if USES_TRX == 1
              trsig.lensize= 0;
            #endif
            trs_runsys();

            #if USES_TRX == 1
              /* Check for trading signal to handle with standard exits.
              .  Trades may also be directly posted from within
              .  trs_runsys(), in which case trsig.lensize should not
              .  be altered or referenced in that function.
              */
              if(trsig.lensize==0) goto L10;  // zero size => no signal

              /* Execute trade with stock (lsectyp==0) */
              if(trsig.lsectyp==0) {
                trsig.lexitbr= trdstock(
                  pf, 			    // application data structure
                  (trsig.lentrybr=ibar+1), // entry bar (bar after signal)
                  trsig.enprce,		// entry price
                  trsig.ptarg,		// profit target
                  trsig.sloss,		// stoploss
                  trsig.lmaxhld,	// time limit in bars (1..MAXHLD)
                  trsig.lensize		// total shares (+ or -)
                );
              }

              /* Execute with call (lsectyp==1) or put (lsectyp==2) */
              else if(trsig.lsectyp==1 || trsig.lsectyp==2) {
                trsig.lexitbr= trdoption(
                  pf, 			    // application data structure
                  (trsig.lentrybr=ibar+1), // entry bar (bar after signal)
                  trsig.enprce,		// entry price (ref to stock)
                  trsig.ptarg,		// profit target (ref to stock)
                  trsig.lmaxhld,	// time limit in bars (1..MAXHLD)
                  trsig.lensize,	// total shares controlled (+ or -)
                  trsig.lsectyp,	// security type (1=call, 2=put)
                  trsig.strike		// strike price
                );
              }
            
              /* Handle security type specification error */
              else ftlerr("invalid security type");
              L10:;
            #endif

        } /* next bar */

        L20:; 
    } /* next security */

    /* Calculate performance statistics from posted trades */
    L30:
    calc_stats(pf);
}

/*---------------------------------------------------------------------------
c  Function is called from trops.c to clean up after run_system()
c  whenever new market data is loaded (loadportfolio command) and
c  just before the program terminates.
*/

void free_system (PORTFOLIO &pf) {

    #if USES_WMS == 1
        /* free any memory allocated by wmstats() */
        if(wms_khasrun) {
            if(wms.u) { free(wms.u); wms.u=NULL; }
            if(wms.rankthr) { free(wms.rankthr); wms.rankthr=NULL; }
            wms_khasrun=FALSE;
        }
    #endif
}

/*---------------------------------------------------------------------------
c  Additional trading model code (brought in via an #include)
*/

#include "tropsmod.c"

/*---------------------------------------------------------------------------
c  Notes:
c
c  Some parameters are used to control features implemented in this
c  module rather than in tropsmod.c (the trading model).  Among
c  these parameters are:
c     pf.parms[11..17]
c        Sets the securities (markets) to be traded.  Set pf.parms[11]
c	 to -1 (p11=-1 at the trops-> command line) to force trading of
c        all securities in the database.  Any of these parameters set
c        to 0 will be ignored; base 1 indexing is used for market selection.
c     pf.parms[18]
c        Sets the profit target for covering short options in trdoption()
c        as a multiple of the option entry price.  Defaults to 0.25 if
c        pf.parms[18] is zero.
c     pf.parms[20]
c        Sets the option expiration and volatility estimate used in
c        trdoption() when calculating option prices for a trade:
c          0.0 = 1st-out option with historical volatility,
c          1.0 = 1st-out option with implied volatility from suppa[], 
c          2.0 = 2nd-out option with implied volatility from suppb[]
c     pf.parms[22]
c        Sets the volatility multiplier used with historical volatility
c        to simulate implied volatility so that option prices may
c        be calculated (e.g., when pf.parms[20] == 0.0) in trdoption().
c     pf.parms[29]
c        Sets the minimum "time left" for entering an options trade
c        calculated as MinDaysLeft= 5 + (long)pf.parms[29] in trdoption().
c  Some of these parameters are likely to change in the future.  See code
c  above for how things work and where these parameters are used.
c  Remember, code in this file should be treated as part of the trading
c  model, and not of the testing platform.
*/

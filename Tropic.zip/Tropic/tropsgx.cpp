// tropsgx.c
//
// Graphics and charting module.
//
// This module requires a recent version of Gnuplot as the graphics
// engine and assumes standard Unix pipes and an X-windows
// graphics environment.  Graphics commands will not work under
// Windows (although most other trops-> commands should operate
// normally in a Windows build of the application).
//
// Revised: 2008.03.24
// Still under development.
//
// Copyright (C) 2008.  All Rights Reserved.
// Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include "libmisc.h"	// utility (misc. functions) library header
#include "libpff.h"	    // portfolio database header for pff_malloc()
#include "libkbd.h"	    // header for kb_hit() and kb_getch_w()
#include "trops.h"	    // main application header

/*---------------------------------------------------------------------------
c  Local structures, variables, and defines
*/

#define ftlerr		misc_ftlerr

#define XGR_MAXPIPE	5

typedef struct {
    FILE    *gp[XGR_MAXPIPE];	// pipe pointers (one per window)
    long    kpipe;			    // target graphics pipe
    long    nbarmin;			// first bar to plot
    long    nbarmax;			// last bar to plot
} XGRAPH;

static XGRAPH xgs;

/*---------------------------------------------------------------------------
c  Graphics (drawing) functions
*/

static void xgr_plotbigchart (FILE *fp, long ldt[], long ltm[],
float opn[], float hi[], float lo[], float cls[], float vol[],
float pind1[], float pind2[], float sinda[], float sindb[],
long nbmin, long nbmax, char title[]) {
    // Draws a complete chart including prices, volumes, and some
    // indicators, using the specified pipe to Gnuplot.
    //   fp    - output pipe for Gnuplot graphics data and commands
    //   ldt   - dates in YYYYMMDD long integer form
    //   ltm   - times in HHMMSS long integer form
    //   opn   - open prices
    //   hi    - high prices
    //   lo    - low prices
    //   cls   - last prices
    //   vol   - volumes
    //   pind1 - first indicator to plot with prices in price subchart
    //   pind2 - second indicator to plot with prices in price subchart
    //   sinda - first series plotted in indicator subchart (or NULL)
    //   sindb - second series plotted in indicator subchart (or NULL)
    //   nbmin - first bar to plot
    //   nbmax - last bar to plot
    //   title - title for chart (NULL if no title)
    // Note: Uses Gnuplot as graphics engine and requires Unix pipes.
    float ymin, ymax, range;
    long k;
    // determine required y-axis range for price subchart
    ymin= ymax= cls[nbmin];
    for(k=nbmin; k<=nbmax; k++) {
        if(hi[k]>ymax) ymax=hi[k];
        if(pind1[k]>ymax) ymax=pind1[k];
        if(pind2[k]>ymax) ymax=pind2[k];        
        if(lo[k]<ymin) ymin=lo[k];
        if(pind1[k]<ymin) ymin=pind1[k];
        if(pind2[k]<ymin) ymin=pind2[k];        
    }
    // handle cases with insufficient range
    if((range=ymax-ymin)<.0002) {
        ymax=1.1*ymax;
        ymin=0.9*ymin;
        fprintf(stdout,"Insufficient range: %d %d %f\n",
            (int)nbmin, (int)nbmax, (float)range);
        range=ymax-ymin;
        if(range<.0002) return;
    }
    // clear plot area and set up for multiple plots
    fprintf(fp,"unset multiplot\nreset\nclear\n");
    #if 1==0
        fprintf(fp,"set title \"%s\"\n",(char*)title);
    #else
        fprintf(fp,"set terminal x11 title \"%s\"\n", (char*)title);
    #endif
    fprintf(fp,"set multiplot\nset grid\nset key off\n");
    // plot price bars in first subchart
    fprintf(fp,"set size %f,%f\n",(float)1.0,(float)0.6);
    fprintf(fp,"set origin %f,%f\n",(float)0.0,(float)0.4);
    fprintf(fp,"set xrange [%d:%d]\n",(int)nbmin,(int)nbmax);
    fprintf(fp,"set yrange [%f:%f]\n",(float)ymin,(float)ymax);
    fprintf(fp,"set lmargin 8\nset bmargin 1\n");
    fprintf(fp,"set format x \"\"\nset bars 1.5\n");
    if(1) {
        fprintf(fp,"plot \"-\" with financebars lt 1 lw 1\n");
        for(k=nbmin; k<=nbmax; k++)
            fprintf(fp,"%d %.4f %.4f %.4f %.4f\n",(int)k,
                (float)opn[k],(float)hi[k],(float)lo[k],(float)cls[k]);
        fprintf(fp,"e\n");
    }
    else {
        fprintf(fp,"plot \"-\" with lines lt 1 lw 1\n");
        for(k=nbmin; k<=nbmax; k++)
            fprintf(fp,"%d %.4f\n",(int)k,(float)cls[k]);
        fprintf(fp,"e\n");
        fprintf(fp,"plot \"-\" with lines lt 3 lw 1\n");
        for(k=nbmin; k<=nbmax; k++)
            fprintf(fp,"%d %.4f\n",(int)k,(float)opn[k]);
        fprintf(fp,"e\n");
    }    
    // plot price-related indicators in same subchart
    fprintf(fp,"plot \"-\" with lines lt 2 lw 2\n");
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.4f\n",(int)k,(float)pind1[k]);
    fprintf(fp,"e\n");
    fprintf(fp,"plot \"-\" with lines lt 3 lw 2\n");
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.4f\n",(int)k,(float)pind2[k]);
    fprintf(fp,"e\n");    
    fflush(fp);
    // plot volumes and hour in second subchart
    for(ymax=1.E-6, k=nbmin; k<=nbmax; k++) if(vol[k]>ymax) ymax=vol[k];
    fprintf(fp,"set size %f,%f\n",(float)1.0,(float)0.15);
    fprintf(fp,"set origin %f,%f\n",(float)0.0,(float)0.25);
    fprintf(fp,"set yrange [0:100]\n");
    fprintf(fp,"set tmargin 0\nunset title\n");
    fprintf(fp,"plot \"-\" with impulses lt 1 lw 2\n");
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.1f\n",(int)k,(float)(100.0*vol[k]/ymax));
    fprintf(fp,"e\n");
    fprintf(fp,"plot \"-\" with lines lt 2 lw 2\n");
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.1f\n",(int)k,(float)(100.0*ltm[k]/240000));
    fprintf(fp,"e\n");    
    fflush(fp);
    // plot two related indicators in third subchart
    if(sinda!=NULL && sindb!=NULL) {
        for(ymax=1.E-6, k=nbmin; k<=nbmax; k++) {
            if(fabs(sinda[k])>ymax) ymax=fabs(sinda[k]);
            if(fabs(sindb[k])>ymax) ymax=fabs(sindb[k]);
        }
        if(ymax<0.01) ymax=0.01;
        fprintf(fp,"set size %f,%f\n",(float)1.0,(float)0.25);
        fprintf(fp,"set origin %f,%f\n",(float)0.0,(float)0.0);
        fprintf(fp,"set yrange [-100:100]\n");
        fprintf(fp,"set format x\nset bmargin 2\n");
        fprintf(fp,"plot \"-\" with lines lt 1 lw 1\n");
        for(k=nbmin; k<=nbmax; k++)
            fprintf(fp,"%d %.2f\n",(int)k,(float)(100.0*sinda[k]/ymax));
        fprintf(fp,"e\n");
        fprintf(fp,"plot \"-\" with lines lt 2 lw 1\n");
        for(k=nbmin; k<=nbmax; k++)
            fprintf(fp,"%d %.2f\n",(int)k,(float)(100.0*sindb[k]/ymax));            
        fprintf(fp,"e\n");
        fprintf(fp,"plot \"-\" with lines lt 3 lw 1\n");
        fprintf(fp,"%d %.2f\n",(int)nbmin,(float)(0.0));
        fprintf(fp,"%d %.2f\n",(int)nbmax,(float)(0.0));
        fprintf(fp,"e\n");
        fflush(fp);        
    }
}

static void xgr_plotline (FILE *fp, float ser[], long nbmin, long nbmax,
long ksty, char title[]) {
    // plots a single series (ser) using specified pipe (fp)
    long k;
    fprintf(fp,"unset multiplot\nclear\nreset\n");
    fprintf(fp,"set terminal x11 title \"%s\"\n",(char*)title);
    fprintf(fp,"plot \"-\" with lines lt %d\n",(int)ksty);
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.4f\n",(int)k,(float)ser[k]);
    fprintf(fp,"e\n");
    fflush(fp);
}

static void xgr_plotbars (FILE *fp, float opn[], float hi[],
float lo[], float cls[], long nbmin, long nbmax, long ksty,
char title[]) {
    // plots finance bars (opn, hi, lo, cls) using specified pipe (fp)
    long k;
    fprintf(fp,"unset multiplot\nclear\nreset\n");
    fprintf(fp,"set terminal x11 title \"%s\"\n",(char*)title);
    fprintf(fp,"plot \"-\" with financebars\n");
    for(k=nbmin; k<=nbmax; k++)
        fprintf(fp,"%d %.4f %.4f %.4f %.4f\n",(int)k,(float)opn[k],
            (float)hi[k],(float)lo[k],(float)cls[k]);
    fprintf(fp,"e\n");
    fflush(fp);
}

long xgr_checkwin (long kp) {
    // performs a range check on pipe (window) index kp
    if(kp<0 || kp>=XGR_MAXPIPE) return(-1);	// out-of-range
    return(0);					// ok
}

long xgr_checkenv (void) {
    // returns environment type (0=Not X terminal, 1=X terminal)
    char *termtype;
    if((termtype=getenv("TERM"))==NULL) return(0);
    // test for various X terminals (add your favourite here)
    if(strcmp(termtype,"xterm")==0) return(1);
    if(strcmp(termtype,"aterm")==0) return(1);
    if(strcmp(termtype,"rxvt")==0) return(1);    
    return(0);
}

float xgr_gridincr (float a, float b, long m, float *xa) {
    // Given an interval (a, b) and the approximate number of desired
    // gridlines (m), determines the best gridline value increment
    // (function return) and the initial gridline value (*xa).
    float d, xd, xg, xq, xi;
    d=b-a;
    for(xq=1.E32, xi= -1.0, xd=0.00001; xd<1000000.0; xd*=10.0) {
        if((xg=fabs(d/(xd*.25)-m))<xq) { xq=xg; xi=xd*.25; }
        if((xg=fabs(d/(xd*.5)-m))<xq) { xq=xg; xi=xd*.5; }
        if((xg=fabs(d/(xd*1.)-m))<xq) { xq=xg; xi=xd*1.; }
    }
    *xa=xi*ceil(a/xi);	// initial gridline value
    return(xi);		    // gridline increment (xi < 0 indicates failure)
}

void xgr_plottextbars (FILE *fp, long ldt[], long ltm[], float hi[],
float lo[], float cls[], float vol[], long n1, long n2, char sym[]) {
    // Draws a bar chart using ASCII text characters on fanfold
    // computer paper.  Useful for visualizing long series in
    // a simple manner.
    float prmin, prmax, grfirst, grincr, x;
    long k, i, nwid= 100, kplo, kphi, kpcls;
    char buf[256];
    // determine price range
    prmin=1.E32;
    prmax= -1.E32;
    for(k=n1; k<=n2; k++) {
        if(hi[k]>prmax) prmax=hi[k];
        if(lo[k]<prmin) prmin=lo[k];
    }
    // output error message if range insufficient
    if(prmax-prmin<1.E-4 || n2-n1<5) {
        fprintf(fp,"INSUFFICIENT RANGE OR DATA\n");
        return;
    }
    // determine first gridline and gridline increment
    grincr=xgr_gridincr(prmin, prmax, 12, &grfirst);
    // output error message if there are no gridlines
    if(grincr<0.0) {
        fprintf(fp,"GRIDLINE CALCULATION ERROR\n");
        return;
    }
    // write header material        
    fprintf(fp,"SYMBOL= %s  BARS= %d - %d  DATES= %d - %d\n\n",
        (char*)sym, (int)n1, (int)n2, (int)ldt[n1], (int)ldt[n2]);
    fprintf(fp,"FIRST GRIDLINE= %.4f  GRIDLINE INCREMENT= %.4f\n",
        (float)grfirst, (float)grincr);
    // ***** write header (symbol, price axis values) **** to be done
    // for each line ...
    for(k=n1; k<=n2; k++) {
        // write date, time, hi, lo
        fprintf(fp,"%06d:%04d %6d %6d",
            (int)(ldt[k]%1000000), (int)(ltm[k]/100),
            (int)(100.0*lo[k]), (int)(100.0*hi[k]));
        // write plot and grid characters
        for(i=0; i<nwid; i++) buf[i]=' ';
        #define kpval(p) ((long)(nwid*(p-prmin)/(prmax-prmin)))
        #define klip(kp) ((kp<0)?(0):(kp>=nwid)?(nwid-1):(kp))
        for(x=grfirst; x<prmax; x+=grincr) {
            i=kpval(x); i=klip(i);
            buf[i]='I';
        }
        kplo=kpval(lo[k]); kphi=kpval(hi[k]); kpcls=kpval(cls[k]);
        kplo=klip(kplo); kphi=klip(kphi); kpcls=klip(kpcls);
            // ***** add grid characters here
        for(i=kplo; i<=kphi; i++) buf[i]='*';
        buf[kpcls]='C';
        buf[nwid]='\0';
        #if 1==0
            misc_strtrim(buf);
        #endif
        fprintf(fp,"%s\n",buf);
        #undef klip
        #undef kpval        
    }
    // final line of output
    fprintf(fp,"\n");
}

/*---------------------------------------------------------------------------
c  Graphics command parser (executes all graphics-related commands and is
c  the only external access point for this module).
*/

long xgr_execute (PORTFOLIO &pf, char cmdln[]) {

    // Parses and executes all graphics-related trading model
    // development commands.
    //   pf       - master application data structure (see trops.h)
    //   cmdln    - graphics command to parse and execute
    //   return   - 0=Okay, -1=Error
    // Note: Uses libkbd.c functions to handle keyboard input.

    // declare local scratch variables
    static long k, kp, m, n, ki, krc;
    static char buf[256], *gcmd;
    static float ftmp;

    // define local constants and macro functions
    #define error(a) {fprintf(stdout,(a)); fflush(stdout); return(-1);}
    #define iscom(a) (1==sscanf(cmdln,"%s",buf) && strcmp(buf,a)==0)
    
    // process xtextbars command (plots ASCII strip-format bar charts)
    if(iscom("xtextbars")) {
        static char sbuf[128];
        static FILE *fp;
        if(!pf.pfloaded) error("Portfolio data not loaded\n");
        krc=sscanf(cmdln+9, "%s %ld %ld %ld", sbuf, &k, &m, &n);
        if(krc!=4) error("Syntax error\n");
        // **** add code to check argument values
        if((fp=fopen(sbuf,"wt"))==NULL)
            error("Cannot open output file\n");
        select_market(pf, k);
        xgr_plottextbars(fp, pf.ldt, pf.ltm, pf.hi, pf.lo, pf.cls,
            pf.vol, m, n, pf.sym);
        fclose(fp);    
    }

    // process xdq command (plots equity curve)
    // **** should add code to decimate for intraday data ****
    else if(iscom("xdq")) {
        if(xgr_checkenv()==0) error("Requires X-Windows\n");
        if(!pf.pfloaded) error("Portfolio data not loaded\n");
        if(xgs.nbarmin<0 || xgs.nbarmax>=pf.nbar || 
            xgs.nbarmax-xgs.nbarmin<10) error("Invalid bar range\n");
        if(xgs.gp[kp=xgs.kpipe]==NULL) xgs.gp[kp]=_popen(gcmd, "w");
        xgr_plotline(xgs.gp[kp], pf.eqcls, xgs.nbarmin, xgs.nbarmax, -1,
            (char*)"System Equity Curve");
    }
    
    // process xscan command (enters interactive single-keypress mode
    // for scanning rapidly through numerous charts)
    else if(iscom((char*)"xscan")) {
        static float *pind, *sinda, *sindb, *pind2;
        static long km, na, nz, mb, ch, npma, k;
        static char title[120], mbuf[256];
        if(xgr_checkenv()==0) error("Requires X-Windows\n");
        if(!pf.pfloaded) error("Requires loaded portfolio data\n");        
        // check total bar count
        if(pf.nbar<30) error("Too few bars\n");
        // initialize plot parameters
        km=0;		// start with first security in database
        nz=pf.nbar-1;	// start with rightmost bar as last data bar
        mb=100;		// start with 100 bars in plot
        npma=10;	// start with 10 bar MA for prices
        ch='r';		// initial command is refresh chart
        // allocate memory for indicators
        pind=(float*)pff_malloc(k= sizeof(float)*pf.nbar);
        pind2=(float*)pff_malloc(k= sizeof(float)*pf.nbar);        
        sinda=(float*)pff_malloc(k);
        sindb=(float*)pff_malloc(k);
        // xscan mode command loop
        while(ch!='q') {
            // handle specific single-keypress user commands
            switch(ch) {            
              case 'h':					// provide help
                  fprintf(stdout, "xscan help:\n"
                    "  r = refresh plot\n"
                    "  n = next security        b = prev security\n"
                    "  e = show more bars       w = show fewer bars\n"
                    "  c = show earlier bars    v = show later bars\n" 
                    "  z = show shorter MA      x = show longer MA\n"
                    "  g = go to symbol\n " );
                  fflush(stdout);
                  goto L11;
              case 'r':  break;				// refresh chart
              case 'n':  km++; break;			// next security
              case 'b':  km--; break;			// previous security
              case 'e':  mb=(int)(1.2*mb); break;	// show more bars
              case 'w':  mb=(int)(mb/1.2); break;	// show fewer bars
              case 'c':  nz=(int)(nz-0.8*mb); break;	// show earlier bars
              case 'v':  nz=(int)(nz+0.8*mb); break;	// show later bars
              case 'z':  npma=(int)(npma/1.3); break;	// shorter MA
              case 'x':  npma=(int)(1.3*npma); break;	// longer MA
              case 'g':					// go to symbol
                  fprintf(stdout,"Enter symbol: ");
                  fflush(stdout);
                  fgets(mbuf, 6, stdin);
                  misc_strtrim(mbuf);
                  for(k=0; mbuf[k]; k++) mbuf[k]=toupper(mbuf[k]);
                  k=symbol_to_index(pf, mbuf);
                  if(k>=0) km=k;
                  else fprintf(stdout,"Symbol not found\n");
                  fflush(stdout);
                  break;
              default: 
                  fprintf(stdout, "Invalid keypress\n");
                  fflush(stdout);
                  goto L11;
            }
            // check and correct chart parameters
            if(km>=pf.nmkt) km=0; else if(km<0) km=pf.nmkt-1;
            if(mb<14) mb=14;
            if(nz>=pf.nbar) nz=pf.nbar-1; else if(nz<30) nz=32;
            na=nz-mb+1;
            if(na>pf.nbar-30) na=pf.nbar-30; else if(na<1) na=1;
            if(npma<5) npma=5; else if(npma>200) npma=200;
            // load data for desired security
            select_market(pf, km);
            fprintf(stdout,"PLOTTING: %-8s\r",(char*)pf.sym);
            fflush(stdout);
            // calculate indicators for chart            
            AverageS(pind, pf.cls, npma, pf.nbar);
            AverageS(pind2, pf.cls, 50, pf.nbar);
            ki=3;
            if(ki==1) {
                /* Lane's Stochastic oscillator */
                FastD(sinda, pf.hi, pf.lo, pf.cls, 14, pf.nbar);
                for(k=0; k<pf.nbar; k++) sinda[k]=(2.0*sinda[k]-1.0);
                XAverageS(sindb, sinda, 9, pf.nbar);
            }
            else if(ki==2) {
                /* Granville's On-Balance Volume */
                OnBalanceVol(pf.cls, pf.vol, sinda, pf.nbar);
                ftmp=Average(sinda+na, nz-na+1, nz-na);
                for(k=0; k<pf.nbar; k++) sinda[k] -= ftmp;
                AverageS(sindb, sinda, 14, pf.nbar);
            }
            else {
                /* Appel's MACD Oscillator */
                XAverageS(sinda, pf.cls, 14, pf.nbar);
                XAverageS(sindb, pf.cls, 27, pf.nbar);
                for(k=0; k<pf.nbar; k++) sinda[k]=sinda[k]-sindb[k];
                XAverageS(sindb, sinda, 14, pf.nbar);
                for(k=0; k<pf.nbar; k++) sindb[k]=sinda[k]-sindb[k];
            }
            // draw the chart
            if(xgs.gp[kp=xgs.kpipe]==NULL) {
                // open a pipe to Gnuplot if one is not already open
                xgs.gp[kp]=_popen(gcmd, "w");
                if(xgs.gp[kp]==NULL)
                    ftlerr((char*)"xgr_execute: cannot access Gnuplot\n");
            }
            sprintf(title, "%s (%ld  %ld:%ld)", 
                (char*)pf.sym, (long)km,
                (long)pf.ldt[nz], (long)pf.ltm[nz] );
            xgr_plotbigchart(xgs.gp[kp], pf.ldt, pf.ltm, pf.opn,
                pf.hi, pf.lo, pf.cls, pf.vol, pind, pind2, sinda,
                sindb, na, nz, title);
            // wait for next single-keypress user command
            L11:;
            ch=kb_getch_w();
        }
        fprintf(stdout,"\n");
        fflush(stdout);
        // free indicator memory
        free(sindb);
        free(sinda);
        free(pind);
        free(pind2);
    }
    
    // process xcl command (plots line curve for closing prices)
    else if(iscom("xcl")) {
        static char title[80];
        if(xgr_checkenv()==0) error("Requires X-Windows\n");
        if(!pf.pfloaded) error("Portfolio data not loaded\n");        
        if((krc=sscanf(cmdln+3,"%ld",&k))!=1) error("Syntax error\n");
        if(k<0 || k>=pf.nmkt) error("Invalid market index\n");
        if(xgs.nbarmin<0 || xgs.nbarmax>=pf.nbar || 
            xgs.nbarmax-xgs.nbarmin<10) error("Invalid bar range\n");
        if(xgs.gp[kp=xgs.kpipe]==NULL) xgs.gp[kp]=_popen(gcmd, "w");
        select_market(pf, k);
        sprintf(title,"CLOSING PRICES: %s (%d)",
            (char*)pf.sym, (int)k);
        xgr_plotline(xgs.gp[kp], pf.cls, xgs.nbarmin, xgs.nbarmax,
            -1, title);
    }
    
    // process xdiff command (plots line curve for closing price
    // differences between two markets)
    else if(iscom("xdiff")) {
        static char sym1[10], sym2[10], title[120];
        long k1, k2;  float w2, *c1, *c2;
        if(xgr_checkenv()==0) error("Requires X-Windows\n");
        if(!pf.pfloaded) error("Portfolio data not loaded\n");        
        if((krc=sscanf(cmdln+5,"%ld %ld %f",&k1,&k2,&w2))!=3) 
            error("Syntax error\n");
        if(k1<0 || k1>=pf.nmkt || k2<0 || k2>=pf.nmkt) 
            error("Invalid market index\n");
        if(xgs.nbarmin<0 || xgs.nbarmax>=pf.nbar || 
            xgs.nbarmax-xgs.nbarmin<10) error("Invalid bar range\n");
        if(xgs.gp[kp=xgs.kpipe]==NULL) xgs.gp[kp]=_popen(gcmd, "w");
        c1=(float*)pff_malloc(sizeof(float)*pf.nbar);
        c2=(float*)pff_malloc(sizeof(float)*pf.nbar);
        select_market(pf, k1);
        memcpy(c1, pf.cls, sizeof(float)*pf.nbar);
        strcpy(sym1, pf.sym);
        select_market(pf, k2);
        memcpy(c2, pf.cls, sizeof(float)*pf.nbar);
        strcpy(sym2, pf.sym);
        for(k=0; k<pf.nbar; k++) c1[k]=c1[k]-w2*c2[k];
        sprintf(title, "PRICE DIFF: %s - %.2f x %s",
            (char*)sym1, (float)w2, (char*)sym2);
        xgr_plotline(xgs.gp[kp], c1, xgs.nbarmin, xgs.nbarmax,
            -1, title);
        free(c1);
        free(c2);        
    }

    // process xpc command (plots standard bar chart for prices)
    else if(iscom("xpc")) {
        static char title[120];
        if(xgr_checkenv()==0) error("Requires X-Windows\n");
        if(!pf.pfloaded) error("Portfolio data not loaded\n");        
        if((krc=sscanf(cmdln+3,"%ld",&k))!=1) error("Syntax error\n");
        if(k<0 || k>=pf.nmkt) error("Invalid market index\n");
        if(xgs.nbarmin<0 || xgs.nbarmax>=pf.nbar || 
            xgs.nbarmax-xgs.nbarmin<10) error("Invalid bar range\n");
        if(xgs.gp[kp=xgs.kpipe]==NULL) xgs.gp[kp]=_popen(gcmd, "w");
        select_market(pf, k);
        sprintf(title, "%s (%d %d:%d)",
            (char*)pf.sym, (int)k,
            (int)pf.ldt[xgs.nbarmax], (int)pf.ltm[xgs.nbarmax] );
        xgr_plotbars(xgs.gp[kp], pf.opn, pf.hi, pf.lo, pf.cls,
            xgs.nbarmin, xgs.nbarmax, 0, title);
    }    
    
    // process xsel command (sets target graphics window)
    else if(iscom("xsel")) {
        if(sscanf(cmdln+4,"%ld",&kp)==1) {
            if(xgr_checkwin(kp)) error("Invalid target window\n");
            xgs.kpipe=kp;
        }
        fprintf(stdout,"TARGET CHART WINDOW: %ld\n",(long)xgs.kpipe);
    }            
    
    // process xbars command (sets range of bars to plot)
    else if(iscom("xbars")) {
        if(!pf.pfloaded) error("Portfolio data not loaded\n");
        // default setting requested (entire range)
        if(strstr(cmdln+5,"def")) {
            xgs.nbarmin=50;
            xgs.nbarmax=pf.nbar-1;
        }
        // settings provided as arguments
        else if((krc=sscanf(cmdln+5,"%ld %ld",&m,&n))==2) {
            if(m<0 || n>=pf.nbar || n-m<10) error("Invalid bar range\n");
            xgs.nbarmin=m;
            xgs.nbarmax=n;
        }
        // command error
        else if(krc!=EOF) error("Syntax error\n");
        // always display current settings
        fprintf(stdout,"CHART BAR RANGE: %ld to %ld\n",
            (long)xgs.nbarmin, (long)xgs.nbarmax);
        fprintf(stdout,"CHART DATE+TIME RANGE: %ld %06ld to %ld %06ld\n",
            (long)pf.ldt[xgs.nbarmin], (long)pf.ltm[xgs.nbarmin],
            (long)pf.ldt[xgs.nbarmax], (long)pf.ltm[xgs.nbarmax] );
    }

    // process xclose command (closes all windows and re-initializes)
    else if(iscom("xclose")) {    
        for(k= 0; k< XGR_MAXPIPE; k++)
            if(xgs.gp[k] != NULL) { _pclose(xgs.gp[k]); xgs.gp[k]= NULL; }
        xgs.kpipe= 0;
        xgs.nbarmin= 0;
        xgs.nbarmax= 0;
    }

    // process xinit command (initialization, execute once at startup)
    else if(iscom("xinit")) {
        // this is a non-user (internal) command that is called
        //   from main() in trops.c as xgr_execute(pf, "xinit")
        //   during application startup
        // initialize module-local data
        for(k= 0; k< XGR_MAXPIPE; k++) xgs.gp[k]= NULL;
        xgs.kpipe= 0;
        xgs.nbarmin= 0;
        xgs.nbarmax= 0;
        // set pointer to gnuplot command string
        gcmd= (char*)"gnuplot-x11 -bg black"		// changed from :   gcmd= (char*)"/usr/bin/gnuplot -bg black"
              " -xrm \"gnuplot*textColor: green\""
              " -xrm \"gnuplot*borderColor: white\""
              " -xrm \"gnuplot*axisColor: white\""
              " -xrm \"gnuplot*line1Color: green\""
              " -xrm \"gnuplot*line2Color: violet\"" ;
    }
    
    // process xfree command (de-initialization, execute once at closedown)
    else if(iscom("xfree")) {
        // this is a non-user (internal) command that is called
        //   from main() in trops.c as xgr_execute(pf, "xfree")
        //   when the application shuts down
        for(k= 0; k< XGR_MAXPIPE; k++)
            if(xgs.gp[k] != NULL) { _pclose(xgs.gp[k]); xgs.gp[k]= NULL; }
        xgs.kpipe= 0;
        xgs.nbarmin= 0;
        xgs.nbarmax= 0;
        gcmd= NULL;
    }

    // process xhelp command (lists available graphics commands)
    else if(iscom("xhelp")) {
        fprintf(stdout,
        "  help                   - Displays basic commands\n"
        "  mhelp                  - Displays additional commands\n"
        "  xhelp                  - Displays graphics commands\n"
        "  xdq                    - Displays equity curve\n"
        "  xcl m                  - Displays line plot of closes\n"
        "  xpc m                  - Displays bar chart of prices\n"
        "  xsel k                 - Selects target graphics window\n"
        "  xbars [m n | def]      - Sets and prints bar range\n"
        "  xscan                  - Enters chart scanning mode\n"
        "  xtextbars fn m n1 n2   - Plots ASCII strip bar chart\n"
        );
    }

    // handle non-existent graphics commands
    else { error("Invalid graphics command!\n"); }

    fflush(stdout);                     // flush terminal output
    return(0);                          // error-free return
    #undef iscom                        // undefine local macro
    #undef error                        // undefine local macro
}


/*
c  glbxapnd.c
c
c  Revised: 2009.08.12
c
c  Extracts intraday market data from fixed-field format files created
c  with glbxcmd and glbxrun (from the raw globex transaction zipfiles)
c  and places the extracted data into a type 939309 portfolio database
c  file.  The input fixed-field files and the target database file must be
c  specified in the glbxapnd.cfg configuration file which must reside in
c  the current working directory (the directory from which glbxapnd is
c  started).  Dates are derived from the first fixed-field input file
c  specified in glbxapnd.cfg and times are constructed as per user
c  specification.  All data bars are date-and-time-aligned with the
c  constructed dates and times.  Missing data points are handled with
c  prices being filled in with earlier or later prices and volumes being
c  set to hard zeros; volumes are set to soft zeros (tiny positive
c  numbers) for valid bars or data points that simply have no volume.
c
c  File glbxapnd.cfg must have the following format:
c
c  Example line contents                       Description
c  =========================================   ==========================
c  OUTPUT_DATABSE=../dbases/glbx5mindb         target database
c  INPUT_TXTPATH=../idddata/                   path for input files
c  DAY_RANGE: FROM=1 TO=5                      day range filter
c  TIME_RANGE: FROM=83500 TO=151500 STEP=300   time range and bar size
c  ES    es5m.txt                              ticker symbol 1 (primary)
c  NQ    nq5m.txt                              ticker symbol 2
c  ER    er5m.txt                              ticker symbol 3
c  ....                                        more tickers as desired
c  *                                           end-of-list marker
c
c  Day ranges are specified using numbers (0=Sun, 1=Mon, .. 6=Sat) and
c  are inclusive of the endpoints.  Time ranges are specified in
c  24-hour HHMMSS format and, like day ranges, are inclusive of the
c  endpoints; the bar interval, STEP, is specified in seconds and must
c  match the actual bar interval supplied in the input fixed-field data.
c  The time and date ranges act as filters, allowing only data falling
c  within the ranges to be included in the output; they do not affect
c  or transform the data in any other way.
c
c  Note that Globex data uses Chicago time.  For example, the ES becomes
c  active at 8:30 AM, which corresponds to 9:30 AM in New York.  I have
c  added some code in this program to adjust the time stamps to New York.
c  No adjustments were made for Daylight Savings Time; although such
c  adjustments were necessary with the Interactive Broker's data feed,
c  they do not seem to be required here.
c
c  Each ticker symbol line must contain the ticker symbol, as it
c  is to appear in the database, and the name of the text file in
c  from which the data derives.
c
c  Unless modifications are made, this program must be run on Intel
c  (big-endian) hardware and compiled with an ISO-standard 32-bit 
c  compiler.  We suggest the GNU gcc compiler which works well 
c  under BSD, Linux, and Windows.
c
c  Copyright (C) 2009.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#define MAXMKT  12            /* max. security (market) count */
#define MINMKT  1             /* min. security (market) count */
#define MAXBAR  775000        /* max. bar count */
#define TINYNUM 1.E-26        /* a very small number */

typedef struct {	      /* security quotes data structure */
    char    txtname[56];      /* input txt file name, with extension */
    char    symbol[10];       /* ticker symbol */
    char    name[40];         /* security name */
    float   opn[MAXBAR];      /* opening price */
    float   hi[MAXBAR];       /* high price */
    float   lo[MAXBAR];       /* low price */
    float   cls[MAXBAR];      /* last or closing price */
    float   vol[MAXBAR];      /* volume */
    float   sf[MAXBAR];       /* split or adjustment factor */
} MARKET;

typedef struct {              /* application data structure */
    char    dbfn[256];        /* database filespec, no extension */
    char    txtpath[256];     /* txt file path, no name or extension */
    long    ltime_start;      /* time range: from ltm_start */
    long    ltime_stop;       /* time range: to ltm_stop */
    long    ltime_step;       /* time increment in seconds (bar size) */
    long    lday_start;       /* day range: from lday_start */
    long    lday_stop;        /* day range: to lday_stop */
    long    nbar;             /* number of bars */
    long    nmkt;             /* number of securities or markets */
    long    ldt[MAXBAR];      /* dates [0..nbar-1] as YYYYMMDD */
    long    ltm[MAXBAR];      /* times [0..nbar-1] as HHMMSS */
    double  fdttm[MAXBAR];    /* datetimes [0..nbar-1] as YYYYMMDDHHMMSS.0 */
    MARKET  mkt[MAXMKT];      /* securities quotes data [0..nmkt-1] */
} APPLICATION;

/* application-specific functions */
void verify_assumptions (void);
void read_configuration (APPLICATION *app);
void extract_times (APPLICATION *app);
void extract_data (APPLICATION *app);
void canonicalize_data (APPLICATION *app);
void write_database (APPLICATION *app);
void correct_times (long *lymd, long *lhms, long lstep, char *sym);

/* utility (library) functions */
void parsecsv (char *pfld[], long *n, char *pstr);
long julday (long mm, long id, long iyyy);
void caldat (long julian, long *mm, long *id, long *iyyy);
long datetoser (long ldt);
long sertodate (long jd);
long dayofweek (long ldt);
long hmstosec (long hms);
long sectohms (long sec);
long imonth (long idate);
long iday (long idate);
long iyear (long idate);
long findflt (float arr[], long n, float val);
long findlng (long larr[], long n, long lval);
long finddbl (double darr[], long n, double dval);
char* fext (char *fn);
char* fpath (char *fn);
char* struprqq (char *str);
void* bmalloc (size_t nbytes);
void bseek (FILE *fp, long fpos, int whence);
void bread (void *v, size_t n, size_t m, FILE *fp);
void bwrite (void *v, size_t n, size_t m, FILE *fp);
void ftlerr (char *msg);

#ifndef max
    #define max(a,b) (((a)>(b))?(a):(b))
    #define min(a,b) (((b)>(a))?(a):(b))
#endif

/*---------------------------------------------------------------------------
c  Entry point for the glbxapnd application.
*/

int main (int nargs, char **args) {
    APPLICATION *app;    
    /* verify compiler data size and floating point assumptions */
    verify_assumptions();    
    /* allocate memory for master application data structure */
    app=(APPLICATION*)bmalloc(sizeof(APPLICATION));
    /* read configuration (control and setup) file */
    read_configuration(app);
    /* initialize date and time series in app->ldt[], app->ltm[], */
    /* and app->ldttm[] */
    extract_times(app);
    /* extract data from specified txt input files into app->mkt[] */
    /* aligning these data with the date and time series */
    extract_data(app);
    /* handle (fill in) missing data points and no-volume bars */
    canonicalize_data(app);
    /* write a type 939309 database and associated symbol file */
    write_database(app);
    /* free memory and terminate */
    free(app);
    fprintf(stdout,"DONE!\n");
    return(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------------
c  Function to verify data size and floating point assumptions.
*/

void verify_assumptions (void) {
    /* Verifies compiler's data size and floating point assumptions */
    long n, m;  float tmp, x;  double xx;
    n=(sizeof(double)==8) && (sizeof(float)==4) && (sizeof(long)==4)
        && (sizeof(int)==4) && (sizeof(short)==2) && (sizeof(char)==1);
    if(!n) ftlerr("invalid data size assumptions");
    memset(&tmp,0,sizeof(float));
    x=1534567.0;  xx=23451231245959.0;  m=23451231;  n=245959;
    if(tmp!=0.0 || (long)x!=1534567 || (1000000.0*m + n)!=xx)
        ftlerr("invalid floating point assumptions");
}

/*---------------------------------------------------------------------------
c  Function to read the glbxapnd.cfg data extraction control file.
*/

void read_configuration (APPLICATION *app) {
    /* Reads configuration (setup and control) file */
    FILE *fp;
    long k, lp;
    char buf[128], *p;
    /* open configuration file */
    if((fp=fopen("glbxapnd.cfg","rt"))==NULL)
        ftlerr("read_configuration: cannot find glbxapnd.cfg");
    /* read target database file specification */
    if(fscanf(fp," OUTPUT_DATABASE=%s",app->dbfn)!=1)
        ftlerr("read_configuration: error reading database filespec");
    /* read path to input txt files */
    if(fscanf(fp," INPUT_TXTPATH=%s",app->txtpath)!=1)
        ftlerr("read_configuration: error reading txt file path");
    /* display what has been read so far */
    fprintf(stdout,"OUTPUT_DATABASE: %s\n",(char*)app->dbfn);
    fprintf(stdout,"INPUT_TXTPATH: %s\n",(char*)app->txtpath);
    fflush(stdout);
    /* check for error in fixed-field txt file path specification */
    if(app->txtpath[strlen(app->txtpath)-1] != '/')
        ftlerr("read_configuration: txt file path must end with / \n");
    /* read day range (0=Sun, 1=Mon, ... 6=Sat) */
    if(fscanf(fp," DAY_RANGE: FROM=%ld TO=%ld",
        &app->lday_start, &app->lday_stop) != 2)
            ftlerr("read_configuration: invalid date range line");
    /* read time range (in HHMMSS form) and step (in seconds) */
    if(fscanf(fp," TIME_RANGE: FROM=%ld TO=%ld STEP=%ld",
        &app->ltime_start, &app->ltime_stop, &app->ltime_step) != 3)
            ftlerr("read_configuration: invalid time range line");
    /* display day and time ranges */
    fprintf(stdout,"DAY_RANGE: FROM=%ld TO=%ld\n"
        "TIME_RANGE: FROM=%06ld TO=%06ld STEP=%ld SECONDS\n",
        (long)app->lday_start, (long)app->lday_stop,
        (long)app->ltime_start, (long)app->ltime_stop,
        (long)app->ltime_step );    
    fflush(stdout);
    if(app->ltime_start > app->ltime_stop)
        ftlerr("read_configuration: time range invalid");
    if(app->lday_start > app->lday_stop)
        ftlerr("read_configuration: day range invalid");        
    /* read all ticker symbols and associated input txt file names */
    app->nmkt=0;
    #if 1==1
        /* Work around for fgets() or fscanf() bug in Debian Etch */
        /* Apparently one cannot mix calls to fscanf and fgets without */
        /* the file position getting messed up; the following two lines */
        /* serve to re-position the file */
        rewind(fp);
        for(lp=0; lp<4; lp++) fgets(buf,sizeof(buf),fp);
    #endif
    while(fgets(buf,sizeof(buf),fp)) {
        /* check for end of ticker list (look for list terminator) */
        if(strchr(buf,'*')) break;
        /* check for comment or empty line */
        if(buf[0]=='#') continue;
        if(strlen(buf)<1) continue;
        /* check for overflow (too many tickers) */
        if(app->nmkt>=MAXMKT)
            ftlerr("read_configuration: MAXMKT exceeded");
        /* extract ticker symbol and associated input file name */
        if(sscanf(buf,"%s %s",app->mkt[app->nmkt].symbol,
            app->mkt[app->nmkt].txtname) != 2) {
                fprintf(stdout,"TICKER_LINE: %s\n",(char*)buf);
                ftlerr("read_configuration: bad ticker line");
        }
        /* check for excessive symbol length */
        if(strlen(app->mkt[app->nmkt].symbol) > 6) {
            fprintf(stdout,"TICKER_SYMBOL: %s\n",(char*)buf);
            ftlerr("read_configuration: ticker longer than 6 chars");
        }
        /* make sure symbol is uppercase */
        struprqq(app->mkt[app->nmkt].symbol);
        /* replace any caret in input file name with a space */
        /* (we use carets to represent spaces in file names in */
        /* order to make scanning easier and less ambiguous) */
        p= app->mkt[app->nmkt].txtname;
        for(k=0; p[k]; k++) if(p[k]=='^') p[k]=' ';
        /* use input filename as descriptive name */
        memcpy(app->mkt[app->nmkt].name, app->mkt[app->nmkt].txtname,
            sizeof(char)*38);
        app->mkt[app->nmkt].name[38]=0;
        /* increment securities count */
        app->nmkt++;
    }
    /* close configuration file */
    fclose(fp);
    /* display and verify security (market) count */
    fprintf(stdout,"NMKT: %ld\n",(long)app->nmkt);
    fflush(stdout);
    if(app->nmkt<MINMKT) ftlerr("read_configuration: too few securities");
    /* display tickers and file names for debugging */
    #if 1==0
    {   long imkt;
        fprintf(stdout,"TICKER SYMBOLS AND FILE NAMES:\n");
        for(imkt=0; imkt<app->nmkt; imkt++) {
            fprintf(stdout,"IMKT=%d SYM=%s TXTNAME=%s\n",
                (int)imkt, (char*)app->mkt[imkt].symbol,
                (char*)app->mkt[imkt].name);
        }
        fflush(stdout);
        exit(EXIT_SUCCESS);   }
    #endif
    fprintf(stdout,"CONFIGURATION FILE HAS BEEN READ\n");
}

/*---------------------------------------------------------------------------
c  Function to make adjustments to the time-stamps on input bars.
*/

void correct_times (long *lymd, long *lhms, long lstep, char *sym) {
    /* Make any needed corrections to the dates and times associated
    .  with the quotes in the input files.  For example, I like to
    .  convert the Chicago time used by CME/Globex to New York time,
    .  which I have done in the code below.  Note that you can make
    .  different time conversions for different symbols, something
    .  you will need to do when the times used in the data for
    .  different securities correspond to different time-zones.
    */
    long lhh, lmm, lss;
    #if 1==1
        /* convert Chicago time to New York time */
        lhh= (*lhms / 10000) % 100;
        lmm= (*lhms / 100) % 100;
        lss= (*lhms) % 100;        
        lhh= lhh + 1;	// add 1 hour for New York time
        if(lhh > 23) {
            lhh= lhh - 24;
            *lymd= sertodate( datetoser(*lymd) + 1 );
        }
        *lhms= 10000*lhh + 100*lmm + lss;
    #endif
}

/*---------------------------------------------------------------------------
c  Function to construct the required date and time series.
*/

void extract_times (APPLICATION *app) {
    /* Constructs dates and times from user-provided ranges together */
    /* with the 'primary' txt data file and places the results in */
    /* app->ldt[], app->ltm[], and app->fdttm[] */
    FILE *fp;
    long kstartsec, kstopsec, kincsec, k, i, ntimes, ndates, nbars;
    long ldate, ldate_prev;
    static char fnbuf[256], linbuf[256];
    static long ltimes[86400], ldates[2400];
    /* find all time slots based strictly on range specification */
    kincsec=app->ltime_step;    
    kstartsec=hmstosec(app->ltime_start);
    kstopsec=hmstosec(app->ltime_stop);
    for(ntimes=0, k=kstartsec; k<=kstopsec; k+=kincsec)
        ltimes[ntimes++]=sectohms(k);
    #if 1==0
        /* debugging code */
        printf("ntimes=%d\n",(int)ntimes);
        for(k=0; k<ntimes; k++)
            printf("%4d %6d\n",(int)k,(int)ltimes[k]);
        exit(EXIT_SUCCESS);
    #endif    
    /* open primary (first) txt input file for reading */
    sprintf(fnbuf,"%s%s",(char*)app->txtpath,(char*)app->mkt[0].txtname);
    fprintf(stdout,"PRIMARY_TXT_FILE: %s\n",(char*)fnbuf);
    if((fp=fopen(fnbuf,"rt"))==NULL)
        ftlerr("extract_times: cannot find primary txt input file");
    /* extract all dates from quotes in primary txt file */
    ndates=0;
    ldate_prev=0;
    while(fgets(linbuf,sizeof(linbuf),fp)) {
        k=sscanf(linbuf,"%ld",&ldate);
        ldate= 20000000 + ldate;
        if(k!=1) {
            fprintf(stdout,"\nLINE: %s\n",linbuf);
            ftlerr("extract_times: bad data line");  }
        /* verify YYYYMMDD date */
        if( (k=iyear(ldate))<1997 || k>2025 ||
            (k=imonth(ldate))<1 || k>12 ||
            (k=iday(ldate))<1 || k>31 ) {
                fprintf(stdout,"\nLINE: %s\n",linbuf);
                ftlerr("extract_times: bad data line");  }
        /* filter date for day-of-week range specified by user */
        k=dayofweek(ldate);
        if(k<app->lday_start || k>app->lday_stop) continue;
        /* save date in list */
        if(ldate==ldate_prev) continue;
        ldates[ndates++]=ldate;
        ldate_prev=ldate;        
    }
    /* close primary txt file */
    fclose(fp);
    /* display counts of distinct dates and distinct times */
    printf("NDATES=%ld  NTIMES=%ld\n", (long)ndates, (long)ntimes);        
    #if 1==0
        /* debugging code */
        for(k=0; k<ndates; k++) printf("%4d %8d\n",(int)k,(int)ldates[k]);
        exit(EXIT_SUCCESS);        
    #endif    
    /* construct datetime series using from dates and times */
    nbars=0;
    for(k=0; k<ndates; k++) {
        for(i=0; i<ntimes; i++) {
            if(nbars>=MAXBAR) ftlerr("extract_times: MAXBAR exceeded");
            app->ldt[nbars]=ldates[k];
            app->ltm[nbars]=ltimes[i];
            app->fdttm[nbars++]=1000000.0*ldates[k] + ltimes[i]; } }
    app->nbar=nbars;
    /* display data for debugging */
    #if 1==0
        fprintf(stdout,"NBAR=%ld\n",(long)app->nbar);
        fprintf(stdout,"SYMBOL=%s\n",(char*)app->mkt[0].symbol);
        fprintf(stdout,"FILESPEC=%s\n",(char*)fnbuf);
        fprintf(stdout,"NAME=%s\n",(char*)app->mkt[0].name);
        for(k=0; k<app->nbar; k++)
            fprintf(stdout,"%7ld %08ld %06ld %20.1lf\n",
                (long)k, (long)app->ldt[k], (long)app->ltm[k],
                (double)app->fdttm[k]);
        fflush(stdout);
        exit(EXIT_SUCCESS);
    #endif
    fprintf(stdout,"DATETIME SERIES HAS BEEN INITIALIZED\n");
}

/*---------------------------------------------------------------------------
c  Function to extract raw fixed-field ASCII data from files generated
c  by glbxcmd and glbxrun, and to place the extracted data into
c  the app->mkt[] structure array.
*/

void extract_data (APPLICATION *app) {
    /* Extracts data series from all .txt input files into app->mkt[] */
    /* aligning and placing all data bars based on common datetimes */
    long imkt, ibar, nfld, lhh, lmm, lss, ldate, ltime, k;
    char fnbuf[256], linbuf[128];
    double fdatetime;
    float fclsprev, fhi, flo, fcls, fvol;
    long lyymmdd, lhhmmss;
    FILE *fp;
    /* for each security or market ... */
    for(imkt=0; imkt<app->nmkt; imkt++) {
        MARKET* mktk = &app->mkt[imkt];
        /* clear data arrays */
        for(ibar=0; ibar<app->nbar; ibar++) {
            mktk->opn[ibar]=0.0;
            mktk->hi[ibar]=0.0;
            mktk->lo[ibar]=0.0;
            mktk->cls[ibar]=0.0;
            mktk->vol[ibar]=0.0;
            mktk->sf[ibar]=0.0;  }
        /* open txt data file for reading */
        sprintf(fnbuf,"%s%s",(char*)app->txtpath,(char*)mktk->txtname);
        fprintf(stdout,"TXT_INPUT: %s\n",(char*)fnbuf);
        fflush(stdout);
        if((fp=fopen(fnbuf,"rt"))==NULL)
            ftlerr("extract_data: cannot find txt input file");
        /* for each line in txt data file ... */
        while(fgets(linbuf,sizeof(linbuf),fp)) {
            /* skip any blank (or nearly blank) line */
            if(strlen(linbuf) < 5) continue;
            /* read the fixed-field input Globex data */
            nfld=sscanf(linbuf,"%ld %ld %f %f %f %f",
                &lyymmdd, &lhhmmss, &fhi, &flo, &fcls, &fvol);
            if(nfld!=6) {
                fprintf(stdout,"Wrong_field_count: %ld\n",(long)nfld);
                goto LERR;  }
            /* convert date field to YYYYMMDD integer and verify */
            if(lyymmdd<500000) ldate= 20000000 + lyymmdd;
            else ldate= 19000000 + lyymmdd;
            if( (k=iyear(ldate))<1997 || k>2025 ||
                (k=imonth(ldate))<1 || k>12 ||
                (k=iday(ldate))<1 || k>31 ) {
                    fprintf(stdout,"Bad_date: %ld\n",(long)ldate);
                    goto LERR;  }
            /* convert time field to HHMMSS integer and verify */
            lhh= (lhhmmss/10000) % 100;
            lmm= (lhhmmss/100) % 100;
            lss= (lhhmmss) % 100;
            if(lhh<0 || lhh>23 || lmm<0 || lmm>59 || lss<0 || lss>59) {
                    fprintf(stdout,"Bad_time: %d:%d:%d\n",
                        (int)lhh, (int)lmm, (int)lss);
                    goto LERR;  }
            ltime=10000*lhh+100*lmm+lss;
            /* make any desired corrections to date and time, e.g., */
            /* convert Chicago to New York time */
            correct_times(&ldate, &ltime, app->ltime_step,
                app->mkt[imkt].symbol);
            /* determine where in data structure (at which bar) to */
            /* insert the data based on its date and time */
            fdatetime= 1000000.0*ldate + ltime;
            ibar= finddbl(app->fdttm, app->nbar, fdatetime);
            if(fdatetime != app->fdttm[ibar]) continue;
            /* convert and insert quote data into data structure */
            if(ibar>0) mktk->opn[ibar]= fclsprev;
            else mktk->opn[ibar]= 0.5 * (fhi + flo);
            mktk->hi[ibar]= fhi;
            mktk->lo[ibar]= flo;
            mktk->cls[ibar]= fcls;
            mktk->vol[ibar]= fvol;
            mktk->sf[ibar]= 1.0;
            fclsprev= fcls;
            /* code for debugging */
            #if 1==0
                fprintf(stdout,"%6d %6s %8d %06d %10.2f %10.2f "
                        "%10.2f %10.2f %12.1f %6.2f\n",
                    (int)ibar, (char*)app->mkt[imkt].symbol,
                    (int)app->ldt[ibar], (int)app->ltm[ibar],
                    (float)app->mkt[imkt].opn[ibar],
                    (float)app->mkt[imkt].hi[ibar],
                    (float)app->mkt[imkt].lo[ibar],
                    (float)app->mkt[imkt].cls[ibar],
                    (float)app->mkt[imkt].vol[ibar],
                    (float)app->mkt[imkt].sf[ibar]   );
                fflush(stdout);
            #endif
	}			/* next line in txt data file */
        /* close input txt data file */
        fclose(fp);
    }				/* next market or security */
    /* return normally */
    return;
    /* handle error */
    LERR:;
    fprintf(stdout,"  File= %s\n",(char*)fnbuf);
    fprintf(stdout,"  Symbol= %s\n",(char*)app->mkt[imkt].symbol);
    fprintf(stdout,"  Name= %s\n",(char*)app->mkt[imkt].name);
    fprintf(stdout,"  Line_Contents= %s\n",(char*)linbuf);
    fprintf(stdout,"  Field_Count= %d\n",(int)nfld);
    ftlerr("extract_data: bad input data line");        
}

/*---------------------------------------------------------------------------
c  Function to canonicalize the extracted data by filling in missing
c  data points and adjusting volume figures.
*/

void canonicalize_data (APPLICATION *app) {
    /* Handles and adjusts missing and no-volume data points */
    /* to be consistent with our conventions for such data */
    long ibar, imkt, kfirst;
    float p;
    /* for each security or market ... */    
    for(imkt=0; imkt<app->nmkt; imkt++) {
        MARKET *amk = &app->mkt[imkt];
        /* for each bar ... */
        kfirst= -1;
        for(ibar=0; ibar<app->nbar; ibar++) {
            /* if bar has no data (close is zero), then .. */
            if(amk->cls[ibar] < TINYNUM) {
                /* if there is a previous bar, then .. */
                if(ibar > 0) {
                    /* fill in prices with close of previous bar */
                    amk->opn[ibar]= (p= amk->cls[ibar-1]);
                    amk->hi[ibar]= p;
                    amk->lo[ibar]= p;
                    amk->cls[ibar]= p;
                    /* fill in split factor from previous bar */
                    amk->sf[ibar]= amk->sf[ibar-1];  }
                /* set volume to hard zero to indicate absence of data */
                amk->vol[ibar]= 0.0;   }
            /* if bar has data, then .. */
            else {
                /* zero volume should be represented by a soft zero */
                if(amk->vol[ibar] < TINYNUM) amk->vol[ibar]= TINYNUM;
                /* note location of first bar that contains data */
                if(kfirst < 0) kfirst= ibar;  }  }
        if(kfirst < 0) ftlerr("canonicalize_data: no valid data");
        /* for each bar, up to the first that contains data, ... */
        for(ibar=0; ibar<kfirst; ibar++) {
            /* fill prices with close of first bar having valid data */
            amk->opn[ibar]= (p= amk->cls[kfirst]);
            amk->hi[ibar]= p;
            amk->lo[ibar]= p;
            amk->cls[ibar]= p;
            /* set volume to hard zero to mark absence of valid data */
            amk->vol[ibar]= 0.0;
            /* fill in split factor from first bar having valid data */
            amk->sf[ibar]= amk->sf[kfirst];   }   }
}

/*---------------------------------------------------------------------------
c  Function to write the market data in app->mkt[] to a type 939309
c  intraday database file compatible with C-Trader Professional.
*/

void write_database (APPLICATION *app) {
    /* Writes a complete type 939309 intraday portfolio database file */
    char fnbuf[256], symbuf[64];
    long k, ibar, imkt;
    float tmp;
    FILE *fp;
    /* open data file for binary writing */
    sprintf(fnbuf,"%s.dat",(char*)app->dbfn);
    if((fp=fopen(fnbuf,"wb"))==NULL)
	ftlerr("write_database: cannot open database for writing");
    /* write file header */
    k=939309;	/* file type for standard intraday O,H,L,C,V,SF data */
    bwrite(&k,sizeof(long),1,fp);		/* file type identifier */
    bwrite(&app->nbar,sizeof(long),1,fp);	/* number of bars */
    bwrite(&app->nmkt,sizeof(long),1,fp);	/* number of securities */
    /* write common (across securities) dates */
    for(ibar=0; ibar<app->nbar; ibar++) {
        tmp=(float)(app->ldt[ibar]-19000000);	/* need YYYMMDD.0 form */
        bwrite(&tmp,sizeof(float),1,fp);   }
    /* write common (across securities) times */
    for(ibar=0; ibar<app->nbar; ibar++) {
        tmp=(float)(app->ltm[ibar]);		/* need HHMMSS.0 form */
        bwrite(&tmp,sizeof(float),1,fp);   }
    /* for each security or market ... */
    for(imkt=0; imkt<app->nmkt; imkt++) {
        /* write data series */
        bwrite(app->mkt[imkt].opn,sizeof(float),app->nbar,fp);
        bwrite(app->mkt[imkt].hi,sizeof(float),app->nbar,fp);
        bwrite(app->mkt[imkt].lo,sizeof(float),app->nbar,fp);
        bwrite(app->mkt[imkt].cls,sizeof(float),app->nbar,fp);
        bwrite(app->mkt[imkt].vol,sizeof(float),app->nbar,fp);
        bwrite(app->mkt[imkt].sf,sizeof(float),app->nbar,fp);
        /* write block terminator */
        bwrite(&k,sizeof(long),1,fp);   }
    /* close data file */
    fclose(fp);
    /* open symbol file for binary writing */
    sprintf(fnbuf,"%s.txt",(char*)app->dbfn);
    if((fp=fopen(fnbuf,"wb"))==NULL)
        ftlerr("write_database: cannot open symbol output file");
    /* for each security or market ... */
    for(imkt=0; imkt<app->nmkt; imkt++) {
        /* build string containing symbol and name */
        memset(symbuf,' ',sizeof(char)*50);
        k=strlen(app->mkt[imkt].symbol);
        if(k>8) ftlerr("write_database: ticker symbol too long");
        memcpy(symbuf,app->mkt[imkt].symbol,sizeof(char)*k);
        k=strlen(app->mkt[imkt].name);
        if(k>38) k=38;
        memcpy(symbuf+10,app->mkt[imkt].name,sizeof(char)*k);
        symbuf[50]=(char)13; 
        symbuf[51]=(char)10;
        /* write it to symbol file */
        bwrite(symbuf,sizeof(char),52,fp);   }
    /* close symbol file */
    fclose(fp);
}

/*---------------------------------------------------------------------------
c  General utility functions.
*/

void parsecsv (char *pfld[], long *n, char *pstr) {
        /* extracts fields from a string containing a csv record */
        *n=1;
        pfld[0]=pstr;
        while(*pstr) {
                if(*pstr == ',') {
                        *pstr=0;
                        pfld[*n]=pstr+1;
                        ++(*n);
                }
                ++pstr;
        }
}

long monthtolong (char *mon) {
        /* returns integer corresponding to month abbreviation */
        char *monsym[12]={"JAN","FEB","MAR","APR","MAY","JUN",
                "JUL","AUG","SEP","OCT","NOV","DEC"};
        long i;
        for(i=0; i<12; i++) 
                if(strcmp(monsym[i],mon)==0) return(i+1);
        return(-1);
}

long julday (long mm, long id, long iyyy) {
        /* returns Julian day number given calendar date */
        #define IGREG (15+31L*(10+12L*1582))
        long jul,ja,jy=iyyy,jm;
        if (jy == 0) ftlerr("julday: there is no year zero.");
        if (jy < 0) ++jy;
        if (mm > 2) {
                jm=mm+1;
        } else {
                --jy;
                jm=mm+13;
        }
        jul = (long) (floor(365.25*jy)+floor(30.6001*jm)+id+1720995);
        if (id+31L*(mm+12L*iyyy) >= IGREG) {
                ja=(long)(0.01*jy);
                jul += 2-ja+(long) (0.25*ja);
        }
        return jul;
        #undef IGREG
}

void caldat (long julian, long *mm, long *id, long *iyyy) {
        /* calculates calendar date given Julian day number */
        #define IGREG 2299161
        long ja,jalpha,jb,jc,jd,je;
        if (julian >= IGREG) {
                jalpha=(long)(((float) (julian-1867216)-0.25)/36524.25);
                ja=julian+1+jalpha-(long) (0.25*jalpha);
        } else
                ja=julian;
        jb=ja+1524;
        jc=(long)(6680.0+((float) (jb-2439870)-122.1)/365.25);
        jd=(long)(365*jc+(0.25*jc));
        je=(long)((jb-jd)/30.6001);
        *id=jb-jd-(long) (30.6001*je);
        *mm=je-1;
        if (*mm > 12) *mm -= 12;
        *iyyy=jc-4715;
        if (*mm > 2) --(*iyyy);
        if (*iyyy <= 0) --(*iyyy);
        #undef IGREG
}

long datetoser (long ldt) {
        /* converts YYYYMMDD date to serial (days since Jan 1, 1900) */
        return(julday((ldt/100)%100,ldt%100,ldt/10000)-2415021);
}

long sertodate (long jd) {
        /* converts serial date (days since Jan 1, 1900) to YYYYMMDD */
        long iyyyy, mm, idd;
        caldat(jd+2415021,&mm,&idd,&iyyyy);
        return(10000*iyyyy+100*mm+idd);
}

long dayofweek (long ldt) {
        /* returns day of week (0=Sun, 1=Mon, ... 6=Sat) */
        /* given YYYYMMDD date */
        return((julday((ldt/100)%100,ldt%100,ldt/10000)+1)%7);
}

long hmstosec (long ltm) {
        /* converts 24-hour HHMMSS time to seconds since midnight */
        return(3600*(ltm/10000)+60*((ltm/100)%100)+(ltm%100));
}

long sectohms (long lsec) {
        /* converts seconds since midnight (0..86399) to HHMMSS time */
        return(10000*(lsec/3600)+100*((lsec/60)%60)+(lsec%60));
}

long imonth (long idate) {
        /* returns month 1..12 given a YYYYMMDD date */
        return((idate/100)%100);
}

long iday (long idate) {
        /* returns day 1..31 given a YYYYMMDD date */
        return(idate%100);
}

long iyear (long idate) {
        /* returns year as YYYY given a YYYYMMDD date */
        return(idate/10000);
}

long findflt (float arr[], long n, float val) {
        /* Finds k such that arr[k] <= val < arr[k+1], if possible */
        /* Assumes that arr[n-1] >= arr[n-2] >= ... >= arr[0] */
        /* In case of ties, returned index points to last tied element */
        long ia, ib, k;
        if(val<arr[ia=0]) return(ia);
        if(val>=arr[ib=n-1]) return(ib);
        while(ib-ia>1) {
                if(arr[k=(ia+ib)>>1]>val) ib=k;
                else ia=k;
        }
        if(val==arr[ib]) return(ib);
        return(ia);
}

long findlng (long larr[], long n, long lval) {
        /* Finds k such that larr[k] <= lval < larr[k+1], if possible */
        /* Assumes that larr[n-1] >= larr[n-2] >= ... >= larr[0] */
        /* In case of ties, returned index points to last tied element */
        long ia, ib, k;
        if(lval<larr[ia=0]) return(ia);
        if(lval>=larr[ib=n-1]) return(ib);
        while(ib-ia>1) {
                if(larr[k=(ia+ib)>>1]>lval) ib=k;
                else ia=k;
        }
        if(lval==larr[ib]) return(ib);
        return(ia);
}

long finddbl (double darr[], long n, double dval) {
        /* Finds k such that darr[k] <= dval < darr[k+1], if possible */
        /* Assumes that darr[n-1] >= darr[n-2] >= ... >= darr[0] */
        /* In case of ties, returned index points to last tied element */
        long ia, ib, k;
        if(dval<darr[ia=0]) return(ia);
        if(dval>=darr[ib=n-1]) return(ib);
        while(ib-ia>1) {
                if(darr[k=(ia+ib)>>1]>dval) ib=k;
                else ia=k;
        }
        if(dval==darr[ib]) return(ib);
        return(ia);
}

char* fext (char *fn) {
        /* returns pointer to file extension (including period) */
        /* or to an empty string if no extension is found */
        int i, k;
        for(i=0, k= -1; fn[i]; i++) if(fn[i]=='.') k=i;
        return((k<0)?(""):(&fn[k]));
}

char* fpath (char *fn) {
        /* returns pointer to file path (ending with / or \) */
        /* or to an empty string if no path is found */
        static char mypath[256];
        int i, k;
        for(i=0, k= -1; fn[i]; i++) if(fn[i]=='/' || fn[i]=='\\') k=i;
        if(k<0) return("");
        mypath[k+1]=0;
        return(memcpy(mypath,fn,sizeof(char)*(k+1)));
}

long fexists (char *fn) {
        /* returns 1 if file exists and can be read, 0 otherwise */
        FILE *fp;
        if((fp=fopen(fn,"rb"))==NULL) return(0);
        fclose(fp);
        return(1);
}

char* struprqq (char *str) {
        /* converts string to uppercase */
        int i;
        for(i=0; str[i]; i++) str[i]=toupper(str[i]);
        return(str);
}

void* bmalloc (size_t nbytes) {
        /* checked memory allocation */
        void *ptr;
        if((ptr=malloc(nbytes))==NULL)
                ftlerr("bmalloc: insufficient memory");
        return(ptr);
}

void bseek (FILE *fp, long fpos, int whence) {
        /* checked file seek */
        if(fseek(fp,fpos,whence) || ferror(fp))
                ftlerr("bseek: file seek error");
}

void bread (void *v, size_t n, size_t m, FILE *fp) {
        /* checked file read */
        if(fread(v,n,m,fp)!=m || ferror(fp))
                ftlerr("bread: file read error");
}

void bwrite (void *v, size_t n, size_t m, FILE *fp) {
        /* checked file write */
        if(fwrite(v,n,m,fp)!=m || ferror(fp))
                ftlerr("bwrite: file write error");
}

void ftlerr (char *msg) {
        /* handles fatal errors */
        fprintf(stdout,"\nERROR: %s\n",(char*)msg);
        exit(EXIT_FAILURE);
}


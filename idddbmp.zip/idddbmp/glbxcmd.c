/*
c  glbxcmd.c
c
c  Extracts data from raw Globex transaction files into intermediate
c  binary files and thence into a standard fixed-field text files.
c  Allows bar intervals and trading times to be specified when extracting
c  the data.  This program compiles without error using the GNU gcc
c  compilers on Unix and Linux systems and will most likely work on
c  Windows as well.
c
c  Copyright (C) 2009.
c  Jeffrey Owen Katz, Ph.D.
c  Scientific Consultant Services, Inc.
*/

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>

typedef struct {                /* structure for raw Globex records */
    double  price;              /* price in decimal form */
    double  strikeprice;        /* strike price for options */
    long    time;               /* time in HHMMSS form */
    long    deliverydate;       /* delivery date in YYMM form */
    long    tradedate;          /* GLOBEX file date in YYMMDD form */
    long    entrydate;          /* actual trade date in YYMMDD form */
    long    sequencenumber;     /* trade sequence number */
    long    quantity;           /* number of contracts traded */
    char    commcode[4];        /* commodity code (classic symbol) */
    char    symbol[4];          /* ticker symbol, e.g., "ES" or "NQ" */
    char    type;               /* ' '=future, 'C'=call, 'P'=put */
    char    foispec;            /* 'F'=future, 'O'=option, 'I'=index */
    char    abind;              /* ask-bid indicator */
    char    ccind;              /* 'X'=cancel, 'C'=correction */
    char    cobind;             /* 'C'=close, 'O'=open, 'B'=both */
    char    insertcode;         /* ' ' or 'I' */
    char    cabind;             /* cabinet indicator */
    char    fastlate;           /* fast or late indicator */
    char    validopenexcept[4]; /* valid open exception */
    char    sessionid;          /* session id: 'E'=electronic */
    char    indicativequote;    /* indicative quote */
    char    gmtdiff;            /* time difference to GMT */
} GLOBEXDATA;

/*---------------------------------------------------------------------------
c  Local utility functions
*/

void ftlerr (char msg[]) {
    /* Handles fatal errors */
    fprintf(stderr,"\nERROR: %s!\n",(char*)msg);
    exit(EXIT_FAILURE);
}

void* bmalloc (long nbytes) {
    /* Safely allocates zero-filled memory */
    void *ptr=malloc(nbytes);
    if(!ptr) ftlerr("bmalloc: insufficient memory");
    return(memset(ptr,0,nbytes));
}

char* extstr (char dst[], char src[], int m, int n) {
    /* Converts characters m through n in src to string in dst */
    memcpy(dst,src+m,n-m+1);
    dst[n-m+1]=0;
    return(dst);
}

long extlng (char src[], int m, int n) {
    /* Converts characters m through n in src to integer */
    char buf[20];
    return(atol(extstr(buf,src,m,n)));
}

double extdbl (char src[], int m, int n) {
    /* Converts characters m through n in src to real number */
    char buf[20];
    return(atof(extstr(buf,src,m,n)));
}

char* strtrim (char str[]) {
    /* Trims whitespace characters from end of string */
    char *p=str;
    while(*p) p++;
    while(p>str) {
        p--;
        if(isspace(*p)) *p=0;
        else break;
    }
    return(str);
}

long julday (long mm, long id, long iyyy) {
    /* Returns the Julian day number given a calendar date (month, day
    .  and 4-digit year).  Accurate for dates after Jan 1, 1584.
    .  Verified against equivalent routine in Numerical Recipies.
    .  mm    - month, 1..12
    .  id    - day, 1..31
    .  iyyy  - year, 1584..
    */
    long mc, iyc, jd;
    mc = (18 - mm) >> 4;
    iyc = (iyyy - mc) / 100;
    jd = (36525 * (iyyy - mc)) / 100
        + (306001 * (mm + 1 + 12 * mc)) / 10000
        + id + (iyc >> 2) - iyc + 1720997;
    return(jd);
}

void caldat (long julian, long *mm, long *id, long *iyyy) {
    /* Returns (via pointer variables) the calendar date (month, day
    .  and 4-digit year) given a Julian day number.  Accurate for dates
    .  after Jan 1, 1584.  This routine is the mathematical inverse
    .  of the julday routine above, and has been verified against
    .  the equivalent routine in Numerical Recipies.
    */
    long l, n;
    l = julian + 68569;
    n = (l << 2) / 146097;
    l = l - ((146097 * n + 3) >> 2);
    *iyyy = (4000 * (l + 1)) / 1461001;
    l = l - ((1461 * *iyyy) >> 2) + 31;
    *mm = (80 * l) / 2447;
    *id = l - (2447 * *mm) / 80;
    l = *mm / 11;
    *mm = *mm + 2 - 12 * l;
    *iyyy = 100 * (n - 49) + *iyyy + l;
}

long datetoserial (long iymd) {
    /* Converts a YYMMDD date to a serial date.
    .  Years from 50 through 99 are mapped to 19XX before
    .  conversion, while years from 00 through 49 are mapped
    .  to 20XX.
    */
    static long basedate=0;
    long iyyyy, imm, idd;
    if(basedate==0) basedate=julday(1,1,1900);
    iyyyy=(iymd/10000)%100;
    imm=(iymd/100)%100;
    idd=iymd%100;
    iyyyy=((iyyyy<50)?(iyyyy+2000):(iyyyy+1900));
    return(julday(imm,idd,iyyyy)-basedate+1);
}

long serialtodate (long jd) {
    /* Converts a serial date to a YYMMDD date.
    .  This is the inverse of datetoserial().
    */
    static long basedate=0;
    long imm, idd, iyyyy;
    if(basedate==0) basedate=julday(1,1,1900);
    caldat(jd+basedate-1,&imm,&idd,&iyyyy);
    iyyyy=((iyyyy<2000)?(iyyyy-1900):(iyyyy-2000));
    return(10000*iyyyy+100*imm+idd);
}

long month (long iymd) { return((iymd/100)%100); }
long dayofmonth (long iymd) { return(iymd%100); }
long year (long iymd) { return((iymd/10000)%100); }  /* YYMMDD form */

long dayofweek (long iymd) {
    /* Returns the day of week: 0=Sunday, 1=Monday, ... 6=Saturday.
    .  Input date is assumed to be in YYMMDD form.
    */
    long jd;
    iymd=((iymd<500000)?(iymd+20000000):(iymd+19000000));
    jd=julday((iymd/100)%100,iymd%100,iymd/10000);
    return((jd+1)%7);
}

long thirdfriday (long iymd) {
    /* Returns YYYMMDD date of 3rd Friday of month.
    .  Input date is assumed to be in YYMMDD form.
    */
    long jd, imm, idd, iyyyy, jd1;
    iymd=((iymd<500000)?(iymd+20000000):(iymd+19000000));
    imm=(iymd/100)%100;
    idd=iymd%100;
    iyyyy=iymd/10000;
    jd=jd1=julday(imm,1,iyyyy);
    while(((jd+1)%7)!=5) jd++;
    jd+=14;
    if(idd>jd-jd1+1) {
	imm+=1;
	if(imm>12) { imm-=12; iyyyy+=1; }
	jd=julday(imm,1,iyyyy);
        while(((jd+1)%7)!=5) jd++;
        jd+=14;
    }
    caldat(jd,&imm,&idd,&iyyyy);
    iyyyy=((iyyyy<2000)?(iyyyy-1900):(iyyyy-2000));
    return(10000*iyyyy+100*imm+idd);
}

long nexttradingday (long iymd) {
    /* Returns YYYMMDD date for the next business (non-weekend) day */
    long jd, idd, imm, iyyyy;
    iymd=((iymd<500000)?(iymd+20000000):(iymd+19000000));
    jd=julday((iymd/100)%100,iymd%100,iymd/10000)+1;
    while(((jd+2)%7)<2) jd++;
    caldat(jd,&imm,&idd,&iyyyy);
    iyyyy=((iyyyy<2000)?(iyyyy-1900):(iyyyy-2000));
    return(idd+100*imm+10000*iyyyy);
}

long tmtosec (long hms) {
    /* Converts HHMMSS time to seconds-past-midnight time */
    long hh, mm, ss;
    ss=hms%100;
    mm=(hms/100)%100;
    hh=(hms/10000)%100;
    return(ss+60*mm+3600*hh);
}

long sectotm (long sec) {
    /* Converts seconds-past-midnight time to HHMMSS time */
    long hh, mm, ss;
    hh=sec/3600;
    sec=sec-3600*hh;
    mm=sec/60;
    ss=sec-60*mm;
    return(10000*hh+100*mm+ss);
}

double poweroften (long k) {
    /* Calculates an integer power of 10 */
    double r=1.0;
    while(k--) r*=10.0;
    return(r);
}

int islisted (long list[], long nlist, long lval) {
    /* Determines whether a given integer is present in a list */
    static long lprev= -123456789;
    long i;
    if(lval==lprev || nlist==0) return(1);  /* assumes list unchanged */
    else {
        for(i=0; i<nlist; i++) {
            if(list[i]==lval) {
                lprev=lval;
                return(1);
            }
        }
    }
    return(0);
}

char* strlwrqq (char str[]) {
    /* Converts string to lower case */
    char *p;
    for(p=str; *p; p++) *p = tolower(*p);
    return(str);
}

/*---------------------------------------------------------------------------
c  Functions to read and process Globex data
*/

int readrecord (FILE *fil, GLOBEXDATA *gd) {
    /* Reads a single data record from a Globex transaction file */
    static char buf[256];
    if(!fgets(buf+1,sizeof(buf)-1,fil)) return(-1);
    strtrim(extstr(gd->symbol,buf,1,3));
    gd->type=buf[4];
    gd->deliverydate=extlng(buf,5,8);  /* YYMM form */
    gd->foispec=buf[9];
    gd->strikeprice=extdbl(buf,10,16)/poweroften(extlng(buf,51,51));
    gd->time=extlng(buf,17,22);  /* HHMMSS form */
    gd->price=extdbl(buf,23,29)/poweroften(extlng(buf,50,50));
    gd->abind=buf[30];
    gd->ccind=buf[31];
    gd->cobind=buf[32];
    gd->insertcode=buf[33];
    gd->sequencenumber=extlng(buf,34,41);
    gd->tradedate=extlng(buf,42,47);  /* YYMMDD form */
    strtrim(extstr(gd->commcode,buf,48,49));
    gd->cabind=buf[52];
    gd->fastlate=buf[53];
    extstr(gd->validopenexcept,buf,54,55);
    gd->entrydate=extlng(buf,56,61);  /* YYMMDD form */
    gd->quantity=extlng(buf,62,66);
    gd->sessionid=buf[67];
    gd->indicativequote=buf[68];
    gd->gmtdiff=buf[70];
    return(0);
}

void showsymbols (FILE *destfil, char srcfn[]) {
    /* Writes a list of the distinct symbols and data types in a
    .  Globex transaction file to an output file or the console
    */
    static FILE *srcfil;
    static GLOBEXDATA gd;
    static char prevsym[4], prevcomm[4], prevfoi, prevtype;
    strcpy(prevsym," ");
    strcpy(prevcomm," ");
    prevfoi=' ';
    prevtype=' ';
    srcfil=fopen(srcfn,"rt");
    if(!srcfil) ftlerr("showsymbols: cannot find source file");
    fprintf(destfil,"%-14s %-6s %-6s %-6s %-6s %-8s\n",
        "FILENAME","SYMBOL","CODE","FOI","TYPE","DLVR");
    while(readrecord(srcfil,&gd)==0) {
        if(strcmp(gd.commcode,prevcomm)!=0 || strcmp(gd.symbol,prevsym)!=0
        || gd.foispec!=prevfoi || gd.type!=prevtype) {
            fprintf(destfil, "%-14s %-6s %-6s %-6c %-6c %-8ld\n",
                (char*)srcfn, (char*)gd.symbol, (char*)gd.commcode,
                (char)gd.foispec, (char)gd.type, (long)gd.deliverydate );
            strcpy(prevsym,gd.symbol);
            strcpy(prevcomm,gd.commcode);
            prevfoi=gd.foispec;
            prevtype=gd.type;
        }
    }
    fclose(srcfil);
}

void append (char inpfn[], char outfn[], char sym[], long dlvry, long nbrsz) {
    /* Appends 24-hour Globex input data to an intermediate nbrsz-second bar
    .  binary output file of type 939383.  Routine handles only futures
    .  (not options) data, and only years 1951 through 2049.
    .  inpfn   -  input (Globex transaction) data file path and name
    .  outfn   -  output (binary nbrsz-second bar) data file path and name
    .  sym     -  commodity futures symbol, e.g., "ES" or "NQ"
    .  dlvry   -  delivery date in YYMM form, e.g., 0212 or 0303
    .  nbrsz   -  number of seconds in each bar of output data
    .  Warning: nbrsz must be evenly divisible into 86400
    */
    static FILE *ifil, *ofil;
    static GLOBEXDATA gd;
    static float d[6], dprev[6];
    static long fileid, rc, iflag, nbar, nbarold, date0;
    static long mdays, msecs, datenow, timenow, count;
    static long bar, k, firstfilledbar;
    static char *ibuf;

    /* validate specified bar interval */
    if((86400%nbrsz)!=0) ftlerr("append: invalid bar size");

    /* open and buffer input data file */
    ifil=fopen(inpfn,"rt");
    if(!ifil) ftlerr("append: cannot find input file");
    rc=setvbuf(ifil,(ibuf=bmalloc(500000)),_IOFBF,500000);
    if(rc) ftlerr("append: cannot buffer input file");

    /* open or create unbuffered output data file */
    ofil=fopen(outfn,"rb+");
    if(ofil) {
        setbuf(ofil,NULL);
        printf("OPENING OUTPUT FILE FOR APPENDING\n");
    }
    else {
        printf("CREATING NEW OUTPUT FILE\n");
        ofil=fopen(outfn,"wb+");
        if(ofil==NULL) ftlerr("append: cannot create output file");
        setbuf(ofil,NULL);
        fileid=939383;
        nbar=0;
        iflag=1;
        rc=fwrite(&fileid,4,1,ofil);    /* file identifier code */
        rc+=fwrite(&nbar,4,1,ofil);     /* number of bars in file */
        rc+=fwrite(&nbrsz,4,1,ofil);    /* bar interval in seconds */
        rc+=fwrite(&iflag,4,1,ofil);    /* intermediate file flag */
        if(rc!=4 || ferror(ofil))
            ftlerr("append: new output file header write error");
    }

    /* read header data from output file */
    rc=fseek(ofil,0,SEEK_SET);
    rc+=fread(&fileid,4,1,ofil);        /* file identifier code */
    rc+=fread(&nbar,4,1,ofil);          /* number of bars in file */
    rc+=fread(&k,4,1,ofil);             /* bar interval in seconds */
    rc+=fread(&iflag,4,1,ofil);         /* intermediate file flag */
    printf("BARS BEFORE APPENDING NEW DATA: %ld\n",(long)nbar);
    if(rc!=4 || ferror(ofil))
        ftlerr("append: output file header read error");
    if(fileid!=939383) ftlerr("append: invalid output file identifier");
    if(nbar<0) ftlerr("append: invalid output file bar count");
    if(k!=nbrsz) ftlerr("append: mismatched bar size");
    if(iflag!=1) ftlerr("append: output file not flagged appendable");
    nbarold=nbar;

    /* initialize starting date for output file */
    if(nbar==0) {
        date0= -1;      /* flag new file not yet having data */
    }
    else {
        rc=fseek(ofil,16,SEEK_SET);
        rc+=fread(d,4,6,ofil);
        if(rc!=6 || ferror(ofil))
            ftlerr("append: output first record read error");
	printf("INITIAL DATE (YYMMDD): %06ld\n",(long)d[0]);
	if((long)d[0]<100) ftlerr("append: output file first date bad");
	date0=datetoserial((long)d[0]);
    }

    /* read each tick in Globex input transaction file ... */
    count= -9999;
    while(readrecord(ifil,&gd)==0) {

        /* exclude irrelevant ticks */
        if(strcmp(gd.symbol,sym)!=0) continue;
        if(gd.type!=' ' || gd.foispec!='F') continue;
        if(gd.indicativequote=='I') continue;
        if(gd.deliverydate!=dlvry) continue;
        if(gd.abind=='A' || gd.abind=='B') continue;

        /* set initial date if this is the first bar in file */
	if(date0<0) date0=datetoserial((long)gd.entrydate);

        /* calculate seconds since midnight on initial date */
	mdays=datetoserial((long)gd.entrydate)-date0;
        if(mdays<0) ftlerr("append: bad mdays or input file order");
        msecs=86400*mdays+tmtosec(gd.time);

        /* determine bar index */
        if(msecs<0) continue;
        bar=msecs/nbrsz;

        /* extend file with empty bars if necessary */
        if(bar>=nbar) {
            memset(d,0,24);
            for(k=nbar; k<=bar; k++) {
                rc=fseek(ofil,16+24*k,SEEK_SET);
                rc+=fwrite(d,4,6,ofil);
                if(rc!=6 || ferror(ofil))
                    ftlerr("append: error extending file");
            }
            nbar=bar+1;
        }

        /* update specified bar in output file */
        rc=fseek(ofil,16+24*bar,SEEK_SET);
        rc+=fread(d,4,6,ofil);
        if(rc!=6 || ferror(ofil))
            ftlerr("append: update read error");
        if(d[0]<=0.0) {
            /* initialize bar */
            /* date of close of bar as float in YYMMDD form */
	    d[0]=serialtodate(((bar+1)*nbrsz)/86400+date0);
            /* time of close of bar as float in HHMMSS form */
            d[1]=sectotm(((bar+1)*nbrsz)%86400);
            d[2]=gd.price;
            d[3]=gd.price;
            d[4]=gd.price;
            d[5]=gd.quantity;
        }
        else {
            /* update bar */
	    datenow=serialtodate(((bar+1)*nbrsz)/86400+date0);
            timenow=sectotm(((bar+1)*nbrsz)%86400);
            if(datenow!=(long)d[0]) ftlerr("append: date mismatch");
            if(timenow!=(long)d[1]) ftlerr("append: time mismatch");
            if(gd.price>d[2]) d[2]=gd.price;
            if(gd.price<d[3]) d[3]=gd.price;
            d[4]=gd.price;
            d[5]+=gd.quantity;
        }
        rc=fseek(ofil,16+24*bar,SEEK_SET);
        rc+=fwrite(d,4,6,ofil);
        if(rc!=6 || ferror(ofil))
            ftlerr("append: output update write error");
        if(nbar>count+500) {
            printf("PROGRESS: %ld\r",(long)nbar);
            count=nbar;
        }
    }
    printf("\nBARS AFTER APPENDING NEW DATA: %ld\n",(long)nbar);

    /* fill in all missing bars and check dates and times */
    if(nbar==nbarold || nbar==0) goto APPEND_DONE;
    printf("FILLING MISSING BARS AND CHECKING DATES AND TIMES\n");
    firstfilledbar= -1;
    for(bar=nbarold; bar<nbar; bar++) {
        if(bar%500==0 || bar==nbar-1)
            printf("PROGRESS: %ld\r",(long)(bar+1));
	datenow=serialtodate(((bar+1)*nbrsz)/86400+date0);
        timenow=sectotm(((bar+1)*nbrsz)%86400);
        rc=fseek(ofil,16+24*bar,SEEK_SET);
        rc+=fread(d,4,6,ofil);
        if(rc!=6 || ferror(ofil)) ftlerr("append: check read error");
        if(d[0]>0.0) {
            /* data exists in bar so just check time and date */
            if(d[0]!=datenow) ftlerr("append: check date error");
            if(d[1]!=timenow) ftlerr("append: check time error");
            if(nbarold==0 && firstfilledbar<0) firstfilledbar=bar;
        }
        else {
            /* no data exists in bar so fill-in from previous bar */
            if(bar==0) memcpy(dprev,d,24);
            else if(bar==nbarold) {
                rc=fseek(ofil,16+24*(bar-1),SEEK_SET);
                rc+=fread(dprev,4,6,ofil);
                if(rc!=6 || ferror(ofil))
                    ftlerr("append: check read previous error");
            }
            d[0]=datenow;
            d[1]=timenow;
            d[2]=dprev[4];
            d[3]=dprev[4];
            d[4]=dprev[4];
            d[5]=0.0;   /* no volume when data is from previous bar */
            rc=fseek(ofil,16+24*bar,SEEK_SET);
            rc+=fwrite(d,4,6,ofil);
            if(rc!=6 || ferror(ofil)) ftlerr("append: check write error");
        }
        memcpy(dprev,d,24);
    }
    printf("\n");

    /* fill in initial bars using first filled bar for data */
    if(firstfilledbar > 0) {
        printf("FILLING IN EARLY BARS\n");
        rc=fseek(ofil,16+24*firstfilledbar,SEEK_SET);
        rc+=fread(&dprev,4,6,ofil);
        if(rc!=6 || ferror(ofil))
            ftlerr("append: first block read error");
        for(bar=0; bar<firstfilledbar; bar++) {
            if(bar%500==0 || bar==firstfilledbar-1)
                printf("PROGRESS: %ld\r",(long)(bar+1));
	    datenow=serialtodate(((bar+1)*nbrsz)/86400+date0);
            timenow=sectotm(((bar+1)*nbrsz)%86400);
            d[0]=datenow;
            d[1]=timenow;
            d[2]=dprev[4];
            d[3]=dprev[4];
            d[4]=dprev[4];
            d[5]=0.0;
            rc=fseek(ofil,16+24*bar,SEEK_SET);
            rc+=fwrite(d,4,6,ofil);
            if(rc!=6 || ferror(ofil))
                ftlerr("append: first block write error");
        }
        printf("\n");
    }

    /* update bar count in output file header */
    rc=fseek(ofil,4,SEEK_SET);
    rc+=fwrite(&nbar,4,1,ofil);
    if(rc!=1 || ferror(ofil)) ftlerr("append: barcount update error");

    /* close up and return */
    APPEND_DONE:;
    fclose(ifil);
    fclose(ofil);
    free(ibuf);
    printf("APPEND DONE!\n");
}

void convert (char inpfn[], char outfn[], char mode[], long nsec,
long stime, long etime, long dates[], long ndate) {
    /* Converts this program's intermediate binary format (type 939383)
    .  to other formats.  Dates in output are in YYMMDD form and times
    .  in HHMMSS form.  Routine is valid for years from 1951 through 2049.
    .  inpfn: input intermediate binary data file path and name
    .  outfn: output (type as set by mode) data file path and name
    .  mode:  output file type
    .    "ba" - binary all bars
    .    "bv" - binary active bars only
    .    "ta" - text all bars (fixed-field, space-delimited)
    .    "tv" - text active bars only (fixed-field, space-delimited)
    .  nsec:  output bar size in seconds (must divide evenly into 86400
    .           and be an integer multiple of the intermediate bar size)
    .  stime: start time (in HHMMSS form, to restrict time of day)
    .  etime: end time (to restrict time of day)
    .  dates: dates (in YYMMDD form) for which data is desired
    .  ndate: number of dates, or 0 for no date filtering
    */
    static FILE *ifil, *ofil;
    static long nbar, rc, fileid, i, nbarout, nbrsz, iflag;
    static float ain[6], aout[6];
    static char *fbuf;

    /* check specified bar size */
    if((86400%nsec)!=0) ftlerr("convert: invalid nsec");

    /* open binary nbrsz-second bar input file and read header data */
    ifil=fopen(inpfn,"rb");
    if(!ifil) ftlerr("convert: cannot find input file");
    rc=fread(&fileid,4,1,ifil); /* file type identifier */
    rc+=fread(&nbar,4,1,ifil);  /* number of bars */
    rc+=fread(&nbrsz,4,1,ifil); /* bar interval in seconds */
    rc+=fread(&iflag,4,1,ifil); /* intermediate file flag */
    if(rc!=4) ftlerr("convert: input file header read error");
    if(fileid!=939383) ftlerr("convert: invalid input fileid");
    if(iflag!=1) ftlerr("convert: input file not intermediate type");
    if(nbar<50) ftlerr("convert: input file too few bars");
    if((nsec%nbrsz)!=0) ftlerr("convert: invalid nsec");

    /* open and buffer output file in specified mode */
    switch(mode[0]) {
        case 'b': ofil=fopen(outfn,"wb"); break;
        case 't': ofil=fopen(outfn,"wt"); break;
        default: ftlerr("convert: invalid mode argument");
    }
    if(ofil==NULL) ftlerr("convert: cannot open output file");
    rc=setvbuf(ofil,(fbuf=bmalloc(500000)),_IOFBF,500000);
    if(rc) ftlerr("convert: unable to buffer output");

    /* position output file for writing data */
    if(mode[0]=='b') {
        rc=fseek(ofil,16,SEEK_SET);
        if(rc) ftlerr("convert: pre-write seek error");
    }

    /* extract data and adjust time frame */
    nbarout=0;
    aout[2]= -1.0E32;
    aout[3]=1.0E32;
    aout[5]=0.0;
    for(i=0; i<nbar; i++) {
        rc=fread(ain,4,6,ifil);
        if(rc!=6 || ferror(ifil))
            ftlerr("convert: input record read error");
        aout[0]=ain[0];                         /* YYMMDD date */
        aout[1]=ain[1];                         /* HHMMSS time */
        if(ain[2]>aout[2]) aout[2]=ain[2];      /* high price */
        if(ain[3]<aout[3]) aout[3]=ain[3];      /* low price */
        aout[4]=ain[4];                         /* last price */
        aout[5]+=ain[5];                        /* tick volume */
        if((tmtosec(ain[1]) % nsec) == 0) {
            if((mode[1]=='v' && aout[5]>0.0) || mode[1]=='a') {
                if(stime<=aout[1] && aout[1]<=etime
                && islisted(dates, ndate, aout[0])) {
                    nbarout++;
                    if(mode[0]=='b') {
                        rc=fwrite(aout,4,6,ofil);
                        if(rc!=6 || ferror(ofil))
                            ftlerr("convert: binary write error");
                    }
                    else if(mode[0]=='t') {
			fprintf(ofil,"%06ld %06ld%12.4f%12.4f%12.4f%8ld\n",
                            (long)aout[0], (long)aout[1], (float)aout[2],
                            (float)aout[3], (float)aout[4], (long)aout[5]);
                        if(ferror(ofil)) ftlerr("convert: text write error");
                    }
                    else ftlerr("convert: invalid mode argument");
                }
            }
            aout[2]= -1.0E32;
            aout[3]=1.0E32;
            aout[5]=0.0;
        }
    }
    printf("TOTAL BARS WRITTEN: %d\n",(int)nbarout);

    /* write output file header data */
    if(mode[0]=='b') {
        iflag=0;
        rc=fseek(ofil,0,SEEK_SET);
        rc+=fwrite(&fileid,4,1,ofil);
        rc+=fwrite(&nbarout,4,1,ofil);
        rc+=fwrite(&nsec,4,1,ofil);
        rc+=fwrite(&iflag,4,1,ofil);
        if(rc!=4 || ferror(ofil))
            ftlerr("convert: output header write error");
    }

    /* close up and return */
    fclose(ofil);
    fclose(ifil);
    free(fbuf);
    printf("DONE!\n");
}

void activedays (char inpfn[], char outfn[], long stime, long etime) {
    /* Automatically determines active trading days using data in this
    .  program's intermediate binary format.  Writes the active
    .  dates to an output file which may be used as input to convert()
    .  as a date filter.  Works by examining volume levels.  Note that
    .  this routine is valid only for years from 1951 through 2049.
    .  inpfn:  input intermediate binary data file path and name
    .  outfn:  output dates file name (YYMMDD, ASCII format)
    .  stime:  start time in HHMMSS for examining volume data
    .  etime:  end time in HHMMSS for examining volume data
    */
    static FILE *ifil, *ofil;
    static long rc, fileid, nbar, nbrsz, iflag, nbarsinday, ibar;
    static long iday, ibarinday, *idates, *ivols, maxday, nday;
    static float d[6];
    static double avgvol;

    /* open binary nbrsz-second bar input file and read header data */
    ifil=fopen(inpfn,"rb");
    if(!ifil) ftlerr("activedays: cannot find input file");
    rc=fread(&fileid,4,1,ifil); /* file type identifier */
    rc+=fread(&nbar,4,1,ifil);  /* number of bars */
    rc+=fread(&nbrsz,4,1,ifil); /* bar interval in seconds */
    rc+=fread(&iflag,4,1,ifil); /* intermediate file flag */
    if(rc!=4) ftlerr("activedays: input file header read error");
    if(fileid!=939383) ftlerr("activedays: invalid input fileid");
    if(iflag!=1) ftlerr("activedays: input file not intermediate type");
    if(nbar<10) ftlerr("activedays: input file too few bars");

    /* allocate array memory */
    nbarsinday=86400/nbrsz;
    maxday=2+nbar/nbarsinday;
    idates=bmalloc(4*maxday);
    ivols=bmalloc(4*maxday);

    /* display some statistics */
    fprintf(stdout,"NBARSINDAY: %d\n",(int)nbarsinday);
    fprintf(stdout,"NBRSZ: %d\n",(int)nbrsz);
    fprintf(stdout,"NBAR: %d\n",(int)nbar);
    fprintf(stdout,"MAXDAY: %d\n",(int)maxday);

    /* loop over days */
    for(iday=0, ibar=0; iday<maxday; iday++) {

        /* loop over bars in day */
        nday=iday+1;
        for(ibarinday=0; ibarinday<nbarsinday; ibarinday++) {

            /* read a data record */
            rc=fread(d,4,6,ifil);
            if(rc!=6) ftlerr("activedays: error reading input record");

            /* accumulate volume over specified times of day */
            if(d[1]>=stime && d[1]<etime) {
                ivols[iday]+=(long)d[5];
                idates[iday]=(long)d[0];
            }

            /* check whether there are more bars to analyze */
            if(++ibar>=nbar) goto X1;
        }
    }
    X1:  /* no more bars or records to process so exit loop */

    /* close input data file */
    fclose(ifil);

    /* write active trading dates to output file */
    ofil=fopen(outfn,"wt");
    if(ofil==NULL) ftlerr("activedays: cannot open output file");
    for(iday=0, avgvol=0.0; iday<nday; iday++)
        avgvol+=((double)ivols[iday]);
    avgvol=avgvol/nday;
    for(iday=0; iday<nday; iday++)
        if(ivols[iday]>0.05*avgvol)
	    fprintf(ofil,"%06ld\n",(long)idates[iday]);
    fclose(ofil);

    /* free memory and return */
    free(ivols);
    free(idates);
}

/*---------------------------------------------------------------------------
c  Debugging code
*/

void debug_aa (void) {
    /* test the tmtosec and sectotm functions */
    long k, i;
    for(k=0; k<86400; k++) {
        i=sectotm(k);
        if(k!=tmtosec(i)) {
            printf("i=%ld k=%ld\n",(long)i,(long)k);
            ftlerr("bug");
        }
    }
    exit(EXIT_SUCCESS);
}

void debug_ab (void) {
    /* test bar indexing with dates and times */
    long k, i, time0, date0, datex, timex, datez, timez, nbrsz;
    long bar, mdays, msecs;
    time0=0;  nbrsz=5;
    date0=datetoserial(1000000 + 020304);
    for(i=0; i<3; i++) {
        datex=serialtodate(date0+i)-1000000;
        for(k=0; k<86400; k++) {
            if(k>150 && k<86250) continue;
            timex=sectotm(k);
            /* datex and timex represent raw Globex data */
            /* calculate bar index from datex and timex */
            mdays=datetoserial(1000000+datex)-date0;
            msecs=86400*mdays+tmtosec(timex)-time0;
            bar=msecs/nbrsz;
            /* calculate datez and timez from bar index */
            bar=bar+1;
            datez=serialtodate((bar*nbrsz+time0)/86400+date0)-1000000;
            timez=sectotm((bar*nbrsz+time0)%86400);
            printf("%6ld %6ld  %6ld %6ld %6ld\n",(long)datex,(long)timex,
                (long)bar,(long)datez,(long)timez);
        }
    }
    exit(EXIT_SUCCESS);
}

void debug_ac (void) {
    /* test readrecord function */
    FILE *ifil;  int i;
    static GLOBEXDATA gd;
    ifil=fopen("gx021203.iom","rt");
    for(i=0; i<1000; i++) {
        readrecord(ifil, &gd);
        if(strcmp(gd.symbol,"ES")!=0) continue;
        printf("%4s %c %8ld %8ld %8ld %8.4lf %8ld %c\n",
            gd.symbol, gd.type, gd.time, gd.entrydate,
            gd.deliverydate, gd.price, gd.quantity,
            gd.abind);
    }
    fclose(ifil);
}

/*---------------------------------------------------------------------------
c  Main entry and control function for Globex data handler
*/

int main (int narg, char **args) {
    static char *extensions[4]={"iom","cme","gem","imm"};
    static char *inpfn, *outfn, *symbol, *mode;
    static long k, idate, nsec, dlvry, stime, etime, ndate, *dates;
    static int itask, rc;
    static FILE *ifil;

    /* Check compiler variable size assumptions */
    rc=((sizeof(double)==8)&&(sizeof(float)==4)&&(sizeof(long)==4)
        &&(sizeof(int)==4)&&(sizeof(short)==2)&&(sizeof(char)==1));
    if(!rc) ftlerr("main: invalid compiler variable size assumptions");

    #if 1==0
      /* Used for debugging */
      debug_ab();
      activedays("ES5.BIN","JUNK.TXT",83005,151000);
      exit(0);
    #endif

    /* Provide user help */
    if(narg==1 || (narg==2 && strcmp(args[1],"--help")==0)) {
        printf( "Usage:\n"
            "List all symbols in raw Globex data files for given date:\n"
            "       glbxcmd 1 fdate\n"
            "Extract or append to an nsec-second bar intermediate file:\n"
            "       glbxcmd 2 inpfn outfn symbol dlvry nsec\n"
            "Convert from intermediate to other formats and timeframes:\n"
            "       glbxcmd 3 inpfn outfn mode nsec [stime etime [dtfn]]\n"
            "Create list of active trading dates:\n"
            "       glbxcmd 4 inpfn outfn stime etime\n"
            "In all commands:\n"
            "    mode:   ba=binary output, all bars\n"
            "            bv=binary output, active bars only\n"
            "            ta=fixed-field text output, all bars\n"
            "            tv=fixed-field text output, active bars only\n"
            "    nsec:   bar interval in seconds\n"
            "    fdate:  file date in YYMMDD format, e.g., 021204\n"
            "    dlvry:  delivery date in YYMM format, e.g., 0212\n"
            "    inpfn:  input file name and path\n"
            "    outfn:  output file name and path\n"
            "    stime:  start time in HHMM form (limits trading day)\n"
            "    etime:  end time in HHMM form (limits trading day)\n"
            "    dtfn:   date list file name\n"
        );
        exit(EXIT_FAILURE);
    }

    /* Perform requested task */
    if(narg<3) ftlerr("glbxcmd: too few arguments");
    itask=atoi(args[1]);
    switch(itask) {
    case 1:
        /* Display symbol list from Globex files on specified date */
        if(narg!=3) ftlerr("glbxcmd: wrong argument count");
        idate=atol(args[2]);
        if(idate<101 || idate>100101) ftlerr("glbxcmd: bad fdate argument");
        inpfn=bmalloc(128);
        for(k=0; k<4; k++) {
            sprintf(inpfn,"gx%06ld.%s",(long)idate,extensions[k]);
            showsymbols(stdout,inpfn);
        }
        free(inpfn);
        break;
    case 2:
        /* Append nsec-second bars to intermediate binary output file. */
        /* Note that all bars, around the clock, are appended, even */
        /* if some of these bars are empty and on days when the market */
        /* is closed.  Empty bars, of course, are are indicated by */
        /* zero volume figures (no transactions) */
        if(narg!=7) ftlerr("glbxcmd: wrong argument count");
        inpfn=args[2];	     /* input Globex file spec */
        outfn=args[3];	     /* output (intermediate binary) file spec */
        symbol=args[4];	     /* commodity symbol */
        dlvry=atol(args[5]); /* delivery date */
        nsec=atol(args[6]);  /* bar interval in seconds */
        if(strlen(inpfn)<1 || strlen(outfn)<1 || strlen(symbol)<1)
            ftlerr("glbxcmd: bad file name or symbol argument");
        if(dlvry>1300 || dlvry<1) ftlerr("glbxcmd: bad dlvry argument");
        if((86400%nsec)!=0)
            ftlerr("glbxcmd: nsec not evenly divisible into 86400");
        append(inpfn,outfn,symbol,dlvry,nsec);
        break;
    case 3:
        /* Read intermediate binary data (see case 2: above) and */
        /* date list (see case 4: below) and write an output file */
        /* with the specified bar interval, trading period, and format */
        if(narg!=6 && narg!=8 && narg!=9)
            ftlerr("glbxcmd: wrong argument count");
        inpfn=args[2];		/* input (intermediate binary) file spec */
        outfn=args[3];		/* output file spec */
        mode=strlwrqq(args[4]);	/* output file format and contents */
        nsec=atol(args[5]);	/* output bar interval */
        if(narg==8 || narg==9) {
            stime=100*atol(args[6]);	/* start time */
            etime=100*atol(args[7]);	/* end time */
        }
        else {
            stime= -999999;
            etime=999999;
        }
        if(strlen(inpfn)<1 || strlen(outfn)<1 || nsec<1)
            ftlerr("glbxcmd: bad file name or nsec argument");
        ndate=0;
        dates=NULL;
        if(narg==9) {
            #define MAXDATES 1750
            dates=bmalloc(4*MAXDATES);
            ifil=fopen(args[8],"rt");
            if(!ifil) ftlerr("convert: unable to find date file");
            while(fscanf(ifil,"%ld",&dates[ndate])==1) ndate++;
            fclose(ifil);
            #undef MAXDATES
        }
        printf("NUMBER OF DATES: %ld\n",(long)ndate);
        convert(inpfn,outfn,mode,nsec,stime,etime,dates,ndate);
        if(dates) free(dates);
        break;
    case 4:
        /* Based on data in the intermediate binary file, create */
        /* a list of dates on which there is active trading, that */
        /* is, an open market.  The date list is required when */
        /* creating output files (for use by other programs) from */
        /* the intermediate binary files used by this program. */
        if(narg!=6) ftlerr("glbxcmd: wrong argument count");
        inpfn=args[2];	/* input intermediate binary file spec */
        outfn=args[3];	/* output date list file spec */
        if(strlen(inpfn)<1 || strlen(outfn)<1)
            ftlerr("glbxcmd: bad inpfn or outfn argument");
        stime=100*atol(args[4]);  /* start time */
        etime=100*atol(args[5]);  /* end time */
        activedays(inpfn,outfn,stime,etime);
        break;
    default:
        ftlerr("main: invalid task request");
    }
    exit(EXIT_SUCCESS);
    return(0);
}


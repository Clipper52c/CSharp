/*
c  glbxrun.c
c
c  Automates the process of extracting and appending Globex data residing
c  in multiple zipfiles in the Globex ZIPPATH directory for a given range
c  of dates to a specified brsec-second bar intermediate binary data file.
c  The current directory (from which this software is run) must contain
c  the glbxcmd executable and unzip must be on the path or an error will 
c  result.  This program was developed and tested on a Linux system using
c  the standard GNU tools.
c
c  Note: be sure to change ZIPPATH to be appropriate for your system!
c
c  Copyright (C) 2009.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D.
c  Scientific Consultant Services Inc.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Specify location of Globex transaction zip files */
#define ZIPPATH "/home/jkatz/mktdata/idddata/"


void ftlerr (char msg[]) {
    /* Handles fatal errors */
    fprintf(stderr,"\nERROR: %s!\n",msg);
    exit(EXIT_FAILURE);
}

char* chgext (char fn[], char ext[]) {
    /* Changes file extension */
    int i, k, n;
    n=strlen(fn);
    for(i=n-1, k=n; i>=0; i--) if(fn[i]=='.') { k=i; break; }
    fn[k]='.';  fn[k+1]=0;
    return(strcat(fn,ext));
}

char* strtrim (char str[]) {
    /* Trims whitespace characters from end of string */
    char *p;
    for(p=str+strlen(str)-1; p>=str && isspace(*p); --p) *p=0;
    return(str);
}

int main (int narg, char **args) {
    static char *flist[4000], *chptr, ffirst[512], flast[512];
    static char zipfn[512], inpfn[512], buf[512];
    static int nlist, r1, r2, i, j, k, rc;
    FILE *fp;

    /* display usage information */
    if(narg==1 || (strcmp(args[1],"--help")==0)) {
	fprintf(stdout, "\nUsage:\n\n"
	    "   glbxrun firstdate lastdate symbol dlvry extn binfn brsec\n"
	    "\nwhere\n\n"
	    "   firstdate: YYMMDD date of first Globex data file to read\n"
	    "   lastdate:  YYMMDD date of last Globex data file to read\n"
	    "   symbol:    commodity symbol (e.g., ES or NQ)\n"
	    "   dlvry:     delivery date (e.g., 0212) in YYMM format\n"
	    "   extn:      input Globex file extension (e.g., IOM)\n"
	    "   binfn:     intermediate binary output file path and name\n"
	    "   brsec:     bar size in seconds (e.g., 1, 5, 20, 60)\n\n"
	);
	exit(EXIT_FAILURE);
    }
    if(narg!=8) ftlerr("glbxrun: wrong number of arguments");

    /* build a list of the zipped Globex data files to be appended */
    sprintf(buf, "ls -1 %sgx*.zip > tmp4bb2782.tmp", (char*)ZIPPATH);
    if(system(buf) != 0)
        ftlerr("glbxrun: cannot create zipfile list in tmp42782.tmp");
    if((fp=fopen("tmp4bb2782.tmp","rt"))==NULL)
        ftlerr("glbxrun: cannot open zipfile list");
    nlist=0;
    sprintf(ffirst,"%sgx%06ld.zip",(char*)ZIPPATH, (long)atol(args[1]));
    sprintf(flast,"%sgx%06ld.zip",(char*)ZIPPATH, (long)atol(args[2]));
    while(fgets(buf,sizeof(buf),fp)) {
        strtrim(buf);
	r1=strcmp(buf, ffirst);
	r2=strcmp(buf, flast);
        #if 1==0
            /* debugging code */
            fprintf(stdout,"%s %s %s  %d %d\n", 
                (char*)ffirst, (char*)flast, (char*)buf, (int)r1, (int)r2);
        #endif	
	if(r1>=0 && r2<=0) {
	    flist[nlist]=strdup(buf);
	    if(flist[nlist]==NULL) 
	        ftlerr("glbxrun: insufficient memory");
	    nlist++;
        }
    }
    fclose(fp);

    /* sort the zipfile list into ascending order of dates */
    for(i=1; i<nlist; i++) {
	for(j=0; j<i; j++) {
	    if(strcmp(flist[i],flist[j])<0) {
		chptr=flist[i];
		flist[i]=flist[j];
		flist[j]=chptr;
	    }
	}
    }
    
    /* remove the no-longer-needed temporary file */
    remove("tmp4bb2782.tmp");

    /* display some useful information on the console */
    printf("FIRST FILE TO APPEND: %s\n", (char*)flist[0]);
    printf("LAST FILE TO APPEND: %s\n", (char*)flist[nlist-1]);
    printf("TOTAL FILES TO APPEND: %d\n\n", (int)nlist);

    /* for each item in the zipfile list ... */
    for(i=0; i<nlist; i++) {

	/* extract the archived (zipped) Globex transaction files */
	strcpy(zipfn, flist[i]);
	chgext(strcpy(buf, flist[i]), args[5]);
	for(k=0, j=0; buf[k]; k++) if(buf[k]=='/') j=k+1;
	strcpy(inpfn, &buf[j]);
	printf("EXTRACTING ARCHIVED FILE %s FROM %s\n", inpfn, zipfn);	
	sprintf(buf, "unzip %s %s", (char*)zipfn, (char*)inpfn);	
	#if 1==0
	    fprintf(stdout, "Unzip command: %s\n", buf);
        #endif
	rc= system(buf);
	if(rc>0) ftlerr("glbxrun: archive extraction failed");
	if(rc<0) ftlerr("glbxrun: system error, unzip not on path");

	/* append extracted data to brsec-second binary data file */
	printf("APPENDING SYMBOL %s WITH DELIVERY %s FROM %s TO %s\n",
	    args[3], args[4], inpfn, args[6]);
        sprintf(buf, "./glbxcmd 2 %s %s %s %s %s",
            inpfn, args[6], args[3], args[4], args[7]);
        rc= system(buf);
	if(rc<0) ftlerr("glbxrun: glbxcmd.exe not found");
	if(rc>0) ftlerr("glbxrun: append failed");

	/* remove the unzipped Globex transaction files */
	/* (original zipfile remains untouched) */
	printf("REMOVING UNARCHIVED GLOBEX FILES %s\n", (char*)inpfn);
	remove(inpfn);
	
    } /* process next list item */
    
    /* free all memory and return */
    for(i=0; i<nlist; i++) free(flist[i]);
    fprintf(stdout, "DONE!\n");
    exit(EXIT_SUCCESS);
    return(EXIT_SUCCESS);
}


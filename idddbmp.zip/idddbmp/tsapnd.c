/*
c  tsapnd.c
c
c  Revised: 2009.08.24
c
c  Extracts intraday market data from comma-seperated-value (CSV) files
c  created with TradeStation and places the extracted data into a
c  type 939309 portfolio database file.  The input CSV files and the
c  target database file must be specified in the tsapnd.cfg configuration
c  file which must reside in the current working directory (the directory
c  from which tsapnd is started).  Dates are derived from the first
c  CSV input file specified in tsapnd.cfg and times are constructed as
c  per user specification.  All data bars are date-and-time-aligned with
c  the constructed dates and times.  Missing data points are handled with
c  prices being filled in with earlier or later prices and volumes being
c  set to hard zeros; volumes are set to soft zeros (tiny positive
c  numbers) for valid bars or data points that simply have no volume.
c
c  File tsapnd.cfg must have the following format:
c
c  Example line contents                       Description
c  =========================================   ==========================
c  OUTPUT_DATABSE=../dbases/mytsdata           target database
c  INPUT_TXTPATH=../idddata/                   path for input files
c  DAY_RANGE: FROM=1 TO=5                      day range filter
c  TIME_RANGE: FROM=93500 TO=161500 STEP=300   time range and bar size
c  SPY   spy_5min.txt                          ticker symbol 1 (primary)
c  ....                                        more tickers as desired
c  ....                                        still more tickers
c  *                                           end-of-list marker
c
c  Day ranges are specified using numbers (0=Sun, 1=Mon, .. 6=Sat) and
c  are inclusive of the endpoints.  Time ranges are specified in
c  24-hour HHMMSS format and, like day ranges, are inclusive of the
c  endpoints; the bar interval, STEP, is specified in seconds and must
c  match the actual bar interval supplied in the input CSV data.
c  The time and date ranges act as filters, allowing only data falling
c  within the ranges to be included in the output; they do not affect
c  or transform the data in any other way.
c
c  Each ticker symbol line must contain the ticker symbol, as it
c  is to appear in the database, and the name of the CSV file
c  from which the data derives.
c
c  Note that TradeStation may use local time for time-stamping its
c  market data.  You can adjust the time-stamps in correct_times(),
c  if desired.  In the present code, the time is adjusted from the
c  Pacific time used in the SPY test data to the New York time that
c  I normally use.
c
c  Also note that TradeStation generates UP and DN volume figures.
c  The volume and split-factor fields (found in the standard type
c  939309 database file) may be used for these if desired.  The
c  code currently adds the two volume figures and places the result
c  into the volume field, leaving the split-factor field fixed at
c  unity.
c
c  Unless modifications are made, this program must be run on Intel
c  (big-endian) hardware and compiled with an ISO-standard 32-bit
c  compiler.  We suggest the GNU gcc compiler which works well
c  under BSD, Linux, and Windows.
c
c  Copyright (C) 2009.  All Rights Reserved.
c  Jeffrey Owen Katz, Ph.D. <jeffkatz@scientific-consultants.com>
c
c
c  Allan Lee Notes:
c  This program uses a date, time, lining algorithm to line up the dates and times.
c  The algorithm for lining up the date, time is all located in the "void extract_times(APPLICATION* app)" function.
c  The algorithm opens the first (PRIMARY) file to read the date, time and then base every other files
c  in this format. Therefore, the first file, which usually is the A.csv file, must contain all the dates, and times.
c  The first (PRIMARY) file cannot missed any dates, and times, otherwise, any subsequent files which based
c  on this first file will be wrong.
c  How can this be wrong? Say the first file, A.csv, has a start date of 05/01/2021 and end date of 12/31/2021.
c  and if your AAPL.csv file has a start date of 02/01/2001 and a end date of 04/30/2021. If this is the case,
c  then the algorithm in the "void extract_times(APPLICATION* app)" function will fail to find the first
c  starting bar for AAPL.csv. The algorithm examines all the date range from 05/01/2021 to 12/31/2021 and see
c  that the date range does not intersects 02/01/2001 to 04/30/2021, so all the bars in the AAPL will be zero,
c  and the algorithm will ultimately report an error and kick you out of the program.
c
c   CTraderPro datatypes:
c
c   939308		libpff.c	end-of-day stock data
c   939309		libpff.c	intraday stock data
c   939310		libpff.c	end-of-day futures data
c   939311		libpff.c	intraday futures data
c   939329		libpff.c	supplemental files containing option implied volatility, earnings, and/or other kinds of data that are bar-aligned with the primary database.
c   393337		libodb.h	compressed options
c   939338		libodb.h	compressed options index file type.
*/

/*
	Note that if you are not using a make file, you have to exclude
	all other c files from the project or put each c file in each separate project
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#define MAXMKT  300             /* max. security (market) count */
#define MINMKT  1				/* min. security (market) count */
#define MAXBAR  200000			/* max. bar count - was 1570000 */
#define TINYNUM 1.E-26			/* a very small number */

typedef struct {				/* security quotes data structure */
	char    csvname[56];		/* input csv file name, with extension */
	char    symbol[10];			/* ticker symbol */
	char    name[40];			/* security name */
	float   opn[MAXBAR];		/* opening price */
	float   hi[MAXBAR];			/* high price */
	float   lo[MAXBAR];			/* low price */
	float   cls[MAXBAR];		/* last or closing price */
	float   vol[MAXBAR];		/* volume */
	float   sf[MAXBAR];			/* split or adjustment factor */
} MARKET;

typedef struct {				/* application data structure */
	char    dbfn[256];			/* database filespec, no extension */
	char    csvpath[256];		/* csv file path, no name or extension */
	long    ltime_start;		/* time range: from ltm_start */
	long    ltime_stop;			/* time range: to ltm_stop */
	long    ltime_step;			/* time increment in seconds (bar size) */
	long    lday_start;			/* day range: from lday_start */
	long    lday_stop;			/* day range: to lday_stop */
	long    nbar;				/* number of bars */
	long    nmkt;				/* number of securities or markets */
	long    ldt[MAXBAR];		/* dates [0..nbar-1] as YYYYMMDD */
	long    ltm[MAXBAR];		/* times [0..nbar-1] as HHMMSS */
	double  fdttm[MAXBAR];		/* datetimes [0..nbar-1] as YYYYMMDDHHMMSS.0 */
	MARKET  mkt[MAXMKT];		/* securities quotes data [0..nmkt-1] */
} APPLICATION;

/* application-specific functions */
void verify_assumptions(void);
void read_configuration(APPLICATION* app);
void extract_times(APPLICATION* app);
void correct_times(long* lymd, long* lhms, long lstep, char* sym);
void extract_data(APPLICATION* app);
void canonicalize_data(APPLICATION* app);
void write_database(APPLICATION* app);

/* utility (library) functions */
void parsecsv(char* pfld[], long* n, char* pstr);
long julday(long mm, long id, long iyyy);
void caldat(long julian, long* mm, long* id, long* iyyy);
long datetoser(long ldt);
long sertodate(long jd);
long dayofweek(long ldt);
long hmstosec(long hms);
long sectohms(long sec);
long imonth(long idate);
long iday(long idate);
long iyear(long idate);
long findflt(float arr[], long n, float val);
long findlng(long larr[], long n, long lval);
long finddbl(double darr[], long n, double dval);
char* fext(char* fn);
char* fpath(char* fn);
char* struprqq(char* str);
void* bmalloc(size_t nbytes);
void bseek(FILE* fp, long fpos, int whence);
void bread(void* v, size_t n, size_t m, FILE* fp);
void bwrite(void* v, size_t n, size_t m, FILE* fp);
void ftlerr(char* msg);

#ifndef max
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((b)>(a))?(a):(b))
#endif

/*---------------------------------------------------------------------------
c  Entry point for the tsapnd application.
*/

int main(int nargs, char** args) {
	APPLICATION* app;
	/* verify compiler data size and floating point assumptions */
	verify_assumptions();
	/* allocate memory for master application data structure */
	app = (APPLICATION*)bmalloc(sizeof(APPLICATION));
	/* read configuration (control and setup) file */
	read_configuration(app);
	/* initialize date and time series in app->ldt[], app->ltm[], */
	/* and app->ldttm[] */
	extract_times(app);
	/* extract data from specified txt input files into app->mkt[] */
	/* aligning these data with the date and time series */
	extract_data(app);
	/* handle (fill in) missing data points and no-volume bars */
	canonicalize_data(app);
	/* write a type 939309 database and associated symbol file */
	write_database(app);
	/* free memory and terminate */
	free(app);
	fprintf(stdout, "DONE!\n");
	return(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------------
c  Function to verify data size and floating point assumptions.
*/

void verify_assumptions(void) {
	/* Verifies compiler's data size and floating point assumptions */
	long n, m;  float tmp, x;  double xx;
	n = (sizeof(double) == 8) && (sizeof(float) == 4) && (sizeof(long) == 4)
		&& (sizeof(int) == 4) && (sizeof(short) == 2) && (sizeof(char) == 1);
	if (!n) ftlerr("invalid data size assumptions");
	memset(&tmp, 0, sizeof(float));
	x = 1534567.0;  xx = 23451231245959.0;  m = 23451231;  n = 245959;
	if (tmp != 0.0 || (long)x != 1534567 || (1000000.0 * m + n) != xx)
		ftlerr("invalid floating point assumptions");
}

/*---------------------------------------------------------------------------
c  Function to read the tsapnd.cfg data extraction control file.
*/

void read_configuration(APPLICATION* app) {
	/* Reads configuration (setup and control) file */
	FILE* fp;
	long k, lp;
	char buf[128], * p;
	/* open configuration file */
	if ((fp = fopen("tsapnd.cfg", "rt")) == NULL)
		ftlerr("read_configuration: cannot find tsapnd.cfg");
	/* read target database file specification */
	if (fscanf(fp, " OUTPUT_DATABASE=%s", app->dbfn) != 1)		// fscanf() ends at a space or end of line.
		ftlerr("read_configuration: error reading database filespec");
	/* read path to input csv files */
	if (fscanf(fp, " INPUT_CSVPATH=%s", app->csvpath) != 1)
		ftlerr("read_configuration: error reading csv file path");
	/* display what has been read so far */
	fprintf(stdout, "OUTPUT_DATABASE: %s\n", (char*)app->dbfn);
	fprintf(stdout, "INPUT_CSVPATH: %s\n", (char*)app->csvpath);
	fflush(stdout);		// note: the reason fflush(stdout) is used here is because there is no newline character in the input (and the buffer may not be full), plus this is a speedy process, we want to ensure the content is flush to the screen immediately.
	/* check for error in csv file path specification */
	if (app->csvpath[strlen(app->csvpath) - 1] != '/')
		ftlerr("read_configuration: csv file path must end with / \n");
	/* read day range (0=Sun, 1=Mon, ... 6=Sat) */
	if (fscanf(fp, " DAY_RANGE: FROM=%ld TO=%ld",
		&app->lday_start, &app->lday_stop) != 2)
		ftlerr("read_configuration: invalid date range line");
	/* read time range (in HHMMSS form) and step (in seconds) */
	if (fscanf(fp, " TIME_RANGE: FROM=%ld TO=%ld STEP=%ld",
		&app->ltime_start, &app->ltime_stop, &app->ltime_step) != 3)
		ftlerr("read_configuration: invalid time range line");
	/* display day and time ranges */
	fprintf(stdout, "DAY_RANGE: FROM=%ld TO=%ld\n"
		"TIME_RANGE: FROM=%06ld TO=%06ld STEP=%ld SECONDS\n",
		(long)app->lday_start, (long)app->lday_stop,
		(long)app->ltime_start, (long)app->ltime_stop,
		(long)app->ltime_step);
	fflush(stdout);
	if (app->ltime_start > app->ltime_stop)
		ftlerr("read_configuration: time range invalid");
	if (app->lday_start > app->lday_stop)
		ftlerr("read_configuration: day range invalid");
	/* read all ticker symbols and associated input csv file names */
	app->nmkt = 0;
	#if 1==1
		/* Work around for fgets() or fscanf() bug in Debian Etch */
		/* Apparently one cannot mix calls to fscanf and fgets without */
		/* the file position getting messed up; the following two lines */
		/* serve to re-position the file */
		rewind(fp);
		for (lp = 0; lp < 4; lp++) fgets(buf, sizeof(buf), fp);
	#endif
	while (fgets(buf, sizeof(buf), fp)) {
		/* check for end of ticker list (look for list terminator) */
		if (strchr(buf, '*')) break;
		/* check for comment or empty line */
		if (buf[0] == '#') continue;
		if (strlen(buf) < 1) continue;
		/* check for overflow (too many tickers) */
		if (app->nmkt >= MAXMKT)
			ftlerr("read_configuration: MAXMKT exceeded");
		/* extract ticker symbol and associated input file name */
		if (sscanf(buf, "%s %s", app->mkt[app->nmkt].symbol,
			app->mkt[app->nmkt].csvname) != 2) {
			fprintf(stdout, "TICKER_LINE: %s\n", (char*)buf);
			ftlerr("read_configuration: bad ticker line");
		}
		/* check for excessive symbol length */
		if (strlen(app->mkt[app->nmkt].symbol) > 6) {
			fprintf(stdout, "TICKER_SYMBOL: %s\n", (char*)buf);
			ftlerr("read_configuration: ticker longer than 6 chars");
		}
		/* make sure symbol is uppercase */
		struprqq(app->mkt[app->nmkt].symbol);
		/* replace any caret in input file name with a space */
		/* (we use carets to represent spaces in file names in */
		/* order to make scanning easier and less ambiguous) */
		p = app->mkt[app->nmkt].csvname;
		for (k = 0; p[k]; k++) if (p[k] == '^') p[k] = ' ';	/* Allan Notes: It is interesting how he let the k in the for loop and the array subscript to reached null at the end */
		/* use input filename as descriptive name */
		memcpy(app->mkt[app->nmkt].name, app->mkt[app->nmkt].csvname,
			sizeof(char) * 38);
		app->mkt[app->nmkt].name[38] = 0;	// no difference from '\0'
		/* increment securities count */
		app->nmkt++;
	}
	/* close configuration file */
	fclose(fp);
	/* display and verify security (market) count */
	fprintf(stdout, "NMKT: %ld\n", (long)app->nmkt);
	fflush(stdout);
	if (app->nmkt < MINMKT) ftlerr("read_configuration: too few securities");
	/* display tickers and file names for debugging */
	#if 1==0
		{   long imkt;
		fprintf(stdout, "TICKER SYMBOLS AND FILE NAMES:\n");
		for (imkt = 0; imkt < app->nmkt; imkt++) {
			fprintf(stdout, "IMKT=%d SYM=%s CSVNAME=%s\n",
				(int)imkt, (char*)app->mkt[imkt].symbol,
				(char*)app->mkt[imkt].name);
		}
		fflush(stdout);
		exit(EXIT_SUCCESS);   }
	#endif
	fprintf(stdout, "CONFIGURATION FILE HAS BEEN READ\n");
}

/*---------------------------------------------------------------------------
c  Function to make adjustments to the time-stamps on input bars.
*/

void correct_times1(long* lymd, long* lhms, long lstep, char* sym) {
	/* Make any needed corrections to the dates and times associated
	.  with the quotes in the input files.  For example, I like to
	.  convert the Chicago time used by CME/Globex to New York time.
	.  The TradeStation data I have has Pacific time-stamps, and the
	.  code below converts these to New York time-stamps.
	.  Note that you can make different time conversions for
	.  different symbols, and on different dates, something
	.  you may need to do when the times used in the data for
	.  different securities correspond to different time-zones
	.  and when correcting for Daylight Savings Time.
	*/
	long lhh, lmm, lss;
	#if 1==0
		/* convert Pacific time to New York time */
		lhh = (*lhms / 10000) % 100;
		lmm = (*lhms / 100) % 100;
		lss = (*lhms) % 100;

		/*
		Allan Note: basically, in this function he is converting the hours and time from serial format to regular format,
		so you can add the hours, i.e., lhh + 3, or lmm + 60, etc.,
		*/

		//    lhh= lhh + 3;	// add 3 hours for New York time

			// note: this line is only used for the NASDAQ PI Trading data; comment it out if working with other datasets
		if (*lymd < 20120414)
			lhh = lhh - 3;	// subtract 3 hours to correct for PI Trading NASDAQ 100 data


		if (lhh > 23) {
			lhh = lhh - 24;
			*lymd = sertodate(datetoser(*lymd) + 1);
		}

		*lhms = 10000 * lhh + 100 * lmm + lss;	/* Allan Note: the above "lhh= (*lhms / 10000) % 100;" codes disseminated the hours, min, and seconds, this line put them back */
	#endif
}

void correct_times (long *lymd, long *lhms, long lstep, char *sym) {
    /* Make any needed corrections to the dates and times associated
    .  with the quotes in the input files.  For example, I like to
    .  convert the Chicago time used by CME/Globex to New York time.
    .  The TradeStation data I have has Pacific time-stamps, and the
    .  code below converts these to New York time-stamps.
    .  Note that you can make different time conversions for
    .  different symbols, and on different dates, something
    .  you may need to do when the times used in the data for
    .  different securities correspond to different time-zones
    .  and when correcting for Daylight Savings Time.
    */
    long lhh, lmm, lss;
    #if 1==0		// original block (work with New York time)  /* Allan Note: basically, in this function he is converting the hours and time from serial format to regular format, so you can add the hours, i.e., lhh + 3, or lmm + 60, etc., */
        /* convert Pacific time to New York time */
        lhh= (*lhms / 10000) % 100;
        lmm= (*lhms / 100) % 100;
        lss= (*lhms) % 100;        
        lhh= lhh + 3;	// add 3 hours for New York time
        if(lhh > 23) {
            lhh= lhh - 24;
            *lymd= sertodate( datetoser(*lymd) + 1 );
        }
        *lhms= 10000*lhh + 100*lmm + lss;	/* Allan Note: the above "lhh= (*lhms / 10000) % 100;" codes disseminated the hours, min, and seconds, this line put them back */
    #endif

    #if 1==0	// This block works with NASDAQ PI Trading data
        /* convert Pacific time to New York time */
        lhh= (*lhms / 10000) % 100;
        lmm= (*lhms / 100) % 100;
        lss= (*lhms) % 100;        
        if (*lymd < 20120414)
			lhh= lhh - 3;	// subtract 3 hours to correct for PI Trading NASDAQ 100 data
        if(lhh > 23) {
            lhh= lhh - 24;
            *lymd= sertodate( datetoser(*lymd) + 1 );
        }
        *lhms= 10000*lhh + 100*lmm + lss;	/* Allan Note: the above "lhh= (*lhms / 10000) % 100;" codes disseminated the hours, min, and seconds, this line put them back */
    #endif
}

/*---------------------------------------------------------------------------
c  Function to construct the required date and time series.
*/

void extract_times(APPLICATION* app) {
	/* Constructs dates and times from user-provided ranges together */
	/* with the 'primary' csv data file and places the results in */
	/* app->ldt[], app->ltm[], and app->fdttm[] */
	FILE* fp;
	long kstartsec, kstopsec, kincsec, k, i, ntimes, ndates, nbars;
	long ldate, ldate_prev;
	static char fnbuf[256], linbuf[1024];    		// for NASDAQ100 PI Trading data, use 512, originally it was  linbuf[256];	fnbuf = filename buffer
	static long ltimes[86400], ldates[2400];		// Allan note: the 86400 is the 24 hours * 60 min * 60 seconds
	/* find all time slots based strictly on range specification */
	kincsec = app->ltime_step;
	kstartsec = hmstosec(app->ltime_start);
	kstopsec = hmstosec(app->ltime_stop);
	for (ntimes = 0, k = kstartsec; k <= kstopsec; k += kincsec)	// Allan note: note that the increment is not 1, but whatever the increment second is, in this case, 3 seconds.
		ltimes[ntimes++] = sectohms(k);		// Allan note: the ltimes[86400] array has room for 24 hours, but we are only filling 6.5 hours here based on the specs in the config's time line.
		#if 1==0
			/* debugging code */
			printf("ntimes=%d\n", (int)ntimes);
			for (k = 0; k < ntimes; k++)
				printf("%4d %6d\n", (int)k, (int)ltimes[k]);
			exit(EXIT_SUCCESS);
		#endif
	/* open primary (first) csv input file for reading */
	sprintf(fnbuf, "%s%s", (char*)app->csvpath, (char*)app->mkt[0].csvname);
	fprintf(stdout, "PRIMARY_CSV_FILE: %s\n", (char*)fnbuf);
	if ((fp = fopen(fnbuf, "rt")) == NULL)
		ftlerr("extract_times: cannot find primary csv input file");
	/* skip the header (first) line */
	fgets(linbuf, sizeof(linbuf), fp);
	/* extract all dates from quotes in primary csv file */
	ndates = 0;
	ldate_prev = 0;
	while (fgets(linbuf, sizeof(linbuf), fp)) {

		/*
			Allan Note: This block of code go and check the dates, it then picks up all the days in the csv file.
						Because these are intraday files, there are many bars with the same dates on it.  The codes
						checks for this and only picks up the dates that are not the same as the previous bar, and store
						these dates into an array ldate

		*/

		long i, kyyyy, kmm, kdd;
		for (i = 0; i < 10; i++) if (linbuf[i] == '/') linbuf[i] = ' ';
		k = sscanf(linbuf, "%ld %ld %ld", &kmm, &kdd, &kyyyy);
		if (k != 3) {
			fprintf(stdout, "\nLINE: %s\n", linbuf);
			ftlerr("extract_times: bad data line");
		}
		ldate = 10000 * kyyyy + 100 * kmm + kdd;
		/* verify YYYYMMDD date */
		if ((k = iyear(ldate)) < 1982 || k > 2027 ||
			(k = imonth(ldate)) < 1 || k > 12 ||
			(k = iday(ldate)) < 1 || k > 31) {
			fprintf(stdout, "\nLINE: %s\n", linbuf);
			ftlerr("extract_times: bad data line");
		}
		/* filter date for day-of-week range specified by user */
		k = dayofweek(ldate);
		if (k<app->lday_start || k>app->lday_stop) continue;
		/* save date in list */
		if (ldate == ldate_prev) continue;
		ldates[ndates++] = ldate;
		ldate_prev = ldate;
	}
	/* close primary csv file */
	fclose(fp);
	/* display counts of distinct dates and distinct times */
	printf("NDATES=%ld  NTIMES=%ld\n", (long)ndates, (long)ntimes);
	#if 1==0
		/* debugging code */
		for (k = 0; k < ndates; k++) printf("%4d %8d\n", (int)k, (int)ldates[k]);
		exit(EXIT_SUCCESS);
	#endif
	/* construct datetime series using from dates and times */

		/*
			Allan Note: 3 arrays here: date, time, dateTime arrays.  The outer LOOP repeat once per all the time units in a day.
						nbars increase once per every 5 min time unit (in this case). nbar = # of 5 min bars in a day times number of days.
						As the arrays are LOOPed, all the date and time elements in the app-> are filled here.
		*/


	nbars = 0;
	for (k = 0; k < ndates; k++) {
		for (i = 0; i < ntimes; i++) {
			if (nbars >= MAXBAR) ftlerr("extract_times: MAXBAR exceeded");
			app->ldt[nbars] = ldates[k];
			app->ltm[nbars] = ltimes[i];
			app->fdttm[nbars++] = 1000000.0 * ldates[k] + ltimes[i];
		}
	}
	app->nbar = nbars;

	/* display data for debugging */
	#if 1==0
		fprintf(stdout, "NBAR=%ld\n", (long)app->nbar);
		fprintf(stdout, "SYMBOL=%s\n", (char*)app->mkt[0].symbol);
		fprintf(stdout, "FILESPEC=%s\n", (char*)fnbuf);
		fprintf(stdout, "NAME=%s\n", (char*)app->mkt[0].name);
		for (k = 0; k < app->nbar; k++)
			fprintf(stdout, "%7ld %08ld %06ld %20.1lf\n",
				(long)k, (long)app->ldt[k], (long)app->ltm[k],
				(double)app->fdttm[k]);
		fflush(stdout);
		exit(EXIT_SUCCESS);
	#endif
	fprintf(stdout, "DATETIME SERIES HAS BEEN INITIALIZED\n");
}

/*---------------------------------------------------------------------------
c  Function to extract raw CSV data from files generated by
c  TradeStation, and to place the extracted data into
c  the app->mkt[] structure array.
*/

void extract_data(APPLICATION* app) {
	/* Extracts data series from all .csv input files into app->mkt[] */
	/* aligning and placing all data bars based on common datetimes */
	long imkt, ibar, nfld, lhh, lmm, lss, ldate, ltime, k;
	char fnbuf[256], linbuf[128];		// fnbuf = filename buffer
	double fdatetime;
	float fopn, fhi, flo, fcls, fvol;
	FILE* fp;
	/* for each security or market ... */
	for (imkt = 0; imkt < app->nmkt; imkt++) {
		MARKET* mktk = &app->mkt[imkt];
		/* clear data arrays */
		for (ibar = 0; ibar < app->nbar; ibar++) {
			mktk->opn[ibar] = 0.0;
			mktk->hi[ibar] = 0.0;
			mktk->lo[ibar] = 0.0;
			mktk->cls[ibar] = 0.0;
			mktk->vol[ibar] = 0.0;
			mktk->sf[ibar] = 0.0;
		}
		/* open csv data file for reading */
		sprintf(fnbuf, "%s%s", (char*)app->csvpath, (char*)mktk->csvname);	// fnbuf = filename buffer
		fprintf(stdout, "CSV_INPUT: %s\n", (char*)fnbuf);
		fflush(stdout);
		if ((fp = fopen(fnbuf, "rt")) == NULL)
			ftlerr("extract_data: cannot find csv input file");
		/* skip header (first) line */
		fgets(linbuf, sizeof(linbuf), fp);
		/* for each line in csv data file ... */
		while (fgets(linbuf, sizeof(linbuf), fp)) {
			long kyyyy, kmm, kdd, khhmm;
			/* skip any blank (or nearly blank) line */
			if (strlen(linbuf) < 10) continue;
			/* read the csv input data generated by Amibroker */
			nfld = sscanf(linbuf, "%ld/%ld/%ld,%ld,%f,%f,%f,%f,%f",
				&kmm, &kdd, &kyyyy, &khhmm, &fopn, &fhi, &flo,
				&fcls, &fvol);
			if (nfld != 9) {
				fprintf(stdout, "Bad_field_count: %ld\n", (long)nfld);
				goto LERR;	}
			/* convert date field to YYYYMMDD integer and verify */
			ldate = 10000 * kyyyy + 100 * kmm + kdd;
			if ((k = iyear(ldate)) < 1997 || k > 2025 ||
				(k = imonth(ldate)) < 1 || k > 12 ||
				(k = iday(ldate)) < 1 || k > 31) {
				fprintf(stdout, "Bad_date: %ld\n", (long)ldate);
				goto LERR;	}
			/* convert time field to HHMMSS integer and verify */
			lhh = (khhmm / 100) % 100;
			lmm = (khhmm) % 100;
			lss = 0;  // TradeStation time-stamps do not include seconds
			if (lhh < 0 || lhh>23 || lmm < 0 || lmm>59 || lss < 0 || lss>59) {
				fprintf(stdout, "Bad_time: %d:%d:%d\n",
					(int)lhh, (int)lmm, (int)lss);
				goto LERR;	}
			ltime = 10000 * lhh + 100 * lmm + lss;
			/* make any desired corrections to date and time, e.g., */
			/* convert Chicago or Pacific time to New York time */
			correct_times(&ldate, &ltime, app->ltime_step,
				app->mkt[imkt].symbol);
			/* determine where in data structure (at which bar) to */
			/* insert the data based on its date and time */
			fdatetime = 1000000.0 * ldate + ltime;
			ibar = finddbl(app->fdttm, app->nbar, fdatetime);
			if (fdatetime != app->fdttm[ibar]) continue;
			/* convert and insert quote data into data structure */
			mktk->opn[ibar] = fopn;
			mktk->hi[ibar] = fhi;
			mktk->lo[ibar] = flo;
			mktk->cls[ibar] = fcls;
			//  mktk->vol[ibar]= (fupvol + fdnvol);
			mktk->vol[ibar] = (fvol);
			mktk->sf[ibar] = 1.0;
			/* code for debugging */
			#if 1==0

			// Note that you cannot use the "==" to compare 2 char arrays,
			// you have to use strcmp.  strcmp returns 0 if equal,
			// Otherwise, the return value is positive if s1 is greater than s2 or negative is s1 in less than s2.

			if ((!strcmp((char*)app->mkt[imkt].symbol, "ABX.TO"))) {  // Note that SLF.TO is case sensitive.
				fprintf(out, "%6d %6s %8d %06d %10.2f %10.2f "   // the file stream used to be stdout
					"%10.2f %10.2f %12.1f %6.2f\n",
					(int)ibar, (char*)app->mkt[imkt].symbol,
					(int)app->ldt[ibar], (int)app->ltm[ibar],
					(float)app->mkt[imkt].opn[ibar],
					(float)app->mkt[imkt].hi[ibar],
					(float)app->mkt[imkt].lo[ibar],
					(float)app->mkt[imkt].cls[ibar],
					(float)app->mkt[imkt].vol[ibar],
					(float)app->mkt[imkt].sf[ibar]); // the file stream used to be stdout
				fflush(out);
			}
			#endif
		}	/* next line in txt data file */
			/* close input csv data file */
		fclose(fp);

	}				/* next market or security */
	/* return normally */
	return;
	/* handle error */
LERR:;
	fprintf(stdout, "  File= %s\n", (char*)fnbuf);
	fprintf(stdout, "  Symbol= %s\n", (char*)app->mkt[imkt].symbol);
	fprintf(stdout, "  Name= %s\n", (char*)app->mkt[imkt].name);
	fprintf(stdout, "  Line_Contents= %s\n", (char*)linbuf);
	fprintf(stdout, "  Field_Count= %d\n", (int)nfld);
	ftlerr("extract_data: bad input data line");
}

/*---------------------------------------------------------------------------
c  Function to canonicalize the extracted data by filling in missing
c  data points and adjusting volume figures.
*/

void canonicalize_data(APPLICATION* app) {
	/* Handles and adjusts missing and no-volume data points */
	/* to be consistent with our conventions for such data */
	long ibar, imkt, kfirst;
	float p;
	/* for each security or market ... */
	for (imkt = 0; imkt < app->nmkt; imkt++) {
		MARKET* amk = &app->mkt[imkt];
		/* for each bar ... */
		kfirst = -1;
		for (ibar = 0; ibar < app->nbar; ibar++) {
			/* if bar has no data (close is zero), then .. */
			if (amk->cls[ibar] < TINYNUM) {
				/* Allan notes: this block is used to fill in the missing data anywhere from beginning to end */
				/* if there is a previous bar, then .. */
				if (ibar > 0) {
					/* fill in prices with close of previous bar */
					amk->opn[ibar] = (p = amk->cls[ibar - 1]);
					amk->hi[ibar] = p;
					amk->lo[ibar] = p;
					amk->cls[ibar] = p;
					/* fill in split factor from previous bar */
					amk->sf[ibar] = amk->sf[ibar - 1];
				}
				/* set volume to hard zero to indicate absence of data */
				amk->vol[ibar] = 0.0;
			}
			/* if bar has data, then .. */
			else {
				/* zero volume should be represented by a soft zero */
				if (amk->vol[ibar] < TINYNUM) amk->vol[ibar] = TINYNUM;
				/* note location of first bar that contains data */
				if (kfirst < 0) kfirst = ibar;
			}
		}
		if (kfirst < 0) ftlerr("canonicalize_data: no valid data");		// original line

		/*
			Allan note: this block is used to fill in those few bars in the beginning where there is no data.
			Here is the scenario, if the first valid bar is the 2nd bar, then the first bar gets filled with the close of the second bar.
			if the first valid bar is the 3rd bar, then the IF statement in the first LOOP (the for LOOP) got executed for the 2nd bar, where all the value got
			filled with the first bar, which are all zeros.  Now this loop here filled all the values using the the close of the first
			valid bar (kfirst = ibar), which is the third bar, for bar 1 and 2
		*/

		/* for each bar, up to the first that contains data, ... */
		for (ibar = 0; ibar < kfirst; ibar++) {
			/* fill prices with close of first bar having valid data */
			amk->opn[ibar] = (p = amk->cls[kfirst]);
			amk->hi[ibar] = p;
			amk->lo[ibar] = p;
			amk->cls[ibar] = p;
			/* set volume to hard zero to mark absence of valid data */
			amk->vol[ibar] = 0.0;
			/* fill in split factor from first bar having valid data */
			amk->sf[ibar] = amk->sf[kfirst];
		}
	}
}

/*---------------------------------------------------------------------------
c  Function to write the market data in app->mkt[] to a type 939309
c  intraday database file compatible with C-Trader Professional.
*/

void write_database(APPLICATION* app) {
	/* Writes a complete type 939309 intraday portfolio database file */
	char fnbuf[256], symbuf[64];	// fnbuf = filename buffer
	long k, ibar, imkt;
	float tmp;
	FILE* fp;
	/* open data file for binary writing */
	sprintf(fnbuf, "%s.dat", (char*)app->dbfn);		// fnbuf = filename buffer
	if ((fp = fopen(fnbuf, "wb")) == NULL)
		ftlerr("write_database: cannot open database for writing");
	/* write file header */
	k = 939309;	/* file type for standard intraday O,H,L,C,V,SF data */
	bwrite(&k, sizeof(long), 1, fp);		/* file type identifier */		/* first line where this is read in Tropic app: libpff.c  "PORTFOLIODATA* pff_open (char fn[], long mode, long nbuf) {} line 229"*/  /* set breakpoints: trops.cpp, line 528, pf.pff=pff_open(fn, mode, PFFBUFSZ); libpff.c:  PORTFOLIODATA* pff_open (char fn[], long mode, long nbuf), at line 229 where rc=fread(&fileid,4,1,pff->dfil); */
	bwrite(&app->nbar, sizeof(long), 1, fp);	/* number of bars */
	bwrite(&app->nmkt, sizeof(long), 1, fp);	/* number of securities */
	/* write common (across securities) dates */
	for (ibar = 0; ibar < app->nbar; ibar++) {
		tmp = (float)(app->ldt[ibar] - 19000000);	/* need YYYMMDD.0 form */
		bwrite(&tmp, sizeof(float), 1, fp);
	}
	/* write common (across securities) times */
	for (ibar = 0; ibar < app->nbar; ibar++) {
		tmp = (float)(app->ltm[ibar]);		/* need HHMMSS.0 form */
		bwrite(&tmp, sizeof(float), 1, fp);
	}
	/* for each security or market ... */
	for (imkt = 0; imkt < app->nmkt; imkt++) {
		/* write data series */
		bwrite(app->mkt[imkt].opn, sizeof(float), app->nbar, fp);
		bwrite(app->mkt[imkt].hi, sizeof(float), app->nbar, fp);
		bwrite(app->mkt[imkt].lo, sizeof(float), app->nbar, fp);
		bwrite(app->mkt[imkt].cls, sizeof(float), app->nbar, fp);
		bwrite(app->mkt[imkt].vol, sizeof(float), app->nbar, fp);
		bwrite(app->mkt[imkt].sf, sizeof(float), app->nbar, fp);
		/* write block terminator */
		bwrite(&k, sizeof(long), 1, fp);
	}
	/* close data file */
	fclose(fp);
	/* open symbol file for binary writing */
	sprintf(fnbuf, "%s.txt", (char*)app->dbfn);
	if ((fp = fopen(fnbuf, "wb")) == NULL)
		ftlerr("write_database: cannot open symbol output file");
	/* for each security or market ... */
	for (imkt = 0; imkt < app->nmkt; imkt++) {
		/* build string containing symbol and name */
		memset(symbuf, ' ', sizeof(char) * 50);		// Allan Note: set the first 50 slots of symbuf to be a space ' '.
		k = strlen(app->mkt[imkt].symbol);
		if (k > 8) ftlerr("write_database: ticker symbol too long");
		memcpy(symbuf, app->mkt[imkt].symbol, sizeof(char) * k);		// Allan Note: copy the symbol which is less than 8 character long to the memory slot symbuf.
		k = strlen(app->mkt[imkt].name);	// Allan Note: the name description cannot be longer than 38 characters.
		if (k > 38) k = 38;

		/*
			Allan Note: the symbuf+10 is to advance the pointer 10 spaces to get to the name description,
			compile the program and open the *.txt file and you will see how the symbols and the names lined up
			in the columns (also enable the "show spaces/tabs" option in UEStudio), and you will see that
			the description begins at column 11, and the symbol is 8 column	wide.
		*/

		memcpy(symbuf + 10, app->mkt[imkt].name, sizeof(char) * k);

		/*
			Allan Note: note that if you don't include the char(13) carriage return, then the end of the line will have some garbage (text characters) in it.
									if you don't include the char(10) line feed, this whole text file will become a binary junk when you open the text file in a text editor.
		*/

		symbuf[50] = (char)13;			// Allan Note: char(13) is carriage return and char(10) is line feed
		symbuf[51] = (char)10;			// Allan Note: char(10) is a line feed
		/* write it to symbol file */
		bwrite(symbuf, sizeof(char), 52, fp);
	}
	/* close symbol file */
	fclose(fp);
}

/*---------------------------------------------------------------------------
c  General utility functions.
*/

void parsecsv(char* pfld[], long* n, char* pstr) {
	/* extracts fields from a string containing a csv record */
	*n = 1;
	pfld[0] = pstr;
	while (*pstr) {
		if (*pstr == ',') {
			*pstr = 0;
			pfld[*n] = pstr + 1;
			++(*n);
		}
		++pstr;
	}
}

long monthtolong(char* mon) {
	/* returns integer corresponding to month abbreviation */
	char* monsym[12] = { "JAN","FEB","MAR","APR","MAY","JUN",
			"JUL","AUG","SEP","OCT","NOV","DEC" };
	long i;
	for (i = 0; i < 12; i++)
		if (strcmp(monsym[i], mon) == 0) return(i + 1);
	return(-1);
}

long julday(long mm, long id, long iyyy) {
	/* returns Julian day number given calendar date */
#define IGREG (15+31L*(10+12L*1582))
	long jul, ja, jy = iyyy, jm;
	if (jy == 0) ftlerr("julday: there is no year zero.");
	if (jy < 0) ++jy;
	if (mm > 2) {
		jm = mm + 1;
	}
	else {
		--jy;
		jm = mm + 13;
	}
	jul = (long)(floor(365.25 * jy) + floor(30.6001 * jm) + id + 1720995);
	if (id + 31L * (mm + 12L * iyyy) >= IGREG) {
		ja = (long)(0.01 * jy);
		jul += 2 - ja + (long)(0.25 * ja);
	}
	return jul;
#undef IGREG
}

void caldat(long julian, long* mm, long* id, long* iyyy) {
	/* calculates calendar date given Julian day number */
#define IGREG 2299161
	long ja, jalpha, jb, jc, jd, je;
	if (julian >= IGREG) {
		jalpha = (long)(((float)(julian - 1867216) - 0.25) / 36524.25);
		ja = julian + 1 + jalpha - (long)(0.25 * jalpha);
	}
	else
		ja = julian;
	jb = ja + 1524;
	jc = (long)(6680.0 + ((float)(jb - 2439870) - 122.1) / 365.25);
	jd = (long)(365 * jc + (0.25 * jc));
	je = (long)((jb - jd) / 30.6001);
	*id = jb - jd - (long)(30.6001 * je);
	*mm = je - 1;
	if (*mm > 12) *mm -= 12;
	*iyyy = jc - 4715;
	if (*mm > 2) --(*iyyy);
	if (*iyyy <= 0) --(*iyyy);
#undef IGREG
}

long datetoser(long ldt) {
	/* converts YYYYMMDD date to serial (days since Jan 1, 1900) */
	return(julday((ldt / 100) % 100, ldt % 100, ldt / 10000) - 2415021);
}

long sertodate(long jd) {
	/* converts serial date (days since Jan 1, 1900) to YYYYMMDD */
	long iyyyy, mm, idd;
	caldat(jd + 2415021, &mm, &idd, &iyyyy);
	return(10000 * iyyyy + 100 * mm + idd);
}

long dayofweek(long ldt) {
	/* returns day of week (0=Sun, 1=Mon, ... 6=Sat) */
	/* given YYYYMMDD date */
	return((julday((ldt / 100) % 100, ldt % 100, ldt / 10000) + 1) % 7);
}

long hmstosec(long ltm) {
	/* converts 24-hour HHMMSS time to seconds since midnight */
	return(3600 * (ltm / 10000) + 60 * ((ltm / 100) % 100) + (ltm % 100));
}

long sectohms(long lsec) {
	/* converts seconds since midnight (0..86399) to HHMMSS time */
	return(10000 * (lsec / 3600) + 100 * ((lsec / 60) % 60) + (lsec % 60));
}

long imonth(long idate) {
	/* returns month 1..12 given a YYYYMMDD date */
	return((idate / 100) % 100);
}

long iday(long idate) {
	/* returns day 1..31 given a YYYYMMDD date */
	return(idate % 100);
}

long iyear(long idate) {
	/* returns year as YYYY given a YYYYMMDD date */
	return(idate / 10000);
}

long findflt(float arr[], long n, float val) {
	/* Finds k such that arr[k] <= val < arr[k+1], if possible */
	/* Assumes that arr[n-1] >= arr[n-2] >= ... >= arr[0] */
	/* In case of ties, returned index points to last tied element */
	long ia, ib, k;
	if (val < arr[ia = 0]) return(ia);
	if (val >= arr[ib = n - 1]) return(ib);
	while (ib - ia > 1) {
		if (arr[k = (ia + ib) >> 1] > val) ib = k;
		else ia = k;
	}
	if (val == arr[ib]) return(ib);
	return(ia);
}

long findlng(long larr[], long n, long lval) {
	/* Finds k such that larr[k] <= lval < larr[k+1], if possible */
	/* Assumes that larr[n-1] >= larr[n-2] >= ... >= larr[0] */
	/* In case of ties, returned index points to last tied element */
	long ia, ib, k;
	if (lval < larr[ia = 0]) return(ia);
	if (lval >= larr[ib = n - 1]) return(ib);
	while (ib - ia > 1) {
		if (larr[k = (ia + ib) >> 1] > lval) ib = k;
		else ia = k;
	}
	if (lval == larr[ib]) return(ib);
	return(ia);
}


/*
			   Allan Note: This block of code is doing a sequential search for the bar that would be used to place the data into the day/time slot.
									   It starts by looking at both extremes first, the beginning (0) and the end (n-1).
									   Then it does a bitwise integer shift to cut the range to half, and compare it to the search date to see where the search day
									   sits in relation to the mid-point of the array.  The search day can either fall in the first half or the second half, and the code
									   would re-set either the ia (beginning range) or the ib (ending range), then the while LOOP repeats until the range narrowed
									   enough to fall out of the while LOOP.

									   In the beginning, ia is set to 0, ib is set to n-1.

*/
long finddbl(double darr[], long n, double dval) {
	/* Finds k such that darr[k] <= dval < darr[k+1], if possible */
	/* Assumes that darr[n-1] >= darr[n-2] >= ... >= darr[0] */
	/* In case of ties, returned index points to last tied element */
	long ia, ib, k;
	if (dval < darr[ia = 0]) return(ia);
	if (dval >= darr[ib = n - 1]) return(ib);
	while (ib - ia > 1) {
		if (darr[k = (ia + ib) >> 1] > dval) ib = k;
		else ia = k;
	}
	if (dval == darr[ib]) return(ib);
	return(ia);
}

//char* fext (char *fn) {
//        /* returns pointer to file extension (including period) */
//        /* or to an empty string if no extension is found */
//        int i, k;
//        for(i=0, k= -1; fn[i]; i++) if(fn[i]=='.') k=i;
//        return((k<0)?(""):(&fn[k]));
//}
//
//char* fpath (char *fn) {
//        /* returns pointer to file path (ending with / or \) */
//        /* or to an empty string if no path is found */
//        static char mypath[256];
//        int i, k;
//        for(i=0, k= -1; fn[i]; i++) if(fn[i]=='/' || fn[i]=='\\') k=i;
//        if(k<0) return("");
//        mypath[k+1]=0;
//        return(memcpy(mypath,fn,sizeof(char)*(k+1)));
//}

long fexists(char* fn) {
	/* returns 1 if file exists and can be read, 0 otherwise */
	FILE* fp;
	if ((fp = fopen(fn, "rb")) == NULL) return(0);
	fclose(fp);
	return(1);
}

char* struprqq(char* str) {
	/* converts string to uppercase */
	int i;
	for (i = 0; str[i]; i++) str[i] = toupper(str[i]);
	return(str);
}

void* bmalloc(size_t nbytes) {
	/* checked memory allocation */
	void* ptr;
	if ((ptr = malloc(nbytes)) == NULL)
		ftlerr("bmalloc: insufficient memory");
	return(ptr);
}

void bseek(FILE* fp, long fpos, int whence) {
	/* checked file seek */
	if (fseek(fp, fpos, whence) || ferror(fp))
		ftlerr("bseek: file seek error");
}

void bread(void* v, size_t n, size_t m, FILE* fp) {
	/* checked file read */
	if (fread(v, n, m, fp) != m || ferror(fp))
		ftlerr("bread: file read error");
}

void bwrite(void* v, size_t n, size_t m, FILE* fp) {
	/* checked file write */
	if (fwrite(v, n, m, fp) != m || ferror(fp))
		ftlerr("bwrite: file write error");
}

void ftlerr(char* msg) {
	/* handles fatal errors */
	fprintf(stdout, "\nERROR: %s\n", (char*)msg);
	exit(EXIT_FAILURE);
}


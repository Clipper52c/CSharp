
/* Tests of faster replacements for NRC functions:
.    julday(), caldat(), hunt(), locate()
.  Copyright (C) 1999. All rights reserved.
.  Jeffrey Owen Katz, Ph.D.
*/

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <time.h>

void ftlerr (char *msg) {
        printf("%s\n",msg);
        exit(0);
}

long zapped;

#define testk(xx) \
        if((xx)<1 || (xx)>n) { \
                printf("Big Error: k=%d\n", (xx)); \
                exit(0); \
        } \

int locate2 (float d[], int n, float x) {
    /* Returns k such that d[k] <= x < d[k+1]
    .    If returned k == 0, then x < d[1]
    .    If returned k == n, then x >= d[n]
    .  Function uses a bisection search and assumes
    .  that d[1] < d[2] < ... < d[n].  Arrays are
    .  assumed to begin at [1], not at [0].
    */
    int ia, ib, k;
    if (x < d[ia = 1]) return 0;
    ib = n;
    while (ib - ia > 1) {
	if (x < d[k = (ia + ib) >> 1]) ib = k;
	else ia = k;
    }
    if (x >= d[ib]) return ib;
    return ia;
}

int hunt2 (float d[], int n, float x, int k) {
    /* Returns k such that d[k] <= x < d[k+1]
    .    If returned k == 0, then x < d[1]
    .    If returned k == n, then x >= d[n]
    .  Function assumes that d[1] < d[2] < ... < d[n] and
    .  that the previous value of k (or a guess as to the
    .  correct value) be provided.  Arrays are assumed to
    .  begin at [1], not at [0].
    */
    int stride, ia, ib;
    if (x < d[1]) return 0;
    if (x >= d[n]) return n;
    if (k < 1) k = 1;
    else if (k >= n) k = n - 1;
    if (x == d[k+1]) return k + 1;
    stride = 1;
    if (x < d[k]) {
	do {
	    if ((k -= stride) < 1) {
		ia = 1;
		ib = k + stride;
		goto BIS;
	    }
	    stride += stride;
	} while (x < d[k]);
	if (x == d[k]) return k;
	ib = (ia = k) + (stride >> 1);
    } else {
	do {
	    if ((k += stride) > n) {
		ia = k - stride;
		ib = n;
		goto BIS;
	    }
	stride += stride;
    } while (x > d[k]);
	if (x == d[k]) return k;
	ia = (ib = k) - (stride >> 1);
    }
    BIS:
    while (ib - ia > 1) {
	if (x < d[k = (ia + ib) >> 1]) ib = k;
	else ia = k;
    }
    return ia;
}

void caldat(long julian, long *mm, long *id, long *iyyy)
{
        /* convert Julian date to MM, DD, YYYY form date */
        #define IGREG 2299161
        long ja,jalpha,jb,jc,jd,je;
        if (julian >= IGREG) {
            jalpha=(long)(((float) (julian-1867216)-0.25)/36524.25);
            ja=julian+1+jalpha-(long) (0.25*jalpha);
        } else ja=julian;
        jb=ja+1524;
        jc=(long)(6680.0+((float) (jb-2439870)-122.1)/365.25);
        jd=(long)(365*jc+(0.25*jc));
        je=(long)((jb-jd)/30.6001);
        *id=jb-jd-(long) (30.6001*je);
        *mm=je-1;
        if (*mm > 12) *mm -= 12;
        *iyyy=jc-4715;
        if (*mm > 2) --(*iyyy);
        if (*iyyy <= 0) --(*iyyy);
        #undef IGREG
}

long julday(int mm, int id, int iyyy)
{
        /* convert MM, DD, YYYY form date to Julian date */
        long jul;
        int ja,jy=iyyy,jm;
        #define IGREG (15+31L*(10+12L*1582))
        if (jy == 0) ftlerr("julday: there is no year zero.");
        if (jy < 0) ++jy;
        if (mm > 2) {   jm=mm+1; } else {  --jy;  jm=mm+13;  }
        jul = (long) (floor(365.25*jy)+floor(30.6001*jm)+id+1720995);
        if (id+31L*(mm+12L*iyyy) >= IGREG) {
                ja=(int)(0.01*jy);
                jul += 2-ja+(int) (0.25*ja);
        }
        return jul;
        #undef IGREG
}

void flmoon(int n, int nph, long *jd, float *frac)
{
        /* find Julian date of specific phase of the moon */
        /* nph: 0=new, 1=first qtr, 2=full, 3=last qtr */
        int i;
        float am,as,c,t,t2,xtra;
        #define RAD (3.14159265/180.0)
        c=n+nph/4.0;
        t=c/1236.85;
        t2=t*t;
        as=359.2242+29.105356*c;
        am=306.0253+385.816918*c+0.010730*t2;
        *jd=2415020+28L*n+7L*nph;
        xtra=0.75933+1.53058868*c+((1.178e-4)-(1.55e-7)*t)*t2;
        if (nph == 0 || nph == 2)
                xtra += (0.1734-3.93e-4*t)*sin(RAD*as)-0.4068*sin(RAD*am);
        else if (nph == 1 || nph == 3)
                xtra += (0.1721-4.0e-4*t)*sin(RAD*as)-0.6280*sin(RAD*am);
        else ftlerr("nph is unknown in flmoon");
        i=(int)(xtra >= 0.0 ? floor(xtra) : ceil(xtra-1.0));
        *jd += i;
        *frac=xtra-i;
        #undef RAD
}

void caldat2 (long julian, long *mm, long *id, long *iyyy)
{
        /* Returns, using pointer variables, the calendar date
           (month, day and 4-digit year) given a Julian day number.
           Accurate for dates after the year 1584.  This routine
           is the mathematical inverse of the julday2(..) routine.
        */

        long l, n;
        l = julian + 68569;
        n = (4 * l) / 146097;
        l -= (146097 * n + 3) / 4;
        *iyyy = (4000 * (l + 1)) / 1461001;
        l = l - (1461 * *iyyy) / 4 + 31;
        *mm = (80 * l) / 2447;
        *id = l - (2447 * *mm) / 80;
        l = *mm / 11;
        *mm = *mm + 2 - 12 * l;
        *iyyy = 100 * (n - 49) + *iyyy + l;
}

/*  Those below are the final and best date conversion routines */

long juldayx (long mm, long id, long iyyy) {
    /*  Returns the Julian day number given a calendar date
    .   (month, day and 4-digit year).  Accurate for dates
    .   after Jan 1, 1584.
    .   mm    - month, 1..12
    .   id    - day, 1..31
    .   iyyy  - year, 1584..
    */
    long mc, iyc, jd;
    mc = (18 - mm) >> 4;
    iyc = (iyyy - mc) / 100;
    jd = (36525 * (iyyy - mc)) / 100
	+ (306001 * (mm + 1 + 12 * mc)) / 10000
	+ id + (iyc >> 2) - iyc + 1720997;
    return jd;
}

void caldatx (long julian, long *mm, long *id, long *iyyy) {
    /* Returns (via pointer variables) the calendar date
    .  (month, day and 4-digit year) given a Julian day number.
    .  Accurate for dates after the year 1584.  This routine
    .  is the mathematical inverse of the julday routine.
    */
    long l, n;
    l = julian + 68569;
    n = (l << 2) / 146097;
    l = l - ((146097 * n + 3) >> 2);
    *iyyy = (4000 * (l + 1)) / 1461001;
    l = l - ((1461 * *iyyy) >> 2) + 31;
    *mm = (80 * l) / 2447;
    *id = l - (2447 * *mm) / 80;
    l = *mm / 11;
    *mm = *mm + 2 - 12 * l;
    *iyyy = 100 * (n - 49) + *iyyy + l;
}

main (int argc, char **args) {

    #define TEST_DATES

    #ifdef TEST_DATES
	long base, i, dd, mm, yyyy, ddx, mmx, yyyyx, jd, jdx;
        static clock_t start_time, stop_time;
        getch();
	base = julday (1, 1, 1584);
        start_time = clock();
	for (i = base; i < base+220000; i++) {
		caldat(i, &mm, &dd, &yyyy);
		caldatx(i, &mmx, &ddx, &yyyyx);
		jd=julday(mm,dd,yyyy);
		jdx=juldayx(mm,dd,yyyy);
		if(i%200L==0 && jd== -1)
			printf("%3ld %3ld  %3ld %3ld  %5ld %5ld  %8ld %8ld\n",
				mm, mmx, dd, ddx, yyyy, yyyyx, jd, jdx);
		if(mm!=mmx || yyyy!=yyyyx || dd!=ddx || jd!=jdx || jd!=i) {
                        printf("***** Error! *****\n");
                        getch();
                        exit(0);
                }
	}
        stop_time = clock();
        printf("Time = %.2f\n", (float)(stop_time - start_time) / CLK_TCK);
        getch();
    #endif

    #ifdef TEST_INDEX
        static float x, d[680000];
        static int n, k;  long i;
        static clock_t start_time, stop_time;
        n=677000;
        for(k=1; k<=n; k++) d[k]=k;
        zapped=0;
        printf("Starting\n");
        start_time = clock();
        for(i=1; i<200000; i++) {
                x = (rand()*(100.0+d[n]-d[1]))/RAND_MAX-50.0+d[1];
                x = floor (x);
                k = hunt2 (d, n, x, k);
/*              k = locate2 (d, n, x);  */
                if (k == 0 && x < d[1]) continue;
                if (k == n && x >= d[n]) continue;
                if (k > 0 && k < n && d[k] == x) continue;
                printf("Bad data: %f %f\n", d[k], x);
                break;
        }
        stop_time = clock();
        printf("Time = %.2f\n", (float)(stop_time - start_time) / CLK_TCK);
        printf("op count = %ld\n", zapped/120000L);
        getch();
    #endif
}



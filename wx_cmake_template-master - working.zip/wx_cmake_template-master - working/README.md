# wx_cmake_template

A template for multiplatform WxWidgets projects using CMake

For details see the blog post: https://justdevtutorials.medium.com/wxwidgets-cmake-multiplatform-superbuild-4ea86c4e6eda

Also check out the video tutorial showcasing installation on Linux, Windows and Mac OS X: https://www.youtube.com/watch?v=MfuBS9n5_aY&t=4s

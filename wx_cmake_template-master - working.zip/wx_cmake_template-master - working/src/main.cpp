#include<wx/wx.h>

class myapp: public wxApp{

    bool virtual OnInit();

};

class myframe : public wxFrame{

public:
    myframe(const wxString &title, wxPoint pos, wxSize size);

};

wxIMPLEMENT_APP(myapp);

myframe::myframe(const wxString &title, wxPoint pos, wxSize size):wxFrame(nullptr, wxID_ANY, title, pos, size){

    // I actually typed this all out from scratch without making a mistake.
    wxPanel* panel1 = new wxPanel(this, -1, wxDefaultPosition, wxSize (200,100));
    wxPanel* panel2 = new wxPanel(this, -1, wxDefaultPosition, wxSize (200,100));
    wxPanel* panel3 = new wxPanel(this, -1, wxDefaultPosition, wxSize (200,100));

    panel1->SetBackgroundColour(wxColor(204,255,204));
    panel2->SetBackgroundColour(wxColor(255,255,204));
    panel3->SetBackgroundColour(wxColor(229,204,255));

    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizerTop = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizerBottom = new wxBoxSizer(wxHORIZONTAL);

    sizerTop->Add(panel1, 1, wxEXPAND|wxLEFT|wxTOP|wxRIGHT, 10);
    sizerBottom->Add(panel2, 1, wxEXPAND|wxLEFT|wxBOTTOM, 10);
    sizerBottom->Add(panel3, 1, wxEXPAND|wxLEFT|wxBOTTOM|wxRIGHT, 10);

    mainSizer->Add(sizerTop, 1, wxEXPAND);
    mainSizer->Add(sizerBottom, 1, wxEXPAND|wxTOP, 10);

    this->SetSizer(mainSizer);
};

bool myapp::OnInit(){

    myframe* frame = new myframe("TDAM PowerPoint Automation", wxDefaultPosition, wxDefaultSize);
    frame->Show(true);
    return true;

};
